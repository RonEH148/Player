package com.brouken.player;

import android.content.Context;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.preference.PreferenceManager;

import java.io.ByteArrayOutputStream;

/**
 * "Dolby Vision → HDR10+": for screens without a Dolby Vision decoder but with HDR10+
 * (Galaxy Tab S9 …). Dolby Vision profile 7/8 then plays as its HDR10 base layer on the HEVC
 * decoder, with one static brightness value for the whole film. The Dolby Vision metadata has
 * per-scene brightness (level 1: min / max / average, in PQ). This turns it into HDR10+ dynamic
 * metadata (SMPTE ST 2094-40, profile A) and adds it to every frame as an HEVC SEI message, the way
 * HDR10+ discs and streams carry it. The decoder passes it on to the display, which can then
 * tone-map scene by scene. The picture data itself is not touched.
 *
 * The HDR10+ percentiles are estimated from min/average/max (Dolby Vision has no histogram).
 */
final class DvHdr10Plus {

    private DvHdr10Plus() {}

    static final String KEY = "dvToHdr10Plus";

    /** Read at every player start. */
    static volatile boolean enabled;
    /** This device has a Dolby Vision decoder (then DV plays as DV and nothing is added). */
    static volatile boolean hasDvDecoder;
    /** Main10 HDR10+ listed by the HEVC decoder. */
    static volatile boolean decoderListsHdr10Plus;

    static int added, existing, noL1, decoderSeen;
    static int lastMaxNits, lastAvgNits, lastMinNits10;

    static void refresh(Context c) {
        try {
            enabled = PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY, false);
        } catch (Throwable t) {
            enabled = false;
        }
        if (enabled) probeDecoders();
        reset();
    }

    static void reset() {
        added = existing = noL1 = decoderSeen = 0;
        trackWanted = false;
        lastMaxNits = lastAvgNits = lastMinNits10 = 0;
        haveL1 = false;
    }

    private static boolean probed;

    private static void probeDecoders() {
        if (probed) return;
        probed = true;
        try {
            for (MediaCodecInfo i : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
                if (i.isEncoder()) continue;
                for (String t : i.getSupportedTypes()) {
                    if ("video/dolby-vision".equalsIgnoreCase(t)) hasDvDecoder = true;
                    if ("video/hevc".equalsIgnoreCase(t)) {
                        try {
                            for (MediaCodecInfo.CodecProfileLevel pl : i.getCapabilitiesForType(t).profileLevels) {
                                if (pl.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10Plus) {
                                    decoderListsHdr10Plus = true;
                                }
                            }
                        } catch (Throwable ignored) { }
                    }
                }
            }
        } catch (Throwable ignored) { }
    }

    /**
     * Add HDR10+ to this track? Only when the video ends up on the plain HEVC decoder:
     * no Dolby Vision decoder on the device, or profile 7 shown as its HDR10 base layer.
     */
    static boolean wanted(androidx.media3.common.Format f, boolean hevcBaseLayer, boolean convertingToP8) {
        if (!enabled || f == null) return false;
        if (!androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType) && !hevcBaseLayer) return false;
        String c = f.codecs == null ? "" : f.codecs.toLowerCase(java.util.Locale.US);
        // profile 5 has no HDR10 base layer (IPT colours): HDR10+ wouldn't make sense
        if (c.startsWith("dvhe.05") || c.startsWith("dvh1.05") || c.startsWith("dav1") || c.startsWith("dvav")) return false;
        // HLG (8.4) / SDR (8.2) base layer: HDR10+ is for PQ only
        if (f.colorInfo != null && f.colorInfo.colorTransfer != androidx.media3.common.Format.NO_VALUE
                && f.colorInfo.colorTransfer != androidx.media3.common.C.COLOR_TRANSFER_ST2084) return false;
        if (hevcBaseLayer && !convertingToP8) return true;   // already relabelled as HEVC
        return !hasDvDecoder;
    }

    // ------------------------------------------------------------------ per access unit

    private static boolean haveL1;
    private static int curMin, curMax, curAvg;

    /**
     * One Annex-B access unit. Returns a new unit with an HDR10+ SEI before the first picture
     * slice, or null to keep it as it is (no metadata found, or HDR10+ already there).
     */
    static byte[] inject(byte[] d, int off, int len) {
        int end = off + len;
        int firstVcl = -1, firstVclHeader = -1;
        boolean hasPlus = false;
        int i = off;
        int[] l1 = null;
        while (i + 3 <= end) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) {
                int sc = i > off && d[i - 1] == 0 ? i - 1 : i;
                int p = i + 3;
                if (p + 1 >= end) break;
                int stop = nextStart(d, p, end);
                int type = (d[p] >> 1) & 0x3F;
                if (type < 32 && firstVcl < 0) { firstVcl = sc; firstVclHeader = p; }
                else if (type == 39 && isHdr10PlusSei(d, p, stop)) hasPlus = true;
                else if (type == 62 && l1 == null) l1 = level1(d, p, stop - p);
                i = stop;
            } else {
                i++;
            }
        }
        if (l1 != null) {
            haveL1 = true;
            curMin = l1[0]; curMax = l1[1]; curAvg = l1[2];
        }
        if (hasPlus) { existing++; return null; }
        if (firstVcl < 0) return null;
        if (!haveL1) { noL1++; return null; }
        int tidPlus1 = d[firstVclHeader + 1] & 7;
        if (tidPlus1 == 0) tidPlus1 = 1;
        byte[] sei = seiNal(curMin, curMax, curAvg, tidPlus1);
        byte[] out = new byte[len + sei.length];
        int head = firstVcl - off;
        System.arraycopy(d, off, out, 0, head);
        System.arraycopy(sei, 0, out, head, sei.length);
        System.arraycopy(d, firstVcl, out, head + sei.length, len - head);
        added++;
        return out;
    }

    private static int nextStart(byte[] d, int from, int end) {
        for (int i = from; i + 3 <= end; i++) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) return i > from && d[i - 1] == 0 ? i - 1 : i;
        }
        return end;
    }

    /** Prefix SEI with user_data_registered_itu_t_t35 B5 003C 0001 04 (HDR10+). */
    private static boolean isHdr10PlusSei(byte[] d, int p, int stop) {
        byte[] raw = unescape(d, p + 2, stop);
        int n = raw.length, i = 0;
        while (i < n - 1) {
            int type = 0, size = 0;
            while (i < n && (raw[i] & 0xFF) == 0xFF) { type += 255; i++; }
            if (i >= n) return false;
            type += raw[i++] & 0xFF;
            while (i < n && (raw[i] & 0xFF) == 0xFF) { size += 255; i++; }
            if (i >= n) return false;
            size += raw[i++] & 0xFF;
            if (type == 4 && size >= 6 && i + 6 <= n
                    && (raw[i] & 0xFF) == 0xB5 && raw[i + 1] == 0 && raw[i + 2] == 0x3C
                    && raw[i + 3] == 0 && raw[i + 4] == 1 && raw[i + 5] == 4) return true;
            i += size;
        }
        return false;
    }

    private static byte[] unescape(byte[] d, int from, int to) {
        byte[] raw = new byte[Math.max(0, to - from)];
        int n = 0;
        for (int i = from; i < to; i++) {
            if (i - from >= 2 && d[i - 2] == 0 && d[i - 1] == 0 && d[i] == 3) continue;
            raw[n++] = d[i];
        }
        return java.util.Arrays.copyOf(raw, n);
    }

    // ------------------------------------------------------------------ Dolby Vision RPU → level 1

    /** RPU NAL (0x7C 0x01 …) → {min_pq, max_pq, avg_pq} or null. */
    static int[] level1(byte[] d, int off, int len) {
        try {
            byte[] raw = unescape(d, off + 2, off + len);
            if (raw.length < 7 || (raw[0] & 0xFF) != 0x19) return null;
            return level1(raw);
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** Unescaped RPU payload starting with 0x19. */
    static int[] level1(byte[] data) {
        R r = new R(data, data.length);
        r.u(8);
        if (r.u(6) != 2) return null;                          // rpu_type
        long rpuFormat = r.u(11);
        r.u(4); r.u(4);                                        // vdr_rpu_profile, level
        if (!r.bit()) return null;                             // vdr_seq_info_present_flag
        r.bit();                                               // chroma_resampling_explicit_filter_flag
        long coefType = r.u(2);
        int coefLen;
        long log2Denom = 0;
        if (coefType == 0) log2Denom = r.ue();
        r.u(2); r.bit();                                       // normalized idc, bl full range
        long blDepthMinus8 = 2, elDepthRaw = 2, reserved3 = 0;
        boolean disableResidual = true;
        if ((rpuFormat & 0x700) == 0) {
            blDepthMinus8 = r.ue();
            elDepthRaw = r.ue();
            r.ue();                                            // vdr_bit_depth_minus8
            r.bit();                                           // spatial_resampling_filter_flag
            reserved3 = r.u(3);
            r.bit();                                           // el_spatial_resampling_filter_flag
            disableResidual = r.bit();
        }
        if (coefType == 0) coefLen = (int) log2Denom;
        else if (coefType == 1) coefLen = 32;
        else return null;
        boolean dmPresent = r.bit();
        boolean usePrev = r.bit();
        if (!dmPresent) return null;
        if (usePrev) {
            r.ue();
        } else {
            r.ue(); r.ue(); r.ue();
            int blDepth = (int) blDepthMinus8 + 8;
            int[] pieces = new int[3];
            for (int cmp = 0; cmp < 3; cmp++) {
                long npm2 = r.ue();
                for (long i = 0; i < npm2 + 2; i++) r.u(blDepth);
                pieces[cmp] = (int) npm2 + 1;
            }
            boolean nlq = (rpuFormat & 0x700) == 0 && !disableResidual;
            if (nlq) {
                if (r.u(3) != 0) return null;
                r.u(blDepth); r.u(blDepth);
            }
            if (r.ue() != 0 || r.ue() != 0) return null;       // partitions
            for (int cmp = 0; cmp < 3; cmp++) {
                for (int i = 0; i < pieces[cmp]; i++) {
                    long idc = r.ue();
                    if (idc == 0) {
                        long order = r.ue();
                        if (order > 1) return null;
                        if (order == 0 && r.bit()) return null;   // linear interpolation: unsupported
                        for (int j = 0; j < order + 2; j++) {
                            if (coefType == 0) r.se();
                            r.u(coefLen);
                        }
                    } else if (idc == 1) {
                        long mo = r.u(2);
                        if (mo > 2) return null;
                        if (coefType == 0) r.se();
                        r.u(coefLen);
                        for (int j = 0; j < (mo + 1) * 7; j++) {
                            if (coefType == 0) r.se();
                            r.u(coefLen);
                        }
                    } else {
                        return null;
                    }
                }
            }
            if (nlq) {
                int elDepth = (int) (elDepthRaw & 0xFF) + 8;
                for (int cmp = 0; cmp < 3; cmp++) {
                    r.u(elDepth);
                    if (coefType == 0) r.ue();
                    r.u(coefLen);
                    if (coefType == 0) r.ue();
                    r.u(coefLen);
                    if (coefType == 0) r.ue();
                    r.u(coefLen);
                }
            }
        }
        r.ue(); r.ue(); r.ue();                                // dm ids, scene_refresh_flag
        if (reserved3 != 1) {
            r.skip(9 * 16 + 3 * 32 + 9 * 16 + 16 * 3 + 32 + 5 + 2 + 2 + 2 + 12 + 12 + 10);
        }
        for (int set = 0; set < 2; set++) {
            if (set == 1 && r.available() < 56) break;
            long n = r.ue();
            while (!r.aligned()) r.u(1);
            for (long b = 0; b < n; b++) {
                long length = r.ue();
                long level = r.u(8);
                long start = r.pos;
                if (level == 1 && length >= 5) {
                    return new int[] {(int) r.u(12), (int) r.u(12), (int) r.u(12)};
                }
                r.pos = start + length * 8;
            }
        }
        return null;
    }

    private static final class R {
        final byte[] d;
        final long endBit;
        long pos;
        R(byte[] d, int len) { this.d = d; this.endBit = (long) len * 8; }
        long u(int n) {
            long v = 0;
            for (int i = 0; i < n; i++) {
                if (pos >= endBit) throw new IndexOutOfBoundsException();
                v = (v << 1) | ((d[(int) (pos >> 3)] >> (7 - (int) (pos & 7))) & 1);
                pos++;
            }
            return v;
        }
        void skip(long n) { pos += n; if (pos > endBit) throw new IndexOutOfBoundsException(); }
        boolean bit() { return u(1) == 1; }
        long ue() {
            int z = 0;
            while (u(1) == 0) { if (++z > 40) throw new IllegalStateException("ue"); }
            return z == 0 ? 0 : ((1L << z) - 1 + u(z));
        }
        long se() {
            long k = ue();
            return (k & 1) == 1 ? (k + 1) / 2 : -(k / 2);
        }
        boolean aligned() { return (pos & 7) == 0; }
        long available() { return endBit - pos; }
    }

    // ------------------------------------------------------------------ HDR10+ (ST 2094-40) SEI

    /** 12-bit PQ code → cd/m². */
    static double pqToNits(int code) {
        double e = Math.max(0, Math.min(4095, code)) / 4095.0;
        final double m1 = 2610.0 / 16384, m2 = 2523.0 / 4096 * 128;
        final double c1 = 3424.0 / 4096, c2 = 2413.0 / 4096 * 32, c3 = 2392.0 / 4096 * 32;
        double p = Math.pow(e, 1 / m2);
        return 10000 * Math.pow(Math.max(p - c1, 0) / (c2 - c3 * p), 1 / m1);
    }

    private static final int[] PERCENTAGES = {1, 5, 10, 25, 50, 75, 90, 95, 99};

    /** Values in 0.1 cd/m², as HDR10+ stores them. */
    private static int tenths(double pq) {
        return (int) Math.max(0, Math.min(100000, Math.round(pqToNits((int) Math.round(pq)) * 10)));
    }

    static byte[] payload(int minPq, int maxPq, int avgPq) {
        int mx = Math.max(maxPq, 0);
        int av = Math.min(Math.max(avgPq, 0), mx);
        int mn = Math.min(Math.max(minPq, 0), av);
        // Estimated maxRGB distribution (in PQ, where brightness steps look even)
        double[] pq = {
                mn + 0.05 * (av - mn), mn + 0.20 * (av - mn), mn + 0.35 * (av - mn), mn + 0.65 * (av - mn),
                mn + 0.92 * (av - mn), av + 0.10 * (mx - av), av + 0.30 * (mx - av), av + 0.45 * (mx - av),
                av + 0.97 * (mx - av)};
        Bits w = new Bits();
        w.u(8, 0xB5);              // itu_t_t35_country_code: USA
        w.u(16, 0x003C);           // terminal_provider_code: Samsung
        w.u(16, 0x0001);           // terminal_provider_oriented_code
        w.u(8, 4);                 // application_identifier
        w.u(8, 1);                 // application_version
        w.u(2, 1);                 // num_windows
        w.u(27, 0);                // targeted_system_display_maximum_luminance (profile A)
        w.u(1, 0);                 // targeted_system_display_actual_peak_luminance_flag
        int peak = tenths(mx);
        w.u(17, peak); w.u(17, peak); w.u(17, peak);   // maxscl R, G, B
        w.u(17, tenths(av));       // average_maxrgb
        w.u(4, PERCENTAGES.length);
        for (int i = 0; i < PERCENTAGES.length; i++) {
            w.u(7, PERCENTAGES[i]);
            w.u(17, tenths(pq[i]));
        }
        w.u(10, 0);                // fraction_bright_pixels
        w.u(1, 0);                 // mastering_display_actual_peak_luminance_flag
        w.u(1, 0);                 // tone_mapping_flag
        w.u(1, 0);                 // color_saturation_mapping_flag
        lastMaxNits = peak / 10;
        lastAvgNits = tenths(av) / 10;
        lastMinNits10 = (int) Math.round(pqToNits(mn) * 10);
        return w.bytes();
    }

    /** Annex-B prefix SEI NAL with start code. */
    static byte[] seiNal(int minPq, int maxPq, int avgPq, int tidPlus1) {
        byte[] pl = payload(minPq, maxPq, avgPq);
        byte[] rbsp = new byte[pl.length + 3];
        rbsp[0] = 4;                       // payloadType: user_data_registered_itu_t_t35
        rbsp[1] = (byte) pl.length;        // payloadSize (< 255)
        System.arraycopy(pl, 0, rbsp, 2, pl.length);
        rbsp[rbsp.length - 1] = (byte) 0x80;   // rbsp_trailing_bits
        ByteArrayOutputStream o = new ByteArrayOutputStream(rbsp.length + 12);
        o.write(0); o.write(0); o.write(0); o.write(1);
        o.write(39 << 1);                  // nal_unit_type PREFIX_SEI, layer 0
        o.write(tidPlus1);
        int zeros = 0;
        for (byte b0 : rbsp) {
            int b = b0 & 0xFF;
            if (zeros >= 2 && b <= 3) { o.write(3); zeros = 0; }
            o.write(b);
            zeros = b == 0 ? zeros + 1 : 0;
        }
        return o.toByteArray();
    }

    private static final class Bits {
        byte[] b = new byte[64];
        int pos;
        void u(int n, long v) {
            for (int i = n - 1; i >= 0; i--) {
                if ((pos >> 3) >= b.length) b = java.util.Arrays.copyOf(b, b.length * 2);
                if (((v >> i) & 1) == 1) b[pos >> 3] |= (byte) (0x80 >> (pos & 7));
                pos++;
            }
        }
        byte[] bytes() { return java.util.Arrays.copyOf(b, (pos + 7) >> 3); }
    }

    // ------------------------------------------------------------------ decoder side / overlay

    /** Decoder configuration: tell the HEVC decoder the stream carries HDR10+. */
    static void request(MediaFormat mf, String codecMimeType) {
        if (!enabled || !trackWanted || mf == null) return;
        if (!"video/hevc".equals(codecMimeType) || !decoderListsHdr10Plus) return;
        mf.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10HDR10Plus);
        Diag.log("HDR10+: decoder set up as HEVC Main 10 HDR10+");
    }

    static volatile boolean trackWanted;

    /** The decoder reports HDR10+ on its output when it has read our SEI. */
    static void check(MediaFormat out) {
        if (!enabled || out == null) return;
        try {
            if (out.containsKey(MediaFormat.KEY_HDR10_PLUS_INFO)) {
                if (decoderSeen++ == 0) Diag.log("HDR10+: the decoder passes the metadata on to the display");
            }
        } catch (Throwable ignored) { }
    }

    /** For the overlay. */
    static String status() {
        if (!enabled || (added == 0 && existing == 0 && noL1 == 0)) return null;
        if (existing > 0 && added == 0) return "DV → HDR10+: the video already has HDR10+, kept as it is";
        StringBuilder sb = new StringBuilder("DV → HDR10+: ").append(added).append(" frames");
        if (added > 0) {
            sb.append(" · now ").append(lastMaxNits).append(" nits peak, ")
              .append(lastAvgNits).append(" average");
        }
        if (noL1 > 0) sb.append(" · ").append(noL1).append(" without metadata");
        sb.append(decoderSeen > 0 ? " · decoder reads it" : " · decoder hasn't reported it yet");
        return sb.toString();
    }
}
