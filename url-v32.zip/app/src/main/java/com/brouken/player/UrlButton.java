package com.brouken.player;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

/** The 🔗 button in the player's control bar. Called from PlayerActivity.onCreate. */
public final class UrlButton {

    private static final int STYLE_BUTTON_BOTTOM = R.style.ExoStyledControls_Button_Bottom;

    private UrlButton() {}

    /** HW+ / HW / SW toggle; reloads the video at the same position. */
    private static void addDecoderButton(final Activity activity, LinearLayout controls) {
        final android.widget.TextView t = new android.widget.TextView(activity);
        t.setText(Decoder.name(Decoder.get(activity)));
        Decoder.button = t;
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setGravity(android.view.Gravity.CENTER);
        int pad = (int) (12 * activity.getResources().getDisplayMetrics().density);
        t.setPadding(pad, 0, pad, 0);
        t.setMinWidth((int) (48 * activity.getResources().getDisplayMetrics().density));
        t.setContentDescription("Decoder");
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = Decoder.cycle(activity);
                t.setText(Decoder.name(mode));
                android.widget.Toast.makeText(activity, "Decoder for this video: " + Decoder.name(mode), android.widget.Toast.LENGTH_SHORT).show();
                if (activity instanceof PlayerActivity) {
                    PlayerActivity pa = (PlayerActivity) activity;
                    if (PlayerActivity.player != null) {
                        pa.releasePlayer();
                        pa.initializePlayer();
                    }
                }
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!(activity instanceof PlayerActivity)) return true;
                PlayerActivity pa = (PlayerActivity) activity;
                Decoder.forget(pa);
                t.setText(Decoder.name(Decoder.get(activity)));
                android.widget.Toast.makeText(activity, "Saved decoder cleared, rechecking this video", android.widget.Toast.LENGTH_SHORT).show();
                if (PlayerActivity.player != null) {
                    pa.releasePlayer();
                    pa.initializePlayer();
                }
                return true;
            }
        });
        controls.addView(t, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
    }

    /** ⟳ Refresh: reopen the current video at the same position (frozen / not responding). */
    private static void addRefreshButton(final Activity activity, LinearLayout controls) {
        ImageButton b = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
        int icon = R.drawable.ic_refresh_24dp;
        if (icon != 0) b.setImageResource(icon);
        b.setContentDescription("Refresh");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activity instanceof PlayerActivity && ((PlayerActivity) activity).mPrefs != null
                        && ((PlayerActivity) activity).mPrefs.mediaUri != null) {
                    android.widget.Toast.makeText(activity, "Refreshing…", android.widget.Toast.LENGTH_SHORT).show();
                    Lifecycle.refresh((PlayerActivity) activity);
                }
            }
        });
        controls.addView(b);
    }

    public static void add(final Activity activity, LinearLayout controls) {
        Perf.init(activity);
        try {
            ImageButton button = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
            int icon = R.drawable.ic_link_24dp;
            if (icon != 0) button.setImageResource(icon);
            button.setContentDescription("Open URL");
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClassName(activity, "com.brouken.player.PasteUrlActivity");
                    intent.putExtra("dialog", true);
                    activity.startActivity(intent);
                }
            });
            button.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Diag.toggle();
                    return true;
                }
            });
            controls.addView(button);
            addDecoderButton(activity, controls);
            addRefreshButton(activity, controls);
        } catch (Throwable t) {
            t.printStackTrace();
        }
        Diag.attach(activity);
        Updater.autoCheck(activity);
    }
}
