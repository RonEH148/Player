package com.brouken.player;

import android.preference.PreferenceManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.ui.SubtitleView;

import java.util.ArrayList;
import java.util.List;

/**
 * Puts dialogue subtitles into the black bar below letterboxed video.
 *
 * The subtitle layer keeps the size of the video (so text size and style stay exactly as set)
 * and is shifted down by the height of the bottom bar. Normal bottom dialogue then lands in
 * the bar; signs and positioned subtitles (ASS signs, PGS images, top-of-screen lines) are
 * moved back up by the same amount so they stay where the subtitle author placed them.
 * Videos without bars (or zoomed to fill) are unaffected.
 */
public final class SubtitleBars {

    static final String PREF_KEY = "subtitlesInBars";

    private static PlayerActivity activity;
    private static SubtitleView view;
    private static float shiftFraction;   // shift as a fraction of the video height
    private static final View.OnLayoutChangeListener LAYOUT = new View.OnLayoutChangeListener() {
        @Override
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            update();
        }
    };

    private SubtitleBars() {}

    static boolean enabled() {
        try {
            return activity != null && PreferenceManager.getDefaultSharedPreferences(activity).getBoolean(PREF_KEY, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Called once the player exists. */
    static void attach(PlayerActivity a) {
        try {
            if (a.playerView == null) return;
            SubtitleView sv = a.playerView.getSubtitleView();
            if (sv == null) return;
            if (sv == view && activity == a) { update(); return; }
            activity = a;
            view = sv;
            // Let the shifted subtitle layer draw outside the video area.
            ViewParent p = sv.getParent();
            while (p instanceof ViewGroup) {
                ((ViewGroup) p).setClipChildren(false);
                ((ViewGroup) p).setClipToPadding(false);
                if (p == a.playerView) break;
                p = p.getParent();
            }
            View frame = (View) sv.getParent();
            frame.addOnLayoutChangeListener(LAYOUT);
            a.playerView.addOnLayoutChangeListener(LAYOUT);
            update();
        } catch (Throwable t) {
            Diag.log("Subtitle bars: " + t);
        }
    }

    static void update() {
        SubtitleView sv = view;
        PlayerActivity a = activity;
        if (sv == null || a == null || a.playerView == null) return;
        View frame = (View) sv.getParent();
        int videoH = frame.getHeight();
        int viewH = a.playerView.getHeight();
        int[] fLoc = new int[2];
        int[] pLoc = new int[2];
        frame.getLocationInWindow(fLoc);
        a.playerView.getLocationInWindow(pLoc);
        int videoBottom = fLoc[1] - pLoc[1] + videoH;
        int bar = viewH - videoBottom;
        float minBar = 16 * a.getResources().getDisplayMetrics().density;
        float shift = (enabled() && videoH > 0 && bar > minBar) ? bar : 0;
        sv.setTranslationY(shift);
        shiftFraction = videoH > 0 ? shift / videoH : 0;
    }

    /** Runs after the player view set the cues: keep positioned subtitles on the picture. */
    static void onCues(CueGroup group) {
        SubtitleView sv = view;
        if (sv == null || group == null || shiftFraction <= 0) return;
        List<Cue> out = new ArrayList<>(group.cues.size());
        for (Cue c : group.cues) {
            boolean text = c.bitmap == null;
            boolean fractionLine = c.line != Cue.DIMEN_UNSET && c.lineType == Cue.LINE_TYPE_FRACTION;
            if (text && fractionLine && c.line >= 0.8f) {
                // Bottom dialogue with an explicit position (e.g. ASS default style): let it drop into the bar.
                out.add(c.buildUpon().setLine(Cue.DIMEN_UNSET, Cue.TYPE_UNSET).build());
            } else if (fractionLine) {
                // Signs, top lines, image subtitles: undo the shift so they stay on the picture.
                out.add(c.buildUpon().setLine(c.line - shiftFraction, c.lineType).build());
            } else {
                out.add(c);   // plain dialogue → bar
            }
        }
        sv.setCues(out);
    }
}
