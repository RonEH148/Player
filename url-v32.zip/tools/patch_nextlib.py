#!/usr/bin/env python3
"""Adjust a NextLib checkout for Just Player URL: arm64 only, extra video decoders (VC-1, MPEG-4…)."""
import sys, re, os, pathlib
ABIS = os.environ.get("NEXTLIB_ABIS", "arm64-v8a").split()
root = pathlib.Path(sys.argv[1])

def edit(rel, pairs):
    p = root / rel
    s = p.read_text()
    for old, new in pairs:
        if old not in s:
            sys.exit(f"patch_nextlib: '{old[:60]}' not found in {rel}")
        s = s.replace(old, new, 1)
    p.write_text(s)

setup = (root / "ffmpeg/setup.sh").read_text()
m = re.search(r'ENABLED_DECODERS="([^"]*)"', setup)
if not m: sys.exit("patch_nextlib: ENABLED_DECODERS not found")
extra = " vc1 wmv3 mpeg4 msmpeg4v3 h263 mpeg1video"
edit("ffmpeg/setup.sh", [
    (m.group(0), f'ENABLED_DECODERS="{m.group(1)}{extra}"'),
    ('ANDROID_ABIS="x86 x86_64 armeabi-v7a arm64-v8a"', 'ANDROID_ABIS="' + " ".join(ABIS) + '"'),
])
edit("media3ext/build.gradle.kts", [
    ('abiFilters += listOf("x86", "x86_64", "armeabi-v7a", "arm64-v8a")', 'abiFilters += listOf(' + ", ".join('"%s"' % a for a in ABIS) + ')'),
])
edit("media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/FfmpegLibrary.java", [
    ('case MimeTypes.VIDEO_VP9 -> "vp9";',
     'case MimeTypes.VIDEO_VP9 -> "vp9";\n      case MimeTypes.VIDEO_VC1 -> "vc1";\n      case MimeTypes.VIDEO_MP4V -> "mpeg4";\n      case MimeTypes.VIDEO_H263 -> "h263";'),
])
# VC-1 (sequence header) and MPEG-4 Part 2 (VOL header) need their codec data as FFmpeg
# "extradata", otherwise the decoder can't start. NextLib only passes it for H.264/H.265.
edit("media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/FfmpegVideoDecoder.java", [
    ("case MimeTypes.VIDEO_H265 -> {", "case MimeTypes.VIDEO_H265, MimeTypes.VIDEO_VC1, MimeTypes.VIDEO_MP4V -> {"),
])
print("NextLib patched: decoders +" + extra)
