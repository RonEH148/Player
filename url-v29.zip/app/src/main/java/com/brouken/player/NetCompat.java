package com.brouken.player;

import android.net.Uri;
import android.util.Base64;

import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.extractor.ts.TsExtractor;

import java.util.HashMap;

/**
 * Network behaviour modelled on what mpv/VLC (FFmpeg networking) do by default:
 * follow every redirect including http<->https, long timeouts, keep retrying dropped
 * connections, a media-player User-Agent, and a large read-ahead buffer.
 */
public final class NetCompat {

    public static final String USER_AGENT = "VLC/3.0.21 LibVLC/3.0.21";
    static final int TIMEOUT_MS = 30_000;
    static final int MIN_RETRIES = 12;

    private NetCompat() {}

    /** Called from PlayerActivity.initializePlayer() right before ExoPlayer.Builder.build(). */
    public static void apply(ExoPlayer.Builder builder, PlayerActivity activity) {
        try {
            Uri uri = activity.mPrefs != null ? activity.mPrefs.mediaUri : null;
            Diag.onNewMedia(uri);
            Lifecycle.beginSession(activity);
            Titles.apply(activity);
            try {
                Decoder.apply(builder, activity);
            } catch (Throwable t) {
                Diag.log("Decoder setup failed: " + t);
            }
            if (!isHttp(uri)) {
                return;
            }

            HashMap<String, String> headers = new HashMap<>();
            String userInfo = uri.getUserInfo();
            if (userInfo != null && userInfo.contains(":")) {
                headers.put("Authorization", "Basic " + Base64.encodeToString(userInfo.getBytes(), Base64.NO_WRAP));
            }

            // mpv-style HTTP: all redirects, no compression, and servers that ignore Range are detected
            // instead of silently downloading the file from the start (see RangeSupport)
            MpvHttpDataSource.Factory http = new MpvHttpDataSource.Factory(USER_AGENT, headers, TIMEOUT_MS, Diag.TRANSFER_LISTENER);

            // Background read-ahead cache (like mpv's stream cache) so the connection runs at full speed.
            DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(activity, new ReadAheadDataSource.Factory(http));

            DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                    .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS)
                    .setTsExtractorTimestampSearchBytes(1500 * TsExtractor.TS_PACKET_SIZE);
            if (RangeSupport.isLinear(uri)) {
                // like mpv on a server that can't seek: don't jump to the MKV index at the end, just play
                extractors.setMatroskaExtractorFlags(androidx.media3.extractor.mkv.MatroskaExtractor.FLAG_DISABLE_SEEK_FOR_CUES);
                Diag.log("Linear playback: index lookup off (server can't seek)");
            }

            DefaultMediaSourceFactory sources = new DefaultMediaSourceFactory(dataSource, extractors);
            sources.setLoadErrorHandlingPolicy(new LoggingRetryPolicy(MIN_RETRIES));
            builder.setMediaSourceFactory(sources);

            // Bigger decoded-sample buffer for high-bitrate remuxes: up to 2 min / 128 MB in memory.
            builder.setLoadControl(new DefaultLoadControl.Builder()
                    .setBufferDurationsMs(30_000, 120_000, 2_000, 4_000)
                    .setTargetBufferBytes(Perf.sampleBufferBytes())
                    .setPrioritizeTimeOverSizeThresholds(false)
                    .build());

            Diag.log("Net: redirects any, timeout " + (TIMEOUT_MS / 1000) + "s, retries " + MIN_RETRIES
                    + ", buffer 120s/" + Perf.sampleBufferBytes() / (1024 * 1024) + "MB + " + ReadAheadDataSource.CAPACITY / (1024 * 1024) + "MB read-ahead");
        } catch (Throwable t) {
            Diag.log("NetCompat failed: " + t);
        }
    }

    static boolean isHttp(Uri uri) {
        if (uri == null || uri.getScheme() == null) return false;
        String s = uri.getScheme().toLowerCase();
        return s.equals("http") || s.equals("https");
    }

    /** Default retry policy with more attempts, and every retry is shown in the overlay. */
    static final class LoggingRetryPolicy extends DefaultLoadErrorHandlingPolicy {
        LoggingRetryPolicy(int minRetries) {
            super(minRetries);
        }

        @Override
        public long getRetryDelayMsFor(LoadErrorHandlingPolicy.LoadErrorInfo info) {
            Throwable e = info.exception;
            if (RangeSupport.find(e) != null) {
                Diag.log("Server ignored a jump: " + e.getMessage());
                return androidx.media3.common.C.TIME_UNSET;   // handled by reopening in linear mode
            }
            long delay = super.getRetryDelayMsFor(info);
            Diag.log("Retry #" + info.errorCount + (delay == androidx.media3.common.C.TIME_UNSET ? " (giving up)" : " in " + delay + " ms")
                    + ": " + Diag.describe(e));
            return delay;
        }
    }
}
