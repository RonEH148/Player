package com.brouken.player;

import android.preference.PreferenceManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import androidx.media3.common.text.Cue;
import androidx.media3.common.text.CueGroup;
import androidx.media3.ui.SubtitleView;

import java.util.ArrayList;
import java.util.List;

/**
 * Puts dialogue subtitles into the black bar below letterboxed video.
 *
 * The subtitle layer keeps the size of the video (so text size and style stay exactly as set)
 * and is shifted down by the height of the bottom bar. Normal bottom dialogue then lands in
 * the bar; signs and positioned subtitles (ASS signs, PGS images, top-of-screen lines) are
 * moved back up by the same amount so they stay where the subtitle author placed them.
 * Videos without bars (or zoomed to fill) are unaffected.
 */
public final class SubtitleBars {

    static final String PREF_KEY = "subtitlesInBars";

    private static PlayerActivity activity;
    private static SubtitleView view;
    private static float shiftFraction;   // shift as a fraction of the video height
    private static final View.OnLayoutChangeListener LAYOUT = new View.OnLayoutChangeListener() {
        @Override
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            update();
        }
    };

    private SubtitleBars() {}

    static boolean enabled() {
        try {
            return activity != null && PreferenceManager.getDefaultSharedPreferences(activity).getBoolean(PREF_KEY, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Called once the player exists. */
    static void attach(PlayerActivity a) {
        try {
            if (a.playerView == null) return;
            SubtitleView sv = a.playerView.getSubtitleView();
            if (sv == null) return;
            if (sv == view && activity == a) { update(); return; }
            activity = a;
            view = sv;
            // Let the shifted subtitle layer draw outside the video area.
            ViewParent p = sv.getParent();
            while (p instanceof ViewGroup) {
                ((ViewGroup) p).setClipChildren(false);
                ((ViewGroup) p).setClipToPadding(false);
                if (p == a.playerView) break;
                p = p.getParent();
            }
            View frame = (View) sv.getParent();
            frame.addOnLayoutChangeListener(LAYOUT);
            a.playerView.addOnLayoutChangeListener(LAYOUT);
            update();
        } catch (Throwable t) {
            Diag.log("Subtitle bars: " + t);
        }
    }

    static void update() {
        SubtitleView sv = view;
        PlayerActivity a = activity;
        if (sv == null || a == null || a.playerView == null) return;
        View frame = (View) sv.getParent();
        int videoH = frame.getHeight();
        int viewH = a.playerView.getHeight();
        int[] fLoc = new int[2];
        int[] pLoc = new int[2];
        frame.getLocationInWindow(fLoc);
        a.playerView.getLocationInWindow(pLoc);
        int videoBottom = fLoc[1] - pLoc[1] + videoH;
        int bar = viewH - videoBottom;
        float minBar = 16 * a.getResources().getDisplayMetrics().density;
        float shift = (enabled() && videoH > 0 && bar > minBar) ? bar : 0;
        sv.setTranslationY(shift);
        shiftFraction = videoH > 0 ? shift / videoH : 0;
    }

    /**
     * Runs after the player view set the cues.
     *  - Subtitles keep their authored look; only broken values are corrected: text bigger than
     *    15 % of the picture per line, positions/widths outside the picture.
     *  - With a black bar: positioned subtitles stay on the picture, dialogue drops into the bar.
     */
    static void onCues(CueGroup group) {
        SubtitleView sv = view;
        if (sv == null || group == null) return;
        boolean changed = false;
        List<Cue> out = new ArrayList<>(group.cues.size());
        for (Cue c : group.cues) {
            Cue n = sane(c, sv);
            if (shiftFraction > 0) {
                boolean text = n.bitmap == null;
                boolean fractionLine = n.line != Cue.DIMEN_UNSET && n.lineType == Cue.LINE_TYPE_FRACTION;
                if (text && fractionLine && n.line >= 0.8f) {
                    // Bottom dialogue with an explicit position (e.g. ASS default style): let it drop into the bar.
                    n = n.buildUpon().setLine(Cue.DIMEN_UNSET, Cue.TYPE_UNSET).build();
                } else if (fractionLine) {
                    // Signs, top lines, image subtitles: undo the shift so they stay on the picture.
                    n = n.buildUpon().setLine(n.line - shiftFraction, n.lineType).build();
                }
            }
            if (n != c) changed = true;
            out.add(n);
        }
        if (changed) sv.setCues(out);
    }

    private static final float MAX_TEXT = 0.15f;   // of the picture height, per line

    private static Cue sane(Cue c, SubtitleView sv) {
        Cue.Builder b = null;
        if (c.bitmap == null && c.textSize != Cue.DIMEN_UNSET && c.textSize > 0) {
            if (c.textSizeType == Cue.TEXT_SIZE_TYPE_ABSOLUTE) {
                float max = sv.getHeight() * MAX_TEXT;
                if (max > 0 && c.textSize > max) b = c.buildUpon().setTextSize(max, c.textSizeType);
            } else if (c.textSize > MAX_TEXT) {
                b = c.buildUpon().setTextSize(MAX_TEXT, c.textSizeType);
            }
        }
        if (c.position != Cue.DIMEN_UNSET && (c.position < 0f || c.position > 1f)) {
            if (b == null) b = c.buildUpon();
            b.setPosition(Math.max(0f, Math.min(1f, c.position)));
        }
        if (c.size != Cue.DIMEN_UNSET && c.size > 1f) {
            if (b == null) b = c.buildUpon();
            b.setSize(1f);
        }
        if (c.line != Cue.DIMEN_UNSET && c.lineType == Cue.LINE_TYPE_FRACTION && (c.line < 0f || c.line > 1f)) {
            if (b == null) b = c.buildUpon();
            b.setLine(Math.max(0f, Math.min(1f, c.line)), c.lineType);
        }
        return b == null ? c : b.build();
    }
}
