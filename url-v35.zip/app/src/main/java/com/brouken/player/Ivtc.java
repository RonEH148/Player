package com.brouken.player;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.preference.PreferenceManager;

import androidx.media3.common.C;
import androidx.media3.common.Format;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegLibrary;
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.VideoFilter;

/**
 * Automatic inverse telecine / deinterlacing for ANY codec or container – the same method as
 * mpv URL+'s ivtc.lua:
 *  1. Only candidates are checked: SDR, up to 1088 lines, 25/29.97/30/50/59.94 fps.
 *     Typical web anime (23.976p) and 4K/HDR are never touched.
 *  2. For ~12 s of playback the video is decoded by FFmpeg and its "idet" filter counts combed
 *     (interlaced) vs. clean (progressive) frames. Hardware decoders hide interlacing, so the
 *     picture itself is measured.
 *  3. Hardly any combing → back to hardware decoding, no filter.
 *     Some combing at 29.97/30/59.94 fps → telecine: fieldmatch + bwdif + decimate.
 *     Combing nearly everywhere → really interlaced: bwdif deinterlace.
 * The result is remembered per video, so the check runs once. Settings → "Inverse telecine"
 * edits the configuration.
 */
final class Ivtc {

    private Ivtc() {}

    static final String KEY_CONFIG = "ivtcConfig";
    private static final String DETECT = "idet";

    static final String DEFAULT_CONFIG =
            "# Automatic inverse telecine / deinterlacing (like mpv's ivtc.lua)\n"
            + "# Lines starting with # are comments. Reset restores these defaults.\n"
            + "\n"
            + "# yes | no\n"
            + "enabled=yes\n"
            + "\n"
            + "# auto  = measure the picture, then decide\n"
            + "# ivtc  = always inverse telecine candidate videos\n"
            + "# deint = always deinterlace candidate videos\n"
            + "# off   = never filter\n"
            + "mode=auto\n"
            + "\n"
            + "# seconds of playback that are measured (software decoding meanwhile)\n"
            + "detect_seconds=12\n"
            + "# at least this many measured frames, else measure again (max 3 more rounds)\n"
            + "min_frames=150\n"
            + "\n"
            + "# share of combed frames below this = progressive: no filter, hardware decoding\n"
            + "progressive_below=0.10\n"
            + "# 29.97/30/59.94 fps and combed share below this = telecine → IVTC, else deinterlace\n"
            + "telecine_below=0.80\n"
            + "\n"
            + "# only videos up to this height and with these frame rates are checked\n"
            + "max_height=1088\n"
            + "fps=25,29.97,30,50,59.94\n"
            + "\n"
            + "# remember the result per video, so the check runs only once\n"
            + "remember=yes\n"
            + "\n"
            + "# FFmpeg filter chains\n"
            + "ivtc_filter=fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate\n"
            + "deint_filter=bwdif=mode=send_frame:deint=all\n";

    // ------------------------------------------------------------------ configuration

    static final class Config {
        boolean enabled = true;
        String mode = "auto";
        double detectSeconds = 12;
        int minFrames = 150;
        double progressiveBelow = 0.10;
        double telecineBelow = 0.80;
        int maxHeight = 1088;
        List<Double> fps = new ArrayList<>();
        boolean remember = true;
        String ivtcFilter = "fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate";
        String deintFilter = "bwdif=mode=send_frame:deint=all";
    }

    static String configText(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getString(KEY_CONFIG, DEFAULT_CONFIG);
    }

    static Config load(Context c) {
        try {
            return parse(configText(c));
        } catch (IllegalArgumentException e) {
            Diag.log("IVTC config error (" + e.getMessage() + ") → defaults used");
            return parse(DEFAULT_CONFIG);
        }
    }

    /** Returns null if the text is a valid configuration, else what is wrong. */
    static String validate(String text) {
        try {
            parse(text);
            return null;
        } catch (IllegalArgumentException e) {
            return e.getMessage();
        }
    }

    static Config parse(String text) {
        Config cfg = new Config();
        boolean fpsSet = false;
        int n = 0;
        for (String raw : text.split("\n")) {
            n++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) throw new IllegalArgumentException("line " + n + ": expected key=value");
            String key = line.substring(0, eq).trim().toLowerCase(Locale.US);
            String value = line.substring(eq + 1).trim();
            try {
                switch (key) {
                    case "enabled": cfg.enabled = bool(value, n); break;
                    case "mode":
                        value = value.toLowerCase(Locale.US);
                        if (!value.equals("auto") && !value.equals("ivtc") && !value.equals("deint") && !value.equals("off")) {
                            throw new IllegalArgumentException("line " + n + ": mode must be auto, ivtc, deint or off");
                        }
                        cfg.mode = value;
                        break;
                    case "detect_seconds": cfg.detectSeconds = range(Double.parseDouble(value), 2, 120, n); break;
                    case "min_frames": cfg.minFrames = (int) range(Integer.parseInt(value), 10, 10000, n); break;
                    case "progressive_below": cfg.progressiveBelow = range(Double.parseDouble(value), 0, 1, n); break;
                    case "telecine_below": cfg.telecineBelow = range(Double.parseDouble(value), 0, 1, n); break;
                    case "max_height": cfg.maxHeight = (int) range(Integer.parseInt(value), 144, 4320, n); break;
                    case "fps":
                        fpsSet = true;
                        for (String f : value.split(",")) {
                            if (!f.trim().isEmpty()) cfg.fps.add(range(Double.parseDouble(f.trim()), 1, 300, n));
                        }
                        break;
                    case "remember": cfg.remember = bool(value, n); break;
                    case "ivtc_filter": cfg.ivtcFilter = filter(value, n); break;
                    case "deint_filter": cfg.deintFilter = filter(value, n); break;
                    default: throw new IllegalArgumentException("line " + n + ": unknown setting '" + key + "'");
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("line " + n + ": '" + value + "' is not a number");
            }
        }
        if (!fpsSet) {
            for (double f : new double[] {25, 29.97, 30, 50, 59.94}) cfg.fps.add(f);
        }
        return cfg;
    }

    private static boolean bool(String v, int n) {
        v = v.toLowerCase(Locale.US);
        if (v.equals("yes") || v.equals("true") || v.equals("on") || v.equals("1")) return true;
        if (v.equals("no") || v.equals("false") || v.equals("off") || v.equals("0")) return false;
        throw new IllegalArgumentException("line " + n + ": use yes or no");
    }

    private static double range(double v, double min, double max, int n) {
        if (v < min || v > max) throw new IllegalArgumentException("line " + n + ": " + v + " is outside " + min + "…" + max);
        return v;
    }

    private static String filter(String v, int n) {
        if (v.isEmpty()) throw new IllegalArgumentException("line " + n + ": filter chain is empty");
        if (v.contains(";") || v.contains("[")) {
            throw new IllegalArgumentException("line " + n + ": use a simple chain (filter1,filter2,…)");
        }
        return v;
    }

    // ------------------------------------------------------------------ state

    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    private static String uri;
    private static String state = "idle";   // idle | detecting | ivtc | deint | off | skip
    private static String filter = "";
    private static boolean weSwitched;
    private static boolean hadOverride;
    private static int previousMode;
    private static long playedMs;
    private static long lastTick;
    private static int extraRounds;
    private static float fps;
    private static Config cfg;
    private static PlayerActivity activity;

    /** New video opened (or exit): forget everything. */
    static void newSession() {
        HANDLER.removeCallbacks(TICK);
        uri = null;
        state = "idle";
        filter = "";
        weSwitched = false;
        VideoFilter.spec = "";
        VideoFilter.clearStats();
    }

    /** Before every player build (also after a decoder switch). */
    static void onPlayerBuild(PlayerActivity a) {
        activity = a;
        String u = a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
        if (u == null || !u.equals(uri)) {
            newSession();
            uri = u;
        }
        switch (state) {
            case "detecting": VideoFilter.spec = DETECT; break;
            case "ivtc":
            case "deint": VideoFilter.spec = filter; break;
            default: VideoFilter.spec = "";
        }
    }

    /** Software decoding is on only because of this (don't save it as "the decoder for this video"). */
    static boolean holdsSoftware() {
        return weSwitched && ("detecting".equals(state) || "ivtc".equals(state) || "deint".equals(state));
    }

    static String status() {
        switch (state) {
            case "detecting": {
                long[] s = VideoFilter.stats(DETECT);
                return String.format(Locale.US, "checking… %d s, %d combed / %d clean frames",
                        playedMs / 1000, s[0] + s[1], s[2]);
            }
            case "ivtc": return "inverse telecine on";
            case "deint": return "deinterlacing on";
            case "off": return "progressive, no filter";
            default: return null;
        }
    }

    /**
     * Tracks known (every player build). Returns true when a decoder switch was started, so the
     * normal decoder choice is skipped for this build.
     */
    static boolean onTracks(PlayerActivity a, Format f) {
        activity = a;
        if (f == null) return false;
        if (!"idle".equals(state)) {
            boolean needsSw = "detecting".equals(state) || "ivtc".equals(state) || "deint".equals(state);
            if (needsSw && Decoder.get(a) != Decoder.SW) {
                // e.g. software was too slow and the decoder fell back to hardware
                state = "skip";
                VideoFilter.spec = "";
                HANDLER.removeCallbacks(TICK);
                Diag.log("IVTC: stopped, the software decoder isn't in use any more");
            }
            return false;
        }
        cfg = load(a);
        fps = f.frameRate;
        if (!cfg.enabled || "off".equals(cfg.mode)) {
            state = "skip";
            return false;
        }
        String skip = notCandidate(a, f);
        if (skip != null) {
            state = "skip";
            Diag.log("IVTC: not checked (" + skip + ")");
            return false;
        }
        String saved = cfg.remember ? memory(a).getString(uri, null) : null;
        if ("off".equals(saved)) {
            state = "off";
            Diag.log("IVTC: progressive (checked before)");
            return false;
        }
        if ("ivtc".equals(saved) || "deint".equals(saved)) return apply(a, saved, "checked before");
        if ("ivtc".equals(cfg.mode) || "deint".equals(cfg.mode)) return apply(a, cfg.mode, "set in config");
        return startDetect(a);
    }

    private static String notCandidate(PlayerActivity a, Format f) {
        if (f.height <= 0 || f.frameRate <= 0) return "size or frame rate unknown";
        if (f.height > cfg.maxHeight) return f.height + " lines";
        if (f.colorInfo != null && (f.colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084
                || f.colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG)) return "HDR";
        boolean fpsOk = false;
        for (double v : cfg.fps) {
            if (Math.abs(f.frameRate - v) < (v > 40 ? 0.3 : 0.15)) fpsOk = true;
        }
        if (!fpsOk) return String.format(Locale.US, "%.3f fps", f.frameRate);
        if (f.sampleMimeType == null || !FfmpegLibrary.isAvailable() || !FfmpegLibrary.supportsFormat(f.sampleMimeType)) {
            return "no FFmpeg decoder for " + f.sampleMimeType;
        }
        if (!TvTune.softwareOk(a, f)) return "too big for software decoding on this device";
        int mode = Decoder.get(a);
        if (mode == Decoder.HW && Decoder.hasOverride(a)) return "decoder set to HW";
        if (mode != Decoder.SW && RangeSupport.isLinear(a.mPrefs.mediaUri)) {
            return "server can't seek, a decoder switch would restart the video";
        }
        return null;
    }

    private static boolean ensureSoftware(PlayerActivity a, String why) {
        if (Decoder.get(a) == Decoder.SW) return false;
        hadOverride = Decoder.hasOverride(a);
        previousMode = Decoder.get(a);
        weSwitched = true;
        Decoder.switchTo(a, Decoder.SW, why);
        return true;
    }

    private static boolean startDetect(PlayerActivity a) {
        state = "detecting";
        filter = "";
        playedMs = 0;
        lastTick = 0;
        extraRounds = 0;
        VideoFilter.clearStats();
        VideoFilter.spec = DETECT;
        Diag.log(String.format(Locale.US, "IVTC: checking for telecine/interlacing (%.0f s)", cfg.detectSeconds));
        HANDLER.removeCallbacks(TICK);
        HANDLER.postDelayed(TICK, 1000);
        return ensureSoftware(a, "checking for telecine");
    }

    private static boolean apply(PlayerActivity a, String mode, String why) {
        HANDLER.removeCallbacks(TICK);
        state = mode;
        filter = "ivtc".equals(mode) ? cfg.ivtcFilter : cfg.deintFilter;
        VideoFilter.spec = filter;
        remember(a, mode);
        String text = ("ivtc".equals(mode) ? "Inverse telecine on" : "Deinterlacing on") + " (" + why + ")";
        Diag.log("IVTC: " + text);
        CenterText.show(a, text);
        HANDLER.postDelayed(CHECK_RUNNING, 4000);
        return ensureSoftware(a, "ivtc".equals(mode) ? "inverse telecine" : "deinterlacing");
    }

    private static void progressive(PlayerActivity a, String why) {
        HANDLER.removeCallbacks(TICK);
        state = "off";
        filter = "";
        VideoFilter.spec = "";
        remember(a, "off");
        Diag.log("IVTC: progressive (" + why + ") → no filter");
        restoreDecoder(a);
    }

    private static void stop(PlayerActivity a, String why) {
        HANDLER.removeCallbacks(TICK);
        state = "skip";
        filter = "";
        VideoFilter.spec = "";
        Diag.log("IVTC: stopped (" + why + ")");
        restoreDecoder(a);
    }

    private static void restoreDecoder(PlayerActivity a) {
        if (!weSwitched) return;
        weSwitched = false;
        if (Decoder.get(a) != Decoder.SW) return;
        if (hadOverride) Decoder.setOverride(a, previousMode);
        else Decoder.clearOverride(a);
        Decoder.reopen(a, "back to " + Decoder.name(previousMode) + ", no filter needed");
    }

    private static void remember(Context c, String mode) {
        if (cfg == null || !cfg.remember || uri == null) return;
        SharedPreferences m = memory(c);
        if (m.getAll().size() > 600) m.edit().clear().apply();
        m.edit().putString(uri, mode).apply();
    }

    private static SharedPreferences memory(Context c) {
        return c.getSharedPreferences("ivtc_memory", Context.MODE_PRIVATE);
    }

    /** Settings: forget all remembered results (after changing the config). */
    static void forgetAll(Context c) {
        memory(c).edit().clear().apply();
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) < tol;
    }

    private static void decide(PlayerActivity a) {
        long[] s = VideoFilter.stats(DETECT);
        if (s[5] < 0) {
            stop(a, "the filters aren't available in this build");
            return;
        }
        if (s[4] == 0) {
            stop(a, "the FFmpeg decoder isn't decoding this video");
            return;
        }
        long combed = s[0] + s[1];
        long clean = s[2];
        long total = combed + clean;
        if (total < cfg.minFrames && extraRounds < 3) {
            extraRounds++;          // too little picture so far (black, still, menus)
            playedMs = 0;
            return;
        }
        double ratio = total > 0 ? (double) combed / total : 0;
        String why = String.format(Locale.US, "%.0f%% combed frames, %.3f fps", ratio * 100, fps);
        if (ratio < cfg.progressiveBelow) {
            progressive(a, why);
        } else if ((near(fps, 29.97, 0.15) || near(fps, 30, 0.15) || near(fps, 59.94, 0.3)) && ratio < cfg.telecineBelow) {
            apply(a, "ivtc", why);
        } else {
            apply(a, "deint", why);
        }
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = activity;
            if (a == null || a.isFinishing() || !"detecting".equals(state)) return;
            long now = SystemClock.elapsedRealtime();
            boolean playing = false;
            try { playing = PlayerActivity.player != null && PlayerActivity.player.isPlaying(); } catch (Throwable ignored) { }
            if (playing && lastTick > 0) playedMs += Math.min(2000, now - lastTick);
            lastTick = now;
            if (playedMs >= cfg.detectSeconds * 1000) decide(a);
            if ("detecting".equals(state)) HANDLER.postDelayed(this, 1000);
        }
    };

    /** A filter that can't be built is switched off by the decoder; go back to hardware then. */
    private static final Runnable CHECK_RUNNING = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = activity;
            if (a == null || a.isFinishing()) return;
            if (!"ivtc".equals(state) && !"deint".equals(state)) return;
            long[] s = VideoFilter.stats(filter);
            if (s[5] < 0) {
                stop(a, "FFmpeg couldn't build the filter: " + filter);
                android.widget.Toast.makeText(a, "Telecine filter failed – check the config in Settings", android.widget.Toast.LENGTH_LONG).show();
            } else if (s[5] == 0 && PlayerActivity.player != null && PlayerActivity.player.isPlaying()) {
                HANDLER.postDelayed(this, 4000);   // not reported yet
            }
        }
    };
}
