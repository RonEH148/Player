package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.preference.Preference;

/** Settings → "Inverse telecine / deinterlacing": edit the config as text, like mpv's script-opts. */
final class IvtcSettings {

    private IvtcSettings() {}

    static void summary(Preference p) {
        try {
            Ivtc.Config c = Ivtc.load(p.getContext());
            p.setSummary(!c.enabled || "off".equals(c.mode) ? "Off"
                    : "On · mode " + c.mode + " · checks " + (int) c.detectSeconds + " s of SD/HD video at "
                    + fpsList(c) + " fps\nTap to edit the config");
        } catch (Throwable t) {
            p.setSummary("Tap to edit the config");
        }
    }

    private static String fpsList(Ivtc.Config c) {
        StringBuilder sb = new StringBuilder();
        for (double f : c.fps) {
            if (sb.length() > 0) sb.append('/');
            sb.append(f == Math.rint(f) ? String.valueOf((int) f) : String.valueOf(f));
        }
        return sb.toString();
    }

    static void edit(final Activity a, final Preference pref) {
        final EditText input = new EditText(a);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setSingleLine(false);
        input.setHorizontallyScrolling(true);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setTypeface(Typeface.MONOSPACE);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        input.setText(Ivtc.configText(a));
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);

        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Inverse telecine config")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNeutralButton("Reset", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String text = input.getText().toString();
                String error = Ivtc.validate(text);
                if (error != null) {
                    input.setError(error);
                    return;
                }
                PreferenceManager.getDefaultSharedPreferences(a).edit().putString(Ivtc.KEY_CONFIG, text).apply();
                Ivtc.forgetAll(a);   // earlier results were decided with the old settings
                summary(pref);
                Toast.makeText(a, "Saved – applies from the next video", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> input.setText(Ivtc.DEFAULT_CONFIG));
        });
        dialog.show();
    }
}
