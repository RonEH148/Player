#!/usr/bin/env python3
"""Adjust a NextLib checkout for Just Player URL: arm64 only, extra video decoders (VC-1, MPEG-4…)."""
import sys, re, os, pathlib
ABIS = os.environ.get("NEXTLIB_ABIS", "arm64-v8a").split()
root = pathlib.Path(sys.argv[1])

def edit(rel, pairs):
    p = root / rel
    s = p.read_text()
    for old, new in pairs:
        if old not in s:
            sys.exit(f"patch_nextlib: '{old[:60]}' not found in {rel}")
        s = s.replace(old, new, 1)
    p.write_text(s)

setup = (root / "ffmpeg/setup.sh").read_text()
m = re.search(r'ENABLED_DECODERS="([^"]*)"', setup)
if not m: sys.exit("patch_nextlib: ENABLED_DECODERS not found")
extra = " vc1 wmv3 mpeg4 msmpeg4v3 h263 mpeg1video"
edit("ffmpeg/setup.sh", [
    (m.group(0), f'ENABLED_DECODERS="{m.group(1)}{extra}"'),
    ('ANDROID_ABIS="x86 x86_64 armeabi-v7a arm64-v8a"', 'ANDROID_ABIS="' + " ".join(ABIS) + '"'),
])
edit("media3ext/build.gradle.kts", [
    ('abiFilters += listOf("x86", "x86_64", "armeabi-v7a", "arm64-v8a")', 'abiFilters += listOf(' + ", ".join('"%s"' % a for a in ABIS) + ')'),
])
edit("media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/FfmpegLibrary.java", [
    ('case MimeTypes.VIDEO_VP9 -> "vp9";',
     'case MimeTypes.VIDEO_VP9 -> "vp9";\n      case MimeTypes.VIDEO_VC1 -> "vc1";\n      case MimeTypes.VIDEO_MP4V -> "mpeg4";\n      case MimeTypes.VIDEO_H263 -> "h263";'),
])
# VC-1 (sequence header) and MPEG-4 Part 2 (VOL header) need their codec data as FFmpeg
# "extradata", otherwise the decoder can't start. NextLib only passes it for H.264/H.265.
edit("media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/FfmpegVideoDecoder.java", [
    ("case MimeTypes.VIDEO_H265 -> {", "case MimeTypes.VIDEO_H265, MimeTypes.VIDEO_VC1, MimeTypes.VIDEO_MP4V -> {"),
])
print("NextLib patched: decoders +" + extra)

# ---------------------------------------------------------------- video filters (inverse telecine)
# FFmpeg's avfilter with only the filters needed for automatic inverse telecine/deinterlacing:
# idet (detection), fieldmatch + decimate (telecine removal), bwdif (deinterlacing).
# fieldmatch is GPL, hence --enable-gpl (this personal build is GPL-compatible).
def edit_once(rel, pairs):
    p = root / rel
    s = p.read_text()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"patch_nextlib: '{old[:60]}' found {n}x in {rel}")
        s = s.replace(old, new, 1)
    p.write_text(s)

edit_once("ffmpeg/setup.sh", [
    ("      --disable-avfilter \\\n",
     "      --enable-avfilter \\\n      --enable-gpl \\\n"
     "      --enable-filter=buffer,buffersink,format,null,idet,fieldmatch,decimate,bwdif \\\n"),
])
edit_once("media3ext/src/main/cpp/CMakeLists.txt", [
    ("avutil avcodec swresample swscale)", "avutil avcodec swresample swscale avfilter)"),
])
import shutil
shutil.copy(pathlib.Path(__file__).parent / "nextlib_filter.h", root / "media3ext/src/main/cpp/jp_filter.h")
cpp = "media3ext/src/main/cpp/ffvideo.cpp"
edit_once(cpp, [
    ("#include <libswscale/swscale.h>\n}",
     "#include <libswscale/swscale.h>\n#include <libavfilter/avfilter.h>\n#include <libavfilter/buffersrc.h>\n"
     "#include <libavfilter/buffersink.h>\n#include <libavutil/dict.h>\n#include <libavutil/mem.h>\n}\n#include <string>\n#include \"jp_filter.h\""),
    ("    std::deque<AVFrame *> pendingFrames;\n",
     "    std::deque<AVFrame *> pendingFrames;\n    VideoFilter filter;\n"),
    ("    jniContext->ClearPendingFrames();\n    avcodec_flush_buffers(context);",
     "    jniContext->ClearPendingFrames();\n    jniContext->filter.Reset();\n    avcodec_flush_buffers(context);"),
    ("    if (result) {\n        av_frame_free(&frame);\n        logError(\"avcodec_receive_frame\", result);\n        return VIDEO_DECODER_ERROR_OTHER;\n    }\n",
     "    if (result) {\n        av_frame_free(&frame);\n        logError(\"avcodec_receive_frame\", result);\n        return VIDEO_DECODER_ERROR_OTHER;\n    }\n"
     "    if (!jniContext->filter.spec.empty()) {\n"
     "        frame = jniContext->filter.Process(frame);\n"
     "        if (!frame) return VIDEO_DECODER_ERROR_INVALID_DATA;   // filter is collecting / dropped it\n"
     "    }\n"),
])
p = root / cpp
p.write_text(p.read_text() + r'''

extern "C"
JNIEXPORT void JNICALL
Java_io_github_anilbeesetti_nextlib_media3ext_ffdecoder_FfmpegVideoDecoder_ffmpegSetFilter(
        JNIEnv *env, jobject, jlong jContext, jstring spec, jint fps_num, jint fps_den) {
    auto *const jniContext = reinterpret_cast<JniContext *>(jContext);
    if (!jniContext) return;
    const char *s = spec ? env->GetStringUTFChars(spec, nullptr) : nullptr;
    jniContext->filter.Set(s, fps_num, fps_den);
    if (s) env->ReleaseStringUTFChars(spec, s);
}

extern "C"
JNIEXPORT void JNICALL
Java_io_github_anilbeesetti_nextlib_media3ext_ffdecoder_FfmpegVideoDecoder_ffmpegFilterStats(
        JNIEnv *env, jobject, jlong jContext, jlongArray out) {
    auto *const jniContext = reinterpret_cast<JniContext *>(jContext);
    if (!jniContext || !out || env->GetArrayLength(out) < 6) return;
    long long v[6];
    jniContext->filter.Stats(v);
    jlong j[6];
    for (int i = 0; i < 6; i++) j[i] = (jlong) v[i];
    env->SetLongArrayRegion(out, 0, 6, j);
}
''')

dec = "media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/FfmpegVideoDecoder.java"
edit_once(dec, [
    ("    private final int rotationDegrees;\n",
     "    private final int rotationDegrees;\n    private String appliedFilter = \"\";\n    private final int fpsNum;\n"
     "    private final int fpsDen;\n    private int filterFrames;\n    private final long[] filterStats = new long[6];\n"),
    ("        rotationDegrees = rotation % 90 == 0 ? (rotation + 360) % 360 : 0;\n",
     "        rotationDegrees = rotation % 90 == 0 ? (rotation + 360) % 360 : 0;\n"
     "        int[] fps = VideoFilter.rational(format.frameRate);\n        fpsNum = fps[0];\n        fpsDen = fps[1];\n"),
    ("        // send packet\n",
     "        String wantFilter = VideoFilter.spec;\n"
     "        if (!wantFilter.equals(appliedFilter)) {\n"
     "            ffmpegSetFilter(nativeContext, wantFilter, fpsNum, fpsDen);\n"
     "            appliedFilter = wantFilter;\n"
     "            filterFrames = 0;\n"
     "        }\n\n        // send packet\n"),
    ("        if (!decodeOnly) {\n            outputBuffer.format = inputBuffer.format;\n",
     "        if (!appliedFilter.isEmpty() && (++filterFrames % 12) == 0) {\n"
     "            ffmpegFilterStats(nativeContext, filterStats);\n"
     "            VideoFilter.publish(appliedFilter, filterStats);\n"
     "        }\n\n"
     "        if (!decodeOnly) {\n            outputBuffer.format = inputBuffer.format;\n"),
    ("    private native long ffmpegInitialize(",
     "    private native void ffmpegSetFilter(long context, String spec, int fpsNum, int fpsDen);\n\n"
     "    private native void ffmpegFilterStats(long context, long[] out);\n\n"
     "    private native long ffmpegInitialize("),
])
shutil.copy(pathlib.Path(__file__).parent / "VideoFilter.java",
            root / "media3ext/src/main/java/io/github/anilbeesetti/nextlib/media3ext/ffdecoder/VideoFilter.java")
print("NextLib patched: video filters (idet, fieldmatch, decimate, bwdif)")
