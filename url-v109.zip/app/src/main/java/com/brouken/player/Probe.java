package com.brouken.player;

import android.net.Uri;
import android.os.SystemClock;
import android.util.Base64;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/**
 * Checks a link before playback the way mpv/VLC effectively do: follow redirects
 * (including http<->https), look at what the server really returns, sniff the first
 * bytes instead of trusting the URL, and measure the real download speed.
 */
public final class Probe {

    public interface Callback {
        void onLog(String line);
        void onDone(Result result);
    }

    public static final class Result {
        public boolean ok;
        public boolean html;
        public String kind = "unknown";
        public String mimeType;          // only set for HLS / DASH
        public String finalUrl;
        public int code;
        public String contentType;
        public long size = -1;
        public boolean seekable;
        public double mbps;
        public String summary = "";
        public String fileName;
        /** Route diagnosis per server (lookup, IPv6 / IPv4 connect times). */
        public final java.util.List<String> routes = new java.util.ArrayList<>();
    }

    private static final int MAX_REDIRECTS = 10;
    private static final long SPEED_TEST_MS = 3000;
    private static final int SPEED_TEST_BYTES = 24 * 1024 * 1024;

    private Probe() {}

    public static void start(final String url, final Callback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Result r;
                try {
                    r = probe(url, cb);
                } catch (Throwable t) {
                    r = new Result();
                    r.summary = "Probe failed: " + Diag.describe(t);
                    cb.onLog("✗ " + r.summary);
                }
                cb.onDone(r);
            }
        }, "link-probe").start();
    }

    /**
     * "Route host: lookup 40 ms · IPv6 2a01:… 3000 ms ✗ · IPv4 1.2.3.4 25 ms" – a slow or broken
     * route (often IPv6) makes every connection wait seconds and can make it slow.
     */
    static String routes(String host, int port) {
        StringBuilder sb = new StringBuilder("Route " + host + ": ");
        long t0 = SystemClock.elapsedRealtime();
        java.net.InetAddress[] all;
        try {
            all = java.net.InetAddress.getAllByName(host);
        } catch (Exception e) {
            return sb.append("lookup failed (").append(e.getClass().getSimpleName()).append(")").toString();
        }
        sb.append("lookup ").append(SystemClock.elapsedRealtime() - t0).append(" ms");
        java.net.InetAddress v6 = null, v4 = null;
        for (java.net.InetAddress a : all) {
            if (a instanceof java.net.Inet6Address && v6 == null) v6 = a;
            if (a instanceof java.net.Inet4Address && v4 == null) v4 = a;
        }
        if (all.length > 0) sb.append(" · first ").append(all[0] instanceof java.net.Inet6Address ? "IPv6" : "IPv4");
        for (java.net.InetAddress a : new java.net.InetAddress[]{v6, v4}) {
            if (a == null) continue;
            sb.append(" · ").append(a instanceof java.net.Inet6Address ? "IPv6 " : "IPv4 ").append(a.getHostAddress()).append(' ');
            long t = SystemClock.elapsedRealtime();
            try (java.net.Socket so = new java.net.Socket()) {
                so.connect(new java.net.InetSocketAddress(a, port), 4000);
                sb.append(SystemClock.elapsedRealtime() - t).append(" ms");
            } catch (Exception e) {
                sb.append("✗ ").append(e instanceof java.net.SocketTimeoutException ? "no answer in 4 s" : e.getClass().getSimpleName());
            }
        }
        if (v6 == null) sb.append(" · no IPv6");
        return sb.toString();
    }

    private static Result probe(String url, Callback cb) throws Exception {
        Result r = new Result();
        String current = url;
        String auth = null;
        String userInfo = Uri.parse(url).getUserInfo();
        if (userInfo != null && userInfo.contains(":")) {
            auth = "Basic " + Base64.encodeToString(userInfo.getBytes(), Base64.NO_WRAP);
        }

        HttpURLConnection conn = null;
        java.util.Set<String> routed = new java.util.HashSet<>();
        for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
            URL u = new URL(current);
            if (routed.add(u.getHost())) {
                // diagnosis: how long the address lookup and a plain connection take, per route
                String line = routes(u.getHost(), u.getPort() > 0 ? u.getPort() : u.getDefaultPort());
                cb.onLog(line);
                r.routes.add(line);
            }
            cb.onLog("→ GET " + Diag.shorten(u.getHost() + u.getPath()));
            conn = (HttpURLConnection) u.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(NetCompat.TIMEOUT_MS / 2);
            conn.setReadTimeout(NetCompat.TIMEOUT_MS / 2);
            conn.setRequestProperty("User-Agent", NetCompat.USER_AGENT);
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Range", "bytes=0-");
            if (auth != null) conn.setRequestProperty("Authorization", auth);

            long t0 = SystemClock.elapsedRealtime();
            int code = conn.getResponseCode();
            long ms = SystemClock.elapsedRealtime() - t0;
            r.code = code;

            if (code >= 300 && code < 400) {
                String loc = conn.getHeaderField("Location");
                conn.disconnect();
                if (loc == null) {
                    cb.onLog("✗ HTTP " + code + " redirect without Location");
                    r.summary = "Broken redirect (HTTP " + code + ")";
                    return r;
                }
                URL next = new URL(u, loc);
                boolean switched = !next.getProtocol().equalsIgnoreCase(u.getProtocol());
                cb.onLog("← " + code + " in " + ms + " ms, redirect → " + next.getHost() + (switched ? " (" + u.getProtocol() + "→" + next.getProtocol() + ", now followed)" : ""));
                current = next.toString();
                continue;
            }

            r.finalUrl = current;
            r.contentType = conn.getContentType();
            r.fileName = Titles.fromContentDisposition(conn.getHeaderField("Content-Disposition"));
            if (r.fileName == null) r.fileName = Titles.fromUrl(Uri.parse(current));
            if (r.fileName != null) cb.onLog("Name: " + r.fileName);
            String range = conn.getHeaderField("Content-Range");
            r.seekable = code == 206;
            if (range != null && range.contains("/")) {
                try { r.size = Long.parseLong(range.substring(range.lastIndexOf('/') + 1).trim()); } catch (NumberFormatException ignored) { }
            }
            if (r.size < 0) {
                String cl = conn.getHeaderField("Content-Length");
                if (cl != null) try { r.size = Long.parseLong(cl.trim()); } catch (NumberFormatException ignored) { }
            }
            cb.onLog("← HTTP " + code + " in " + ms + " ms · " + (r.contentType != null ? r.contentType : "no type")
                    + (r.size > 0 ? " · " + Diag.mb(r.size) : ""));

            if (code >= 400) {
                String body = readText(conn);
                cb.onLog("✗ Server refused: HTTP " + code + (body.isEmpty() ? "" : " · " + body));
                r.summary = "Server error HTTP " + code;
                conn.disconnect();
                return r;
            }
            break;
        }
        if (r.finalUrl == null) {
            cb.onLog("✗ Too many redirects");
            r.summary = "Too many redirects";
            return r;
        }

        // Read the start of the body: sniff the format and measure throughput.
        InputStream in = conn.getInputStream();
        byte[] head = new byte[4096];
        int headLen = 0;
        byte[] buf = new byte[256 * 1024];
        long total = 0;
        long start = SystemClock.elapsedRealtime();
        long firstByteMs = -1;
        while (true) {
            int n = in.read(buf);
            if (n < 0) break;
            if (firstByteMs < 0) firstByteMs = SystemClock.elapsedRealtime() - start;
            if (headLen < head.length) {
                int c = Math.min(n, head.length - headLen);
                System.arraycopy(buf, 0, head, headLen, c);
                headLen += c;
            }
            total += n;
            long el = SystemClock.elapsedRealtime() - start;
            if (el >= SPEED_TEST_MS || total >= SPEED_TEST_BYTES) break;
        }
        long elapsed = Math.max(1, SystemClock.elapsedRealtime() - start);
        try { in.close(); } catch (Exception ignored) { }
        conn.disconnect();
        r.mbps = total * 8.0 / 1_000_000.0 / (elapsed / 1000.0);

        sniff(r, head, headLen);
        cb.onLog("Format: " + r.kind + (r.seekable ? " · seeking supported" : " · server ignores Range (no seeking)"));
        cb.onLog(String.format(Locale.US, "Speed: %.1f Mbit/s (first byte %d ms)", r.mbps, firstByteMs));
        if (r.mbps < 40 && !r.html && r.mimeType == null && total >= 1_000_000) {
            cb.onLog("⚠ Under ~40 Mbit/s: 4K remuxes will likely buffer");
        }

        if (r.html) {
            cb.onLog("✗ This link returns a web page, not a video file");
            r.summary = "Web page, not a video";
            return r;
        }
        r.ok = true;
        r.summary = String.format(Locale.US, "Probe: HTTP %d · %s%s · %.0f Mbit/s%s", r.code, r.kind,
                r.size > 0 ? " · " + Diag.mb(r.size) : "", r.mbps, r.seekable ? " · seek ok" : " · no seek");
        return r;
    }

    private static void sniff(Result r, byte[] h, int len) {
        String ct = r.contentType == null ? "" : r.contentType.toLowerCase(Locale.US);
        String text = new String(h, 0, Math.min(len, 1024), java.nio.charset.StandardCharsets.ISO_8859_1);
        String lower = text.toLowerCase(Locale.US).trim();

        if (text.startsWith("#EXTM3U") || ct.contains("mpegurl")) {
            r.kind = "HLS playlist";
            r.mimeType = "application/x-mpegURL";
        } else if (lower.contains("<mpd") || ct.contains("dash+xml")) {
            r.kind = "DASH manifest";
            r.mimeType = "application/dash+xml";
        } else if (len >= 4 && (h[0] & 0xFF) == 0x1A && (h[1] & 0xFF) == 0x45 && (h[2] & 0xFF) == 0xDF && (h[3] & 0xFF) == 0xA3) {
            r.kind = "Matroska/WebM";
        } else if (len >= 8 && h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p') {
            r.kind = "MP4/MOV";
        } else if (len > 188 && h[0] == 0x47 && h[188] == 0x47) {
            r.kind = "MPEG-TS";
        } else if (lower.startsWith("<!doctype html") || lower.startsWith("<html") || ct.contains("text/html")) {
            r.kind = "HTML page";
            r.html = true;
        }
    }

    private static String readText(HttpURLConnection conn) {
        try {
            InputStream es = conn.getErrorStream();
            if (es == null) return "";
            byte[] b = new byte[600];
            int n = es.read(b);
            es.close();
            if (n <= 0) return "";
            String s = new String(b, 0, n, "UTF-8").replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim();
            return s.length() > 160 ? s.substring(0, 160) + "…" : s;
        } catch (Exception e) {
            return "";
        }
    }
}
