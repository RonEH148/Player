package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The "Checking link…" dialog. It belongs to whichever screen opens it: the paste box, or the
 * player's own start screen (Continue watching). Before, Continue watching opened it in a separate
 * see-through window in a new task; on the TV that window could end up without the remote's focus,
 * so neither button could be reached and only Back worked.
 */
final class LinkCheck {

    interface Listener {
        void play(String url, String mimeType);
        void cancel();
        boolean gone();
    }

    private LinkCheck() { }

    static void run(final Activity a, String raw, final Listener l) {
        final String url = PasteUrlActivity.normalize(raw);
        if (!url.toLowerCase(Locale.US).startsWith("http")) {
            l.play(url, null);   // rtsp: nothing to probe
            return;
        }

        final List<String> lines = new ArrayList<>();
        final TextView log = new TextView(a);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        final boolean tv = Utils.isTvBox(a);
        // selectable text (to copy the log) only on touch screens: on the TV it took the remote's focus
        if (!tv) log.setTextIsSelectable(true);
        int pad = dp(a, 20);
        log.setPadding(pad, dp(a, 8), pad, dp(a, 8));
        log.setText("Checking link…");
        ScrollView scroll = new ScrollView(a);
        scroll.addView(log);
        if (tv) {
            scroll.setFocusable(false);
            scroll.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        }

        final boolean[] closed = {false};
        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Checking link…")
                .setView(scroll)
                .setPositiveButton("Play anyway", null)
                .setNegativeButton("Cancel", (d, w) -> { closed[0] = true; l.cancel(); })
                .setOnCancelListener(d -> { closed[0] = true; l.cancel(); })
                .create();
        final Probe.Result[] holder = new Probe.Result[1];

        // The remote must always land on a button: whenever a key arrives and nothing in the
        // dialog has focus, put it on Cancel (or Play anyway) and use that key for it.
        dialog.setOnKeyListener((d, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN || code == KeyEvent.KEYCODE_BACK) return false;
            if (dialog.getCurrentFocus() != null) return false;
            return focusButton(dialog);
        });

        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
            }
            for (int which : new int[]{AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_POSITIVE}) {
                Button b = dialog.getButton(which);
                if (b != null) b.setFocusable(true);
            }
            focusButton(dialog);
            // once more after the window has really taken focus (slow TVs)
            View decor = dialog.getWindow() != null ? dialog.getWindow().getDecorView() : null;
            if (decor != null) decor.postDelayed(() -> { if (dialog.getCurrentFocus() == null) focusButton(dialog); }, 300);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                Probe.Result r = holder[0];
                Diag.setProbe(url, probeLines(r, lines));
                closed[0] = true;
                dialog.setOnCancelListener(null);
                dialog.dismiss();
                l.play(url, r != null ? r.mimeType : null);
            });
        });
        dialog.show();

        Probe.start(url, new Probe.Callback() {
            @Override
            public void onLog(final String line) {
                a.runOnUiThread(() -> {
                    lines.add(line);
                    log.setText(PasteUrlActivity.join(lines));
                });
            }

            @Override
            public void onDone(final Probe.Result r) {
                a.runOnUiThread(() -> {
                    holder[0] = r;
                    Decoder.rememberSize(a, url, r.size);
                    // the server can't seek: start in linear mode right away
                    if (r.ok && !r.seekable && r.code == 200) RangeSupport.markLinear(android.net.Uri.parse(url));
                    if (closed[0] || l.gone() || !dialog.isShowing()) return;
                    if (r.ok) {
                        lines.add("✓ Looks playable, starting…");
                        log.setText(PasteUrlActivity.join(lines));
                        Diag.setProbe(url, probeLines(r, lines));
                        log.postDelayed(() -> {
                            if (closed[0] || l.gone() || !dialog.isShowing()) return;
                            closed[0] = true;
                            dialog.setOnCancelListener(null);
                            dialog.dismiss();
                            l.play(url, r.mimeType);
                        }, 700);
                    } else {
                        dialog.setTitle("Problem with this link");
                        Button b = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                        if (b != null) b.setText("Play anyway");
                        if (PasteUrlActivity.isTemporary(url)) {
                            lines.add("This address only works while the browser is playing it. Open the video from the browser again.");
                            log.setText(PasteUrlActivity.join(lines));
                        }
                        if (dialog.getCurrentFocus() == null || !(dialog.getCurrentFocus() instanceof Button)) focusButton(dialog);
                    }
                });
            }
        });
    }

    private static boolean focusButton(AlertDialog dialog) {
        Button c = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        if (c != null && c.getVisibility() == View.VISIBLE) {
            c.setFocusableInTouchMode(false);
            if (c.requestFocus()) return true;
        }
        Button p = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        return p != null && p.requestFocus();
    }

    static List<String> probeLines(Probe.Result r, List<String> lines) {
        List<String> out = new ArrayList<>();
        if (r != null) out.addAll(r.routes);   // also in the ⓘ overlay
        if (r != null && r.summary != null && !r.summary.isEmpty()) {
            out.add(r.summary);
        } else if (!lines.isEmpty()) {
            out.add("Probe: " + lines.get(lines.size() - 1));
        }
        return out;
    }

    private static int dp(Activity a, int v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
