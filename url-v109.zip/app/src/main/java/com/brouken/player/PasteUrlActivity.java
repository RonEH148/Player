package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Paste a link, check it, then hand it to PlayerActivity. */
public class PasteUrlActivity extends Activity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(base);
        ThemeMode.override(this, base);   // Gamma Player: light / dark dialogs (Settings → Theme)
    }


    /** A link to check and play right away (from Saved links). */
    static final String EXTRA_URL = "url";

    private boolean handled;
    private boolean finished;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || handled) return;
        handled = true;
        // Saved links → Play: straight to the link check
        String given = getIntent() != null ? getIntent().getStringExtra(EXTRA_URL) : null;
        if (given != null && isValid(given)) {
            check(given);
            return;
        }
        // URL build: the box always starts empty (no clipboard / last link filled in or played)
        showInput(null);
    }

    // ------------------------------------------------------------ input box

    private void showInput(String prefill) {
        final EditText input = new EditText(this);
        input.setHint("Paste a link (http, https or rtsp)");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        if (prefill != null) {
            input.setText(prefill);
            input.setSelection(prefill.length());   // whole link, cursor at the end, nothing highlighted
        }
        FrameLayout box = new FrameLayout(this);
        int pad = dp(20);
        box.setPadding(pad, dp(8), pad, 0);
        box.addView(input);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Open link")
                .setView(box)
                .setPositiveButton("Play", null)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { done(); }
                })
                .setNeutralButton("Saved links", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Intent i = new Intent(PasteUrlActivity.this, SavedLinksActivity.class);
                        startActivity(i);
                        done();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) { done(); }
                })
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                Button cancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                if (cancel != null) cancel.requestFocus();   // the remote starts on a button
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = input.getText().toString().trim();
                        if (isValid(url)) {
                            dialog.setOnCancelListener(null);
                            dialog.dismiss();
                            check(url);
                        } else {
                            input.setError("That isn't a valid http, https or rtsp link");
                        }
                    }
                });
            }
        });
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        dialog.show();
        input.requestFocus();
    }

    private static final String KEY_LAST = "lastPastedUrl";

    private String lastUrl() {
        return android.preference.PreferenceManager.getDefaultSharedPreferences(this).getString(KEY_LAST, null);
    }

    // ------------------------------------------------------------ link check

    private void check(String raw) {
        LinkCheck.run(this, raw, new LinkCheck.Listener() {
            @Override public void play(String url, String mime) { PasteUrlActivity.this.play(url, mime); }
            @Override public void cancel() { done(); }
            @Override public boolean gone() { return finished || isFinishing(); }
        });
    }

    private void play(String url, String mimeType) {
        launchPlayer(this, url, mimeType);
        done();
    }

    /** Hand a checked link to the player (also used straight from the start screen). */
    static void launchPlayer(Context c, String url, String mimeType) {
        android.preference.PreferenceManager.getDefaultSharedPreferences(c).edit().putString(KEY_LAST, url).apply();
        Lifecycle.clear(c);
        Decoder.clearOverride(c);
        Lifecycle.markFreshStart(c, url);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if (mimeType != null) {
            intent.setDataAndType(Uri.parse(url), mimeType);
        } else {
            intent.setData(Uri.parse(url));
        }
        intent.setClassName(c, "com.brouken.player.PlayerActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(intent);
    }

    private void done() {
        finished = true;
        finish();
    }

    // ------------------------------------------------------------ helpers

    private String readClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return null;
            CharSequence t = clip.getItemAt(0).coerceToText(this);
            if (t == null) return null;
            String s = t.toString().trim();
            return isValid(s) ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * A temporary address on this device (127.0.0.1, localhost): a browser's own stream relay that
     * only works while the browser is showing that video. Never kept in history or saved links.
     */
    static boolean isTemporary(String s) {
        if (s == null) return false;
        try {
            String h = Uri.parse(s).getHost();
            if (h == null) return false;
            h = h.toLowerCase(Locale.US);
            return h.equals("localhost") || h.startsWith("127.") || h.equals("::1") || h.equals("[::1]") || h.equals("0.0.0.0");
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isValid(String s) {
        if (s == null || s.isEmpty() || s.indexOf(' ') >= 0 || s.indexOf('\n') >= 0) return false;
        String l = s.toLowerCase(Locale.US);
        return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("rtsp://");
    }

    /** Official Pixeldrain share pages (/u/ID) → direct file links (/api/file/ID), always https. */
    public static String normalize(String s) {
        try {
            Uri u = Uri.parse(s);
            String host = u.getHost();
            if (host == null) return s;
            host = host.toLowerCase(Locale.US);
            if (!(host.equals("pixeldrain.com") || host.equals("www.pixeldrain.com") || host.equals("pixeldra.in"))) {
                return s;
            }
            List<String> seg = u.getPathSegments();
            if (seg.size() >= 2 && "u".equals(seg.get(0))) {
                return "https://pixeldrain.com/api/file/" + seg.get(1);
            }
            if (s.startsWith("http://")) {
                return "https://" + s.substring(7);
            }
        } catch (Exception ignored) { }
        return s;
    }

    static String join(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(l);
        }
        return sb.toString();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
