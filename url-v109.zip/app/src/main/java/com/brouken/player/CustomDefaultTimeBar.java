package com.brouken.player;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.annotation.Nullable;
import androidx.media3.ui.DefaultTimeBar;

import java.lang.reflect.Field;

class CustomDefaultTimeBar extends DefaultTimeBar {

    Rect scrubberBar;
    private boolean scrubbing;
    private int scrubbingStartX;

    public CustomDefaultTimeBar(Context context) {
        this(context, null);
    }

    public CustomDefaultTimeBar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomDefaultTimeBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, attrs);
    }

    public CustomDefaultTimeBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr, @Nullable AttributeSet timebarAttrs) {
        this(context, attrs, defStyleAttr, timebarAttrs, 0);
    }

    public CustomDefaultTimeBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr, @Nullable AttributeSet timebarAttrs, int defStyleRes) {
        super(context, attrs, defStyleAttr, timebarAttrs, defStyleRes);
        try {
            Field field = DefaultTimeBar.class.getDeclaredField("scrubberBar");
            field.setAccessible(true);
            scrubberBar = (Rect) field.get(this);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    // A touch away from the round handle: wait to see what it is. A tap jumps straight there
    // (seeks on linear links still stop at the end of what's loaded); a slide starts dragging from
    // where the finger went down. Touches on the handle drag it as before.
    private boolean pending;
    private float downX, downY;
    private long downTime;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled() || scrubberBar == null) return super.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pending = false;
                scrubbing = false;
                scrubbingStartX = (int) event.getX();
                if (Math.abs(scrubberBar.right - scrubbingStartX) > Utils.dpToPx(24)) {
                    pending = true;
                    downX = event.getX();
                    downY = event.getY();
                    downTime = event.getDownTime();
                    return true;
                }
                scrubbing = true;
                return super.onTouchEvent(event);
            case MotionEvent.ACTION_MOVE:
                if (pending) {
                    if (Math.abs(event.getX() - downX) <= Utils.dpToPx(6)) return true;
                    pending = false;
                    scrubbing = true;
                    replayDown();
                }
                return super.onTouchEvent(event);
            case MotionEvent.ACTION_UP:
                if (pending) {
                    pending = false;
                    // a tap: press and let go at the same spot
                    replayDown();
                    MotionEvent up = MotionEvent.obtain(downTime, event.getEventTime(), MotionEvent.ACTION_UP, downX, downY, 0);
                    boolean r = super.onTouchEvent(up);
                    up.recycle();
                    return r;
                }
                return super.onTouchEvent(event);
            case MotionEvent.ACTION_CANCEL:
                if (pending) { pending = false; return true; }
                return super.onTouchEvent(event);
            default:
                return pending || super.onTouchEvent(event);
        }
    }

    private void replayDown() {
        MotionEvent down = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, downX, downY, 0);
        super.onTouchEvent(down);
        down.recycle();
    }
}
