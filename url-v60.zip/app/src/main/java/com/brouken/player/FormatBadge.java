package com.brouken.player;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.MediaFormat;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;

/**
 * When a video starts (tablet only; the TV shows its own logo): its HDR format appears for a
 * few seconds in the top right corner as a small emblem, the way the video is really played
 * (Dolby Vision that plays as its HDR10 base layer shows HDR10). Nothing for SDR.
 * The emblems are the app's own design: a symbol, the format name and a short description.
 */
final class FormatBadge {

    private FormatBadge() {}

    static final int DV = 1, HDR10_PLUS = 2, HDR10 = 3, HLG = 4;

    private static Emblem view;
    private static String shownFor;
    private static volatile boolean decoderHdr10Plus;

    /** From the video renderer: the decoder reports HDR10+ metadata in the stream. */
    static void onOutputFormat(MediaFormat mf) {
        try {
            if (mf != null && mf.containsKey("hdr10-plus-info")) decoderHdr10Plus = true;
        } catch (Throwable ignored) { }
    }

    /** Player (re)built: the decoder reports HDR10+ again. */
    static void newMedia() {
        decoderHdr10Plus = false;
    }

    /** Video closed: the next one (even the same link again) shows its badge. */
    static void reset() {
        shownFor = null;
        decoderHdr10Plus = false;
        if (view != null) {
            view.animate().cancel();
            view.setVisibility(View.GONE);
        }
    }

    /** First frame on screen. */
    static void show(Activity a) {
        if (!(a instanceof PlayerActivity) || PlayerActivity.player == null) return;
        if (Utils.isTvBox(a)) return;   // the TV shows its own Dolby Vision / HDR logo
        PlayerActivity pa = (PlayerActivity) a;
        String uri = pa.mPrefs != null && pa.mPrefs.mediaUri != null ? pa.mPrefs.mediaUri.toString() : null;
        if (uri == null || uri.equals(shownFor)) return;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 24 && a.isInPictureInPictureMode()) return;
        } catch (Throwable ignored) { }
        int kind = kind(PlayerActivity.player.getVideoFormat(), Diag.videoDecoderName());
        shownFor = uri;
        if (kind == 0) return;
        try {
            final Emblem v = view(a);
            v.setKind(kind);
            v.animate().cancel();
            v.setAlpha(0f);
            v.setScaleX(0.92f);
            v.setScaleY(0.92f);
            v.setVisibility(View.VISIBLE);
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(320).withEndAction(() ->
                    v.animate().alpha(0f).setStartDelay(3000).setDuration(500)
                            .withEndAction(() -> v.setVisibility(View.GONE)).start()).start();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    static int kind(Format f, String decoder) {
        if (f == null) return 0;
        String d = decoder == null ? "" : decoder.toLowerCase(java.util.Locale.US);
        boolean dvDecoder = d.contains("dolby") || d.contains("dvhe") || d.contains("dvav") || d.contains(".dv.");
        int transfer = f.colorInfo != null ? f.colorInfo.colorTransfer : Format.NO_VALUE;
        if (MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType)) {
            if (dvDecoder) return DV;
            if (transfer == C.COLOR_TRANSFER_HLG) return HLG;
            if (transfer == C.COLOR_TRANSFER_SDR) return 0;
            return decoderHdr10Plus ? HDR10_PLUS : HDR10;   // Dolby Vision without a DV decoder: its HDR10 base
        }
        if (transfer == C.COLOR_TRANSFER_ST2084) return decoderHdr10Plus ? HDR10_PLUS : HDR10;
        if (transfer == C.COLOR_TRANSFER_HLG) return HLG;
        return 0;
    }

    private static Emblem view(Activity a) {
        if (view != null && view.getContext() == a) return view;
        float dp = a.getResources().getDisplayMetrics().density;
        Emblem e = new Emblem(a);
        e.setVisibility(View.GONE);
        e.setClickable(false);
        e.setFocusable(false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        lp.topMargin = (int) (24 * dp);
        lp.rightMargin = (int) (28 * dp);
        a.addContentView(e, lp);
        e.setPivotX(0);   // grows from its right edge (set again after layout)
        view = e;
        return e;
    }

    // ------------------------------------------------------------------ the emblem

    private static final class Emblem extends View {
        private final float dp;
        private int kind = HDR10;
        private String title = "", sub = "";
        private int c1, c2, accent, accent2;

        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sym = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint titleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final Path path = new Path();

        private final float height, padH, icon, gap, radius;

        Emblem(Context c) {
            super(c);
            dp = c.getResources().getDisplayMetrics().density;
            float sp = c.getResources().getDisplayMetrics().scaledDensity;
            height = 50 * dp;
            padH = 14 * dp;
            icon = 28 * dp;
            gap = 11 * dp;
            radius = 10 * dp;
            titleP.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            titleP.setTextSize(16 * sp);
            titleP.setLetterSpacing(0.10f);
            titleP.setColor(0xFFFFFFFF);
            subP.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            subP.setTextSize(9.5f * sp);
            subP.setLetterSpacing(0.14f);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(1.2f * dp);
            sym.setStrokeCap(Paint.Cap.ROUND);
            sym.setStrokeJoin(Paint.Join.ROUND);
            setLayerType(LAYER_TYPE_SOFTWARE, null);   // for the glow / shadow
        }

        void setKind(int k) {
            kind = k;
            switch (k) {
                case DV:
                    title = "DOLBY VISION"; sub = "DYNAMIC HDR";
                    c1 = 0xFF3A1C71; c2 = 0xFF0C0716; accent = 0xFFC3A6FF; accent2 = 0xFF7F5CFF;
                    break;
                case HDR10_PLUS:
                    title = "HDR10+"; sub = "DYNAMIC HDR";
                    c1 = 0xFF4A3400; c2 = 0xFF0E0B05; accent = 0xFFFFD36B; accent2 = 0xFFFF9F1C;
                    break;
                case HLG:
                    title = "HLG"; sub = "HYBRID LOG-GAMMA";
                    c1 = 0xFF00433F; c2 = 0xFF051312; accent = 0xFF6FF2DA; accent2 = 0xFF1FB8A0;
                    break;
                default:
                    title = "HDR10"; sub = "HIGH DYNAMIC RANGE";
                    c1 = 0xFF0E3460; c2 = 0xFF060B16; accent = 0xFF8CCBFF; accent2 = 0xFF3D8BFF;
            }
            subP.setColor((accent & 0x00FFFFFF) | 0xD0000000);
            requestLayout();
            invalidate();
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            float text = Math.max(titleP.measureText(title), subP.measureText(sub));
            int w = (int) Math.ceil(padH + icon + gap + text + padH + 4 * dp);
            int h = (int) Math.ceil(height + 8 * dp);   // room for the glow
            setMeasuredDimension(w, h);
            setPivotX(w);
            setPivotY(0);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), m = 4 * dp;
            r.set(m, m, w - m, m + height - 4 * dp);
            // shadow + background
            bg.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom, c1, c2, Shader.TileMode.CLAMP));
            bg.setShadowLayer(6 * dp, 0, 1.5f * dp, 0x99000000);
            c.drawRoundRect(r, radius, radius, bg);
            // soft light behind the symbol
            float cx = r.left + padH - 2 * dp + icon / 2, cy = r.centerY();
            glow.setShader(new RadialGradient(cx, cy, icon * 1.3f, (accent2 & 0x00FFFFFF) | 0x66000000, 0x00000000, Shader.TileMode.CLAMP));
            c.save();
            c.clipRect(r);
            c.drawCircle(cx, cy, icon * 1.3f, glow);
            c.restore();
            // border: bright at the top, fading down
            border.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                    (accent & 0x00FFFFFF) | 0xCC000000, (accent2 & 0x00FFFFFF) | 0x40000000, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, radius, radius, border);
            // symbol
            drawSymbol(c, cx, cy, icon / 2);
            // text
            float tx = r.left + padH - 2 * dp + icon + gap;
            Paint.FontMetrics ft = titleP.getFontMetrics(), fs = subP.getFontMetrics();
            float th = -ft.ascent, sh = -fs.ascent;
            float block = th + 3 * dp + sh;
            float top = cy - block / 2;
            titleP.setShadowLayer(3 * dp, 0, 0, (accent2 & 0x00FFFFFF) | 0x80000000);
            c.drawText(title, tx, top + th, titleP);
            c.drawText(sub, tx, top + th + 3 * dp + sh, subP);
        }

        private void drawSymbol(Canvas c, float cx, float cy, float s) {
            sym.setShader(new LinearGradient(cx - s, cy - s, cx + s, cy + s, accent, accent2, Shader.TileMode.CLAMP));
            switch (kind) {
                case DV: {
                    // a prism splitting a ray of light into a fan
                    sym.setStyle(Paint.Style.STROKE);
                    sym.setStrokeWidth(1.8f * dp);
                    path.reset();
                    path.moveTo(cx - 0.15f * s, cy - 0.85f * s);
                    path.lineTo(cx + 0.55f * s, cy + 0.65f * s);
                    path.lineTo(cx - 0.85f * s, cy + 0.65f * s);
                    path.close();
                    c.drawPath(path, sym);
                    sym.setStrokeWidth(1.4f * dp);
                    c.drawLine(cx - 1.05f * s, cy - 0.05f * s, cx - 0.45f * s, cy + 0.05f * s, sym);
                    int[] fan = {0xFFFF6B9A, 0xFFFFD36B, 0xFF6FF2DA, 0xFF8CCBFF};
                    sym.setShader(null);
                    for (int i = 0; i < fan.length; i++) {
                        sym.setColor(fan[i]);
                        float a = -0.35f + i * 0.23f;
                        c.drawLine(cx + 0.25f * s, cy + 0.1f * s,
                                cx + 1.05f * s, cy + 0.1f * s + a * s, sym);
                    }
                    break;
                }
                case HLG: {
                    // a broadcast wave under a small sun
                    sym.setStyle(Paint.Style.STROKE);
                    sym.setStrokeWidth(2f * dp);
                    path.reset();
                    float y = cy + 0.35f * s;
                    path.moveTo(cx - s, y);
                    path.cubicTo(cx - 0.6f * s, y - 0.55f * s, cx - 0.2f * s, y - 0.55f * s, cx, y);
                    path.cubicTo(cx + 0.2f * s, y + 0.55f * s, cx + 0.6f * s, y + 0.55f * s, cx + s, y);
                    c.drawPath(path, sym);
                    sym.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy - 0.45f * s, 0.32f * s, sym);
                    break;
                }
                case HDR10: {
                    // the sun rising over the horizon
                    sym.setStyle(Paint.Style.FILL);
                    float hy = cy + 0.35f * s;
                    c.save();
                    c.clipRect(cx - s, cy - s, cx + s, hy - 0.12f * s);
                    c.drawCircle(cx, hy, 0.5f * s, sym);
                    c.restore();
                    sym.setStyle(Paint.Style.STROKE);
                    sym.setStrokeWidth(1.8f * dp);
                    for (int i = 0; i < 5; i++) {
                        double a = Math.PI + Math.PI * (i + 1) / 6.0;
                        c.drawLine(cx + (float) Math.cos(a) * 0.7f * s, hy + (float) Math.sin(a) * 0.7f * s,
                                cx + (float) Math.cos(a) * 0.98f * s, hy + (float) Math.sin(a) * 0.98f * s, sym);
                    }
                    c.drawLine(cx - s, hy + 0.05f * s, cx + s, hy + 0.05f * s, sym);
                    break;
                }
                default: {
                    // HDR10+: a full sun with alternating long and short rays
                    sym.setStyle(Paint.Style.FILL);
                    c.drawCircle(cx, cy, 0.42f * s, sym);
                    sym.setStyle(Paint.Style.STROKE);
                    sym.setStrokeWidth(1.8f * dp);
                    for (int i = 0; i < 12; i++) {
                        double a = Math.PI * 2 * i / 12.0;
                        float inner = 0.62f * s, outer = (i % 2 == 0 ? 1.0f : 0.82f) * s;
                        c.drawLine(cx + (float) Math.cos(a) * inner, cy + (float) Math.sin(a) * inner,
                                cx + (float) Math.cos(a) * outer, cy + (float) Math.sin(a) * outer, sym);
                    }
                }
            }
            sym.setShader(null);
        }
    }
}
