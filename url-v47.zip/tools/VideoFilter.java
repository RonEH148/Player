package io.github.anilbeesetti.nextlib.media3ext.ffdecoder;

/**
 * Just Player URL: FFmpeg filter graph applied after the software (FFmpeg) video decoder.
 * Set {@link #spec} to an FFmpeg filter chain (e.g. "idet" or
 * "fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate"), "" for none.
 * The running decoder picks the change up on its next frame, without restarting playback.
 */
public final class VideoFilter {

    private VideoFilter() {}

    public static volatile String spec = "";

    /** false = AV1 film grain synthesis off (dav1d exports the grain parameters instead). Read when the decoder starts. */
    public static volatile boolean applyFilmGrain = true;

    /** Frame rate measured by the app, used when the file doesn't state one (needed by decimate). */
    public static volatile float fpsHint;

    private static volatile String statsSpec = "";
    private static volatile long[] stats = new long[12];
    private static volatile String error = "";

    static void publish(String forSpec, long[] values, String err) {
        stats = values.clone();
        error = err == null ? "" : err;
        statsSpec = forSpec;
    }

    private static volatile String patternSpec = "";
    private static volatile byte[] pattern = new byte[0];

    static void publishPattern(String forSpec, byte[] p) {
        pattern = p == null ? new byte[0] : p;
        patternSpec = forSpec;
    }

    /**
     * Per-frame idet results (in order): bits 0-1 repeated field (0 none, 1 top, 2 bottom),
     * bits 2-3 frame type (0 undetermined, 1 tff, 2 bff, 3 progressive).
     */
    public static byte[] pattern(String forSpec) {
        return forSpec.equals(patternSpec) ? pattern.clone() : new byte[0];
    }

    /** Why FFmpeg couldn't run the filter ("" if it runs). */
    public static String error() {
        return error;
    }

    /** Forget earlier counts (new video). */
    public static void clearStats() {
        statsSpec = "";
        patternSpec = "";
        pattern = new byte[0];
        error = "";
        stats = new long[12];
    }

    /**
     * Counts for the given filter chain: idet top-field-first, bottom-field-first, progressive,
     * undetermined frames; frames into the filter; status (1 running, -1 failed, 0 not running);
     * frames out of the filter; frames coded interlaced; frames coded in total; frames coded top-field-first; frames with repeat-field flags (soft telecine); median frame duration in µs (0 = not yet).
     */
    public static long[] stats(String forSpec) {
        return forSpec.equals(statsSpec) ? stats.clone() : new long[12];
    }

    /** Frame rate as a fraction; NTSC rates exact. {0,1} when unknown. */
    static int[] rational(float fps) {
        if (!(fps > 0)) return new int[] {0, 1};
        if (Math.abs(fps - 23.976f) < 0.01f) return new int[] {24000, 1001};
        if (Math.abs(fps - 29.97f) < 0.02f) return new int[] {30000, 1001};
        if (Math.abs(fps - 59.94f) < 0.03f) return new int[] {60000, 1001};
        return new int[] {Math.round(fps * 1000), 1000};
    }
}
