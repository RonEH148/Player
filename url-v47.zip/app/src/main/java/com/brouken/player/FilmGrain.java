package com.brouken.player;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;

import java.util.List;
import java.util.Locale;

import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.VideoFilter;

/**
 * AV1 film grain synthesis. AV1 encoders often strip grain/noise and store a description of it;
 * the decoder re-creates it with random noise on every frame. On old SD anime this "grain" is
 * modelled noise from the analog source and shows up as crawling vertical streaks.
 *
 * film-grain=auto (default): drop the synthesized grain on AV1 videos up to film-grain-max-height
 *                            (SD) whose stream says it carries grain; keep it on HD (films).
 * film-grain=no            : never add it (every AV1 video with grain)
 * film-grain=yes           : always add it, like other players
 *
 * Dropping it needs the FFmpeg (dav1d) decoder: Android's hardware AV1 decoders always add it.
 */
final class FilmGrain {

    private FilmGrain() {}

    private static String uri;
    private static boolean drop;
    private static boolean weSwitched;
    private static boolean decided;

    private static SharedPreferences memory(Context c) {
        return c.getSharedPreferences("filmgrain_memory", Context.MODE_PRIVATE);
    }

    private static String currentUri(PlayerActivity a) {
        return a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
    }

    /** Before every player build: tell the FFmpeg decoder whether to add grain. */
    static void onPlayerBuild(PlayerActivity a) {
        String u = currentUri(a);
        if (u == null || !u.equals(uri)) {
            uri = u;
            decided = false;
            weSwitched = false;
            drop = u != null && memory(a).getBoolean(u, false);
            if (drop && Decoder.get(a) != Decoder.SW && !Decoder.userChosen(a)) {
                Decoder.setOverride(a, Decoder.SW);   // known from last time: start on FFmpeg directly
                weSwitched = true;
            }
        }
        VideoFilter.applyFilmGrain = !drop;
    }

    static boolean needsSoftware() {
        return drop;
    }

    /** Software decoding is on only for this. */
    static boolean holdsSoftware() {
        return drop && weSwitched;
    }

    static String status() {
        return drop ? "film grain: not added (AV1 grain synthesis, SD)" : null;
    }

    /**
     * Tracks known. Returns true when the player is being rebuilt (decoder switch or the FFmpeg
     * decoder has to be restarted without grain).
     */
    static boolean onTracks(PlayerActivity a, Format f) {
        if (f == null || !MimeTypes.VIDEO_AV1.equals(f.sampleMimeType) || decided) return false;
        decided = true;
        Ivtc.Config cfg = Ivtc.load(a);
        Boolean grain = hasGrain(f.initializationData);
        boolean want;
        String why;
        switch (cfg.filmGrain) {
            case "yes":
                want = false;
                why = "film-grain=yes";
                break;
            case "no":
                want = grain == null || grain;
                why = "film-grain=no";
                break;
            default:
                want = grain != null && grain && f.height > 0 && f.height <= cfg.filmGrainMaxHeight;
                why = grain == null ? "grain unknown" : grain
                        ? (f.height <= cfg.filmGrainMaxHeight ? "SD with synthesized grain" : f.height + " lines: keeping the grain")
                        : "no grain in this stream";
        }
        if (want && !TvTune.softwareOk(a, f)) {
            want = false;
            why = "too heavy for software decoding on this device";
        }
        Diag.log("AV1 film grain: " + (want ? "not added" : "as encoded") + " (" + why + ")");
        if (want == drop) return false;
        drop = want;
        if (uri != null) memory(a).edit().putBoolean(uri, want).apply();
        VideoFilter.applyFilmGrain = !want;
        if (!want) return false;
        if (Decoder.userChosen(a) && Decoder.get(a) != Decoder.SW) {
            Diag.log("AV1 film grain: kept, you chose " + Decoder.name(Decoder.get(a)) + " (hardware always adds it)");
            return false;
        }
        if (Decoder.get(a) != Decoder.SW) {
            weSwitched = true;
            Decoder.switchTo(a, Decoder.SW, "AV1 without synthesized film grain");
        } else {
            Decoder.reopen(a, "AV1 without synthesized film grain");   // FFmpeg decoder already running with grain
        }
        return true;
    }

    // ------------------------------------------------------------------ AV1 sequence header

    /**
     * film_grain_params_present from the AV1 sequence header in the codec data (av1C from MKV/MP4).
     * Returns null when it can't be read.
     */
    static Boolean hasGrain(List<byte[]> init) {
        if (init == null) return null;
        for (byte[] d : init) {
            if (d == null || d.length < 3) continue;
            // av1C starts with 0x81 (marker + version 1) and 3 more bytes, then the config OBUs
            int start = (d[0] & 0xFF) == 0x81 && d.length > 4 ? 4 : 0;
            Boolean r = scanObus(d, start);
            if (r == null && start == 4) r = scanObus(d, 0);
            if (r != null) return r;
        }
        return null;
    }

    private static Boolean scanObus(byte[] d, int pos) {
        try {
            while (pos < d.length) {
                int h = d[pos] & 0xFF;
                int type = (h >> 3) & 0xF;
                boolean ext = ((h >> 2) & 1) != 0;
                boolean hasSize = ((h >> 1) & 1) != 0;
                pos++;
                if (ext) pos++;
                long size;
                if (hasSize) {
                    size = 0;
                    for (int i = 0; i < 8; i++) {
                        int b = d[pos++] & 0xFF;
                        size |= (long) (b & 0x7F) << (7 * i);
                        if ((b & 0x80) == 0) break;
                    }
                } else {
                    size = d.length - pos;
                }
                if (type == 1) return sequenceHeaderGrain(d, pos, (int) Math.min(size, d.length - pos));
                pos += size;
            }
        } catch (RuntimeException ignored) { }
        return null;
    }

    private static final class Bits {
        final byte[] d;
        int bit;
        final int end;
        Bits(byte[] d, int off, int len) { this.d = d; this.bit = off * 8; this.end = (off + len) * 8; }
        int f(int n) {
            int v = 0;
            for (int i = 0; i < n; i++) {
                if (bit >= end) throw new IndexOutOfBoundsException();
                v = (v << 1) | ((d[bit >> 3] >> (7 - (bit & 7))) & 1);
                bit++;
            }
            return v;
        }
        long uvlc() {
            int zeros = 0;
            while (f(1) == 0) { zeros++; if (zeros >= 32) return (1L << 32) - 1; }
            return zeros == 0 ? 0 : ((1L << zeros) - 1 + f(zeros));
        }
    }

    /** AV1 spec 5.5 sequence_header_obu(), up to film_grain_params_present (its last field). */
    static Boolean sequenceHeaderGrain(byte[] d, int off, int len) {
        Bits b = new Bits(d, off, len);
        int profile = b.f(3);
        b.f(1);                                   // still_picture
        int reduced = b.f(1);
        boolean decoderModelInfo = false;
        int bufferDelayLength = 0;
        if (reduced == 1) {
            b.f(5);                               // seq_level_idx[0]
        } else {
            if (b.f(1) == 1) {                    // timing_info_present_flag
                b.f(32); b.f(32);
                if (b.f(1) == 1) b.uvlc();        // equal_picture_interval
                if (b.f(1) == 1) {                // decoder_model_info_present_flag
                    decoderModelInfo = true;
                    bufferDelayLength = b.f(5) + 1;
                    b.f(32); b.f(5); b.f(5);
                }
            }
            int initialDisplayDelay = b.f(1);
            int ops = b.f(5) + 1;
            for (int i = 0; i < ops; i++) {
                b.f(12);                          // operating_point_idc
                int level = b.f(5);
                if (level > 7) b.f(1);            // seq_tier
                if (decoderModelInfo && b.f(1) == 1) {
                    b.f(bufferDelayLength); b.f(bufferDelayLength); b.f(1);
                }
                if (initialDisplayDelay == 1 && b.f(1) == 1) b.f(4);
            }
        }
        int wBits = b.f(4) + 1;
        int hBits = b.f(4) + 1;
        b.f(wBits); b.f(hBits);
        if (reduced == 0 && b.f(1) == 1) { b.f(4); b.f(3); }   // frame_id_numbers_present_flag
        b.f(1); b.f(1); b.f(1);                   // 128x128 sb, filter intra, intra edge filter
        if (reduced == 0) {
            b.f(1); b.f(1); b.f(1); b.f(1);       // interintra, masked, warped, dual filter
            int orderHint = b.f(1);
            if (orderHint == 1) { b.f(1); b.f(1); }   // jnt_comp, ref_frame_mvs
            int forceScreenContent = b.f(1) == 1 ? 2 : b.f(1);   // seq_choose_screen_content_tools
            if (forceScreenContent > 0) {
                if (b.f(1) == 0) b.f(1);          // seq_choose_integer_mv / seq_force_integer_mv
            }
            if (orderHint == 1) b.f(3);           // order_hint_bits_minus_1
        }
        b.f(1); b.f(1); b.f(1);                   // superres, cdef, restoration
        // color_config()
        int highBitdepth = b.f(1);
        int bitDepth = 8;
        if (profile == 2 && highBitdepth == 1) bitDepth = b.f(1) == 1 ? 12 : 10;
        else if (highBitdepth == 1) bitDepth = 10;
        int mono = profile == 1 ? 0 : b.f(1);
        int cp = 2, tc = 2, mc = 2;
        if (b.f(1) == 1) { cp = b.f(8); tc = b.f(8); mc = b.f(8); }
        if (mono == 1) {
            b.f(1);                               // color_range
        } else if (cp == 1 && tc == 13 && mc == 0) {
            // sRGB: no more fields
        } else {
            b.f(1);                               // color_range
            int sx, sy;
            if (profile == 0) { sx = 1; sy = 1; }
            else if (profile == 1) { sx = 0; sy = 0; }
            else if (bitDepth == 12) { sx = b.f(1); sy = sx == 1 ? b.f(1) : 0; }
            else { sx = 1; sy = 0; }
            if (sx == 1 && sy == 1) b.f(2);       // chroma_sample_position
        }
        if (mono == 0) b.f(1);                    // separate_uv_delta_q
        return b.f(1) == 1;                       // film_grain_params_present
    }

    static String describe(Boolean g) {
        return g == null ? "?" : g ? "yes" : "no";
    }

    @SuppressWarnings("unused")
    private static String fmt(String s, Object... a) {
        return String.format(Locale.US, s, a);
    }
}
