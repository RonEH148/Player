// Just Player URL: optional FFmpeg filter graph after the software video decoder.
// Used for automatic inverse telecine / deinterlacing (idet, fieldmatch, bwdif, decimate),
// the same filters mpv uses. Inserted into NextLib's ffvideo.cpp by tools/patch_nextlib.py.
//
// The graph only runs while Java has set a filter (VideoFilter.spec); otherwise frames pass
// through untouched. Any failure (filter missing, unsupported pixel format) switches the
// graph off for this decoder and frames pass through, so video never breaks because of it.

struct VideoFilter {
    ~VideoFilter() { Free(); }

    void Set(const char *new_spec, int num, int den) {
        Free();
        spec = new_spec ? new_spec : "";
        fps_num = num;
        fps_den = den > 0 ? den : 1;
        failed = false;
        for (long long &v : base) v = 0;
        for (long long &v : last) v = 0;
        frames = 0;
        frames_out = 0;
        coded_interlaced = coded_total = coded_tff = coded_repeat = 0;
        pattern.clear();
        error.clear();
    }

    void Fail(const char *what, int code) {
        char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
        if (code < 0) av_strerror(code, buf, sizeof(buf));
        error = std::string(what) + (code < 0 ? std::string(": ") + buf : std::string());
        failed = true;
    }

    // Seek / flush: rebuild on the next frame, keep the counts.
    void Reset() { Free(); last_pts = AV_NOPTS_VALUE; }

    void Free() {
        if (graph) {
            for (int i = 0; i < 4; i++) { base[i] += last[i]; last[i] = 0; }
        }
        avfilter_graph_free(&graph);
        src = nullptr;
        sink = nullptr;
        for (AVFrame *f : out) av_frame_free(&f);
        out.clear();
    }

    bool Build(const AVFrame *f, bool with_color) {
        graph = avfilter_graph_alloc();
        if (!graph) return false;
        graph->nb_threads = 2;
        AVRational sar = f->sample_aspect_ratio;
        if (sar.num <= 0 || sar.den <= 0) sar = AVRational{1, 1};
        char args[320];
        int n = snprintf(args, sizeof(args),
                "video_size=%dx%d:pix_fmt=%d:time_base=1/1000000:pixel_aspect=%d/%d",
                f->width, f->height, f->format, sar.num, sar.den);
        if (fps_num > 0) {
            n += snprintf(args + n, sizeof(args) - n, ":frame_rate=%d/%d", fps_num, fps_den);
        }
        if (with_color) {
            snprintf(args + n, sizeof(args) - n, ":colorspace=%d:range=%d",
                     (int) f->colorspace, (int) f->color_range);
        }
        last_error = 0;
        last_what = "buffer source";
        if (avfilter_graph_create_filter(&src, avfilter_get_by_name("buffer"), "in",
                                         args, nullptr, graph) < 0) return false;
        if (avfilter_graph_create_filter(&sink, avfilter_get_by_name("buffersink"), "out",
                                         nullptr, nullptr, graph) < 0) return false;
        AVFilterInOut *outputs = avfilter_inout_alloc();
        AVFilterInOut *inputs = avfilter_inout_alloc();
        if (!outputs || !inputs) {
            avfilter_inout_free(&outputs);
            avfilter_inout_free(&inputs);
            return false;
        }
        outputs->name = av_strdup("in");
        outputs->filter_ctx = src;
        outputs->pad_idx = 0;
        outputs->next = nullptr;
        inputs->name = av_strdup("out");
        inputs->filter_ctx = sink;
        inputs->pad_idx = 0;
        inputs->next = nullptr;
        int r = avfilter_graph_parse_ptr(graph, spec.c_str(), &inputs, &outputs, nullptr);
        avfilter_inout_free(&inputs);
        avfilter_inout_free(&outputs);
        if (r < 0) {
            logError("avfilter_graph_parse_ptr", r);
            last_error = r;
            last_what = "filter not available / bad options";
            return false;
        }
        r = avfilter_graph_config(graph, nullptr);
        if (r < 0) {
            logError("avfilter_graph_config", r);
            last_error = r;
            last_what = "filter can't handle this video's pixel format";
            return false;
        }
        return true;
    }

    static long long Meta(const AVFrame *f, const char *key) {
        const AVDictionaryEntry *e = av_dict_get(f->metadata, key, nullptr, 0);
        return e && e->value ? atoll(e->value) : -1;
    }

    void ReadIdet(const AVFrame *f) {
        static const char *keys[4] = {"lavfi.idet.multiple.tff", "lavfi.idet.multiple.bff",
                                      "lavfi.idet.multiple.progressive",
                                      "lavfi.idet.multiple.undetermined"};
        for (int i = 0; i < 4; i++) {
            long long v = Meta(f, keys[i]);
            if (v >= 0) last[i] = v;
        }
        // Per-frame idet result, kept as a sequence for the 3:2 cadence analysis in Java:
        // bits 0-1 repeated field (0 neither, 1 top, 2 bottom),
        // bits 2-3 this frame (0 undetermined, 1 tff, 2 bff, 3 progressive), bit 7 = has data.
        const AVDictionaryEntry *rep = av_dict_get(f->metadata, "lavfi.idet.repeated.current_frame", nullptr, 0);
        const AVDictionaryEntry *one = av_dict_get(f->metadata, "lavfi.idet.single.current_frame", nullptr, 0);
        if ((rep || one) && pattern.size() < 6000) {
            int b = 0x80;
            if (rep && rep->value) {
                if (!strcmp(rep->value, "top")) b |= 1;
                else if (!strcmp(rep->value, "bottom")) b |= 2;
            }
            if (one && one->value) {
                if (!strcmp(one->value, "tff")) b |= 1 << 2;
                else if (!strcmp(one->value, "bff")) b |= 2 << 2;
                else if (!strcmp(one->value, "progressive")) b |= 3 << 2;
            }
            pattern.push_back((uint8_t) b);
        }
    }

    // Takes ownership of `in`. Returns a frame to show, or nullptr when the filters are
    // still collecting frames (or dropped this one, e.g. decimate).
    AVFrame *Process(AVFrame *in) {
        if (failed) return in;
        if (graph && (in->width != width || in->height != height || in->format != format)) Free();
        if (!graph) {
            bool ok = Build(in, true);
            if (!ok) {
                Free();
                ok = Build(in, false);   // older FFmpeg: no colorspace/range options
            }
            if (!ok) {
                LOGE("video filter disabled, could not build: %s", spec.c_str());
                Free();
                char what[160];
                snprintf(what, sizeof(what), "%s (pixel format %d, %dx%d)", last_what, in->format, in->width, in->height);
                Fail(what, last_error);
                return in;
            }
            width = in->width;
            height = in->height;
            format = in->format;
        }
        // How the stream itself is coded: interlaced (PAFF/MBAFF, MPEG-2 field pictures …)
        // and field order. Read before filtering, straight from the decoder.
        coded_total++;
        if (in->repeat_pict > 0) coded_repeat++;   // soft telecine: "repeat this field" flags (RFF / pic_struct)
#ifdef AV_FRAME_FLAG_INTERLACED
        if (in->flags & AV_FRAME_FLAG_INTERLACED) coded_interlaced++;
        if (in->flags & AV_FRAME_FLAG_TOP_FIELD_FIRST) coded_tff++;
#else
        if (in->interlaced_frame) coded_interlaced++;
        if (in->top_field_first) coded_tff++;
#endif
        int r = av_buffersrc_add_frame_flags(src, in, AV_BUFFERSRC_FLAG_KEEP_REF);
        if (r < 0) {
            logError("av_buffersrc_add_frame_flags", r);
            Free();
            Fail("feeding frames", r);
            return in;
        }
        av_frame_free(&in);
        frames++;
        for (;;) {
            AVFrame *o = av_frame_alloc();
            if (!o) break;
            r = av_buffersink_get_frame(sink, o);
            if (r < 0) {
                av_frame_free(&o);
                break;
            }
            ReadIdet(o);
            // Filters may change the time base (bwdif/yadif output 1/2 of the input time base,
            // with doubled timestamps). The player needs microseconds, or it waits twice as long
            // for every frame: picture frozen while audio and subtitles continue.
            const AVRational tb = av_buffersink_get_time_base(sink);
            if (o->pts != AV_NOPTS_VALUE && tb.num > 0 && tb.den > 0 && !(tb.num == 1 && tb.den == 1000000)) {
                o->pts = av_rescale_q(o->pts, tb, AVRational{1, 1000000});
            }
            if (o->pts == AV_NOPTS_VALUE) {
                const int64_t step = fps_num > 0 ? (int64_t) 1000000 * fps_den / fps_num : 33367;
                o->pts = last_pts == AV_NOPTS_VALUE ? 0 : last_pts + step;
            }
            last_pts = o->pts;
            frames_out++;
            out.push_back(o);
            while (out.size() > 3) {
                AVFrame *d = out.front();
                out.pop_front();
                av_frame_free(&d);
            }
        }
        if (out.empty()) return nullptr;
        AVFrame *o = out.front();
        out.pop_front();
        return o;
    }

    // tff, bff, progressive, undetermined, frames in, status (1 running, -1 failed, 0 none), frames out
    void Stats(long long *v) const {
        for (int i = 0; i < 4; i++) v[i] = base[i] + last[i];
        v[4] = frames;
        v[5] = spec.empty() ? 0 : failed ? -1 : 1;
        v[6] = frames_out;
        v[7] = coded_interlaced;
        v[8] = coded_total;
        v[9] = coded_tff;
        v[10] = coded_repeat;
    }

    std::string spec;
    int fps_num = 0;
    int fps_den = 1;
    bool failed = false;
    AVFilterGraph *graph = nullptr;
    AVFilterContext *src = nullptr;
    AVFilterContext *sink = nullptr;
    int width = 0, height = 0, format = -1;
    std::deque<AVFrame *> out;
    long long base[4] = {0, 0, 0, 0};
    long long last[4] = {0, 0, 0, 0};
    long long frames = 0;
    long long frames_out = 0;
    long long coded_interlaced = 0, coded_total = 0, coded_tff = 0, coded_repeat = 0;
    std::vector<uint8_t> pattern;
    int64_t last_pts = AV_NOPTS_VALUE;
    std::string error;
    int last_error = 0;
    const char *last_what = "";
};
