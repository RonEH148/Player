package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * In-app updates from your own GitHub repository.
 *
 * The build workflow publishes every Just Player URL build as a release tagged
 * "justplayer-url-b<build number>" with JustPlayer-URL-Tablet.apk and JustPlayer-URL-TV.apk.
 * Only releases with that prefix are looked at, so other apps built in the same repository
 * (mpv URL+, LeanKeyboard Plus) are never touched. The TV picks the TV APK, the tablet the tablet one.
 */
public final class Updater {

    static final String TAG_PREFIX = "justplayer-url-b";
    private static final String KEY_LAST_CHECK = "urlUpdateLastCheck";
    private static final long AUTO_INTERVAL = 12L * 60 * 60 * 1000;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Updater() {}

    static int currentBuild() {
        return BuildConfig.URL_BUILD;
    }

    static String repo() {
        return BuildConfig.UPDATE_REPO;
    }

    static String assetName(Context c) {
        return Utils.isTvBox(c) ? "JustPlayer-URL-TV.apk" : "JustPlayer-URL-Tablet.apk";
    }

    /** Quiet check on app start, at most every 12 h; only speaks up if there is an update. */
    public static void autoCheck(Activity a) {
        try {
            SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(a);
            long last = p.getLong(KEY_LAST_CHECK, 0);
            if (System.currentTimeMillis() - last < AUTO_INTERVAL) return;
            p.edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply();
            check(a, false);
        } catch (Throwable ignored) { }
    }

    /** "Check for updates" button. */
    public static void check(final Activity a, final boolean manual) {
        if (manual) Toast.makeText(a, "Checking " + repo() + " for updates…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String error = null;
                int bestBuild = -1;
                String bestUrl = null, bestTitle = null, bestNotes = null;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo() + "/releases?per_page=50").openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("Accept", "application/vnd.github+json");
                    c.setRequestProperty("User-Agent", "JustPlayerURL-updater");
                    int code = c.getResponseCode();
                    if (code != 200) throw new Exception("GitHub answered " + code);
                    String body = readAll(c.getInputStream());
                    c.disconnect();
                    JSONArray releases = new JSONArray(body);
                    String wanted = assetName(a);
                    for (int i = 0; i < releases.length(); i++) {
                        JSONObject r = releases.getJSONObject(i);
                        String tag = r.optString("tag_name", "");
                        if (!tag.startsWith(TAG_PREFIX) || r.optBoolean("draft")) continue;
                        int build;
                        try { build = Integer.parseInt(tag.substring(TAG_PREFIX.length())); } catch (Exception e) { continue; }
                        if (build <= bestBuild) continue;
                        JSONArray assets = r.optJSONArray("assets");
                        if (assets == null) continue;
                        for (int j = 0; j < assets.length(); j++) {
                            JSONObject as = assets.getJSONObject(j);
                            if (wanted.equals(as.optString("name"))) {
                                bestBuild = build;
                                bestUrl = as.optString("browser_download_url");
                                bestTitle = r.optString("name", tag);
                                bestNotes = r.optString("body", "");
                            }
                        }
                    }
                } catch (Throwable t) {
                    error = t.getMessage() != null ? t.getMessage() : t.toString();
                }
                final String err = error;
                final int build = bestBuild;
                final String url = bestUrl, title = bestTitle, notes = bestNotes;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        if (a.isFinishing()) return;
                        if (err != null) {
                            if (manual) Toast.makeText(a, "Update check failed: " + err, Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (url == null || build <= currentBuild()) {
                            if (manual) Toast.makeText(a, "You're up to date" + (currentBuild() > 0 ? " (" + currentBuild() + ")" : ""), Toast.LENGTH_LONG).show();
                            return;
                        }
                        new AlertDialog.Builder(a)
                                .setTitle("Update available")
                                .setMessage(title + "\n\nInstalled build: " + (currentBuild() > 0 ? currentBuild() : "older") + "\nNew build: " + build
                                        + (notes != null && !notes.isEmpty() ? "\n\n" + notes : ""))
                                .setPositiveButton("Install", (d, w) -> download(a, url))
                                .setNegativeButton("Later", null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private static void download(final Activity a, final String url) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(a, "Allow installing updates for this app, then press Install again", Toast.LENGTH_LONG).show();
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
            } catch (Throwable ignored) { }
            return;
        }
        final AlertDialog progress = new AlertDialog.Builder(a)
                .setTitle("Downloading update")
                .setMessage("Starting…")
                .setCancelable(false)
                .show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                File apk = new File(a.getCacheDir(), "update.apk");
                String error = null;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(30000);
                    c.setRequestProperty("User-Agent", "JustPlayerURL-updater");
                    int code = c.getResponseCode();
                    if (code != 200) throw new Exception("Download failed (" + code + ")");
                    final long total = c.getContentLengthLong();
                    try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(apk)) {
                        byte[] buf = new byte[64 * 1024];
                        long done = 0, lastUi = 0;
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            done += n;
                            if (done - lastUi > 512 * 1024) {
                                lastUi = done;
                                final long d = done;
                                MAIN.post(() -> progress.setMessage((d >> 20) + (total > 0 ? " / " + (total >> 20) : "") + " MB"));
                            }
                        }
                    }
                    c.disconnect();
                    install(a, apk);
                } catch (Throwable t) {
                    error = t.getMessage() != null ? t.getMessage() : t.toString();
                }
                final String err = error;
                MAIN.post(() -> {
                    try { progress.dismiss(); } catch (Throwable ignored) { }
                    if (err != null) Toast.makeText(a, "Update failed: " + err, Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private static void install(Context c, File apk) throws Exception {
        PackageInstaller installer = c.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(c.getPackageName());
        int id = installer.createSession(params);
        PackageInstaller.Session session = installer.openSession(id);
        try {
            try (OutputStream out = session.openWrite("update", 0, apk.length()); InputStream in = new FileInputStream(apk)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            }
            Intent done = new Intent(c, UpdateReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
            PendingIntent pi = PendingIntent.getBroadcast(c, id, done, flags);
            session.commit(pi.getIntentSender());
        } finally {
            session.close();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[16 * 1024];
        int n;
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        sb.append(bo.toString("UTF-8"));
        return sb.toString();
    }
}
