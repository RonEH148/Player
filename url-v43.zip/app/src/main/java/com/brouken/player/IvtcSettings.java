package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.preference.Preference;

/** Settings → "Player config": mpv.conf-style text (hwdec, vf, deinterlace, ivtc-…). */
final class IvtcSettings {

    private IvtcSettings() {}

    static void summary(Preference p) {
        try {
            Ivtc.Config c = Ivtc.load(p.getContext());
            StringBuilder sb = new StringBuilder();
            if (c.hwdec != null) sb.append("hwdec ").append(Decoder.name(c.hwdec)).append(" · ");
            if (!c.vf.isEmpty()) sb.append("vf=").append(c.vf).append(" · ");
            sb.append(!c.enabled || "off".equals(c.mode) ? "auto telecine off" : "auto telecine " + c.mode);
            p.setSummary(sb + "\nmpv.conf-style options");
        } catch (Throwable t) {
            p.setSummary("mpv.conf-style options");
        }
    }

    static void edit(final Activity a, final Preference pref) {
        final EditText input = new EditText(a);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setSingleLine(false);
        input.setHorizontallyScrolling(true);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setTypeface(Typeface.MONOSPACE);
        input.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        input.setText(Ivtc.configText(a));
        int pad = (int) (16 * a.getResources().getDisplayMetrics().density);
        FrameLayout box = new FrameLayout(a);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);

        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Player config")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNeutralButton("Reset", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String text = input.getText().toString();
                java.util.List<String> warnings;
                try {
                    warnings = Ivtc.check(text);
                } catch (IllegalArgumentException e) {
                    input.setError(e.getMessage());
                    return;
                }
                PreferenceManager.getDefaultSharedPreferences(a).edit().putString(Ivtc.KEY_CONFIG, text).apply();
                Ivtc.forgetAll(a);   // earlier results were decided with the old settings
                summary(pref);
                dialog.dismiss();
                if (warnings.isEmpty()) {
                    Toast.makeText(a, "Saved. Applies when you go back to the video.", Toast.LENGTH_SHORT).show();
                } else {
                    StringBuilder sb = new StringBuilder("Saved. These lines were ignored:\n\n");
                    for (String w : warnings) sb.append("• ").append(w).append('\n');
                    new AlertDialog.Builder(a).setTitle("Player config").setMessage(sb.toString())
                            .setPositiveButton(android.R.string.ok, null).show();
                }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> input.setText(Ivtc.DEFAULT_CONFIG));
        });
        dialog.show();
    }
}
