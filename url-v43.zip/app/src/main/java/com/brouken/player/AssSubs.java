package com.brouken.player;

import android.view.View;
import android.view.ViewGroup;

import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.RenderersFactory;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.mkv.MatroskaExtractor;
import androidx.media3.ui.SubtitleView;

import io.github.peerless2012.ass.media.AssHandler;
import io.github.peerless2012.ass.media.AssHandlerConfig;
import io.github.peerless2012.ass.media.extractor.AssMatroskaExtractor;
import io.github.peerless2012.ass.media.factory.AssRenderersFactory;
import io.github.peerless2012.ass.media.parser.AssSubtitleParserFactory;
import io.github.peerless2012.ass.media.type.AssRenderType;
import io.github.peerless2012.ass.media.widget.AssSubtitleView;

/**
 * ASS/SSA subtitles rendered by libass – the same renderer mpv uses: the file's own fonts
 * (attached in the MKV), styles, sizes, positions, signs and animations, scaled to the picture.
 * SRT, PGS and other formats still use Media3's subtitle view.
 */
final class AssSubs {

    private AssSubs() {}

    private static AssHandler handler;
    private static AssSubtitleParserFactory parsers;
    private static boolean failed;

    /** Before each player build. */
    static void newPlayer(android.content.Context c) {
        if (failed) return;
        try {
            // TV: render subtitles at most at 1080p (the TV upscales); tablet: full screen size
            int maxPixels = Utils.isTvBox(c) ? 1920 * 1080 : 0;
            handler = new AssHandler(AssRenderType.OVERLAY_OPEN_GL, new AssHandlerConfig(10000, 128, maxPixels));
            parsers = new AssSubtitleParserFactory(handler);
        } catch (Throwable t) {
            failed = true;
            handler = null;
            parsers = null;
            Diag.log("libass unavailable: " + t);
        }
    }

    static boolean active() {
        return handler != null && parsers != null;
    }

    static void apply(DefaultMediaSourceFactory f) {
        if (active()) f.setSubtitleParserFactory(parsers);
    }

    static RenderersFactory renderers(RenderersFactory base) {
        return active() ? new AssRenderersFactory(handler, base) : base;
    }

    /** The current player's handler and parser factory, kept by its extractor factory. */
    static Object[] current() {
        return active() ? new Object[] {handler, parsers} : null;
    }

    /** MKV extractor that also reads the attached fonts and hands ASS tracks to libass. */
    static Extractor[] extractors(Extractor[] in, boolean linear, Object[] bound) {
        if (bound == null) return in;
        AssHandler handler = (AssHandler) bound[0];
        AssSubtitleParserFactory parsers = (AssSubtitleParserFactory) bound[1];
        for (int i = 0; i < in.length; i++) {
            if (in[i] instanceof MatroskaExtractor && !(in[i] instanceof AssMatroskaExtractor)) {
                in[i] = new AssMatroskaExtractor(parsers, handler,
                        linear ? MatroskaExtractor.FLAG_DISABLE_SEEK_FOR_CUES : 0);
            }
        }
        return in;
    }

    private static AssHandler lastAttached;

    /**
     * The picture surface already exists when the player is rebuilt (decoder change), so Android
     * doesn't announce its size again and libass would draw into a 0×0 area: tell it the size.
     */
    static void surfaceSize(View surface) {
        final AssHandler h = lastAttached;
        if (h == null || surface == null) return;
        surface.post(() -> {
            try {
                if (surface.getWidth() > 0 && surface.getHeight() > 0) h.onSurfaceSizeChanged(surface.getWidth(), surface.getHeight());
            } catch (Throwable ignored) { }
        });
    }

    /** Player built: connect libass and put its drawing layer over the picture. */
    static void attach(ExoPlayer p, SubtitleView sv) {
        if (!active() || p == null || sv == null) return;
        try {
            handler.init(p);
            for (int i = sv.getChildCount() - 1; i >= 0; i--) {
                View v = sv.getChildAt(i);
                if (v instanceof AssSubtitleView) sv.removeViewAt(i);
            }
            sv.addView(new AssSubtitleView(sv.getContext(), handler),
                    new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            lastAttached = handler;
        } catch (Throwable t) {
            Diag.log("libass attach: " + t);
        }
    }
}
