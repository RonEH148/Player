package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Audio track button next to the subtitle button (it used to be inside the gear menu). */
public final class TrackButtons {

    private TrackButtons() {}

    private static final float[] SPEEDS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f};

    public static void add(final Activity a, LinearLayout controls) {
        try {
            ImageButton audio = new ImageButton(a, null, 0, R.style.ExoStyledControls_Button_Bottom);
            audio.setImageResource(R.drawable.exo_ic_audiotrack);
            audio.setContentDescription("Audio track");
            audio.setOnClickListener(v -> pickAudio(a));
            controls.addView(audio);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private static void pickAudio(Activity a) {
        final ExoPlayer p = PlayerActivity.player;
        if (p == null) return;
        final List<Tracks.Group> groups = new ArrayList<>();
        final List<Integer> indexes = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int checked = -1;
        for (Tracks.Group g : p.getCurrentTracks().getGroups()) {
            if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                if (g.isTrackSelected(i)) checked = labels.size();
                groups.add(g);
                indexes.add(i);
                labels.add(label(g.getTrackFormat(i)));
            }
        }
        if (labels.isEmpty()) return;
        new AlertDialog.Builder(a)
                .setTitle("Audio track")
                .setSingleChoiceItems(labels.toArray(new String[0]), checked, (d, which) -> {
                    Tracks.Group g = groups.get(which);
                    p.setTrackSelectionParameters(p.getTrackSelectionParameters().buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                            .setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), indexes.get(which)))
                            .build());
                    d.dismiss();
                })
                .show();
    }

    private static void pickSpeed(Activity a) {
        final ExoPlayer p = PlayerActivity.player;
        if (p == null) return;
        float cur = p.getPlaybackParameters().speed;
        String[] labels = new String[SPEEDS.length];
        int checked = -1;
        for (int i = 0; i < SPEEDS.length; i++) {
            labels[i] = (SPEEDS[i] == 1f ? "Normal" : String.format(Locale.US, "%.2fx", SPEEDS[i]).replace(".00x", "x"));
            if (Math.abs(SPEEDS[i] - cur) < 0.01f) checked = i;
        }
        new AlertDialog.Builder(a)
                .setTitle("Playback speed")
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    p.setPlaybackSpeed(SPEEDS[which]);
                    d.dismiss();
                })
                .show();
    }

    private static String label(Format f) {
        StringBuilder sb = new StringBuilder();
        if (f.language != null && !f.language.equals("und")) {
            String name = new Locale(f.language).getDisplayLanguage(Locale.ENGLISH);
            sb.append(name.isEmpty() ? f.language : name);
        } else {
            sb.append("Unknown language");
        }
        String m = f.sampleMimeType == null ? "" : f.sampleMimeType.toLowerCase(Locale.US);
        String codec = m.contains("eac3-joc") ? "E-AC-3 Atmos" : m.contains("eac3") ? "E-AC-3" : m.contains("ac3") ? "AC-3"
                : m.contains("true-hd") ? "TrueHD" : m.contains("dts") ? "DTS" : m.contains("flac") ? "FLAC"
                : m.contains("mp4a") ? "AAC" : m.contains("opus") ? "Opus" : m.replace("audio/", "");
        sb.append(" · ").append(codec);
        if (f.channelCount > 0) sb.append(" · ").append(f.channelCount == 6 ? "5.1" : f.channelCount == 8 ? "7.1" : f.channelCount + "ch");
        if (f.label != null && !f.label.isEmpty()) sb.append(" · ").append(f.label);
        return sb.toString();
    }
}
