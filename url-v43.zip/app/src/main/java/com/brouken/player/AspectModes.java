package com.brouken.player;

import android.preference.PreferenceManager;
import android.view.View;

import androidx.media3.ui.AspectRatioFrameLayout;

/**
 * Aspect ratio button: cycles through the modes and shows the name in the middle of the picture.
 * Fixed ratios (16:9, 4:3 …) override the video's own shape; the choice is kept for the next video.
 */
final class AspectModes {

    private AspectModes() {}

    private static final String KEY = "aspectModeIndex";

    private static final String[] NAMES = {
            "Original", "Fill screen", "Stretch", "16:9", "4:3", "21:9", "2.35:1", "1.85:1"};
    private static final int[] RESIZE = {
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FIT};
    private static final float[] RATIO = {0, 0, 0, 16f / 9f, 4f / 3f, 21f / 9f, 2.35f, 1.85f};

    private static int current = -1;

    static void next(PlayerActivity a) {
        int i = (index(a) + 1) % NAMES.length;
        apply(a, i);
        CenterText.show(a, NAMES[i], 1500);
    }

    /** Player (re)started: apply the saved mode. */
    static void restore(PlayerActivity a) {
        int i = index(a);
        // pinch-zoom on the tablet sets Crop with a custom scale: keep that
        if (a.mPrefs != null && a.mPrefs.resizeMode == AspectRatioFrameLayout.RESIZE_MODE_ZOOM && i != 1) i = 1;
        if (i == 1) {
            current = i;
            forced(a, 0);
            return;
        }
        apply(a, i);
    }

    private static int index(PlayerActivity a) {
        if (current < 0) {
            try {
                current = PreferenceManager.getDefaultSharedPreferences(a).getInt(KEY, 0);
            } catch (Throwable t) {
                current = 0;
            }
        }
        if (current < 0 || current >= NAMES.length) current = 0;
        return current;
    }

    private static void apply(PlayerActivity a, int i) {
        current = i;
        try {
            PreferenceManager.getDefaultSharedPreferences(a).edit().putInt(KEY, i).apply();
        } catch (Throwable ignored) { }
        if (a.playerView == null) return;
        a.playerView.setScale(1.f);
        a.playerView.setResizeMode(RESIZE[i]);
        if (a.mPrefs != null) a.mPrefs.resizeMode = RESIZE[i];
        forced(a, RATIO[i]);
    }

    private static float forcedRatio;

    /**
     * The picture's real shape: width × pixel aspect ratio / height, from the file.
     * The software (FFmpeg) renderer reports only the stored size, so anamorphic video
     * (DVD 720×480 for 16:9 …) would otherwise be shown squeezed/stretched.
     */
    private static float naturalRatio() {
        try {
            androidx.media3.common.Format f = PlayerActivity.player == null ? null : PlayerActivity.player.getVideoFormat();
            if (f == null || f.width <= 0 || f.height <= 0) return 0;
            float par = f.pixelWidthHeightRatio > 0 ? f.pixelWidthHeightRatio : 1f;
            float r = f.width * par / f.height;
            if (f.rotationDegrees == 90 || f.rotationDegrees == 270) r = 1f / r;
            return r;
        } catch (Throwable t) {
            return 0;
        }
    }

    private static float target() {
        if (forcedRatio > 0) return forcedRatio;
        if (current == 2) return 0;      // Stretch: no ratio
        return naturalRatio();
    }

    private static void forced(PlayerActivity a, float ratio) {
        forcedRatio = ratio;
        final AspectRatioFrameLayout frame = a.playerView == null ? null
                : a.playerView.findViewById(androidx.media3.ui.R.id.exo_content_frame);
        if (frame == null) return;
        if (frame.getTag(R.id.controls) == null) {
            // The player view sets its own ratio whenever the video size is reported (the FFmpeg
            // renderer reports it without the pixel aspect ratio); put the right one back.
            frame.setTag(R.id.controls, Boolean.TRUE);
            frame.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    float want = target();
                    if (want > 0) frame.setAspectRatio(want);
                }
            });
        }
        float want = target();
        if (want > 0) frame.setAspectRatio(want);
    }

    /** Video format known/changed: re-apply the shape. */
    static void onVideoSize(PlayerActivity a) {
        if (a == null || a.playerView == null) return;
        a.playerView.post(() -> forced(a, forcedRatio));
    }
}
