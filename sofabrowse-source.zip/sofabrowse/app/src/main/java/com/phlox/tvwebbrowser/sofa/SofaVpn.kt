package com.phlox.tvwebbrowser.sofa

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.utils.observable.ObservableValue
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.StringReader

/**
 * WireGuard VPN built on the official wireguard-android tunnel library.
 * "Browser only" mode routes just SofaBrowse's traffic; otherwise the whole TV uses the tunnel.
 */
object SofaVpn {
    enum class Status { NOT_CONFIGURED, DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    val status = ObservableValue(Status.DISCONNECTED)
    var lastError: String? = null
        private set

    private val uiHandler = Handler(Looper.getMainLooper())
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "sofabrowse"
        override fun onStateChange(newState: Tunnel.State) {
            setStatus(if (newState == Tunnel.State.UP) Status.CONNECTED else Status.DISCONNECTED)
        }
    }

    private fun setStatus(value: Status) {
        uiHandler.post { status.value = value }
    }

    private fun backend(context: Context): GoBackend =
        backend ?: GoBackend(context.applicationContext).also { backend = it }

    fun hasConfig(): Boolean = AppContext.provideConfig().sofaVpnConfigEncrypted.isNotEmpty()

    fun refreshStatus() {
        if (!hasConfig()) {
            status.value = Status.NOT_CONFIGURED
        } else if (status.value == Status.NOT_CONFIGURED) {
            status.value = Status.DISCONNECTED
        }
    }

    /** Validates and stores a wg-quick style configuration. Returns an error message or null. */
    fun importConfig(text: String): String? {
        val clean = text.replace("\r", "").trim()
        try {
            Config.parse(BufferedReader(StringReader(clean)))
        } catch (e: Exception) {
            return e.message ?: e.javaClass.simpleName
        }
        val enc = SofaCrypto.encrypt(clean) ?: return "Android keystore is not available"
        AppContext.provideConfig().sofaVpnConfigEncrypted = enc
        refreshStatus()
        return null
    }

    fun removeConfig(context: Context) {
        disconnectAsync(context)
        AppContext.provideConfig().sofaVpnConfigEncrypted = ""
        status.value = Status.NOT_CONFIGURED
    }

    /** Name of the server (endpoint host) for display, if a config exists. */
    fun endpointLabel(): String? {
        val text = storedConfigText() ?: return null
        return Regex("(?im)^\\s*Endpoint\\s*=\\s*(\\S+)").find(text)?.groupValues?.get(1)
    }

    private fun storedConfigText(): String? {
        val enc = AppContext.provideConfig().sofaVpnConfigEncrypted
        if (enc.isEmpty()) return null
        return SofaCrypto.decrypt(enc)
    }

    /** Adds the app filter required by "browser only" mode to the [Interface] section. */
    private fun withRouting(text: String, packageName: String, browserOnly: Boolean): String {
        val lines = text.lines().filterNot {
            val l = it.trim().lowercase()
            l.startsWith("includedapplications") || l.startsWith("excludedapplications")
        }.toMutableList()
        if (browserOnly) {
            val idx = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
            if (idx >= 0) lines.add(idx + 1, "IncludedApplications = $packageName")
        }
        return lines.joinToString("\n")
    }

    /** Intent that asks the user to allow VPN connections, or null if already allowed. */
    fun permissionIntent(context: Context): Intent? = VpnService.prepare(context)

    suspend fun connect(context: Context): Boolean = withContext(Dispatchers.IO) {
        val text = storedConfigText()
        if (text == null) {
            setStatus(Status.NOT_CONFIGURED)
            return@withContext false
        }
        setStatus(Status.CONNECTING)
        try {
            val routed = withRouting(text, context.packageName, AppContext.provideConfig().sofaVpnBrowserOnly)
            val config = Config.parse(BufferedReader(StringReader(routed)))
            val state = backend(context).setState(tunnel, Tunnel.State.UP, config)
            lastError = null
            setStatus(if (state == Tunnel.State.UP) Status.CONNECTED else Status.DISCONNECTED)
            state == Tunnel.State.UP
        } catch (e: Exception) {
            e.printStackTrace()
            lastError = e.message ?: e.javaClass.simpleName
            setStatus(Status.ERROR)
            false
        }
    }

    suspend fun disconnect(context: Context) = withContext(Dispatchers.IO) {
        try {
            backend(context).setState(tunnel, Tunnel.State.DOWN, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        setStatus(if (hasConfig()) Status.DISCONNECTED else Status.NOT_CONFIGURED)
    }

    private fun disconnectAsync(context: Context) {
        val app = context.applicationContext
        Thread {
            try {
                backend(app).setState(tunnel, Tunnel.State.DOWN, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}
