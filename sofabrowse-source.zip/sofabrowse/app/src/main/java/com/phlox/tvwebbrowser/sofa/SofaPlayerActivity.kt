package com.phlox.tvwebbrowser.sofa

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import android.app.AlertDialog
import android.app.Activity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.R
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Native full-screen player for web videos. It plays through Media3/ExoPlayer on a SurfaceView, so
 * the TV's hardware decoder renders 4K, HDR10, HLG and Dolby Vision directly (web engines usually
 * can't), sends Dolby/DTS audio to the TV or soundbar when supported, and can switch the TV's
 * refresh rate to match the video.
 */
@OptIn(UnstableApi::class)
class SofaPlayerActivity : Activity() {
    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_USER_AGENT = "user_agent"
        const val EXTRA_COOKIES = "cookies"
        const val EXTRA_POSITION_MS = "position_ms"
        const val EXTRA_DEBAND = "deband"

        fun start(context: Context, stream: SofaVideoHandoff.Stream, deband: Boolean = false) {
            val intent = Intent(context, SofaPlayerActivity::class.java)
                .putExtra(EXTRA_URL, stream.url)
                .putExtra(EXTRA_TITLE, stream.title)
                .putExtra(EXTRA_REFERER, stream.referer)
                .putExtra(EXTRA_USER_AGENT, stream.userAgent)
                .putExtra(EXTRA_COOKIES, stream.cookies)
                .putExtra(EXTRA_POSITION_MS, stream.positionMs)
                .putExtra(EXTRA_DEBAND, deband)
            context.startActivity(intent)
        }
    }

    private val config = AppContext.provideConfig()
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var infoView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var refreshRateApplied = false
    private var stream: SofaVideoHandoff.Stream? = null

    //Deband: per video, off when the player opens
    private lateinit var debandButton: TextView
    private var cleanup = LumenVideoCleanup.Level.OFF
    private val debandOn get() = cleanup != LumenVideoCleanup.Level.OFF
    private var effectsPipelineReady = false
    private var trackSelector: DefaultTrackSelector? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank()) {
            finish()
            return
        }
        stream = SofaVideoHandoff.Stream(
            url = url,
            title = intent.getStringExtra(EXTRA_TITLE) ?: "",
            referer = intent.getStringExtra(EXTRA_REFERER),
            userAgent = intent.getStringExtra(EXTRA_USER_AGENT),
            cookies = intent.getStringExtra(EXTRA_COOKIES),
            positionMs = intent.getLongExtra(EXTRA_POSITION_MS, 0L)
        )

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        playerView = PlayerView(this)
        playerView.keepScreenOn = true
        playerView.setShowSubtitleButton(true)
        playerView.setShowNextButton(false)
        playerView.setShowPreviousButton(false)
        playerView.setControllerShowTimeoutMs(4000)
        root.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        infoView = TextView(this)
        infoView.setTextColor(Color.WHITE)
        infoView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        infoView.setBackgroundColor(0xB0000000.toInt())
        val pad = (12 * resources.displayMetrics.density).roundToInt()
        infoView.setPadding(pad, pad / 2, pad, pad / 2)
        infoView.visibility = View.GONE
        root.addView(infoView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        ).also { it.setMargins(pad * 3, pad * 3, pad * 3, pad * 3) })

        //small "Deband" toggle, shown together with the player controls
        debandButton = TextView(this)
        debandButton.setTextColor(Color.WHITE)
        debandButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        debandButton.setPadding(pad + pad / 2, pad / 2 + 2, pad + pad / 2, pad / 2 + 2)
        debandButton.isFocusable = true
        debandButton.isClickable = true
        debandButton.visibility = View.GONE
        debandButton.setOnClickListener { toggleDeband() }
        debandButton.setOnFocusChangeListener { _, _ -> updateDebandButton() }
        updateDebandButton()
        root.addView(debandButton, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START
        ).also { it.setMargins(pad * 3, pad * 3, pad * 3, pad * 3) })
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
            debandButton.visibility = if (visibility == View.VISIBLE) View.VISIBLE else View.GONE
        })

        setContentView(root)
        initPlayer(stream!!)
    }

    private fun initPlayer(stream: SofaVideoHandoff.Stream) {
        val headers = HashMap<String, String>()
        stream.referer?.let { headers["Referer"] = it }
        stream.cookies?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(20000)
        stream.userAgent?.let { httpFactory.setUserAgent(it) }
        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)

        val trackSelector = DefaultTrackSelector(this)
        this.trackSelector = trackSelector
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .setForceHighestSupportedBitrate(config.sofaAutoMaxQuality)
                .setTunnelingEnabled(config.sofaPlayerTunneling)
        )

        //Media3 uses the device's hardware decoders (MediaCodec) first, exactly like VLC/MX/Just Player,
        //and only falls back to another decoder if the first one fails
        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)

        //Bigger buffer for high-bitrate streams (4K HLS): fewer stalls. The buffer lives in the app's
        //Java memory, so it's capped to a third of what this device gives the app - a fixed large
        //buffer made 10+ Mbit/s videos run out of memory on TVs.
        val maxHeap = Runtime.getRuntime().maxMemory()
        val bufferBytes = (maxHeap / 3).coerceIn(32L * 1024 * 1024, 160L * 1024 * 1024).toInt()
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 90_000, 2_500, 5_000)
            .setTargetBufferBytes(bufferBytes)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(10_000, true)
            .build()

        val exo = ExoPlayer.Builder(this, renderersFactory)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setVideoScalingMode(C.VIDEO_SCALING_MODE_SCALE_TO_FIT)
            .build()

        exo.addAnalyticsListener(object : androidx.media3.exoplayer.analytics.AnalyticsListener {
            override fun onDroppedVideoFrames(
                eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                droppedFrames: Int, elapsedMs: Long
            ) {
                onFramesDropped(droppedFrames)
            }
        })
        exo.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (debandOn && isHdr(exo.videoFormat)) setCleanup(LumenVideoCleanup.Level.OFF, announce = false)
                updateInfoAndDisplayMode()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) updateInfoAndDisplayMode()
                if (playbackState == Player.STATE_ENDED) finish()
            }

            override fun onPlayerError(error: PlaybackException) {
                if (debandOn) {
                    //the GPU couldn't run the filters: turn them off and keep playing
                    cleanup = LumenVideoCleanup.Level.OFF
                    updateDebandButton()
                    val pos = exo.currentPosition
                    exo.setVideoEffects(emptyList())
                    exo.seekTo(pos)
                    exo.prepare()
                    Toast.makeText(this@SofaPlayerActivity, R.string.lumen_deband_failed, Toast.LENGTH_LONG).show()
                    return
                }
                showErrorDialog(error)
            }
        })

        //opened with "Play in Lumen player with anime deband": filters on from the first frame
        if (intent.getBooleanExtra(EXTRA_DEBAND, false)) {
            cleanup = LumenVideoCleanup.Level.ANIME
            effectsPipelineReady = true
            trackSelector.setParameters(trackSelector.buildUponParameters().setTunnelingEnabled(false))
            exo.setVideoEffects(LumenVideoCleanup.effectsFor(cleanup))
            updateDebandButton()
        }

        val itemBuilder = MediaItem.Builder().setUri(stream.url)
        SofaVideoHandoff.guessMimeType(stream.url)?.let { itemBuilder.setMimeType(it) }
        exo.setMediaItem(itemBuilder.build(), stream.positionMs.coerceAtLeast(0L))
        exo.playWhenReady = true
        exo.prepare()
        playerView.player = exo
        player = exo
    }

    private fun updateInfoAndDisplayMode() {
        val exo = player ?: return
        val format = exo.videoFormat ?: return
        if (config.sofaMatchFrameRate && !refreshRateApplied && format.frameRate > 0) {
            refreshRateApplied = true
            applyBestDisplayMode(format)
        }
        showInfo(format)
    }

    @SuppressLint("SetTextI18n")
    private fun showInfo(format: Format) {
        val parts = ArrayList<String>()
        if (format.width > 0 && format.height > 0) parts.add("${format.width}×${format.height}")
        parts.add(hdrLabel(format))
        if (format.frameRate > 0) parts.add(String.format(java.util.Locale.US, "%.3f fps", format.frameRate).replace(".000", ""))
        format.codecs?.let { parts.add(it.substringBefore('.')) }
        val mode = currentDisplay()?.mode
        if (mode != null) parts.add("TV ${mode.physicalWidth}×${mode.physicalHeight} @ ${mode.refreshRate.roundToInt()}Hz")
        infoView.text = parts.joinToString("  ·  ")
        infoView.visibility = View.VISIBLE
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ infoView.visibility = View.GONE }, 6000)
    }

    private fun hdrLabel(format: Format): String {
        if (format.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION) return "Dolby Vision"
        return when (format.colorInfo?.colorTransfer) {
            C.COLOR_TRANSFER_ST2084 -> "HDR10"
            C.COLOR_TRANSFER_HLG -> "HLG"
            else -> "SDR"
        }
    }

    @Suppress("DEPRECATION")
    private fun currentDisplay(): Display? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else windowManager.defaultDisplay

    /**
     * Pick a TV display mode whose refresh rate equals (or is a whole multiple of) the video frame
     * rate, so 24p films play without judder. For 4K videos on TVs whose interface runs at 1080p,
     * a 4K mode is preferred.
     */
    private fun applyBestDisplayMode(format: Format) {
        val display = currentDisplay() ?: return
        val current = display.mode
        val fps = format.frameRate
        val wantHeight = maxOf(format.height, current.physicalHeight)
        val sameOrBigger = display.supportedModes.filter {
            it.physicalHeight >= wantHeight || it.physicalHeight == current.physicalHeight
        }
        fun multiple(mode: Display.Mode): Int {
            val ratio = mode.refreshRate / fps
            val rounded = ratio.roundToInt()
            return if (rounded >= 1 && abs(ratio - rounded) < 0.012f) rounded else 0
        }
        val best = sameOrBigger
            .filter { multiple(it) > 0 }
            .sortedWith(compareBy<Display.Mode>(
                { if (format.height > current.physicalHeight && it.physicalHeight < format.height) 1 else 0 },
                { multiple(it) },
                { abs(it.physicalHeight - wantHeight) }
            ))
            .firstOrNull() ?: return
        if (best.modeId == current.modeId) return
        val attrs = window.attributes
        attrs.preferredDisplayModeId = best.modeId
        window.attributes = attrs
    }

    private fun updateDebandButton() {
        if (!::debandButton.isInitialized) return
        debandButton.text = getString(if (debandOn) R.string.lumen_anime_deband_on else R.string.lumen_anime_deband_off_label)
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = 18 * resources.displayMetrics.density
        bg.setColor(if (debandOn) 0xFF0FA3A3.toInt() else 0xB0000000.toInt())
        if (debandButton.isFocused) bg.setStroke((2 * resources.displayMetrics.density).roundToInt(), 0xFF20C997.toInt())
        debandButton.background = bg
    }

    private fun isHdr(format: Format?): Boolean {
        if (format == null) return false
        if (format.sampleMimeType == MimeTypes.VIDEO_DOLBY_VISION) return true
        val transfer = format.colorInfo?.colorTransfer
        return transfer == C.COLOR_TRANSFER_ST2084 || transfer == C.COLOR_TRANSFER_HLG
    }

    /** "Anime deband" button: on/off for this video only. */
    private fun toggleDeband() {
        val next = LumenVideoCleanup.Level.entries[(cleanup.ordinal + 1) % LumenVideoCleanup.Level.entries.size]
        setCleanup(next, announce = true)
    }

    private fun setCleanup(level: LumenVideoCleanup.Level, announce: Boolean) {
        val exo = player ?: return
        if (level != LumenVideoCleanup.Level.OFF && isHdr(exo.videoFormat)) {
            //the filters would have to convert HDR to SDR: keep HDR untouched
            Toast.makeText(this, R.string.lumen_deband_hdr, Toast.LENGTH_LONG).show()
            return
        }
        cleanup = level
        updateDebandButton()
        val effects = LumenVideoCleanup.effectsFor(level)
        if (!effectsPipelineReady) {
            //the video-effects pipeline can only be set up before prepare(): restart at the same spot
            effectsPipelineReady = true
            trackSelector?.let { it.setParameters(it.buildUponParameters().setTunnelingEnabled(false)) }
            val pos = exo.currentPosition
            val play = exo.playWhenReady
            exo.stop()
            exo.setVideoEffects(effects)
            exo.seekTo(pos)
            exo.playWhenReady = play
            exo.prepare()
        } else {
            exo.setVideoEffects(effects)
        }
        droppedFramesSince = android.os.SystemClock.elapsedRealtime()
        droppedFrames = 0
        if (announce) {
            Toast.makeText(this, if (level == LumenVideoCleanup.Level.OFF) R.string.lumen_anime_deband_off
                else R.string.lumen_anime_deband_on_desc, Toast.LENGTH_SHORT).show()
        }
    }

    //"intelligent" safety net: if the device can't keep up (many dropped frames), step the level down
    private var droppedFrames = 0
    private var droppedFramesSince = 0L

    private fun onFramesDropped(count: Int) {
        if (!debandOn) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - droppedFramesSince > 20_000) {
            droppedFramesSince = now
            droppedFrames = 0
        }
        droppedFrames += count
        if (droppedFrames >= 40) {
            setCleanup(LumenVideoCleanup.Level.OFF, announce = false)
            Toast.makeText(this, R.string.lumen_anime_deband_too_slow, Toast.LENGTH_LONG).show()
        }
    }

    private fun showErrorDialog(error: PlaybackException) {
        val s = stream ?: return
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this)
            .setTitle(R.string.sofa_player_error_title)
            .setMessage(getString(R.string.sofa_player_error_msg, error.errorCodeName))
            .setPositiveButton(R.string.sofa_open_external) { _, _ ->
                SofaVideoHandoff.openExternal(this, s.copy(positionMs = player?.currentPosition ?: 0L))
                finish()
            }
            .setNegativeButton(R.string.cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        //show controls on any D-pad key, PlayerView handles the rest (media keys, seeking)
        if (event.action == KeyEvent.ACTION_DOWN && !playerView.isControllerFullyVisible &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER ||
                    event.keyCode == KeyEvent.KEYCODE_DPAD_UP || event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN)) {
            playerView.showController()
            return true
        }
        //the Deband button sits above the controls: Up reaches it, Down returns to the controls
        if (::debandButton.isInitialized && debandButton.isFocused) {
            if (event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && event.action == KeyEvent.ACTION_DOWN) {
                playerView.showController()
                playerView.requestFocus()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
        if (event.keyCode == KeyEvent.KEYCODE_DPAD_UP && event.action == KeyEvent.ACTION_DOWN &&
            playerView.isControllerFullyVisible && debandButton.visibility == View.VISIBLE) {
            val focused = currentFocus
            //from the top row of the controls (nothing above inside the player) go to the button
            val next = focused?.focusSearch(View.FOCUS_UP)
            if (next == null || next === playerView || !isDescendant(playerView, next)) {
                debandButton.requestFocus()
                return true
            }
        }
        return playerView.dispatchKeyEvent(event) || super.dispatchKeyEvent(event)
    }

    private fun isDescendant(parent: View, child: View): Boolean {
        var v: android.view.ViewParent? = child.parent
        while (v != null) {
            if (v === parent) return true
            v = v.parent
        }
        return false
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            //true full screen on phones/tablets: hide status and navigation bars
            val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
