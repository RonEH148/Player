package com.phlox.tvwebbrowser.activity.main

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Typeface
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.BuildConfig
import com.phlox.tvwebbrowser.Config
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.TVBro
import com.phlox.tvwebbrowser.singleton.AppDatabase
import com.phlox.tvwebbrowser.sofa.LumenDownloads
import com.phlox.tvwebbrowser.sofa.LumenUpdater
import com.phlox.tvwebbrowser.sofa.SofaPasswords
import com.phlox.tvwebbrowser.sofa.SofaVpn
import com.phlox.tvwebbrowser.webengine.WebEngineFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wisp (phone build): settings as a phone screen - a list of sections, each opening its own page
 * with switches and choices (Lumen keeps its TV settings dialog). Only phone-relevant settings:
 * nothing for the remote, the cursor or TV video chips.
 */
class WispSettings(
    private val activity: MainActivity,
    private val settingsModel: SettingsModel,
    private val adblockModel: AdblockModel
) {
    private val config: Config = AppContext.provideConfig()
    private val dp = activity.resources.displayMetrics.density
    private fun px(v: Float) = (v * dp).toInt()
    private fun color(id: Int) = ContextCompat.getColor(activity, id)
    private fun str(id: Int, vararg args: Any): String = activity.getString(id, *args)

    private val dialog = object : Dialog(activity, R.style.WispSettingsScreen) {
        @Deprecated("Deprecated in Java")
        override fun onBackPressed() {
            if (pages.size > 1) {
                pages.removeAt(pages.size - 1)
                render()
            } else {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }
    private val title = TextView(activity)
    private val content = LinearLayout(activity)
    private val scroll = ScrollView(activity)

    /** Open pages, the current one last. */
    private val pages = ArrayList<Page>()

    private enum class Page(val title: Int) {
        MAIN(R.string.wisp_settings),
        GENERAL(R.string.wisp_set_general),
        PRIVACY(R.string.wisp_set_privacy),
        ADBLOCK(R.string.wisp_set_adblock),
        CONTENT(R.string.wisp_set_content),
        DOWNLOADS(R.string.wisp_set_downloads),
        VPN(R.string.wisp_set_vpn),
        ABOUT(R.string.wisp_set_about)
    }

    private val vpnObserver: (SofaVpn.Status) -> Unit = { if (pages.lastOrNull() == Page.VPN || pages.lastOrNull() == Page.MAIN) render() }
    private val adblockObserver: (Boolean) -> Unit = { if (pages.lastOrNull() == Page.ADBLOCK) render() }

    init {
        val root = LinearLayout(activity)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(color(R.color.wisp_bg))

        //app bar: ← Title
        val bar = LinearLayout(activity)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(px(4f), px(4f), px(16f), px(4f))
        bar.setBackgroundColor(color(R.color.wisp_bar))
        val back = ImageView(activity)
        back.setImageResource(R.drawable.ic_wisp_back)
        back.setColorFilter(color(R.color.wisp_icon))
        back.scaleType = ImageView.ScaleType.CENTER_INSIDE
        back.background = ripple()
        back.contentDescription = str(R.string.wisp_back)
        @Suppress("DEPRECATION")
        back.setOnClickListener { dialog.onBackPressed() }
        bar.addView(back, LinearLayout.LayoutParams(px(48f), px(48f)))
        title.textSize = 20f
        title.setTextColor(color(R.color.wisp_text))
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setPadding(px(8f), 0, 0, 0)
        bar.addView(title)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(60f)))

        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, px(4f), 0, px(32f))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        dialog.setContentView(root)
        dialog.setOnDismissListener {
            scroll.removeCallbacks(vpnPoll)
            SofaVpn.status.unsubscribe(vpnObserver)
            adblockModel.clientLoading.unsubscribe(adblockObserver)
        }
        dialog.window?.let {
            it.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
            it.setWindowAnimations(android.R.style.Animation_Activity)
        }
    }

    /** The tunnel runs in the main process: its state is read again every 1.5 s while settings are open. */
    private val vpnPoll = object : Runnable {
        override fun run() {
            SofaVpn.refreshStatus()
            if (dialog.isShowing) scroll.postDelayed(this, 1500)
        }
    }

    fun show() {
        pages.clear()
        pages.add(Page.MAIN)
        SofaVpn.refreshStatus()
        scroll.postDelayed(vpnPoll, 1500)
        SofaVpn.status.subscribe(vpnObserver, false)
        adblockModel.clientLoading.subscribe(adblockObserver, false)
        render()
        dialog.show()
    }

    private fun open(page: Page) {
        pages.add(page)
        render()
        scroll.scrollTo(0, 0)
    }

    private fun render() {
        val page = pages.last()
        title.text = str(page.title)
        val y = scroll.scrollY
        content.removeAllViews()
        when (page) {
            Page.MAIN -> mainPage()
            Page.GENERAL -> generalPage()
            Page.PRIVACY -> privacyPage()
            Page.ADBLOCK -> adblockPage()
            Page.CONTENT -> contentPage()
            Page.DOWNLOADS -> downloadsPage()
            Page.VPN -> vpnPage()
            Page.ABOUT -> aboutPage()
        }
        scroll.post { scroll.scrollTo(0, y) }
    }

    // ---------------- pages ----------------

    private fun mainPage() {
        nav(R.drawable.ic_settings_grey_900_24dp, R.string.wisp_set_general, str(R.string.wisp_set_general_sum), Page.GENERAL)
        nav(R.drawable.ic_wisp_shield, R.string.wisp_set_privacy, str(R.string.wisp_set_privacy_sum), Page.PRIVACY)
        nav(R.drawable.ic_wisp_block, R.string.wisp_set_adblock,
            str(if (config.adBlockEnabled) R.string.wisp_on else R.string.wisp_off), Page.ADBLOCK)
        nav(R.drawable.ic_wisp_globe, R.string.wisp_set_content, str(R.string.wisp_set_content_sum), Page.CONTENT)
        nav(R.drawable.ic_wisp_download, R.string.wisp_set_downloads, LumenDownloads.folderLabel(activity), Page.DOWNLOADS)
        nav(R.drawable.ic_wisp_vpn, R.string.wisp_set_vpn, vpnStatusText(), Page.VPN)
        nav(R.drawable.ic_wisp_info, R.string.wisp_set_about, BuildConfig.VERSION_NAME, Page.ABOUT)
    }

    private fun generalPage() {
        header(R.string.wisp_set_search)
        val engineIndex = Config.SearchEnginesURLs.indexOf(config.searchEngineURL.value)
            .let { if (it < 0 || config.searchEngineURL.value.isEmpty()) Config.SearchEnginesTitles.size - 1 else it }
        choice(R.string.wisp_set_search_engine, Config.SearchEnginesTitles.toList(), engineIndex) { i ->
            if (i == Config.SearchEnginesTitles.size - 1) {
                textInput(R.string.wisp_set_search_engine, config.searchEngineURL.value, str(R.string.wisp_set_search_custom_hint)) { url ->
                    if (url.contains("[query]")) settingsModel.setSearchEngineURL(url)
                    else Toast.makeText(activity, R.string.wisp_set_search_custom_hint, Toast.LENGTH_LONG).show()
                    render()
                }
            } else {
                settingsModel.setSearchEngineURL(Config.SearchEnginesURLs[i])
            }
        }

        header(R.string.wisp_set_start)
        val modes = activity.resources.getStringArray(R.array.home_page_modes).toList()
        choice(R.string.wisp_set_start_page, modes, settingsModel.homePageMode.ordinal) { i ->
            val mode = Config.HomePageMode.entries[i]
            if (mode == Config.HomePageMode.CUSTOM) {
                textInput(R.string.wisp_set_start_page, if (settingsModel.homePage.startsWith("http")) settingsModel.homePage else "https://",
                    "https://…") { url ->
                    settingsModel.setHomePageProperties(mode, url, settingsModel.homePageLinksMode)
                    render()
                }
            } else {
                settingsModel.setHomePageProperties(mode, null, settingsModel.homePageLinksMode)
            }
        }
        if (settingsModel.homePageMode == Config.HomePageMode.HOME_PAGE) {
            val links = activity.resources.getStringArray(R.array.home_page_links_modes).toList()
            choice(R.string.wisp_set_start_shows, links, settingsModel.homePageLinksMode.ordinal) { i ->
                settingsModel.setHomePageProperties(settingsModel.homePageMode, null, Config.HomePageLinksMode.entries[i])
            }
        }

        header(R.string.wisp_set_look)
        val themes = listOf(str(R.string.wisp_theme_system), str(R.string.wisp_theme_light), str(R.string.wisp_theme_dark))
        choice(R.string.wisp_set_theme, themes, config.theme.value.ordinal) { i ->
            config.theme.value = Config.Theme.values()[i]
        }
        val zooms = listOf(75, 85, 100, 115, 130, 150, 175, 200)
        val zoomIndex = zooms.indices.minByOrNull { kotlin.math.abs(zooms[it] - config.wispTextZoom) } ?: 2
        choice(R.string.wisp_set_text_size, zooms.map { "$it %" }, zoomIndex) { i ->
            config.wispTextZoom = zooms[i]
            activity.applyTextZoom()
        }
        switch(R.string.wisp_set_hide_bar, R.string.wisp_set_hide_bar_sum, config.lumenAutoHideToolbar) {
            config.lumenAutoHideToolbar = it
            if (!it) activity.showToolbar()
        }
        switch(R.string.wisp_set_pull_refresh, R.string.wisp_set_pull_refresh_sum, config.wispPullToRefresh) {
            config.wispPullToRefresh = it
        }

        header(R.string.wisp_set_identity)
        val uaTitles = settingsModel.userAgentStringTitles.toList()
        val ua = config.userAgentString.value
        val uaIndex = if (ua == null) 0 else settingsModel.uaStrings.indexOf(ua).let { if (it < 0) uaTitles.size - 1 else it }
        choice(R.string.wisp_set_user_agent, uaTitles, uaIndex) { i ->
            if (i == uaTitles.size - 1) {
                textInput(R.string.wisp_set_user_agent, ua ?: "", "Mozilla/5.0 …") { text ->
                    config.userAgentString.value = text.trim().ifEmpty { null }
                    render()
                }
            } else {
                config.userAgentString.value = settingsModel.uaStrings[i].ifEmpty { null }
            }
        }
    }

    private fun privacyPage() {
        header(R.string.wisp_set_private_browsing)
        switch(R.string.wisp_set_always_private, R.string.wisp_set_always_private_sum, config.wispAlwaysPrivate) {
            config.wispAlwaysPrivate = it
        }
        switch(R.string.wisp_set_clear_history, R.string.wisp_set_clear_history_sum, config.lumenClearHistoryOnExit) {
            config.lumenClearHistoryOnExit = it
        }
        switch(R.string.wisp_set_clear_cookies, R.string.wisp_set_clear_cookies_sum, config.lumenClearCookiesOnExit) {
            config.lumenClearCookiesOnExit = it
        }
        action(R.string.wisp_set_clear_now, str(R.string.wisp_set_clear_now_sum)) { clearBrowsingData() }
        action(R.string.wisp_set_clear_cache, str(R.string.wisp_set_clear_cache_sum)) {
            activity.lifecycleScope.launch {
                WebEngineFactory.clearCache(activity)
                Toast.makeText(activity, R.string.wisp_set_done, Toast.LENGTH_SHORT).show()
            }
        }

        header(R.string.wisp_set_tracking)
        switch(R.string.wisp_set_https_first, R.string.wisp_set_https_first_sum, config.wispHttpsFirst) {
            config.wispHttpsFirst = it
        }
        switch(R.string.wisp_set_block_3p, R.string.wisp_set_block_3p_sum, config.wispBlockThirdPartyCookies) {
            config.wispBlockThirdPartyCookies = it
            activity.reapplyCookiePolicy()
        }
        val allowed = config.wispThirdPartyCookieSites.sorted()
        action(R.string.wisp_set_3p_sites, if (allowed.isEmpty()) str(R.string.wisp_set_none) else allowed.joinToString(", ")) {
            editSiteList(R.string.wisp_set_3p_sites, allowed) {
                config.wispThirdPartyCookieSites = it.toSet()
                activity.reapplyCookiePolicy()
            }
        }
        switch(R.string.wisp_set_verify_compat, R.string.wisp_set_verify_compat_sum, config.sofaCloudflareCompat) {
            config.sofaCloudflareCompat = it
            Toast.makeText(activity, R.string.wisp_set_restart_hint, Toast.LENGTH_SHORT).show()
        }

        header(R.string.wisp_set_passwords)
        switch(R.string.wisp_set_save_passwords, R.string.wisp_set_save_passwords_sum, config.sofaSavePasswords) {
            config.sofaSavePasswords = it
        }
        action(R.string.wisp_set_saved_passwords, null) { SofaPasswords.showManager(activity) }

        note(R.string.wisp_privacy_note)
    }

    private fun adblockPage() {
        switch(R.string.wisp_set_block_ads, R.string.wisp_set_block_ads_sum, config.adBlockEnabled) {
            config.adBlockEnabled = it
            render()
        }
        if (!config.adBlockEnabled) return
        switch(R.string.wisp_set_cosmetic, R.string.wisp_set_cosmetic_sum, config.sofaCosmeticFilter) {
            config.sofaCosmeticFilter = it
        }
        switch(R.string.wisp_set_popups, R.string.wisp_set_popups_sum, config.sofaPopupBlocker) {
            config.sofaPopupBlocker = it
        }
        header(R.string.wisp_set_filter_lists)
        val lists = config.adBlockListURL.value.split('\n', ' ', ',').count { it.isNotBlank() }
        action(R.string.wisp_set_filter_lists, activity.resources.getQuantityString(R.plurals.wisp_lists_n, lists, lists)) {
            textInput(R.string.wisp_set_filter_lists, config.adBlockListURL.value, "https://…", multiLine = true) { text ->
                config.adBlockListURL.value = text.trim().ifEmpty { Config.DEFAULT_ADBLOCK_LIST_URL }
                render()
            }
        }
        val last = if (config.adBlockListLastUpdate == 0L) str(R.string.never)
            else SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(config.adBlockListLastUpdate))
        val loading = adblockModel.clientLoading.value
        action(R.string.wisp_set_update_lists, if (loading) str(R.string.wisp_set_updating) else str(R.string.wisp_set_last_update_s, last),
            enabled = !loading) {
            adblockModel.loadAdBlockList(true)
            render()
        }
        val sites = config.adBlockDisabledHosts.sorted()
        action(R.string.wisp_set_adblock_sites, if (sites.isEmpty()) str(R.string.wisp_set_none) else sites.joinToString(", ")) {
            editSiteList(R.string.wisp_set_adblock_sites, sites) { config.adBlockDisabledHosts = it.toSet() }
        }
        note(R.string.wisp_set_reload_note)
    }

    private fun contentPage() {
        header(R.string.wisp_set_dark)
        switch(R.string.wisp_set_force_dark, R.string.wisp_set_force_dark_sum, config.sofaForceDark) { config.sofaForceDark = it }
        switch(R.string.wisp_set_algo_dark, R.string.wisp_set_algo_dark_sum, config.webviewUseAlgorithmicDarkeningWithDarkUiMode) {
            config.webviewUseAlgorithmicDarkeningWithDarkUiMode = it
        }
        header(R.string.wisp_set_media)
        switch(R.string.wisp_set_autoplay, R.string.wisp_set_autoplay_sum, config.allowAutoplayMedia) { config.allowAutoplayMedia = it }
        switch(R.string.wisp_set_max_quality, R.string.wisp_set_max_quality_sum, config.sofaAutoMaxQuality) { config.sofaAutoMaxQuality = it }
        switch(R.string.wisp_set_stop_mini, R.string.wisp_set_stop_mini_sum, config.lumenStopMiniPlayer) { config.lumenStopMiniPlayer = it }
        switch(R.string.wisp_set_subtitle_box, R.string.wisp_set_subtitle_box_sum, config.lumenSubtitleBox) { config.lumenSubtitleBox = it }
        header(R.string.wisp_set_scripts)
        action(R.string.wisp_set_user_script,
            if (config.sofaUserScript.isBlank()) str(R.string.wisp_set_none) else str(R.string.wisp_set_user_script_set)) {
            textInput(R.string.wisp_set_user_script, config.sofaUserScript, "document.body.style…", multiLine = true, code = true) {
                config.sofaUserScript = it
                render()
            }
        }
        note(R.string.wisp_set_reload_note)
    }

    private fun downloadsPage() {
        action(R.string.wisp_set_download_folder, LumenDownloads.folderLabel(activity)) {
            activity.pickDownloadFolder { render() }
        }
        if (config.lumenDownloadFolderUri.isNotEmpty()) {
            action(R.string.wisp_set_default_folder, null) {
                config.lumenDownloadFolderUri = ""
                render()
            }
        }
        val parts = (1..16).toList()
        choice(R.string.wisp_set_parts, parts.map { it.toString() }, (config.lumenDownloadParts - 1).coerceIn(0, 15),
            summary = str(R.string.wisp_set_parts_sum)) { i -> config.lumenDownloadParts = parts[i] }
        val max = (1..6).toList()
        choice(R.string.wisp_set_max_downloads, max.map { it.toString() }, (config.lumenMaxDownloads - 1).coerceIn(0, 5)) { i ->
            config.lumenMaxDownloads = max[i]
        }
        //KB/s: off, 0.5, 1, 2, 3, 5, 8, 12, 20, 40 MB/s
        val limits = intArrayOf(0, 512, 1024, 2048, 3072, 5120, 8192, 12288, 20480, 40960)
        fun limitText(k: Int) = if (k == 0) str(R.string.wisp_set_no_limit) else if (k < 1024) "$k KB/s" else
            (if (k % 1024 == 0) (k / 1024).toString() else String.format(Locale.US, "%.1f", k / 1024.0)) + " MB/s"
        val cur = limits.indices.minByOrNull { kotlin.math.abs(limits[it] - config.lumenSpeedLimitKBps) } ?: 0
        choice(R.string.wisp_set_speed_limit, limits.map { limitText(it) }, cur) { i -> config.lumenSpeedLimitKBps = limits[i] }
    }

    private fun vpnPage() {
        val status = SofaVpn.status.value
        val configured = status != SofaVpn.Status.NOT_CONFIGURED
        action(R.string.wisp_set_vpn_status, vpnStatusText(), enabled = false) {}
        if (configured) {
            val connected = status == SofaVpn.Status.CONNECTED
            action(if (connected) R.string.sofa_vpn_disconnect else R.string.sofa_vpn_connect, null,
                enabled = status != SofaVpn.Status.CONNECTING) {
                if (connected) activity.lifecycleScope.launch { SofaVpn.disconnect(activity.applicationContext) }
                else activity.requestVpnConnect()
            }
        }
        header(R.string.wisp_set_vpn_config)
        action(R.string.sofa_vpn_import_file, null) { activity.pickVpnConfigFile() }
        action(R.string.sofa_vpn_paste, null) { pasteVpnConfig() }
        action(R.string.sofa_vpn_import_any, str(R.string.sofa_vpn_import_any_sum)) { activity.pickVpnFileOrArchive() }
        if (configured) {
            action(R.string.sofa_vpn_remove, null, danger = true) {
                confirm(R.string.sofa_vpn_remove, str(R.string.sofa_vpn_remove_q)) { SofaVpn.removeConfig(activity) }
            }
        }
        header(R.string.wisp_set_vpn_options)
        switch(R.string.sofa_vpn_browser_only, R.string.sofa_vpn_browser_only_desc, config.sofaVpnBrowserOnly) { config.sofaVpnBrowserOnly = it }
        switch(R.string.sofa_vpn_auto_connect, R.string.sofa_vpn_auto_connect_desc, config.sofaVpnAutoConnect) { config.sofaVpnAutoConnect = it }
    }

    private fun aboutPage() {
        action(R.string.wisp_set_version, "${BuildConfig.VERSION_NAME} · build ${BuildConfig.VERSION_CODE}\n" +
                str(R.string.wisp_set_engine_s, WebEngineFactory.getWebEngineVersionString()), enabled = false) {}
        header(R.string.wisp_set_updates)
        action(R.string.wisp_set_check_updates, null) {
            dialog.dismiss()
            LumenUpdater.check(activity, quiet = false)
        }
        switch(R.string.wisp_set_auto_updates, R.string.wisp_set_auto_updates_sum, config.lumenAutoCheckUpdates) {
            config.lumenAutoCheckUpdates = it
        }
        action(R.string.lumen_update_source, config.lumenUpdateRepo +
                if (LumenUpdater.hasToken()) " · " + str(R.string.wisp_set_token_saved) else "") { updateSource() }
        action(R.string.wisp_set_browser_check, str(R.string.wisp_set_browser_check_sum)) {
            dialog.dismiss()
            activity.openBrowserCheck()
        }
        header(R.string.wisp_set_credits)
        note(R.string.sofabrowse_credit)
        action(R.string.view_license, null) {
            dialog.dismiss()
            activity.navigate("https://github.com/truefedex/tv-bro/blob/master/LICENSE.md")
        }
    }

    // ---------------- actions ----------------

    private fun vpnStatusText(): String {
        val server = SofaVpn.endpointLabel()
        return when (SofaVpn.status.value) {
            SofaVpn.Status.NOT_CONFIGURED -> str(R.string.sofa_vpn_status_none)
            SofaVpn.Status.DISCONNECTED -> str(R.string.sofa_vpn_status_off, server ?: "")
            SofaVpn.Status.CONNECTING -> str(R.string.sofa_vpn_status_connecting)
            SofaVpn.Status.CONNECTED -> str(R.string.sofa_vpn_status_on, server ?: "",
                str(if (config.sofaVpnBrowserOnly) R.string.sofa_vpn_scope_browser else R.string.sofa_vpn_scope_device))
            SofaVpn.Status.ERROR -> str(R.string.sofa_vpn_status_error, SofaVpn.lastError ?: "")
        }
    }

    private fun clearBrowsingData() {
        val labels = arrayOf(str(R.string.wisp_clear_history), str(R.string.wisp_clear_cookies), str(R.string.wisp_clear_cache))
        val checked = booleanArrayOf(true, true, true)
        AlertDialog.Builder(activity)
            .setTitle(R.string.wisp_set_clear_now)
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.wisp_clear) { _, _ ->
                activity.lifecycleScope.launch {
                    if (checked[0]) withContext(Dispatchers.IO) {
                        try { AppDatabase.db.historyDao().deleteWhereTimeLessThan(Long.MAX_VALUE) } catch (e: Exception) {}
                    }
                    if (checked[1]) {
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        WebStorage.getInstance().deleteAllData()
                    }
                    if (checked[2]) WebEngineFactory.clearCache(activity)
                    Toast.makeText(activity, R.string.wisp_set_done, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** A list of sites; untick the ones to remove. */
    private fun editSiteList(titleRes: Int, sites: List<String>, save: (List<String>) -> Unit) {
        if (sites.isEmpty()) {
            Toast.makeText(activity, R.string.wisp_set_sites_empty, Toast.LENGTH_LONG).show()
            return
        }
        val checked = BooleanArray(sites.size) { true }
        AlertDialog.Builder(activity)
            .setTitle(titleRes)
            .setMultiChoiceItems(sites.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.wisp_save) { _, _ ->
                save(sites.filterIndexed { i, _ -> checked[i] })
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pasteVpnConfig() {
        textInput(R.string.sofa_vpn_paste, "", "[Interface]\nPrivateKey = …\nAddress = …\n\n[Peer]\nPublicKey = …\nEndpoint = …",
            multiLine = true, code = true) { text ->
            val error = SofaVpn.importConfig(text)
            Toast.makeText(activity,
                if (error == null) str(R.string.sofa_vpn_imported) else str(R.string.sofa_vpn_bad_config, error),
                Toast.LENGTH_LONG).show()
            SofaVpn.refreshStatus()
            render()
        }
    }

    private fun updateSource() {
        val box = LinearLayout(activity)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(px(22f), px(8f), px(22f), 0)
        val repo = EditText(activity)
        repo.hint = "owner/repository"
        repo.isSingleLine = true
        repo.setText(config.lumenUpdateRepo)
        val token = EditText(activity)
        token.hint = str(R.string.lumen_update_token_hint)
        token.isSingleLine = true
        token.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val help = TextView(activity)
        help.text = str(R.string.lumen_update_token_help)
        help.textSize = 13f
        help.setTextColor(color(R.color.wisp_text_secondary))
        help.setPadding(0, px(8f), 0, 0)
        box.addView(repo)
        box.addView(token)
        box.addView(help)
        AlertDialog.Builder(activity)
            .setTitle(R.string.lumen_update_source)
            .setView(box)
            .setPositiveButton(R.string.wisp_save) { _, _ ->
                val r = repo.text.toString().trim().removePrefix("https://github.com/").trim('/')
                if (r.matches(Regex("""[\w.-]+/[\w.-]+"""))) config.lumenUpdateRepo = r
                val t = token.text.toString().trim()
                if (t.isNotEmpty()) LumenUpdater.setToken(t)
                render()
            }
            .setNeutralButton(R.string.lumen_update_token_clear) { _, _ ->
                LumenUpdater.setToken(null)
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun textInput(titleRes: Int, value: String, hint: String, multiLine: Boolean = false, code: Boolean = false,
                          save: (String) -> Unit) {
        val box = LinearLayout(activity)
        box.setPadding(px(22f), px(8f), px(22f), 0)
        val edit = EditText(activity)
        edit.setText(value)
        edit.hint = hint
        if (multiLine) {
            edit.minLines = 4
            edit.maxLines = 10
            edit.gravity = Gravity.TOP or Gravity.START
            edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        } else {
            edit.isSingleLine = true
            edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        if (code) {
            edit.typeface = Typeface.MONOSPACE
            edit.textSize = 13f
        }
        box.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(activity)
            .setTitle(titleRes)
            .setView(box)
            .setPositiveButton(R.string.wisp_save) { _, _ -> save(edit.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirm(titleRes: Int, message: String, yes: () -> Unit) {
        AlertDialog.Builder(activity)
            .setTitle(titleRes)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> yes() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------------- rows ----------------

    private fun ripple(): android.graphics.drawable.Drawable? {
        val tv = android.util.TypedValue()
        activity.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return if (tv.resourceId != 0) ContextCompat.getDrawable(activity, tv.resourceId) else null
    }

    private fun header(textRes: Int) {
        val t = TextView(activity)
        t.text = str(textRes)
        t.textSize = 13f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(color(R.color.wisp_accent))
        t.setPadding(px(20f), px(22f), px(20f), px(6f))
        content.addView(t)
    }

    private fun note(textRes: Int) {
        val t = TextView(activity)
        t.text = str(textRes)
        t.textSize = 13f
        t.setTextColor(color(R.color.wisp_text_secondary))
        t.setPadding(px(20f), px(16f), px(20f), px(8f))
        content.addView(t)
    }

    /** Title, second line, and something on the right (switch, chevron or nothing). */
    private fun row(title: String, summary: String?, icon: Int? = null, right: View? = null, enabled: Boolean = true,
                    danger: Boolean = false, onClick: (() -> Unit)?): LinearLayout {
        val row = LinearLayout(activity)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = px(56f)
        row.setPadding(px(20f), px(10f), px(16f), px(10f))
        if (onClick != null && enabled) {
            row.background = ripple()
            row.setOnClickListener { onClick() }
        }
        if (icon != null) {
            val iv = ImageView(activity)
            iv.setImageResource(icon)
            iv.setColorFilter(color(R.color.wisp_icon))
            val lp = LinearLayout.LayoutParams(px(24f), px(24f))
            lp.marginEnd = px(20f)
            row.addView(iv, lp)
        }
        val texts = LinearLayout(activity)
        texts.orientation = LinearLayout.VERTICAL
        val t = TextView(activity)
        t.text = title
        t.textSize = 16f
        t.setTextColor(if (danger) 0xFFD84343.toInt() else color(R.color.wisp_text))
        texts.addView(t)
        if (!summary.isNullOrEmpty()) {
            val s = TextView(activity)
            s.text = summary
            s.textSize = 13.5f
            s.setTextColor(color(R.color.wisp_text_secondary))
            s.maxLines = 4
            s.ellipsize = TextUtils.TruncateAt.END
            s.setPadding(0, px(2f), 0, 0)
            texts.addView(s)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (right != null) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginStart = px(12f)
            row.addView(right, lp)
        }
        row.alpha = if (enabled || onClick == null) 1f else 0.4f
        content.addView(row)
        return row
    }

    private fun nav(icon: Int, titleRes: Int, summary: String?, page: Page) {
        val chevron = ImageView(activity)
        chevron.setImageResource(R.drawable.ic_wisp_chevron)
        chevron.setColorFilter(color(R.color.wisp_text_secondary))
        row(str(titleRes), summary, icon, chevron) { open(page) }
    }

    private fun switch(titleRes: Int, summaryRes: Int, value: Boolean, save: (Boolean) -> Unit) {
        val sw = android.widget.Switch(activity)
        sw.isChecked = value
        sw.isClickable = false
        sw.isFocusable = false
        WispSheets.tintSwitch(sw, activity)
        row(str(titleRes), str(summaryRes), right = sw) {
            sw.isChecked = !sw.isChecked
            save(sw.isChecked)
        }
    }

    private fun action(titleRes: Int, summary: String?, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) {
        row(str(titleRes), summary, enabled = enabled, danger = danger, onClick = onClick)
    }

    /** A setting with a few choices: shows the current one, opens a list to pick another. */
    private fun choice(titleRes: Int, labels: List<String>, current: Int, summary: String? = null, pick: (Int) -> Unit) {
        val shown = labels.getOrNull(current) ?: ""
        row(str(titleRes), if (summary != null) "$shown · $summary" else shown) {
            AlertDialog.Builder(activity)
                .setTitle(titleRes)
                .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                    d.dismiss()
                    pick(which)
                    render()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }
}
