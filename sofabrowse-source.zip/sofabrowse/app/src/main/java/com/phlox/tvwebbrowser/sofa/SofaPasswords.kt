package com.phlox.tvwebbrowser.sofa

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.webkit.WebView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.Config
import com.phlox.tvwebbrowser.R
import org.json.JSONObject

/**
 * Built-in password saver. One login per site, encrypted with [SofaCrypto]. Logins are only
 * filled into the top-level page of the exact site they were saved for.
 */
object SofaPasswords {
    private const val PREFS = "sofa_passwords"

    data class Login(val site: String, val username: String, val password: String)

    private fun prefs() = AppContext.get().getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun siteOf(url: String?): String? {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return null
        val host = try { Uri.parse(url).host } catch (e: Exception) { null } ?: return null
        return Config.siteKey(host).ifEmpty { null }
    }

    fun get(site: String): Login? {
        val enc = prefs().getString(site, null) ?: return null
        val json = SofaCrypto.decrypt(enc) ?: return null
        return try {
            val o = JSONObject(json)
            Login(site, o.optString("u"), o.optString("p"))
        } catch (e: Exception) {
            null
        }
    }

    fun save(login: Login): Boolean {
        val json = JSONObject().put("u", login.username).put("p", login.password).toString()
        val enc = SofaCrypto.encrypt(json) ?: return false
        prefs().edit().putString(login.site, enc).apply()
        return true
    }

    fun delete(site: String) = prefs().edit().remove(site).apply()

    fun all(): List<Login> = prefs().all.keys.sorted().mapNotNull { get(it) }

    fun offerToSave(activity: Activity, webView: WebView, username: String, password: String) {
        val config = AppContext.provideConfig()
        if (!config.sofaSavePasswords || config.incognitoMode) return
        val site = siteOf(webView.url) ?: return
        if (config.sofaPasswordNeverHosts.contains(site)) return
        val existing = get(site)
        if (existing != null && existing.username == username && existing.password == password) return
        val title = activity.getString(
            if (existing != null && existing.username == username) R.string.sofa_update_password_q else R.string.sofa_save_password_q,
            site
        )
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(if (username.isNotEmpty()) activity.getString(R.string.sofa_username_s, username) else null)
            .setPositiveButton(R.string.sofa_save) { _, _ ->
                val ok = save(Login(site, username, password))
                Toast.makeText(activity, if (ok) R.string.sofa_password_saved else R.string.sofa_password_save_failed,
                    Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.sofa_not_now, null)
            .setNeutralButton(R.string.sofa_never_for_site) { _, _ ->
                config.sofaPasswordNeverHosts = config.sofaPasswordNeverHosts + site
            }
            .show()
    }

    /**
     * Sign-up forms and the suggested strong password: saved without asking. An empty username
     * keeps the one already saved (the address is often typed after the password is chosen).
     */
    fun autoSave(activity: Activity, webView: WebView, username: String, password: String) {
        val config = AppContext.provideConfig()
        if (!config.sofaSavePasswords || config.incognitoMode || password.isEmpty()) return
        val site = siteOf(webView.url) ?: return
        if (config.sofaPasswordNeverHosts.contains(site)) return
        val existing = get(site)
        val user = username.ifEmpty { existing?.username ?: "" }
        if (existing != null && existing.username == user && existing.password == password) return
        if (save(Login(site, user, password))) {
            Toast.makeText(activity, if (user.isNotEmpty()) "Password for $user saved for $site"
                else "Password saved for $site", Toast.LENGTH_SHORT).show()
        }
    }

    /** Called when a page has finished loading in the top frame. */
    fun fillIfSaved(webView: WebView, url: String?) {
        val config = AppContext.provideConfig()
        if (!config.sofaSavePasswords) return
        val site = siteOf(url) ?: return
        if (site != siteOf(webView.url)) return
        val login = get(site) ?: return
        webView.evaluateJavascript(
            "window.__sofaFill && window.__sofaFill(" + JSONObject.quote(login.username) + "," +
                    JSONObject.quote(login.password) + ");", null
        )
    }

    /** Settings screen: list saved logins, tap one to delete it. */
    fun showManager(activity: Activity) {
        val logins = all()
        val config = AppContext.provideConfig()
        val builder = AlertDialog.Builder(activity).setTitle(R.string.sofa_saved_passwords)
        if (logins.isEmpty()) {
            builder.setMessage(R.string.sofa_no_saved_passwords)
        } else {
            val labels = logins.map { if (it.username.isNotEmpty()) "${it.site}  ·  ${it.username}" else it.site }
                .toTypedArray()
            builder.setItems(labels) { _, which ->
                val login = logins[which]
                AlertDialog.Builder(activity)
                    .setTitle(login.site)
                    .setMessage("Username: ${login.username.ifEmpty { "—" }}\nPassword: ${login.password}\n\n" +
                            activity.getString(R.string.sofa_delete_login_q))
                    .setPositiveButton(R.string.sofa_delete) { _, _ ->
                        delete(login.site)
                        showManager(activity)
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        }
        if (config.sofaPasswordNeverHosts.isNotEmpty()) {
            builder.setNeutralButton(R.string.sofa_reset_never_list) { _, _ ->
                config.sofaPasswordNeverHosts = emptySet()
            }
        }
        builder.setPositiveButton(R.string.ok, null).show()
    }
}
