package com.phlox.tvwebbrowser.sofa

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.phlox.tvwebbrowser.R
import java.util.Collections
import java.util.Locale

/**
 * Hands a web video over to the native 4K player or to an external player app.
 *
 * Sites that use Media Source Extensions play from a "blob:" URL that no other player can open,
 * so the browser also remembers the stream files (HLS .m3u8, DASH .mpd, MP4, WebM, MKV) each page
 * requests and offers those instead.
 */
object SofaVideoHandoff {
    const val MODE_NATIVE = "native"
    const val MODE_EXTERNAL = "external"
    /** Lumen's player with anime deband switched on from the start. */
    const val MODE_NATIVE_DEBAND = "native_deband"

    /** When a player was last opened (several frames of a page may answer the same request). */
    @Volatile var lastLaunchAt = 0L

    data class Stream(
        val url: String,
        val title: String,
        val referer: String?,
        val userAgent: String?,
        val cookies: String?,
        val positionMs: Long,
        /** Request headers the page's own player used for this stream (Origin, Referer, ...). */
        val headers: Map<String, String> = emptyMap()
    )

    enum class MediaKind(val label: String) { VIDEO("Video"), AUDIO("Audio"), SUBTITLE("Subtitles") }

    class DetectedMedia(val url: String, val referer: String?, val time: Long,
                        val kind: MediaKind = MediaKind.VIDEO,
                        val headers: Map<String, String> = emptyMap())

    /** Thread-safe list of media requests seen by one tab; newest last. */
    class MediaLog {
        private val items = Collections.synchronizedList(ArrayList<DetectedMedia>())

        /** Called (on any thread) whenever the list changes; used for the count on the grab button. */
        @Volatile var onChanged: (() -> Unit)? = null

        val size: Int get() = items.size

        fun clear() {
            val had = items.isNotEmpty()
            items.clear()
            if (had) onChanged?.invoke()
        }

        fun onRequest(url: String, pageUrl: String?, headers: Map<String, String>? = null) {
            val kind = classify(url) ?: return
            add(normalize(url), pageUrl, kind, headers)
        }

        fun add(url: String, pageUrl: String?, kind: MediaKind, headers: Map<String, String>? = null) {
            synchronized(items) {
                //keep headers seen earlier for the same address (a later DOM scan has none)
                val old = items.firstOrNull { it.url == url }
                val keep = headers?.takeIf { it.isNotEmpty() } ?: old?.headers ?: emptyMap()
                items.removeAll { it.url == url }
                items.add(DetectedMedia(url, pageUrl ?: old?.referer, System.currentTimeMillis(), kind, keep))
                while (items.size > 100) items.removeAt(0)
            }
            onChanged?.invoke()
        }

        /** Videos only, manifests first (newest first), then progressive files. */
        fun candidates(): List<DetectedMedia> {
            val copy = synchronized(items) { ArrayList(items) }
            copy.reverse()
            return copy.filter { it.kind == MediaKind.VIDEO }.sortedBy { if (isManifest(it.url)) 0 else 1 }
        }

        fun find(url: String): DetectedMedia? = synchronized(items) { items.lastOrNull { it.url == url } }

        /** Everything captured (video, audio, subtitles), grouped by kind, newest first. */
        fun all(): List<DetectedMedia> {
            val copy = synchronized(items) { ArrayList(items) }
            copy.reverse()
            return copy.sortedBy { it.kind.ordinal }
        }
    }

    private val AUDIO_RE = Regex("""\.(mp3|m4a|aac|ogg|oga|opus|flac|wav|weba|mka)(\?|#|$)""", RegexOption.IGNORE_CASE)
    private val NUMBERED_PIECE_RE = Regex("""(seg|chunk|frag|segment|part)[-_]?\d+.*\.(aac|vtt|webvtt)(\?|#|$)""", RegexOption.IGNORE_CASE)
    private val SUBTITLE_RE = Regex("""\.(vtt|webvtt|srt|ass|ssa|ttml|dfxp|sbv|sub)(\?|#|$)""", RegexOption.IGNORE_CASE)

    /** Video, audio or subtitle file/stream; null for anything else (and for stream segments). */
    fun classify(url: String): MediaKind? {
        if (!url.startsWith("http")) return null
        val lower = url.lowercase(Locale.ROOT)
        //pieces of a stream (HLS/DASH segments) are not useful on their own
        if (SEGMENT_RE.containsMatchIn(url) || NUMBERED_PIECE_RE.containsMatchIn(url) ||
            lower.substringBefore('?').endsWith(".m4s")) return null
        if (SUBTITLE_RE.containsMatchIn(url) || lower.contains("/api/timedtext") ||
            lower.contains("fmt=vtt") || lower.contains("format=vtt") || lower.contains("fmt=srv3")) return MediaKind.SUBTITLE
        //YouTube-style "videoplayback?mime=video/..." streams
        if (lower.contains("mime=audio%2f") || lower.contains("mime=audio/")) return MediaKind.AUDIO
        if (lower.contains("mime=video%2f") || lower.contains("mime=video/")) return MediaKind.VIDEO
        if (AUDIO_RE.containsMatchIn(url)) return MediaKind.AUDIO
        if (isStreamUrl(url)) return MediaKind.VIDEO
        return null
    }

    /** Drops per-request byte-range parameters so one stream shows up once. */
    private fun normalize(url: String): String {
        if (!url.contains("videoplayback")) return url
        return url.replace(Regex("""[&?](range|rn|rbuf|ump|srfvp)=[^&]*"""), "").let {
            if (!it.contains('?') && it.contains('&')) it.replaceFirst('&', '?') else it
        }
    }

    private val STREAM_RE = Regex("""\.(m3u8|mpd|mp4|m4v|webm|mkv|mov|ts)(\?|#|$)""", RegexOption.IGNORE_CASE)
    private val SEGMENT_RE = Regex("""(seg|chunk|frag|segment)[-_]?\d+.*\.(ts|mp4|m4s)|/\d+\.ts(\?|$)""", RegexOption.IGNORE_CASE)

    fun isManifest(url: String): Boolean {
        val path = url.substringBefore('?').lowercase(Locale.ROOT)
        return path.endsWith(".m3u8") || path.endsWith(".mpd")
    }

    fun isStreamUrl(url: String): Boolean {
        if (!url.startsWith("http")) return false
        if (!STREAM_RE.containsMatchIn(url)) return false
        val path = url.substringBefore('?').lowercase(Locale.ROOT)
        if (path.endsWith(".ts")) return false //HLS segment, not playable on its own
        if (SEGMENT_RE.containsMatchIn(url)) return false
        return true
    }

    fun guessMimeType(url: String): String? {
        val path = url.substringBefore('?').lowercase(Locale.ROOT)
        return when {
            path.endsWith(".m3u8") -> "application/x-mpegURL"
            path.endsWith(".mpd") -> "application/dash+xml"
            path.endsWith(".mp4") || path.endsWith(".m4v") -> "video/mp4"
            path.endsWith(".webm") -> "video/webm"
            path.endsWith(".mkv") -> "video/x-matroska"
            path.endsWith(".mov") -> "video/quicktime"
            else -> null
        }
    }

    /**
     * Entry point used by the video bar. [src] is the video element's currentSrc, which may be a
     * blob: URL. Shows a picker when several detected streams could be the right one.
     */
    fun open(activity: Activity, mode: String, src: String?, pageUrl: String?, title: String?,
             positionSec: Double, userAgent: String?, log: MediaLog?) {
        val positionMs = (positionSec * 1000).toLong().coerceAtLeast(0L)
        val direct = src?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
        if (direct != null) {
            val known = log?.find(direct)
            launch(activity, mode, makeStream(direct, known?.referer ?: pageUrl, title, userAgent, positionMs, known?.headers))
            return
        }
        val candidates = log?.candidates().orEmpty()
        when {
            candidates.isEmpty() -> {
                Toast.makeText(activity, R.string.sofa_no_stream_found, Toast.LENGTH_LONG).show()
            }
            candidates.size == 1 -> {
                val c = candidates[0]
                launch(activity, mode, makeStream(c.url, c.referer ?: pageUrl, title, userAgent, positionMs, c.headers))
            }
            else -> {
                val labels = candidates.map { describe(it.url) }.toTypedArray()
                AlertDialog.Builder(activity)
                    .setTitle(R.string.sofa_choose_stream)
                    .setItems(labels) { _, which ->
                        val c = candidates[which]
                        launch(activity, mode, makeStream(c.url, c.referer ?: pageUrl, title, userAgent, positionMs, c.headers))
                    }
                    .show()
            }
        }
    }

    private fun describe(url: String): String {
        val uri = Uri.parse(url)
        val kind = when {
            url.contains(".m3u8", true) -> "HLS"
            url.contains(".mpd", true) -> "DASH"
            else -> (uri.lastPathSegment?.substringAfterLast('.', "")?.uppercase(Locale.ROOT) ?: "FILE")
        }
        val name = uri.lastPathSegment ?: url
        return "$kind · ${uri.host} · $name"
    }

    /** Headers that must not be copied (the player sets them itself or they'd break the request). */
    private val SKIPPED_HEADERS = setOf("range", "host", "content-length", "accept-encoding", "connection",
        "cookie", "user-agent", "x-requested-with", "if-none-match", "if-modified-since")

    private fun makeStream(url: String, referer: String?, title: String?, userAgent: String?, positionMs: Long,
                           seenHeaders: Map<String, String>? = null) =
        Stream(
            url = url,
            title = title ?: "",
            referer = referer,
            userAgent = userAgent,
            cookies = try { CookieManager.getInstance().getCookie(url) } catch (e: Exception) { null },
            positionMs = positionMs,
            headers = playerHeaders(url, referer, seenHeaders)
        )

    /**
     * The headers the site's own player sent. Many video hosts refuse a stream unless Origin and
     * Referer match the page that embeds the player, which is why such links "don't play anywhere else".
     */
    private fun playerHeaders(url: String, referer: String?, seen: Map<String, String>?): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        seen?.forEach { (k, v) -> if (k.lowercase(Locale.ROOT) !in SKIPPED_HEADERS) out[k] = v }
        if (out.keys.none { it.equals("Referer", true) } && !referer.isNullOrBlank()) out["Referer"] = referer
        val ref = out.entries.firstOrNull { it.key.equals("Referer", true) }?.value
        if (out.keys.none { it.equals("Origin", true) } && ref != null) {
            try {
                val r = Uri.parse(ref)
                val target = Uri.parse(url)
                //browsers send Origin on cross-site player requests
                if (r.scheme != null && r.host != null && r.host != target.host) {
                    out["Origin"] = r.scheme + "://" + r.host + (if (r.port > 0) ":" + r.port else "")
                }
            } catch (ignored: Exception) {
            }
        }
        return out
    }

    private fun launch(activity: Activity, mode: String, stream: Stream) {
        val now = System.currentTimeMillis()
        if (now - lastLaunchAt < 2000) return
        lastLaunchAt = now
        when (mode) {
            MODE_EXTERNAL -> openExternal(activity, stream)
            MODE_NATIVE_DEBAND -> SofaPlayerActivity.start(activity, stream, deband = true)
            else -> SofaPlayerActivity.start(activity, stream)
        }
    }

    /** Always shows Android's app chooser so the player can be picked each time. */
    fun openExternal(context: Context, stream: Stream) {
        val uri = Uri.parse(stream.url)
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(uri, guessMimeType(stream.url) ?: "video/*")
        intent.putExtra("title", stream.title)
        intent.putExtra(Intent.EXTRA_TITLE, stream.title)
        //request headers, understood by MX Player, Just Player and others
        val headers = ArrayList<String>()
        stream.headers.forEach { (k, v) ->
            if (!k.equals("Referer", true)) { headers.add(k); headers.add(v) }
        }
        stream.referer?.let { headers.add("Referer"); headers.add(it) }
        stream.userAgent?.let { headers.add("User-Agent"); headers.add(it) }
        stream.cookies?.takeIf { it.isNotBlank() }?.let { headers.add("Cookie"); headers.add(it) }
        if (headers.isNotEmpty()) intent.putExtra("headers", headers.toTypedArray())
        stream.referer?.let { intent.putExtra("http-referrer", it) } //VLC
        if (stream.positionMs > 0) intent.putExtra("position", stream.positionMs.toInt())
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val chooser = Intent.createChooser(intent, context.getString(R.string.sofa_open_with))
        if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(chooser)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.sofa_no_player_app, Toast.LENGTH_LONG).show()
        }
    }
}
