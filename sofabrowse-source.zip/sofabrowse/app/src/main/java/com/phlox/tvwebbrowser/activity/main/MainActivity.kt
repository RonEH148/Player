package com.phlox.tvwebbrowser.activity.main

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Process
import android.util.Log
import android.util.Patterns
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebStorage
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.Config
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.TVBro
import com.phlox.tvwebbrowser.activity.IncognitoModeMainActivity
import com.phlox.tvwebbrowser.activity.downloads.DownloadsActivity
import com.phlox.tvwebbrowser.activity.history.HistoryActivity
import com.phlox.tvwebbrowser.activity.main.dialogs.favorites.FavoriteEditorDialog
import com.phlox.tvwebbrowser.activity.main.dialogs.favorites.FavoritesDialog
import com.phlox.tvwebbrowser.activity.main.dialogs.settings.SettingsDialog
import com.phlox.tvwebbrowser.activity.main.view.ActionBar
import com.phlox.tvwebbrowser.activity.main.view.CursorMenuView
import com.phlox.tvwebbrowser.activity.main.view.tabs.TabsAdapter.Listener
import com.phlox.tvwebbrowser.databinding.ActivityMainBinding
import com.phlox.tvwebbrowser.model.Download
import com.phlox.tvwebbrowser.model.FavoriteItem
import com.phlox.tvwebbrowser.model.HomePageLink
import com.phlox.tvwebbrowser.model.HostConfig
import com.phlox.tvwebbrowser.model.WebTabState
import com.phlox.tvwebbrowser.service.downloads.DownloadService
import com.phlox.tvwebbrowser.singleton.AppDatabase
import com.phlox.tvwebbrowser.singleton.shortcuts.ShortcutMgr
import com.phlox.tvwebbrowser.utils.BackNavigationEventsAdapter
import com.phlox.tvwebbrowser.utils.DownloadUtils
import com.phlox.tvwebbrowser.utils.BaseAnimationListener
import com.phlox.tvwebbrowser.utils.Utils
import com.phlox.tvwebbrowser.utils.VoiceSearchHelper
import com.phlox.tvwebbrowser.utils.activemodel.ActiveModelsRepository
import com.phlox.tvwebbrowser.utils.childs
import com.phlox.tvwebbrowser.utils.sameDay
import com.phlox.tvwebbrowser.webengine.WebEngine
import com.phlox.tvwebbrowser.webengine.WebEngineFactory
import com.phlox.tvwebbrowser.webengine.WebEngineWindowProviderCallback
import com.phlox.tvwebbrowser.widgets.NotificationView
import com.phlox.tvwebbrowser.widgets.cursor.CursorDrawerDelegate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Runnable
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.UnsupportedEncodingException
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.Locale
import kotlin.system.exitProcess


open class MainActivity : AppCompatActivity(), ActionBar.Callback {
    companion object {
        private const val PREF_CLEAR_PENDING = "lumen_clear_pending"
        /** False until the first screen of this app process has loaded. */
        private var processStarted = false
        private const val LIVE_TABS = 2
        private val TAG = MainActivity::class.java.simpleName
        const val VOICE_SEARCH_REQUEST_CODE = 10001
        const val MY_PERMISSIONS_REQUEST_POST_NOTIFICATIONS_ACCESS = 10003
        const val MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE_ACCESS = 10004
        const val PICK_FILE_REQUEST_CODE = 10005
        private const val REQUEST_CODE_HISTORY_ACTIVITY = 10006
        const val REQUEST_CODE_UNKNOWN_APP_SOURCES = 10007
        const val REQUEST_CODE_VPN_PERMISSION = 10020
        const val REQUEST_CODE_VPN_IMPORT_FILE = 10021
        const val REQUEST_CODE_PICK_DOWNLOAD_FOLDER = 10022
        const val REQUEST_CODE_DOWNLOADS = 10023
        const val KEY_PROCESS_ID_TO_KILL = "proc_id_to_kill"
        private const val MY_PERMISSIONS_REQUEST_VOICE_SEARCH_PERMISSIONS = 10008
        private const val COMMON_REQUESTS_START_CODE = 10100
    }

    private lateinit var vb: ActivityMainBinding
    private lateinit var viewModel: MainActivityViewModel
    private lateinit var tabsModel: TabsModel
    private lateinit var settingsModel: SettingsModel
    private lateinit var adblockModel: AdblockModel
    private lateinit var uiHandler: Handler
    private var isFullscreen: Boolean = false
    private lateinit var prefs: SharedPreferences
    protected val config = AppContext.provideConfig()
    private val voiceSearchHelper = VoiceSearchHelper(this, VOICE_SEARCH_REQUEST_CODE,
        MY_PERMISSIONS_REQUEST_VOICE_SEARCH_PERMISSIONS)
    private var lastCommonRequestsCode = COMMON_REQUESTS_START_CODE
    private var downloadService: DownloadService? = null
    private var downloadIntent: Download? = null
    var openUrlInExternalAppDialog: AlertDialog? = null
    private var linkActionsMenu: PopupMenu? = null

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val incognitoMode = config.incognitoMode
        Log.d(TAG, "onCreate incognitoMode: $incognitoMode")
        if (incognitoMode xor (this is IncognitoModeMainActivity)) {
            switchProcess(incognitoMode, intent?.extras)
            finish()
            return
        }
        val pidToKill = intent?.getIntExtra(KEY_PROCESS_ID_TO_KILL, -1) ?: -1
        if (pidToKill != -1) {
            Process.killProcess(pidToKill)
        }

        viewModel = ActiveModelsRepository.get(MainActivityViewModel::class, this)
        if (incognitoMode) {
            viewModel.prepareSwitchToIncognito()
        }
        settingsModel = ActiveModelsRepository.get(SettingsModel::class, this)
        adblockModel = ActiveModelsRepository.get(AdblockModel::class, this)
        tabsModel = ActiveModelsRepository.get(TabsModel::class, this)
        uiHandler = Handler()
        prefs = getSharedPreferences(TVBro.MAIN_PREFS_NAME, Context.MODE_PRIVATE)
        vb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(vb.root)
        com.phlox.tvwebbrowser.sofa.LumenCrashLog.showIfAny(this)
        //get Chrome's network stack from Google Play services ready for the video player
        try {
            com.google.android.gms.net.CronetProviderInstaller.installProvider(this)
        } catch (e: Throwable) {
        }
        vb.vToolbarCursor.host = object : com.phlox.tvwebbrowser.activity.main.view.ToolbarCursorView.Host {
            override fun toolbarBottom(): Int = (vb.rlActionBar.top + vb.rlActionBar.height + vb.rlActionBar.translationY).toInt()
            override fun onLeaveToPage(x: Float, dirX: Int, dirY: Int, speedX: Float, speedY: Float) =
                returnPointerToPage(x, dirX, dirY, speedX, speedY)
            override fun onCursorClosed() = returnPointerToPage(null)
            override fun touchTarget(): android.view.ViewGroup = vb.rlRoot
            override fun onLongPress(x: Float, y: Float): Boolean = pasteIntoFieldAt(x, y)
        }
        //pushed against the bottom of a page that can't scroll (a player page): the bar goes away,
        //so the page gets the whole screen (and tall player menus fit)
        vb.flWebViewContainer.cursorDrawerDelegate.bottomEdgeCallback = {
            val view = tabsModel.currentTab.value?.webEngine?.getView()
            if (toolbarShown && canAutoHideToolbar() && view != null && !view.canScrollVertically(1)) {
                autoHideToolbar()
            }
        }
        //the page pointer pushed against the top of a page that can't scroll further up:
        //it carries straight on over the top bar (which slides in), no extra key press
        vb.flWebViewContainer.cursorDrawerDelegate.topEdgeCallback = { x, speedX, speedY, dirX ->
            val engine = tabsModel.currentTab.value?.webEngine
            if (engine == null || isFullscreen || vb.vToolbarCursor.active || vb.rlActionBar.hasFocus() ||
                !isPageAtTop(engine)) {
                false
            } else {
                enterToolbarPointer(x, dirX, speedX, speedY)
                true
            }
        }
        vb.rlActionBar.addOnLayoutChangeListener { _, _, top, _, bottom, _, oldTop, _, oldBottom ->
            if (bottom - top != oldBottom - oldTop && toolbarAnimator == null && !isFullscreen) applyToolbarLayout(toolbarShown)
        }

        vb.ivMiniatures.visibility = View.INVISIBLE
        //Lumen: the top bar (address bar, buttons and tabs) is always visible
        vb.progressBar.visibility = View.GONE

        vb.vTabs.listener = tabsListener

        vb.ibAdBlock.setOnClickListener { showAdBlockOptions() }
        vb.ibDesktopSite.setOnClickListener { toggleDesktopSite() }
        vb.ibGrabLinks.setOnClickListener { showGrabbedLinks() }
        vb.ibDeband.setOnClickListener { showDebandMenu() }
        vb.ibPopupBlock.setOnClickListener { lifecycleScope.launch(Dispatchers.Main) { showPopupBlockOptions() } }
        vb.ibBack.setOnClickListener { navigateBack() }
        vb.ibForward.setOnClickListener {
            val tab = tabsModel.currentTab.value ?: return@setOnClickListener
            if (tab.webEngine.canGoForward()) {
                tab.webEngine.goForward()
            }
        }
        vb.ibRefresh.setOnClickListener { refresh() }
        vb.ibCloseTab.setOnClickListener { tabsModel.currentTab.value?.apply { closeTab(this) } }

        vb.vActionBar.callback = this


        config.userAgentString.subscribe(this.lifecycle, false) {
            for (tab in tabsModel.tabsStates) {
                tab.webEngine.userAgentString = it
            }
        }

        config.theme.subscribe(this.lifecycle, false) {
            when (it) {
                Config.Theme.BLACK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                Config.Theme.WHITE -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            WebEngineFactory.onThemeSettingUpdated(it)
        }

        settingsModel.keepScreenOn.subscribe(this.lifecycle) {
            if (it) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        viewModel.homePageLinks.subscribe(this) {
            Log.i(TAG, "homePageLinks updated")
            val currentUrl = tabsModel.currentTab.value?.url ?: return@subscribe
            if (Config.HOME_PAGE_URL == currentUrl) {
                tabsModel.currentTab.value?.webEngine?.reload()
            }
        }

        tabsModel.currentTab.subscribe(this) {
            vb.vActionBar.setAddressBoxText(it?.url ?: "")
            it?.let {
                onWebViewUpdated(it)
            }
        }

        tabsModel.tabsStates.subscribe(this, false) {
            if (it.isEmpty()) {
                if (!config.isWebEngineGecko()) {
                    vb.flWebViewContainer.removeAllViews()
                }
            }
        }

        onBackPressedDispatcher.addCallback(onBackPressedCallback)

        loadState()


        //Lumen: WireGuard auto-connect
        com.phlox.tvwebbrowser.sofa.SofaVpn.refreshStatus()
        if (config.sofaVpnAutoConnect && com.phlox.tvwebbrowser.sofa.SofaVpn.hasConfig() &&
            com.phlox.tvwebbrowser.sofa.SofaVpn.permissionIntent(this) == null &&
            com.phlox.tvwebbrowser.sofa.SofaVpn.status.value != com.phlox.tvwebbrowser.sofa.SofaVpn.Status.CONNECTED) {
            lifecycleScope.launch { com.phlox.tvwebbrowser.sofa.SofaVpn.connect(applicationContext) }
        }
    }

    private var touchMenuButton: View? = null

    private fun isTvDevice(): Boolean {
        val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager
        return uiModeManager?.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
                packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }

    private fun addTouchMenuButton() {
        val density = resources.displayMetrics.density
        val size = (52 * density).toInt()
        val margin = (16 * density).toInt()
        val button = android.widget.ImageButton(this)
        button.setImageResource(R.drawable.ic_menu_24)
        button.setColorFilter(Color.WHITE)
        button.contentDescription = getString(R.string.sofa_menu)
        button.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.OVAL
            setColor(0xDD2A2A30.toInt())
        }
        button.elevation = 8 * density
        button.alpha = 0.9f
        button.setOnClickListener { toggleMenu() }
        val lp = android.widget.RelativeLayout.LayoutParams(size, size)
        lp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_BOTTOM)
        lp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_END)
        lp.setMargins(margin, margin, margin, margin)
        vb.rlRoot.addView(button, lp)
        touchMenuButton = button
    }

    /** Remote "channel up/down": jump to the next or previous tab. */
    fun switchTabRelative(delta: Int) {
        val tabs = tabsModel.tabsStates
        if (tabs.size < 2) {
            Toast.makeText(this, R.string.sofa_only_one_tab, Toast.LENGTH_SHORT).show()
            return
        }
        val current = tabsModel.currentTab.value
        val idx = if (current == null) 0 else tabs.indexOf(current).coerceAtLeast(0)
        val newIndex = ((idx + delta) % tabs.size + tabs.size) % tabs.size
        val newTab = tabs[newIndex]
        changeTab(newTab)
        vb.vTabs.current = newIndex
        val title = newTab.title.ifBlank { newTab.url }
        NotificationView.showBottomRight(vb.rlRoot, R.drawable.ic_menu_24,
            getString(R.string.sofa_tab_n_of_m, newIndex + 1, tabs.size, title))
    }

    /**
     * Grab button: lists the video, audio and subtitle addresses the current page has loaded
     * (seen in its network requests) or written into its <video>/<audio>/<track> elements.
     */
    private fun showGrabbedLinks() {
        val tab = tabsModel.currentTab.value ?: return
        val webView = tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        if (webView == null) {
            Toast.makeText(this, R.string.lumen_grab_engine, Toast.LENGTH_LONG).show()
            return
        }
        webView.evaluateJavascript("JSON.stringify(window.__lumenDomMedia ? window.__lumenDomMedia() : [])") { result ->
            try {
                val json = org.json.JSONTokener(result).nextValue() as? String ?: "[]"
                val arr = org.json.JSONArray(json)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val kind = when (o.optString("k")) {
                        "a" -> com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.MediaKind.AUDIO
                        "s" -> com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.MediaKind.SUBTITLE
                        else -> com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.MediaKind.VIDEO
                    }
                    webView.mediaLog.add(o.optString("u"), tab.url, kind)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            presentGrabbedLinks(webView.mediaLog.all())
        }
    }

    private fun presentGrabbedLinks(links: List<com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.DetectedMedia>) {
        if (links.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.lumen_grab_title)
                .setMessage(R.string.lumen_grab_empty)
                .setPositiveButton(R.string.ok, null)
                .show()
            return
        }
        fun label(m: com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.DetectedMedia): String {
            val uri = Uri.parse(m.url)
            val name = uri.lastPathSegment ?: m.url
            val format = when {
                com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.isManifest(m.url) && m.url.contains(".mpd", true) -> "DASH"
                com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.isManifest(m.url) -> "HLS"
                else -> name.substringAfterLast('.', "").uppercase(Locale.ROOT).take(5).ifEmpty { "STREAM" }
            }
            return "${m.kind.label} · $format · $name\n${uri.host}"
        }
        val labels = links.map { label(it) }.toTypedArray()
        val checked = BooleanArray(links.size)
        fun selectedOrAll(): List<String> {
            val sel = links.filterIndexed { i, _ -> checked[i] }.map { it.url }
            return sel.ifEmpty { links.map { it.url } }
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lumen_grab_title) + " (" + links.size + ")")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.lumen_grab_copy) { _, _ ->
                val urls = selectedOrAll()
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Media links", urls.joinToString("\n")))
                Toast.makeText(this, getString(R.string.lumen_grab_copied, urls.size), Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton(R.string.lumen_grab_show_text) { _, _ -> showLinksAsText(selectedOrAll()) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** The full addresses in a text box, so any part can be selected and copied. */
    private fun showLinksAsText(urls: List<String>) {
        val text = android.widget.EditText(this)
        text.setText(urls.joinToString("\n\n"))
        text.setTextIsSelectable(true)
        text.isFocusable = true
        text.keyListener = null //read-only, but still selectable
        text.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
        text.typeface = android.graphics.Typeface.MONOSPACE
        val pad = (16 * resources.displayMetrics.density).toInt()
        val scroll = android.widget.ScrollView(this)
        scroll.setPadding(pad, pad / 2, pad, 0)
        scroll.addView(text)
        AlertDialog.Builder(this)
            .setTitle(R.string.lumen_grab_text_title)
            .setView(scroll)
            .setPositiveButton(R.string.lumen_grab_copy) { _, _ ->
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val sel = if (text.hasSelection()) text.text.substring(text.selectionStart, text.selectionEnd) else null
                clipboard.setPrimaryClip(ClipData.newPlainText("Media links", sel ?: urls.joinToString("\n")))
                Toast.makeText(this, getString(R.string.lumen_grab_copied, if (sel != null) 1 else urls.size), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /**
     * Toolbar Deband button: deband the video inside the page, or hand the video over to Lumen's own
     * player with anime deband on (hardware decoding, filters on the GPU - the most reliable way).
     */
    private fun showDebandMenu() {
        val tab = tabsModel.currentTab.value ?: return
        val webView = tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        if (webView == null) {
            Toast.makeText(this, R.string.lumen_grab_engine, Toast.LENGTH_LONG).show()
            return
        }
        val host = try { Uri.parse(tab.url).host } catch (e: Exception) { null }
        val siteOn = config.isDebandSite(host)
        val items = arrayListOf(
            getString(if (webView.pageDeband) R.string.lumen_deband_menu_page_off else R.string.lumen_deband_menu_page_on),
            getString(R.string.lumen_deband_menu_player)
        )
        if (!host.isNullOrEmpty()) {
            items.add(getString(if (siteOn) R.string.lumen_deband_menu_site_off else R.string.lumen_deband_menu_site_on,
                host.removePrefix("www.")))
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.lumen_deband_menu_title)
            .setItems(items.toTypedArray()) { _, which ->
                when (which) {
                    0 -> togglePageDeband()
                    1 -> playWithDeband(tab, webView)
                    else -> {
                        val key = Config.siteKey(host!!)
                        config.lumenDebandSites = if (siteOn) config.lumenDebandSites.filterNot {
                            host == it || host.endsWith(".$it")
                        }.toSet() else config.lumenDebandSites + key
                        Toast.makeText(this, if (siteOn) R.string.lumen_deband_site_removed else R.string.lumen_deband_site_added,
                            Toast.LENGTH_LONG).show()
                        if (!siteOn && !webView.pageDeband) togglePageDeband()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Deband didn't start: show what each part of the page reported, with a Copy button. */
    private fun showDebandDiagnosis(webView: com.phlox.tvwebbrowser.webengine.webview.WebViewEx) {
        val lines = ArrayList<String>()
        val scans = synchronized(webView.debandScans) { ArrayList(webView.debandScans) }
        for (raw in scans) {
            try {
                val o = org.json.JSONObject(raw)
                val where = (if (o.optBoolean("top")) "page " else "frame ") + o.optString("h")
                lines.add("• $where: ${o.optInt("v")} video(s), ${o.optInt("p")} playing, " +
                        "${o.optInt("f")} filtered" +
                        (if (o.optInt("d") > 0) ", ${o.optInt("d")} DRM-protected" else "") +
                        (if (!o.optBoolean("gl", true)) ", no WebGL" else ""))
            } catch (e: Exception) {
                lines.add("• $raw")
            }
        }
        val anyVideo = scans.any { it.contains("\"v\":") && !it.contains("\"v\":0") }
        val summary = when {
            scans.isEmpty() -> getString(R.string.lumen_deband_diag_noscript)
            !anyVideo -> getString(R.string.lumen_deband_diag_novideo)
            else -> getString(R.string.lumen_deband_diag_notdrawn)
        }
        val text = summary + "\n\n" + lines.joinToString("\n") + "\n\n" + (tabsModel.currentTab.value?.url ?: "")
        AlertDialog.Builder(this)
            .setTitle(R.string.lumen_deband_diag_title)
            .setMessage(text)
            .setPositiveButton(R.string.ok, null)
            .setNeutralButton(R.string.lumen_grab_copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Lumen deband", text))
                Toast.makeText(this, R.string.lumen_copied, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun playWithDeband(tab: WebTabState, webView: com.phlox.tvwebbrowser.webengine.webview.WebViewEx) {
        val asked = System.currentTimeMillis()
        //the frame that plays the video answers with its address and position (see 'handoff-deband')
        webView.evaluateJavascript("window.__sofaMedia && window.__sofaMedia('handoff-deband')", null)
        toolbarHandler.postDelayed({
            if (com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.lastLaunchAt >= asked) return@postDelayed
            //no frame answered: use the streams the page has loaded
            com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.open(this, com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.MODE_NATIVE_DEBAND,
                null, tab.url, tab.title, 0.0, webView.settings.userAgentString, webView.mediaLog)
        }, 1500)
    }

    /** Toolbar Deband button: anime deband for the video(s) on the current page, until it reloads. */
    private fun togglePageDeband() {
        val tab = tabsModel.currentTab.value ?: return
        val webView = tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        if (webView == null) {
            Toast.makeText(this, R.string.lumen_grab_engine, Toast.LENGTH_LONG).show()
            return
        }
        if (isTvDevice() && !webView.pageDeband) {
            //TVs: no deband inside pages (too heavy for TV graphics chips, broke the picture);
            //the video plays in Lumen's player with deband instead
            Toast.makeText(this, "On TVs deband runs in Lumen's player: opening the video there", Toast.LENGTH_LONG).show()
            playWithDeband(tab, webView)
            return
        }
        webView.pageDeband = !webView.pageDeband
        webView.evaluateJavascript("window.__lumenSetDeband && window.__lumenSetDeband(" + webView.pageDeband + ")", null)
        webView.debandConfirmed = false
        webView.debandScans.clear()
        Toast.makeText(this, if (webView.pageDeband) R.string.lumen_deband_waiting else R.string.lumen_deband_page_off,
            Toast.LENGTH_SHORT).show()
        if (webView.pageDeband) {
            //no confirmation and no error after a while: say so instead of leaving the user guessing
            val asked = System.currentTimeMillis()
            toolbarHandler.postDelayed({
                if (webView.pageDeband && !webView.debandConfirmed && webView.lastDebandReport < asked &&
                    tabsModel.currentTab.value?.webEngine?.getView() === webView) {
                    showDebandDiagnosis(webView)
                }
            }, 10_000)
        }
        onWebViewUpdated(tab)
    }

    /** Hides the tablet's status and navigation bars while a video is full screen. */
    private fun setLumenImmersive(on: Boolean) {
        val controller = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            controller.systemBarsBehavior =
                androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes = window.attributes.also {
                    it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
        } else {
            controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                window.attributes = window.attributes.also {
                    it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                }
            }
        }
    }

    private fun toggleDesktopSite() {
        val tab = tabsModel.currentTab.value ?: return
        val webView = tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        if (webView == null) {
            Toast.makeText(this, R.string.sofa_desktop_not_supported, Toast.LENGTH_LONG).show()
            return
        }
        val site = Config.siteKey(try { URL(tab.url).host } catch (e: Exception) { null })
        if (site.isEmpty()) return
        val sites = config.desktopSites.toMutableSet()
        val nowDesktop = if (config.isDesktopSite(site)) {
            //remove the entry and any parent-domain entry that covers this site
            sites.removeAll { site == it || site.endsWith(".$it") }
            false
        } else {
            sites.add(site)
            true
        }
        config.desktopSites = sites
        Toast.makeText(this, getString(if (nowDesktop) R.string.sofa_desktop_on else R.string.sofa_desktop_off, site),
            Toast.LENGTH_SHORT).show()
        onWebViewUpdated(tab)
        hideMenuOverlay()
        //load again with the new user agent
        webView.loadUrl(tab.url)
    }

    private fun isAdBlockOnForTab(tab: WebTabState): Boolean {
        tab.adblock?.let { return it }
        if (!config.adBlockEnabled) return false
        val host = try { URL(tab.url).host } catch (e: Exception) { null }
        return !config.isAdBlockDisabledForHost(host)
    }

    private fun showAdBlockOptions() {
        val tab = tabsModel.currentTab.value ?: return
        val host = try { URL(tab.url).host } catch (e: Exception) { null }
        val site = Config.siteKey(host)
        if (site.isEmpty() || !config.adBlockEnabled) {
            toggleAdBlockForTab()
            return
        }
        val disabledForSite = config.adBlockDisabledHosts.contains(site)
        val items = arrayOf(
            getString(R.string.sofa_adblock_on_site, site),
            getString(R.string.sofa_adblock_off_site, site),
            getString(R.string.sofa_adblock_off_tab)
        )
        val checked = when {
            tab.adblock == false -> 2
            disabledForSite -> 1
            else -> 0
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.sofa_adblock_title)
            .setSingleChoiceItems(items, checked) { dialog, which ->
                val sites = config.adBlockDisabledHosts.toMutableSet()
                when (which) {
                    0 -> { sites.remove(site); tab.adblock = null }
                    1 -> { sites.add(site); tab.adblock = null }
                    2 -> { tab.adblock = false }
                }
                config.adBlockDisabledHosts = sites
                val newState = isAdBlockOnForTab(tab)
                tab.webEngine.onUpdateAdblockSetting(newState)
                onWebViewUpdated(tab)
                dialog.dismiss()
                refresh()
            }
            .setNeutralButton("Site fixes…") { _, _ -> showSiteFixes(tab, site) }
            .show()
    }

    /** Shield menu → "Site fixes…": for sites stuck on a verification or ad gate. */
    private fun showSiteFixes(tab: WebTabState, site: String) {
        val wv = tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        val ff = config.isFirefoxSite(site)
        val ext = config.isExternalSite(site)
        val firefox = com.phlox.tvwebbrowser.sofa.LumenExternal.firefoxPackage(this) != null
        val browser = if (firefox) "Firefox" else "another browser"
        val items = arrayOf(
            "Open this page in $browser now",
            if (ext) "✓ Always open $site in $browser (tap to stop)" else "Always open $site in $browser",
            "Verification failing? Reload clean (no ad blocking or page changes, this time)",
            if (ff) "✓ Identify as Firefox on $site (tap to stop)" else "Identify as Firefox on $site",
            "Reset $site (undo all fixes, forget its verification, new cookies)"
        )
        AlertDialog.Builder(this)
            .setTitle("Site fixes · $site")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> com.phlox.tvwebbrowser.sofa.LumenExternal.open(this, tab.url)
                    1 -> {
                        config.lumenExternalSites = if (ext) config.lumenExternalSites - site else config.lumenExternalSites + site
                        if (!ext) {
                            com.phlox.tvwebbrowser.sofa.LumenExternal.open(this, tab.url)
                            Toast.makeText(this, "$site will open in $browser from now on. " +
                                    "To stop: the same menu in Lumen.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "$site opens in Lumen again", Toast.LENGTH_SHORT).show()
                        }
                    }
                    2 -> if (wv?.startManualCleanMode() == true) Toast.makeText(this,
                        "Reloaded without ad blocking or page changes for the verification. " +
                                "Password saving is off on this page.", Toast.LENGTH_LONG).show()
                    4 -> {
                        config.lumenFirefoxSites = config.lumenFirefoxSites - site
                        config.lumenExternalSites = config.lumenExternalSites - site
                        config.desktopSites = config.desktopSites - site
                        com.phlox.tvwebbrowser.sofa.LumenVerify.forget(site)
                        clearSiteCookies(tab.url)
                        wv?.applyUserAgentFor(tab.url)
                        tab.webEngine.reload()
                        Toast.makeText(this, "$site reset: it opens like a site you never visited", Toast.LENGTH_LONG).show()
                    }
                    3 -> {
                        config.lumenFirefoxSites = if (ff) config.lumenFirefoxSites - site else config.lumenFirefoxSites + site
                        wv?.applyUserAgentFor(tab.url)
                        tab.webEngine.reload()
                        Toast.makeText(this, if (ff) "$site: normal identity again"
                            else "$site now sees Firefox. If its videos or sign-in break, switch it off here.",
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    /** Expires every cookie the site's address can see (Cloudflare's pass cookies included). */
    private fun clearSiteCookies(url: String) {
        try {
            val cm = android.webkit.CookieManager.getInstance()
            val uri = android.net.Uri.parse(url)
            val host = uri.host ?: return
            val parts = host.split('.')
            val domains = (0 until (parts.size - 1).coerceAtLeast(1)).map { parts.drop(it).joinToString(".") }
            val cookies = cm.getCookie(url) ?: return
            for (c in cookies.split(';')) {
                val name = c.substringBefore('=').trim()
                if (name.isEmpty()) continue
                for (d in domains) {
                    for (path in listOf("/", uri.path ?: "/")) {
                        cm.setCookie("https://$host", "$name=; Max-Age=0; Path=$path; Domain=$d")
                        cm.setCookie("https://$host", "$name=; Max-Age=0; Path=$path")
                    }
                }
            }
            cm.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Settings → VPN → connect: asks for the Android VPN permission first if needed. */
    fun requestVpnConnect() {
        val intent = com.phlox.tvwebbrowser.sofa.SofaVpn.permissionIntent(this)
        if (intent != null) {
            try {
                startActivityForResult(intent, REQUEST_CODE_VPN_PERMISSION)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, R.string.sofa_vpn_not_supported, Toast.LENGTH_LONG).show()
            }
            return
        }
        lifecycleScope.launch { com.phlox.tvwebbrowser.sofa.SofaVpn.connect(applicationContext) }
    }

    private var onDownloadFolderPicked: (() -> Unit)? = null

    /** Settings → Downloads → Choose folder: system folder picker (internal storage, SD card, USB). */
    fun pickDownloadFolder(onPicked: () -> Unit) {
        onDownloadFolderPicked = onPicked
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        //Android TV answers this request with a placeholder ("there's no app that can do this"),
        //so only real folder pickers (system Files, AnExplorer, ...) are offered, next to our own browser
        val pickers = packageManager.queryIntentActivities(intent, 0)
            .filter { !it.activityInfo.packageName.contains("frameworkpackagestubs") && it.activityInfo.exported }
        val builtIn = { com.phlox.tvwebbrowser.sofa.LumenFolderPicker(this) { onPicked() }.show() }
        if (pickers.isEmpty()) {
            builtIn()
            return
        }
        val labels = ArrayList<String>()
        labels.add("Lumen folder browser (works with the remote)")
        for (p in pickers) labels.add(p.loadLabel(packageManager).toString())
        AlertDialog.Builder(this)
            .setTitle(R.string.lumen_choose_folder_with)
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == 0) {
                    builtIn()
                    return@setItems
                }
                val info = pickers[which - 1].activityInfo
                val explicit = Intent(intent).setClassName(info.packageName, info.name)
                try {
                    startActivityForResult(explicit, REQUEST_CODE_PICK_DOWNLOAD_FOLDER)
                } catch (e: Exception) {
                    builtIn()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onDownloadFolderResult(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
        //make sure files can really be created there (read-only drives, unsupported file systems)
        val problem = com.phlox.tvwebbrowser.sofa.LumenDownloads.testWritable(uri)
        if (problem != null) {
            try {
                contentResolver.releasePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (ignored: Exception) {
            }
            AlertDialog.Builder(this)
                .setTitle(R.string.lumen_folder_not_writable)
                .setMessage(getString(R.string.lumen_folder_not_writable_msg, problem))
                .setPositiveButton(R.string.ok, null)
                .show()
            return
        }
        config.lumenDownloadFolderUri = uri.toString()
        Toast.makeText(this, getString(R.string.lumen_folder_set,
            com.phlox.tvwebbrowser.sofa.LumenDownloads.folderLabel(this)), Toast.LENGTH_LONG).show()
        onDownloadFolderPicked?.invoke()
        onDownloadFolderPicked = null
    }

    fun pickVpnConfigFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(Intent.createChooser(intent, getString(R.string.sofa_vpn_import_file)),
                REQUEST_CODE_VPN_IMPORT_FILE)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.sofa_vpn_no_file_picker, Toast.LENGTH_LONG).show()
        }
    }

    private fun onVpnConfigFilePicked(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text == null || text.length > 100_000) {
                Toast.makeText(this@MainActivity, R.string.sofa_vpn_import_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val error = com.phlox.tvwebbrowser.sofa.SofaVpn.importConfig(text)
            Toast.makeText(this@MainActivity,
                if (error == null) getString(R.string.sofa_vpn_imported) else getString(R.string.sofa_vpn_bad_config, error),
                Toast.LENGTH_LONG).show()
        }
    }

    private var progressBarHideRunnable: Runnable = Runnable {
        val anim = AnimationUtils.loadAnimation(this@MainActivity, android.R.anim.fade_out)
        anim.setAnimationListener(object : BaseAnimationListener() {
            override fun onAnimationEnd(animation: Animation) {
                vb.progressBar.visibility = View.GONE
            }
        })
        vb.progressBar.startAnimation(anim)
    }

    private val mConnectivityChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = cm.activeNetworkInfo
            val isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting
            val tab = tabsModel.currentTab.value ?: return
            tab.webEngine.setNetworkAvailable(isConnected)
        }
    }

    private val displayThumbnailRunnable = object : Runnable {
        var tabState: WebTabState? = null
        override fun run() {
            tabState?.let {
                lifecycleScope.launch(Dispatchers.Main) {
                    displayThumbnail(it)
                }
            }
        }
    }

    private val tabsListener = object : Listener {
        override fun onTitleChanged(index: Int) {
            Log.d(TAG, "onTitleChanged: $index")
            val tab = tabByTitleIndex(index)
            vb.vActionBar.setAddressBoxText(tab?.url ?: "")
            uiHandler.removeCallbacks(displayThumbnailRunnable)
            displayThumbnailRunnable.tabState = tab
            uiHandler.postDelayed(displayThumbnailRunnable, 200)
        }

        override fun onTitleSelected(index: Int) {
            //a tap selects the tab directly (touch screens don't move the focus first)
            tabByTitleIndex(index)?.let { if (!it.selected) changeTab(it) }
            vb.vTabs.current = index
            hideMenuOverlay()
        }

        override fun onAddNewTabSelected() {
            openInNewTab(settingsModel.homePage, tabsModel.tabsStates.size)
        }

        override fun closeTab(tabState: WebTabState?) = this@MainActivity.closeTab(tabState)

        override fun openInNewTab(url: String, tabIndex: Int) {
            this@MainActivity.openInNewTab(url, tabIndex,
                needToHideMenuOverlay = false,
                navigateImmediately = true
            )
        }
    }

    override fun closeWindow() {
        Log.d(TAG, "closeWindow")
        lifecycleScope.launch {
            clearDataOnExit()
            if (config.incognitoMode) {
                toggleIncognitoMode(false).join()
            }
            finish()
        }
    }

    override fun showDownloads() {
        startActivityForResult(Intent(this@MainActivity, DownloadsActivity::class.java), REQUEST_CODE_DOWNLOADS)
    }

    /**
     * Downloads screen → "Download from link". Checks what the link is first: web pages open in a
     * tab, files are downloaded (with the name the server gives).
     */
    private fun downloadFromLink(link: String) {
        lifecycleScope.launch {
            val ua = (tabsModel.currentTab.value?.webEngine?.getView() as? android.webkit.WebView)?.settings?.userAgentString
                ?: android.webkit.WebSettings.getDefaultUserAgent(this@MainActivity)
            val info = withContext(Dispatchers.IO) {
                var c: java.net.HttpURLConnection? = null
                try {
                    c = java.net.URL(link).openConnection() as java.net.HttpURLConnection
                    c.requestMethod = "HEAD"
                    c.instanceFollowRedirects = true
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.setRequestProperty("User-Agent", ua)
                    CookieManager.getInstance().getCookie(link)?.let { c.setRequestProperty("cookie", it) }
                    c.connect()
                    if (c.responseCode in 200..299) {
                        Triple(c.getHeaderField("Content-Type"), c.getHeaderField("Content-Disposition"), c.url.toString())
                    } else null
                } catch (e: Exception) {
                    null //HEAD not supported or failed: just try the download
                } finally {
                    c?.disconnect()
                }
            }
            val mime = info?.first?.substringBefore(';')?.trim()
            //a stream playlist isn't a file to save: play it in the built-in player
            if (com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.isManifest(info?.third ?: link) ||
                mime?.lowercase()?.contains("mpegurl") == true || mime == "application/dash+xml") {
                com.phlox.tvwebbrowser.sofa.SofaPlayerActivity.start(this@MainActivity,
                    com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.Stream(link, "", null, ua,
                        CookieManager.getInstance().getCookie(link), 0L))
                return@launch
            }
            if (mime != null && (mime.startsWith("text/html") || mime.startsWith("application/xhtml")) && info?.second == null) {
                Toast.makeText(this@MainActivity, R.string.lumen_link_is_page, Toast.LENGTH_LONG).show()
                openInNewTab(link, tabsModel.tabsStates.size, needToHideMenuOverlay = true, navigateImmediately = true)
                return@launch
            }
            val fileName = DownloadUtils.guessFileName(link, info?.second, mime)
            //coming back from the downloads list, the download service is still being connected:
            //wait for it, or the download would silently never start
            awaitDownloadService()
            onDownloadRequested(link, "", fileName, ua, mime, Download.OperationAfterDownload.NOP, null, null)
            //back to the list to watch the progress
            showDownloads()
        }
    }

    override fun showHistory() {
        startActivityForResult(
                Intent(this@MainActivity, HistoryActivity::class.java),
                REQUEST_CODE_HISTORY_ACTIVITY)
        hideMenuOverlay()
    }

    override fun showFavorites() {
        val currentTab = tabsModel.currentTab.value
        val currentPageTitle = currentTab?.title ?: ""
        val currentPageUrl = currentTab?.url ?: ""

        FavoritesDialog(this@MainActivity, lifecycleScope, object : FavoritesDialog.Callback {
            override fun onFavoriteChoosen(item: FavoriteItem?) {
                navigate(item!!.url!!)
            }
        }, currentPageTitle, currentPageUrl).show()
        hideMenuOverlay()
    }

    private val bottomButtonsOnTouchListener = View.OnTouchListener{ v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                return@OnTouchListener true
            }
            MotionEvent.ACTION_UP -> {
                hideMenuOverlay(false)
                v.performClick()
                return@OnTouchListener true
            }
            else -> return@OnTouchListener false
        }
    }

    private val bottomButtonsFocusListener = View.OnFocusChangeListener { view, hasFocus ->
        if (hasFocus) {
            hideMenuOverlay(false)
        }
    }

    private val bottomButtonsKeyListener = View.OnKeyListener { view, i, keyEvent ->
        when (keyEvent.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (keyEvent.action == KeyEvent.ACTION_UP) {
                    hideBottomPanel()
                    tabsModel.currentTab.value?.webEngine?.getView()?.requestFocus()
                }
                return@OnKeyListener true
            }
        }
        false
    }

    private fun tabByTitleIndex(index: Int) =
            if (index >= 0 && index < tabsModel.tabsStates.size) tabsModel.tabsStates[index] else null

    override fun showSettings() {
        SettingsDialog(this, settingsModel).show()
    }

    override fun onExtendedAddressBarMode() {
        //the second row (tabs and buttons) stays visible while typing
    }

    override fun onUrlInputDone() {
        hideMenuOverlay()
    }

    fun navigateBack(goHomeIfNoHistory: Boolean = false) {
        val currentTab = tabsModel.currentTab.value
        if (currentTab != null && currentTab.webEngine.canGoBack()) {
            currentTab.webEngine.goBack()
        } else if (currentTab == null || isOnHomePage(currentTab)) {
            confirmExit()
        } else {
            //no history left in this tab: go to the home page; Back there asks to exit
            navigate(settingsModel.homePage)
        }
    }

    private fun isOnHomePage(tab: WebTabState): Boolean {
        val url = tab.url
        return url == settingsModel.homePage || url == Config.HOME_URL_ALIAS ||
                url.startsWith(Config.HOME_PAGE_URL) || url.isBlank() || url == "about:blank"
    }

    private var exitDialogShown = false

    private fun confirmExit() {
        if (exitDialogShown) return
        exitDialogShown = true
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.lumen_exit_title, getString(R.string.app_name_short)))
            .setPositiveButton(R.string.lumen_exit) { _, _ -> closeWindow() }
            .setNegativeButton(R.string.cancel, null)
            .setOnDismissListener { exitDialogShown = false }
            .show()
    }

    /** Set when the session's tabs were removed: nothing may save them again while closing. */
    private var sessionCleared = false

    /**
     * Settings: clear history / cookies when the browser is closed. "History" also closes all tabs,
     * so the next start begins with a fresh home page.
     */
    private suspend fun clearDataOnExit() {
        if (config.incognitoMode) return
        if (config.lumenClearHistoryOnExit) {
            sessionCleared = true
            val tabs = ArrayList(tabsModel.tabsStates)
            withContext(Dispatchers.IO) {
                try {
                    AppDatabase.db.historyDao().deleteWhereTimeLessThan(Long.MAX_VALUE)
                    AppDatabase.db.tabsDao().deleteAll(false)
                    tabs.forEach { try { it.removeFiles() } catch (ignored: Exception) {} }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        if (config.lumenClearCookiesOnExit) {
            try {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun refresh() {
        tabsModel.currentTab.value?.webEngine?.reload()
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy")
        //here properties can be uninitialized in case of wrong activity for incognito mode
        //detection and force activity restart in onCreate()
        if (::tabsModel.isInitialized) {
            tabsModel.onDetachActivity()
        }
        super.onDestroy()
    }

    @SuppressLint("MissingSuperCall")
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.data != null) {
            handleIntent(intent)
        }
    }

    private fun loadState() = lifecycleScope.launch(Dispatchers.Main) {
        Log.d(TAG, "loadState")
        WebEngineFactory.initialize(this@MainActivity, vb.flWebViewContainer)

        vb.progressBarGeneric.visibility = View.VISIBLE
        vb.progressBarGeneric.requestFocus()
        viewModel.loadState().join()
        //the browser was left (Home) and Android has since ended it: that counts as closing it
        if (!processStarted && prefs.getBoolean(PREF_CLEAR_PENDING, false)) {
            clearDataOnExit()
            sessionCleared = false
        }
        processStarted = true
        prefs.edit().putBoolean(PREF_CLEAR_PENDING, false).apply()
        tabsModel.loadState().join()

        if (!isActive) {
            return@launch
        }

        vb.progressBarGeneric.visibility = View.GONE

        if (intent.data == null) {
            if (tabsModel.tabsStates.isEmpty()) {
                openInNewTab(settingsModel.homePage, 0,
                    needToHideMenuOverlay = true,
                    navigateImmediately = true
                )
            } else {
                var foundSelectedTab = false
                for (i in tabsModel.tabsStates.indices) {
                    val tab = tabsModel.tabsStates[i]
                    if (tab.selected) {
                        changeTab(tab)
                        foundSelectedTab = true
                        break
                    }
                }
                if (!foundSelectedTab) {//this may happen in some error states
                    changeTab(tabsModel.tabsStates[0])
                }
            }
        } else {
            handleIntent(intent)
        }

        val currentTab = tabsModel.currentTab.value
        if (currentTab == null || currentTab.url == settingsModel.homePage) {
            showMenuOverlay()
        }
        com.phlox.tvwebbrowser.sofa.LumenUpdater.checkOnStart(this@MainActivity)
    }

    private fun handleIntent(intent: Intent) {
        Log.d(TAG, "handleIntent: " + intent.data)
        if (intent.getBooleanExtra("com.phlox.tvwebbrowser.EXTRA_OPEN_IN_SAME_TAB", false) &&
            tabsModel.tabsStates.isNotEmpty()) {
            if (tabsModel.currentTab.value == null) {
                changeTab(tabsModel.tabsStates[0])
            }
            navigate(intent.data.toString())
            return
        }

        openInNewTab(
            intent.data.toString(), tabsModel.tabsStates.size, needToHideMenuOverlay = true,
            navigateImmediately = true
        )
    }

    private fun openInNewTab(url: String?, index: Int = 0, needToHideMenuOverlay: Boolean = true, navigateImmediately: Boolean): WebEngine? {
        Log.d(TAG, "openInNewTab: url: $url, index: $index, needToHideMenuOverlay: $needToHideMenuOverlay, navigateImmediately: $navigateImmediately")
        if (url == null) {
            return null
        }
        val tab = WebTabState(url = url, incognito = config.incognitoMode)
        createWebView(tab) ?: return null
        tabsModel.tabsStates.add(index, tab)
        changeTab(tab)
        if (navigateImmediately) {
            navigate(url)
        }
        if (needToHideMenuOverlay && toolbarShown) {
            hideMenuOverlay(true)
        }
        return tab.webEngine
    }

    private fun closeTab(tab: WebTabState?) {
        if (tab == null) return
        val tabs = tabsModel.tabsStates
        val position = tabs.indexOf(tab)
        if (position < 0) return
        val wasCurrent = tabsModel.currentTab.value == tab
        if (tabs.size == 1) {
            //closing the only tab leaves a fresh home page tab
            tabsModel.currentTab.value = null
            openInNewTab(settingsModel.homePage, 0, needToHideMenuOverlay = false, navigateImmediately = true)
        } else if (wasCurrent) {
            //show the neighbour; closing a background tab doesn't change the visible one
            tabsModel.currentTab.value = null
            changeTab(if (position > 0) tabs[position - 1] else tabs[position + 1])
        }
        tabsModel.onCloseTab(tab)
        //indexes shifted: keep the tab strip pointing at the visible tab
        tabsModel.currentTab.value?.let { vb.vTabs.current = tabsModel.tabsStates.indexOf(it) }
        hideMenuOverlay(true)
    }

    /** Tabs in the order they were last shown; only the newest ones keep their web page in memory. */
    private val recentTabs = ArrayList<WebTabState>()

    private fun changeTab(newTab: WebTabState) {
        tabsModel.changeTab(newTab, { tab: WebTabState -> createWebView(tab) }, vb.flWebViewContainer, WebEngineCallback(newTab))
        //TVs have little memory: keep the shown tab and the one before it loaded, release the others
        //(their state is saved; they reload when opened again)
        recentTabs.remove(newTab)
        recentTabs.add(0, newTab)
        recentTabs.retainAll(tabsModel.tabsStates.toSet())
        while (recentTabs.size > LIVE_TABS) {
            val old = recentTabs.removeAt(recentTabs.size - 1)
            if (old != tabsModel.currentTab.value && old.webEngine.getView()?.isAttachedToWindow == false) {
                try { old.saveWebViewStateToFile() } catch (e: Exception) { Log.e(TAG, "save tab state", e) }
                old.trimMemory()
            }
        }
        //switching tabs shows the tab strip; it hides again when the page is scrolled down
        showToolbar()
        updateGrabCount()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: WebTabState): View? {
        val webView: View
        try {
            webView = tab.webEngine.getOrCreateView(this) //WebViewEx(this, WebViewCallback(tab), AndroidJSInterface(this, viewModel, tabsModel, tab))
        } catch (e: Throwable) {
            e.printStackTrace()

            if (!config.isWebEngineGecko()) {
                val dialogBuilder = AlertDialog.Builder(this)
                    .setTitle(R.string.error)
                    .setCancelable(false)
                    .setMessage(R.string.err_webview_can_not_link)
                    .setNegativeButton(R.string.exit) { _, _ -> finish() }

                val appPackageName = "com.google.android.webview"
                val intent =
                    Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$appPackageName"))
                val activities = packageManager.queryIntentActivities(intent, 0)
                if (activities.size > 0) {
                    dialogBuilder.setPositiveButton(R.string.find_in_apps_store) { _, _ ->
                        try {
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        finish()
                    }
                }
                dialogBuilder.show()
            }
            return null
        }

        var ua = config.userAgentString.value
        if (ua?.contains("TV Bro/1.0 ") == true) {//legacy ua string - now default one should be used
            config.userAgentString.value = null
            ua = null
        }
        if (ua != null) {
            tab.webEngine.userAgentString = ua
        }

        (webView as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx)?.mediaLog?.onChanged = { scheduleGrabCountUpdate() }
        return webView
    }

    private fun onWebViewUpdated(tab: WebTabState) {
        vb.ibBack.isEnabled = tab.webEngine.canGoBack() == true
        vb.ibForward.isEnabled = tab.webEngine.canGoForward() == true

        val debandOn = (tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx)?.pageDeband == true
        if (debandOn) vb.ibDeband.setColorFilter(Color.parseColor("#20C997")) else vb.ibDeband.clearColorFilter()
        val desktopOn = config.isDesktopSite(try { URL(tab.url).host } catch (e: Exception) { null })
        if (desktopOn) vb.ibDesktopSite.setColorFilter(Color.parseColor("#20C997")) else vb.ibDesktopSite.clearColorFilter()

        val adblockEnabled = isAdBlockOnForTab(tab)
        vb.ibAdBlock.setImageResource(if (adblockEnabled) R.drawable.ic_adblock_on else R.drawable.ic_adblock_off)
        vb.tvBlockedAdCounter.visibility = if (adblockEnabled && tab.blockedAds != 0) View.VISIBLE else View.GONE
        vb.tvBlockedAdCounter.text = tab.blockedAds.toString()

        vb.tvBlockedPopupCounter.visibility = if (tab.blockedPopups != 0) View.VISIBLE else View.GONE
        vb.tvBlockedPopupCounter.text = tab.blockedPopups.toString()
    }

    private fun onDownloadRequested(url: String, referer: String, originalDownloadFileName: String, userAgent: String?, mimeType: String? = null,
                                    operationAfterDownload: Download.OperationAfterDownload = Download.OperationAfterDownload.NOP,
                                    base64BlobData: String? = null, stream: InputStream?, size: Long = 0L) {
        downloadIntent = Download(url, originalDownloadFileName, null, operationAfterDownload,
            mimeType, referer, userAgent, base64BlobData, stream, size)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE_ACCESS
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                MY_PERMISSIONS_REQUEST_POST_NOTIFICATIONS_ACCESS
            )
        } else {
            startDownload()
        }
    }

    private fun startDownload() {
        val download = this.downloadIntent ?: return
        this.downloadIntent = null
        val service = downloadService
        if (service == null) {
            //not connected yet: started as soon as it is (see downloadServiceConnection)
            pendingDownloads.add(download)
            bindService(Intent(this, DownloadService::class.java), downloadServiceConnection, Context.BIND_AUTO_CREATE)
            return
        }
        service.startDownload(download)
        onDownloadStarted(download.filename)
    }

    private val pendingDownloads = mutableListOf<Download>()

    private suspend fun awaitDownloadService() {
        var waited = 0
        while (downloadService == null && waited < 5000) {
            kotlinx.coroutines.delay(50)
            waited += 50
        }
    }

    override fun onTrimMemory(level: Int) {
        for (tab in tabsModel.tabsStates) {
            if (!tab.selected) {
                tab.trimMemory()
            }
        }
        super.onTrimMemory(level)
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                            permissions: Array<String>, grantResults: IntArray) {
        if (voiceSearchHelper.processPermissionsResult(requestCode, permissions, grantResults)) {
            return
        }
        if (tabsModel.currentTab.value?.webEngine?.onPermissionsResult(requestCode, permissions, grantResults) == true) return
        if (grantResults.isEmpty()) return
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_EXTERNAL_STORAGE_ACCESS -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startDownload()
                }
            }
            MY_PERMISSIONS_REQUEST_POST_NOTIFICATIONS_ACCESS -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startDownload()
                }
            }
            com.phlox.tvwebbrowser.sofa.LumenFolderPicker.REQUEST_CODE_STORAGE -> {
                val picked = onDownloadFolderPicked
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED && picked != null) {
                    com.phlox.tvwebbrowser.sofa.LumenFolderPicker(this) { picked() }.show()
                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (voiceSearchHelper.processActivityResult(requestCode, resultCode, data)) {
            return
        }
        when (requestCode) {
            PICK_FILE_REQUEST_CODE -> {
                tabsModel.currentTab.value?.webEngine?.onFilePicked(resultCode, data)
            }
            REQUEST_CODE_HISTORY_ACTIVITY -> if (resultCode == Activity.RESULT_OK) {
                val url = data?.getStringExtra(HistoryActivity.KEY_URL)
                if (url != null) {
                    navigate(url)
                }
                hideMenuOverlay()
            }
            REQUEST_CODE_UNKNOWN_APP_SOURCES -> {}
            REQUEST_CODE_VPN_PERMISSION -> if (resultCode == Activity.RESULT_OK) {
                lifecycleScope.launch { com.phlox.tvwebbrowser.sofa.SofaVpn.connect(applicationContext) }
            } else {
                Toast.makeText(this, R.string.sofa_vpn_permission_denied, Toast.LENGTH_LONG).show()
            }
            REQUEST_CODE_DOWNLOADS -> if (resultCode == Activity.RESULT_OK) {
                data?.getStringExtra(DownloadsActivity.EXTRA_DOWNLOAD_URL)?.let { downloadFromLink(it) }
            }
            REQUEST_CODE_PICK_DOWNLOAD_FOLDER -> if (resultCode == Activity.RESULT_OK) {
                data?.data?.let { onDownloadFolderResult(it) }
            }
            REQUEST_CODE_VPN_IMPORT_FILE -> if (resultCode == Activity.RESULT_OK) {
                data?.data?.let { onVpnConfigFilePicked(it) }
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, DownloadService::class.java), downloadServiceConnection, Context.BIND_AUTO_CREATE)
        //back in the same session: nothing to clear later
        if (processStarted) prefs.edit().putBoolean(PREF_CLEAR_PENDING, false).apply()
    }

    override fun onStop() {
        super.onStop()
        unbindService(downloadServiceConnection)
        downloadService = null
        //On a TV the browser is rarely "closed": it's left with Home and Android ends it later.
        //Remember that clearing is due; it happens on the next fresh start (see loadState).
        if (!isFinishing && !config.incognitoMode &&
            (config.lumenClearHistoryOnExit || config.lumenClearCookiesOnExit)) {
            prefs.edit().putBoolean(PREF_CLEAR_PENDING, true).apply()
        }
    }

    override fun onResume() {
        super.onResume()
        val intentFilter = IntentFilter("android.net.conn.CONNECTIVITY_CHANGE")
        registerReceiver(mConnectivityChangeReceiver, intentFilter)
        tabsModel.currentTab.value?.webEngine?.onResume()
    }

    override fun onPause() {
        unregisterReceiver(mConnectivityChangeReceiver)
        tabsModel.currentTab.value?.apply {
            webEngine.onPause()
            onPause()
            if (!sessionCleared) runBlocking { tabsModel.saveTab(this@apply) }
        }
        super.onPause()
    }

    private fun toggleAdBlockForTab() {
        tabsModel.currentTab.value?.apply {
            val currentState = isAdBlockOnForTab(this)
            val newState = !currentState
            adblock = newState
            webEngine.onUpdateAdblockSetting(newState)
            onWebViewUpdated(this)
            refresh()
        }
    }

    private suspend fun showPopupBlockOptions() {
        val tab = tabsModel.currentTab.value ?: return
        val currentHostConfig = tabsModel.findHostConfig(tab,false)
        val currentBlockPopupsLevelValue = currentHostConfig?.popupBlockLevel ?: HostConfig.DEFAULT_BLOCK_POPUPS_VALUE
        val hostName = currentHostConfig?.hostName ?: try { URL(tab.url).host } catch (e: Exception) { "" }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.block_popups_s, hostName))
            .setSingleChoiceItems(R.array.popup_blocking_level, currentBlockPopupsLevelValue) {
                    dialog, itemId -> lifecycleScope.launch {
                        tabsModel.changePopupBlockingLevel(itemId, tab)
                        dialog.dismiss()
                    }
            }
            .show()
    }

    fun navigate(url: String) {
        Log.d(TAG, "navigate: $url")
        vb.vActionBar.setAddressBoxTextColor(ContextCompat.getColor(this@MainActivity, R.color.default_url_color))
        val tab = tabsModel.currentTab.value
        if (tab != null) {
            tab.url = url
            tab.webEngine.loadUrl(url)
        } else {
            openInNewTab(url, 0, needToHideMenuOverlay = true, navigateImmediately = true)
        }
    }

    override fun search(aText: String) {
        var text = aText
        val trimmedLowercased = text.trim { it <= ' ' }.lowercase(Locale.ROOT)
        if (Patterns.WEB_URL.matcher(text).matches() || trimmedLowercased.startsWith("http://") || trimmedLowercased.startsWith("https://")) {
            if (!text.lowercase(Locale.ROOT).contains("://")) {
                text = "https://$text"
            }
            navigate(text)
        } else {
            var query: String? = null
            try {
                query = URLEncoder.encode(text, "utf-8")
            } catch (e1: UnsupportedEncodingException) {
                e1.printStackTrace()
                Utils.showToast(this, R.string.error)
                return
            }

            val searchUrl = config.searchEngineURL.value.replace("[query]", query!!)
            navigate(searchUrl)
        }
    }

    override fun goHome() {
        navigate(settingsModel.homePage)
        hideMenuOverlay()
    }

    override fun toggleIncognitoMode() {
        toggleIncognitoMode(true)
    }

    private fun toggleIncognitoMode(andSwitchProcess: Boolean) = lifecycleScope.launch(Dispatchers.Main) {
        Log.d(TAG, "toggleIncognitoMode andSwitchProcess: $andSwitchProcess")
        val becomingIncognitoMode = !config.incognitoMode
        vb.progressBarGeneric.visibility = View.VISIBLE
        if (!becomingIncognitoMode) {
            if (!config.isWebEngineGecko()) {
                withContext(Dispatchers.IO) {
                    WebStorage.getInstance().deleteAllData()
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                }

                WebEngineFactory.clearCache(this@MainActivity)
            }

            tabsModel.onCloseAllTabs().join()
            tabsModel.currentTab.value = null

            if (!config.isWebEngineGecko()) {
                viewModel.clearIncognitoData().join()
            }
        }
        vb.progressBarGeneric.visibility = View.GONE
        config.incognitoMode = becomingIncognitoMode
        if (andSwitchProcess) {
            switchProcess(becomingIncognitoMode)
        }
    }

    private fun switchProcess(incognitoMode: Boolean, intentDataToCopy: Bundle? = null) {
        Log.d(TAG, "switchProcess incognitoMode: $incognitoMode")
        val activityClass = if (incognitoMode) IncognitoModeMainActivity::class.java
        else MainActivity::class.java
        val intent = Intent(this@MainActivity, activityClass)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        intent.putExtra(KEY_PROCESS_ID_TO_KILL, Process.myPid())
        intentDataToCopy?.let {
            intent.putExtras(it)
        }
        startActivity(intent)
        exitProcess(0)
    }

    fun toggleMenu() {
        if (vb.rlActionBar.hasFocus()) {
            hideMenuOverlay()
        } else {
            showMenuOverlay()
        }
    }

    val onBackPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            backNavigationEventsAdapter.dispatchSystemBackNavigationEvent()
        }
    }

    private val backNavigationEventsAdapter = BackNavigationEventsAdapter(
        onEmulatedBackEvent = {
            if (!hideSoftwareKeyboardIfVisible()) {
                handleBackNavigation()
            }
        }
    )

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val localCallback = window.callback
        window.callback = object : Window.Callback by localCallback {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                //Log.d(TAG, "dispatchKeyEvent event: $event")
                //Lumen: the remote's pointer is over the top bar
                if (vb.vToolbarCursor.active && vb.vToolbarCursor.handleKey(event)) {
                    if (event.action == KeyEvent.ACTION_UP &&
                        (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                        //a click into the address bar: put the pointer away so the keyboard can be used
                        vb.rlRoot.post {
                            if (currentFocus is android.widget.EditText) vb.vToolbarCursor.close(notify = false)
                        }
                    }
                    return true
                }
                //Lumen: selecting text on the page: OK copies, Back cancels, arrows move the end
                if (textSelecting && handleSelectionKey(event)) return true
                backNavigationEventsAdapter.dispatchKeyEvent(event)

                val keyCode = if (event.keyCode != 0) event.keyCode else event.scanCode
                val keyCodeBackNavigation = keyCode == KeyEvent.KEYCODE_ESCAPE ||
                        keyCode == KeyEvent.KEYCODE_BUTTON_B || keyCode == KeyEvent.KEYCODE_BACK
                val shortcutMgr = ShortcutMgr.getInstance()
                val currentTab = tabsModel.currentTab.value
                if (!keyCodeBackNavigation &&
                    shortcutMgr.handle(event, this@MainActivity, currentTab)) {
                    return true
                }

                return localCallback.dispatchKeyEvent(event)
            }

            override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
                //Log.d(TAG, "dispatchGenericMotionEvent event: $event")
                if (backNavigationEventsAdapter.dispatchGenericMotionEvent(event)) {
                    return true
                }
                return localCallback.dispatchGenericMotionEvent(event)
            }
        }
    }

    /**
     * When the IME is visible, the first back press should only dismiss it; this mirrors standard
     * Android behavior and avoids navigating away while the user is typing.
     *
     * @return true if the IME was visible and a hide was requested.
     */
    private fun hideSoftwareKeyboardIfVisible(): Boolean {
        val root = window.decorView.rootView
        val insets = ViewCompat.getRootWindowInsets(root) ?: return false
        if (!insets.isVisible(WindowInsetsCompat.Type.ime())) {
            return false
        }
        val view = currentFocus ?: root
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
        return true
    }

    private fun handleBackNavigation() {
        Log.d(TAG, "handleBackNavigation")
        if (tabsModel.currentTab.value?.webEngine?.isVirtualCursorMode() == false) {
            tabsModel.currentTab.value?.webEngine?.setVirtualCursorMode(true)
            backNavigationEventsAdapter.gameControllersLongPressBForBackNavigation = false
            return
        }

        if (vb.vCursorMenu.isVisible) {
            vb.vCursorMenu.close(CursorMenuView.CloseAnimation.ROTATE_OUT)
        } else if (vb.flWebViewContainer.cursorDrawerDelegate.canHandleBackNavigation()) {
            vb.flWebViewContainer.cursorDrawerDelegate.handleBackNavigation()
        } else if (isFullscreen) {
            tabsModel.currentTab.value?.webEngine?.hideFullscreenView()
        } else if (vb.rlActionBar.hasFocus()) {
            //Back while in the top bar returns to the page
            hideMenuOverlay()
        } else {
            navigateBack()
        }
    }

    // ---------------- Lumen: long press = select & copy / paste ----------------
    private var textSelecting = false
    private var selectionIgnoreUp = false
    private var selectionBanner: android.widget.TextView? = null
    private var selectionLastX = -1f
    private var selectionLastY = -1f

    private fun clipboardText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = cm.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.takeIf { it.isNotEmpty() }
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Lumen", text))
        val shown = if (text.length > 60) text.take(57) + "…" else text
        Toast.makeText(this, "Copied: $shown", Toast.LENGTH_SHORT).show()
    }

    private fun pageWebView(engine: com.phlox.tvwebbrowser.webengine.WebEngine?): android.webkit.WebView? =
        engine?.getView() as? android.webkit.WebView

    private fun onPageLongPress(engine: com.phlox.tvwebbrowser.webengine.WebEngine, result: String): Boolean {
        val o = try { org.json.JSONObject(result) } catch (e: Exception) { return false }
        val wv = pageWebView(engine) ?: return false
        when (o.optString("kind")) {
            "edit" -> {
                val text = clipboardText()
                if (text == null) {
                    Toast.makeText(this, "Nothing copied yet", Toast.LENGTH_SHORT).show()
                } else {
                    wv.evaluateJavascript("window.__lumenPaste(" + org.json.JSONObject.quote(text) + ")", null)
                    Toast.makeText(this, "Pasted", Toast.LENGTH_SHORT).show()
                }
            }
            "text" -> startTextSelection()
            "link" -> o.optString("href").takeIf { it.isNotEmpty() }?.let { copyToClipboard(it) }
            else -> {}
        }
        return true
    }

    private fun startTextSelection() {
        textSelecting = true
        selectionIgnoreUp = true //the release of the long press itself
        val d = vb.flWebViewContainer.cursorDrawerDelegate
        selectionLastX = d.cursorPosition.x
        selectionLastY = d.cursorPosition.y
        if (selectionBanner == null) {
            selectionBanner = android.widget.TextView(this).apply {
                text = "Move to select more  ·  OK copies  ·  Back cancels"
                setTextColor(Color.WHITE)
                textSize = 16f
                val pad = (12 * resources.displayMetrics.density).toInt()
                setPadding(pad * 2, pad, pad * 2, pad)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 22 * resources.displayMetrics.density
                    setColor(0xE00F1D20.toInt())
                }
                elevation = 30 * resources.displayMetrics.density
            }
            val lp = android.widget.RelativeLayout.LayoutParams(android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_BOTTOM)
            lp.addRule(android.widget.RelativeLayout.CENTER_HORIZONTAL)
            lp.bottomMargin = (32 * resources.displayMetrics.density).toInt()
            vb.rlRoot.addView(selectionBanner, lp)
        }
        selectionBanner?.visibility = View.VISIBLE
        uiHandler.removeCallbacks(selectionTicker)
        uiHandler.postDelayed(selectionTicker, 60)
    }

    /** While selecting: the end of the selection follows the pointer. */
    private val selectionTicker = object : Runnable {
        override fun run() {
            if (!textSelecting) return
            val d = vb.flWebViewContainer.cursorDrawerDelegate
            val x = d.cursorPosition.x
            val y = d.cursorPosition.y
            if (x != selectionLastX || y != selectionLastY) {
                selectionLastX = x
                selectionLastY = y
                val wv = pageWebView(tabsModel.currentTab.value?.webEngine)
                wv?.evaluateJavascript("window.__lumenSelExtend && window.__lumenSelExtend(${x.toInt()}, ${y.toInt()}, ${wv.width})", null)
            }
            uiHandler.postDelayed(this, 60)
        }
    }

    private fun endTextSelection(copy: Boolean) {
        textSelecting = false
        uiHandler.removeCallbacks(selectionTicker)
        selectionBanner?.visibility = View.GONE
        val wv = pageWebView(tabsModel.currentTab.value?.webEngine) ?: return
        wv.evaluateJavascript("window.__lumenSelCopy ? window.__lumenSelCopy(${!copy}) : ''") { res ->
            if (!copy) return@evaluateJavascript
            val text = try { org.json.JSONArray("[$res]").getString(0) } catch (e: Exception) { "" }
            if (text.isNotBlank()) copyToClipboard(text.trim())
        }
    }

    private fun handleSelectionKey(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A -> {
                if (event.action == KeyEvent.ACTION_UP) {
                    if (selectionIgnoreUp) selectionIgnoreUp = false else endTextSelection(copy = true)
                } else if (event.repeatCount == 0) {
                    selectionIgnoreUp = false
                }
                return true
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_B -> {
                if (event.action == KeyEvent.ACTION_UP) endTextSelection(copy = false)
                return true
            }
        }
        return false
    }

    /** OK held on a text field of the app (address bar, settings): paste what was copied last. */
    private fun pasteIntoFieldAt(x: Float, y: Float): Boolean {
        val field = findEditTextAt(vb.rlRoot, x, y) ?: return false
        val text = clipboardText()
        if (text == null) {
            Toast.makeText(this, "Nothing copied yet", Toast.LENGTH_SHORT).show()
            return true
        }
        field.requestFocus()
        val editable = field.text
        if (field.id == R.id.etUrl) {
            //the address bar shows the current address: replace it
            field.setText(text.trim())
            field.setSelection(field.text.length)
        } else {
            val s = field.selectionStart.coerceAtLeast(0)
            val e = field.selectionEnd.coerceAtLeast(0)
            editable.replace(minOf(s, e), maxOf(s, e), text)
        }
        Toast.makeText(this, "Pasted", Toast.LENGTH_SHORT).show()
        return true
    }

    /** The visible text field at ([x], [y]) in [root]'s coordinates (screen positions, so sliding bars count). */
    private fun findEditTextAt(root: android.view.ViewGroup, x: Float, y: Float): android.widget.EditText? {
        val rootLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        val sx = rootLoc[0] + x
        val sy = rootLoc[1] + y
        val loc = IntArray(2)
        var found: android.widget.EditText? = null
        fun walk(v: View) {
            if (v.visibility != View.VISIBLE || found != null) return
            if (v is android.widget.EditText) {
                if (!v.isEnabled || !v.isShown) return
                v.getLocationOnScreen(loc)
                if (sx >= loc[0] && sx < loc[0] + v.width && sy >= loc[1] && sy < loc[1] + v.height) found = v
                return
            }
            if (v is android.view.ViewGroup) for (k in v.childCount - 1 downTo 0) walk(v.getChildAt(k))
        }
        walk(root)
        return found
    }

    // ---------------- Lumen: auto-hiding top bar ----------------
    private var toolbarAutoHidden = false
    private var scrollDownSinceShown = 0
    private var toolbarShownByUserAt = 0L
    private var hideScheduledForThisLoad = false
    private val toolbarHandler = Handler(android.os.Looper.getMainLooper())
    private val hideToolbarAfterLoad = Runnable {
        //don't hide a bar the user brought back a moment ago
        if (System.currentTimeMillis() - toolbarShownByUserAt > 4000) autoHideToolbar()
    }

    /** The page pointer reached the top: it continues over the bar (buttons, tabs, ✕) like a mouse. */
    private fun enterToolbarPointer(pageX: Float, dirX: Int, speedX: Float, speedY: Float) {
        //just above the page's top edge, where the page pointer was; if the bar is hidden it
        //slides in and the pointer rides down with it (see setToolbarShown)
        val page = vb.flWebViewContainer
        val y = page.top + page.translationY - 1f
        vb.vToolbarCursor.show(pageX + page.left, y, dirX, -1, speedX, speedY)
        showToolbar()
        toolbarShownByUserAt = System.currentTimeMillis()
    }

    /** Back to the page pointer, at [x] just below the bar (or where it was). */
    private fun returnPointerToPage(x: Float?, dirX: Int = 0, dirY: Int = 0, speedX: Float = 0f, speedY: Float = 0f) {
        val engine = tabsModel.currentTab.value?.webEngine ?: return
        val delegate = engine.getCursorDrawerDelegate()
        engine.getView()?.requestFocus()
        if (delegate == null) return
        if (x != null) {
            //continues at the page's top edge with the same speed: one smooth movement
            delegate.continueMove(x - vb.flWebViewContainer.left, 0f, dirX, dirY, speedX, speedY)
        } else {
            delegate.animateAppearing()
        }
    }

    private fun canAutoHideToolbar(): Boolean {
        if (!config.lumenAutoHideToolbar || isFullscreen) return false
        if (vb.vToolbarCursor.active) return false
        val tab = tabsModel.currentTab.value ?: return false
        if (isOnHomePage(tab)) return false
        //the user is using the bar (typing an address, picking a button)
        if (vb.rlActionBar.hasFocus()) return false
        return true
    }

    private fun autoHideToolbar() {
        if (!canAutoHideToolbar() || !toolbarShown) return
        toolbarAutoHidden = true
        setToolbarShown(false)
    }

    /** Shows the top bar again; it stays until the page is scrolled down. */
    fun showToolbar() {
        toolbarHandler.removeCallbacks(hideToolbarAfterLoad)
        scrollDownSinceShown = 0
        if (isFullscreen) return
        toolbarAutoHidden = false
        if (!toolbarShown) setToolbarShown(true)
    }

    // The top bar slides in and out. The page below it is never resized while the bar moves (that
    // re-layout made the old version jerky and could flicker): when hiding, the page first grows
    // downwards, off screen, and both slide up together; when showing, both slide down and the page
    // shrinks at the bottom, off screen, only when the slide has finished.
    private var toolbarShown = true
    private var toolbarAnimator: android.animation.ValueAnimator? = null
    private var toolbarMovingUntil = 0L

    private fun setPageTopMargin(px: Int) {
        val lp = vb.flWebViewContainer.layoutParams as android.view.ViewGroup.MarginLayoutParams
        if (lp.topMargin != px) {
            lp.topMargin = px
            vb.flWebViewContainer.layoutParams = lp
        }
    }

    /** Puts bar and page in their final place at once (no animation). */
    private fun applyToolbarLayout(show: Boolean) {
        toolbarAnimator?.cancel()
        toolbarAnimator = null
        val h = vb.rlActionBar.height
        vb.rlActionBar.visibility = if (show) View.VISIBLE else View.INVISIBLE
        vb.rlActionBar.translationY = if (show) 0f else -h.toFloat()
        vb.flWebViewContainer.translationY = 0f
        setPageTopMargin(if (show) h else 0)
    }

    private fun setToolbarShown(show: Boolean, animate: Boolean = true) {
        if (show == toolbarShown && toolbarAnimator == null) return
        toolbarShown = show
        val bar = vb.rlActionBar
        val page = vb.flWebViewContainer
        val h = bar.height.toFloat()
        if (!animate || h <= 0f || isFullscreen) {
            applyToolbarLayout(show)
            return
        }
        toolbarAnimator?.cancel()
        //scroll events caused by the move itself must not hide/show the bar again
        toolbarMovingUntil = System.currentTimeMillis() + 500
        val barFrom = bar.translationY
        val pageFrom: Float
        if (show) {
            bar.visibility = View.VISIBLE
            pageFrom = page.translationY
        } else {
            //page grows at the bottom (off screen) and is shifted down by the bar height, so nothing moves yet
            val current = (page.layoutParams as android.view.ViewGroup.MarginLayoutParams).topMargin + page.translationY
            setPageTopMargin(0)
            page.translationY = current
            pageFrom = current
        }
        val barTo = if (show) 0f else -h
        val pageTo = if (show) h else 0f
        val anim = android.animation.ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 220
        anim.interpolator = android.view.animation.DecelerateInterpolator()
        anim.addUpdateListener {
            val f = it.animatedValue as Float
            bar.translationY = barFrom + (barTo - barFrom) * f
            page.translationY = pageFrom + (pageTo - pageFrom) * f
            vb.vToolbarCursor.onBarMoved()
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (cancelled) return
                toolbarAnimator = null
                applyToolbarLayout(show)
            }
        })
        toolbarAnimator = anim
        anim.start()
    }

    private fun isPageAtTop(engine: com.phlox.tvwebbrowser.webengine.WebEngine): Boolean {
        val view = engine.getView() ?: return true
        val box = (view as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx)?.boxScrollY ?: 0
        return view.scrollY == 0 && box <= 0
    }

    private fun onTabScrolled(tab: WebTabState, y: Int, dy: Int) {
        if (tab != tabsModel.currentTab.value || isFullscreen) return
        if (System.currentTimeMillis() < toolbarMovingUntil) return
        if (y <= 0 && dy <= 0) {
            //scrolled (or pulled) all the way up
            if (toolbarAutoHidden || !toolbarShown) {
                showToolbar()
                toolbarShownByUserAt = System.currentTimeMillis()
            }
            return
        }
        if (dy > 0) {
            scrollDownSinceShown += dy
            if (scrollDownSinceShown > Utils.D2P(this, 48f)) autoHideToolbar()
        } else if (dy < 0) {
            scrollDownSinceShown = 0
        }
    }

    /**
     * The web page process died (usually out of memory). Android would close the app; instead the
     * tab gets a fresh page that explains what happened, without reloading the page that crashed.
     */
    private fun recoverFromPageCrash(tab: WebTabState, url: String?) {
        //don't restore the saved state: it would load the crashing page again
        tab.savedState = null
        tab.removeFiles()
        val failedUrl = url?.takeIf { it.startsWith("http") } ?: tab.url
        if (tab != tabsModel.currentTab.value) {
            tab.url = failedUrl //rebuilt (and reloaded) when the tab is shown again
            return
        }
        showToolbar()
        try {
            //a blank start, so the new view doesn't load (and crash on) the same page right away
            tab.url = "about:blank"
            changeTab(tab)
            tab.url = failedUrl
            (tab.webEngine.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx)?.showCrashPage(failedUrl)
        } catch (e: Exception) {
            Log.e(TAG, "recoverFromPageCrash", e)
        }
    }

    // ---------------- Lumen: number of grabbed media links on the grab button ----------------
    private var grabCountUpdatePending = false

    private fun scheduleGrabCountUpdate() {
        //media requests arrive in bursts from network threads: update at most ~4 times a second
        if (grabCountUpdatePending) return
        grabCountUpdatePending = true
        toolbarHandler.postDelayed({
            grabCountUpdatePending = false
            updateGrabCount()
        }, 250)
    }

    private fun updateGrabCount() {
        val webView = tabsModel.currentTab.value?.webEngine?.getView() as? com.phlox.tvwebbrowser.webengine.webview.WebViewEx
        val count = webView?.mediaLog?.size ?: 0
        if (count <= 0) {
            vb.tvGrabCount.visibility = View.GONE
        } else {
            vb.tvGrabCount.text = if (count > 99) "99+" else count.toString()
            vb.tvGrabCount.visibility = View.VISIBLE
        }
        vb.ibGrabLinks.contentDescription = if (count > 0)
            getString(R.string.lumen_grab) + " ($count)" else getString(R.string.lumen_grab)
    }

    private fun onTabPageStartedForToolbar(tab: WebTabState) {
        if (tab != tabsModel.currentTab.value) return
        updateGrabCount()
        hideScheduledForThisLoad = false
        showToolbar()
    }

    private fun onTabPageFinishedForToolbar(tab: WebTabState) {
        if (tab != tabsModel.currentTab.value || hideScheduledForThisLoad) return
        hideScheduledForThisLoad = true
        if (!canAutoHideToolbar()) return
        toolbarHandler.removeCallbacks(hideToolbarAfterLoad)
        toolbarHandler.postDelayed(hideToolbarAfterLoad, 2000)
    }

    /** The top bar is always visible; "showing the menu" moves the remote's focus into it. */
    private fun showMenuOverlay() {
        showToolbar()
        toolbarShownByUserAt = System.currentTimeMillis()
        vb.flWebViewContainer.visibility = View.VISIBLE
        vb.vActionBar.dismissExtendedAddressBarMode()
        vb.vActionBar.catchFocus()
    }

    private suspend fun displayThumbnail(currentTab: WebTabState?) {
        //Lumen: no thumbnail previews; the page itself stays visible under the top bar
        vb.ivMiniatures.visibility = View.INVISIBLE
        vb.llMiniaturePlaceholder.visibility = View.INVISIBLE
        if (vb.ivMiniatures.visibility == View.INVISIBLE) return
        if (currentTab != null) {
            if (tabByTitleIndex(vb.vTabs.current) != currentTab) return
            vb.llMiniaturePlaceholder.visibility = View.INVISIBLE
            vb.ivMiniatures.visibility = View.VISIBLE
            if (currentTab.thumbnail != null) {
                vb.ivMiniatures.setImageBitmap(currentTab.thumbnail)
            } else if (currentTab.thumbnailHash != null) {
                withContext(Dispatchers.IO) {
                    val thumbnail = currentTab.loadThumbnail()
                    withContext(Dispatchers.Main) {
                        if (thumbnail != null) {
                            vb.ivMiniatures.setImageBitmap(currentTab.thumbnail)
                        } else {
                            vb.ivMiniatures.setImageResource(0)
                        }
                    }
                }
            } else {
                vb.ivMiniatures.setImageResource(0)
            }
        } else {
            vb.llMiniaturePlaceholder.visibility = View.VISIBLE
            vb.ivMiniatures.setImageResource(0)
            vb.ivMiniatures.visibility = View.INVISIBLE
        }
    }

    /** Leaves the top bar: shows the selected tab and gives the focus back to the page. */
    private fun hideMenuOverlay(hideBottomButtons: Boolean = true) {
        vb.ivMiniatures.visibility = View.INVISIBLE
        vb.llMiniaturePlaceholder.visibility = View.INVISIBLE
        syncTabWithTitles()
        vb.flWebViewContainer.visibility = View.VISIBLE
        if (hideBottomButtons) {
            tabsModel.currentTab.value?.webEngine?.getView()?.requestFocus()
        }
    }

    private fun syncTabWithTitles() {
        val tab = tabByTitleIndex(vb.vTabs.current)
        if (tab == null) {
            if (tabsModel.tabsStates.isEmpty()) {
                openInNewTab(settingsModel.homePage, 0, needToHideMenuOverlay = false, navigateImmediately = true)
            } else {
                //stale index (e.g. right after closing a tab): point back at the visible tab
                tabsModel.currentTab.value?.let { vb.vTabs.current = tabsModel.tabsStates.indexOf(it) }
            }
        } else if (!tab.selected) {
            changeTab(tab)
        }
    }

    private fun hideBottomPanel() {
        //the buttons are part of the permanent top bar now
    }

    private fun onDownloadStarted(fileName: String) {
        Utils.showToast(this, getString(R.string.download_started,
                com.phlox.tvwebbrowser.sofa.LumenDownloads.folderLabel(this) + File.separator + fileName))
    }

    override fun initiateVoiceSearch() {
        //Lumen has no microphone access: the search key opens the address bar for typing instead
        vb.vActionBar.focusAddressBar()
    }

    private fun onEditHomePageBookmark(favoriteItem: FavoriteItem) {
        FavoriteEditorDialog(this, object : FavoriteEditorDialog.Callback {
            override fun onDone(item: FavoriteItem) {
                viewModel.onHomePageLinkEdited(item)
            }
        }, favoriteItem).show()
    }

    private inner class WebEngineCallback(val tab: WebTabState) : WebEngineWindowProviderCallback {
        override fun getActivity(): Activity {
            return this@MainActivity
        }

        override fun onOpenInNewTabRequested(url: String, navigateImmediately: Boolean): WebEngine? {
            var index = tabsModel.tabsStates.indexOf(tabsModel.currentTab.value)
            index = if (index == -1) tabsModel.tabsStates.size else index + 1
            return openInNewTab(url, index, true, navigateImmediately)
        }

        override fun onDownloadRequested(url: String) {
            Log.i(TAG, "onDownloadRequested url: $url")
            val fileName = Uri.parse(url).lastPathSegment
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(url))
            onDownloadRequested(url, tab.url,
                fileName, tab.webEngine.userAgentString, mimeType)
        }

        override fun onDownloadRequested(url: String, referer: String,
                                         originalDownloadFileName: String?, userAgent: String?, mimeType: String?,
                                         operationAfterDownload: Download.OperationAfterDownload, base64BlobData: String?,
                                         stream: InputStream?, size: Long, contentDisposition: String?) {
            val fileName = DownloadUtils.guessFileName(url, contentDisposition, mimeType)

            this@MainActivity.onDownloadRequested(url, referer, fileName,
                userAgent, mimeType, operationAfterDownload, base64BlobData, stream, size)
        }

        override fun onDownloadRequested(url: String, userAgent: String?, contentDisposition: String,
                                         mimetype: String?, contentLength: Long ) {
            Log.i(TAG, "DownloadListener.onDownloadStart url: $url")
            onDownloadRequested(url= url, referer = tab.url, originalDownloadFileName = null,
                userAgent = userAgent, mimeType = mimetype, size = contentLength, contentDisposition = contentDisposition)
        }

        override fun onProgressChanged(newProgress: Int) {
            vb.progressBar.visibility = View.VISIBLE
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                vb.progressBar.setProgress(newProgress, true)
            } else {
                vb.progressBar.progress = newProgress
            }
            uiHandler.removeCallbacks(progressBarHideRunnable)
            if (newProgress == 100) {
                uiHandler.postDelayed(progressBarHideRunnable, 1000)
            } else {
                uiHandler.postDelayed(progressBarHideRunnable, 5000)
            }
        }

        override fun onReceivedTitle(title: String) {
            tab.title = title
            vb.vTabs.onTabTitleUpdated(tab)
            viewModel.onTabTitleUpdated(tab)
        }

        override fun requestPermissions(array: Array<String>): Int {
            val requestCode = lastCommonRequestsCode++
            this@MainActivity.requestPermissions(array, requestCode)
            return requestCode
        }

        override fun onShowFileChooser(intent: Intent): Boolean {
            try {
                startActivityForResult(intent, PICK_FILE_REQUEST_CODE)
            } catch (e: ActivityNotFoundException) {
                try {
                    //trying again with type */* (seems file pickers usually doesn't support specific types in intent filters but still can do the job)
                    intent.type = "*/*"
                    startActivityForResult(intent, PICK_FILE_REQUEST_CODE)
                } catch (e: ActivityNotFoundException) {
                    Utils.showToast(applicationContext, getString(R.string.err_cant_open_file_chooser))
                    return false
                }
            }
            return true
        }

        override fun onReceivedIcon(icon: Bitmap) {
            vb.vTabs.onFavIconUpdated(tab)
        }

        override fun shouldOverrideUrlLoading(url: String): Boolean {
            tab.lastLoadingUrl = url

            val uri = try {
                Uri.parse(url)
            } catch (e: Exception) {
                Log.e(TAG, "shouldOverrideUrlLoading: ", e)
                return true
            }

            if (uri.scheme == null) {
                Log.d(TAG, "shouldOverrideUrlLoading: no scheme: $url")
                return true
            }

            if (URLUtil.isNetworkUrl(url) || uri.scheme.equals("javascript", true) ||
                    uri.scheme.equals("data", true) || uri.scheme.equals("about", true) ||
                    uri.scheme.equals("blob", true)) {
                Log.d(TAG, "shouldOverrideUrlLoading: network url: $url")
                return false
            }

            if (uri.scheme.equals("intent", true)) {
                Log.d(TAG, "shouldOverrideUrlLoading: intent url: $url")
                onOpenInExternalAppRequested(url)
                return true
            }

            //try to handle intent for non-network urls by external apps
            //TODO: ask user if he wants to open this url in external app
            return try {
                Log.d(TAG, "shouldOverrideUrlLoading: non-network url: $url")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                if (intent.resolveActivity(TVBro.instance.packageManager) != null) {
                    runOnUiThread {
                        askUserAndOpenInExternalApp(url, intent)
                    }
                    true
                } else {
                    Log.d(TAG, "shouldOverrideUrlLoading: no activity to handle intent")
                    runOnUiThread {
                        Utils.showToast(applicationContext, getString(R.string.err_no_app_to_handle_url))
                    }
                    true
                }
            } catch (e: Exception) {
                Log.e(TAG, "shouldOverrideUrlLoading: ", e)
                true
            }
        }

        override fun onPageScrolled(y: Int, dy: Int) {
            onTabScrolled(tab, y, dy)
        }

        override fun onRenderProcessGone(url: String?) {
            recoverFromPageCrash(tab, url)
        }

        override fun onPageStateChanged() {
            onWebViewUpdated(tab)
        }

        override fun onVideoStarted() {
            //a video started in the page: give it the whole screen
            if (tab == tabsModel.currentTab.value && toolbarShown && canAutoHideToolbar() &&
                System.currentTimeMillis() - toolbarShownByUserAt > 3000) {
                autoHideToolbar()
            }
        }

        override fun onUrlChanged(url: String) {
            if (url.isBlank() || url == "about:blank" || url.startsWith("data:")) return
            if (tab.url == url) return
            tab.url = url
            if (tabByTitleIndex(vb.vTabs.current) == tab && !vb.vActionBar.hasFocus()) {
                vb.vActionBar.setAddressBoxText(url)
            }
        }

        override fun onPageStarted(url: String?) {
            onTabPageStartedForToolbar(tab)
            onWebViewUpdated(tab)
            if (url != null && url.startsWith(Config.HOME_PAGE_URL)) {
                //pick up bookmarks added since the home page was last shown
                viewModel.refreshHomePageLinks()
            }
            //the close button depends on the page (see TabsAdapter)
            vb.vTabs.onTabTitleUpdated(tab)
            val webViewUrl = tab.webEngine.url
            if (webViewUrl != null) {
                tab.url = webViewUrl
            } else if (url != null) {
                tab.url = url
            }
            if (tabByTitleIndex(vb.vTabs.current) == tab) {
                vb.vActionBar.setAddressBoxText(tab.url)
            }
            tab.blockedAds = 0
            tab.blockedPopups = 0
        }

        override fun onPageFinished(url: String?) {
            if (tabsModel.currentTab.value == null) {
                return
            }
            onWebViewUpdated(tab)
            onTabPageFinishedForToolbar(tab)

            val webViewUrl = tab.webEngine.url
            if (webViewUrl != null) {
                tab.url = webViewUrl
            } else if (url != null) {
                tab.url = url
            }
            if (tabByTitleIndex(vb.vTabs.current) == tab) {
                vb.vActionBar.setAddressBoxText(tab.url)
            }

            //Lumen: no tab thumbnails (they aren't shown): saves memory and work on every page load
            tabsModel.tabsStates.onEach { it.thumbnail = null }
        }

        override fun onPageCertificateError(url: String?) {
            vb.vActionBar.setAddressBoxTextColor(Color.RED)
        }

        override fun isAd(url: Uri, acceptHeader: String?, baseUri: Uri): Boolean? {
            return adblockModel.isAd(url, acceptHeader, baseUri)
        }

        override fun isAdBlockingEnabled(): Boolean {
            return isAdBlockOnForTab(tab)
        }

        override fun isDialogsBlockingEnabled(): Boolean {
            if (tab.url == Config.HOME_PAGE_URL) return false
            return shouldBlockNewWindow(dialog = true, userGesture = false)
        }

        override fun shouldBlockNewWindow(dialog: Boolean, userGesture: Boolean): Boolean {
            val hostConfig = runBlocking(Dispatchers.Main.immediate){ tabsModel.findHostConfig(tab, false) }
            val currentBlockPopupsLevelValue = hostConfig?.popupBlockLevel ?: HostConfig.DEFAULT_BLOCK_POPUPS_VALUE
            return when (currentBlockPopupsLevelValue) {
                HostConfig.POPUP_BLOCK_NONE -> false
                HostConfig.POPUP_BLOCK_DIALOGS -> dialog
                HostConfig.POPUP_BLOCK_NEW_AUTO_OPENED_TABS -> dialog || !userGesture
                else -> true
            }
        }

        override fun onBlockedAd(uri: String) {
            Log.i(TAG, "onBlockedAd: $uri")
            if (!config.adBlockEnabled) return
            tab.blockedAds++
            vb.tvBlockedAdCounter.visibility = if (tab.blockedAds > 0) View.VISIBLE else View.GONE
            vb.tvBlockedAdCounter.text = tab.blockedAds.toString()
        }

        override fun onBlockedDialog(newTab: Boolean) {
            tab.blockedPopups++
            runOnUiThread {
                vb.tvBlockedPopupCounter.visibility = if (tab.blockedPopups > 0) View.VISIBLE else View.GONE
                vb.tvBlockedPopupCounter.text = tab.blockedPopups.toString()
                val msg = getString(if (newTab) R.string.new_tab_blocked else R.string.popup_dialog_blocked)
                NotificationView.showBottomRight(vb.rlRoot, R.drawable.ic_block_popups, msg)
            }
        }

        override fun onCreateWindow(dialog: Boolean, userGesture: Boolean): View? {
            if (shouldBlockNewWindow(dialog, userGesture)) {
                onBlockedDialog(!dialog)
                return null
            }
            val tab = WebTabState(incognito = config.incognitoMode)
            val webView = createWebView(tab) ?: return null
            val currentTab = this@MainActivity.tabsModel.currentTab.value ?: return null
            val index = tabsModel.tabsStates.indexOf(currentTab) + 1
            tabsModel.tabsStates.add(index, tab)
            changeTab(tab)
            return webView
        }

        override fun closeWindow(internalRepresentation: Any) {
            for (tab in tabsModel.tabsStates) {
                if (tab.webEngine.isSameSession(internalRepresentation)) {
                    closeTab(tab)
                    break
                }
            }
        }

        override fun onScaleChanged(oldScale: Float, newScale: Float) {
            Log.d(TAG, "onScaleChanged: oldScale: $oldScale newScale: $newScale")
            tab.scale = newScale
        }

        override fun onCopyTextToClipboardRequested(url: String) {
            val clipBoard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clipData = ClipData.newPlainText("URL", url)
            clipBoard.setPrimaryClip(clipData)
            Toast.makeText(this@MainActivity, getString(R.string.copied_to_clipboard), Toast.LENGTH_SHORT).show()
        }

        override fun onShareUrlRequested(url: String) {
            val share = Intent(Intent.ACTION_SEND)
            share.type = "text/plain"
            share.putExtra(Intent.EXTRA_SUBJECT, R.string.share_url)
            share.putExtra(Intent.EXTRA_TEXT, url)
            try {
                startActivity(share)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, R.string.external_app_open_error, Toast.LENGTH_SHORT).show()
            }
        }

        override fun onOpenInExternalAppRequested(url: String) {
            val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            val activityComponent = intent.resolveActivity(this@MainActivity.packageManager)
            if (activityComponent != null && activityComponent.packageName == this@MainActivity.packageName) {
                Toast.makeText(this@MainActivity, R.string.external_app_open_error, Toast.LENGTH_SHORT).show()
                return
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, R.string.external_app_open_error, Toast.LENGTH_SHORT).show()
            }
        }

        override fun initiateVoiceSearch() {
            this@MainActivity.initiateVoiceSearch()
        }

        override fun onEditHomePageBookmarkSelected(index: Int) {
            lifecycleScope.launch {
                val bookmark = viewModel.homePageLinks.firstOrNull { it.order == index }
                var favoriteItem: FavoriteItem? = bookmark?.favoriteId?.let {
                    AppDatabase.db.favoritesDao().getById(it)
                }

                if (favoriteItem == null) {
                    favoriteItem = FavoriteItem()
                    favoriteItem.title = bookmark?.title
                    favoriteItem.url = bookmark?.url
                    favoriteItem.order = index
                    favoriteItem.homePageBookmark = true
                    onEditHomePageBookmark(favoriteItem)
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(R.string.bookmarks)
                        .setItems(arrayOf(getString(R.string.edit), getString(R.string.delete))) { _, which ->
                            when (which) {
                                0 -> onEditHomePageBookmark(favoriteItem)
                                1 -> viewModel.removeHomePageLink(bookmark!!)
                            }
                        }
                        .show()
                }
            }
        }

        override fun getHomePageLinks(): List<HomePageLink> {
            return viewModel.homePageLinks
        }

        override fun onPrepareForFullscreen() {
            touchMenuButton?.visibility = View.GONE
            toolbarShown = false
            applyToolbarLayout(false)
            vb.rlActionBar.visibility = View.GONE
            //window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            //        WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setLumenImmersive(true)
            isFullscreen = true
        }

        override fun onExitFullscreen() {
            touchMenuButton?.visibility = View.VISIBLE
            toolbarShown = true
            applyToolbarLayout(true)
            toolbarAutoHidden = false
            scrollDownSinceShown = 0
            //window.setFlags(0, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            if (!config.keepScreenOn) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            setLumenImmersive(false)
            isFullscreen = false
        }

        override fun onVisited(url: String) {
            val tab = tabsModel.currentTab.value ?: return

            if (!config.incognitoMode) {
                viewModel.logVisitedHistory(tab.title, url, tab.faviconHash)
            }
        }

        override fun onPageLongPress(engine: com.phlox.tvwebbrowser.webengine.WebEngine, result: String, x: Int, y: Int): Boolean =
            this@MainActivity.onPageLongPress(engine, result)

        override fun onContextMenu(
            cursorDrawer: CursorDrawerDelegate,
            baseUri: String?,
            linkUri: String?,
            srcUri: String?,
            title: String?,
            altText: String?,
            textContent: String?,
            x: Int,
            y: Int
        ) {
            uiHandler.post {
                vb.vCursorMenu.show(
                    tab,this, cursorDrawer,
                    baseUri, linkUri, srcUri,
                    title, altText, textContent,
                    x, y,
                    backNavigationEventsAdapter
                )
            }
        }

        override fun suggestActionsForLink(baseUri: String?, linkUri: String?, srcUri: String?,
                                           title: String?, altText: String?, textContent: String?,
                                           x: Int, y: Int) {
            var s = linkUri ?: srcUri
            if (s != null && s.startsWith("\"") && s.endsWith("\"")) {
                s = s.substring(1, s.length - 1)
            }
            val url = s
            val isHTTPUrl = url != null && (url.startsWith("http://") || url.startsWith("https://"))
            val anchor = View(this@MainActivity)
            val lp = FrameLayout.LayoutParams(1, 1)
            lp.setMargins(x, y, 0, 0)
            vb.flWebViewContainer.addView(anchor, lp)
            linkActionsMenu = PopupMenu(this@MainActivity, anchor, Gravity.BOTTOM).also {
                it.inflate(R.menu.menu_link)
                it.menu.findItem(R.id.miOpenInNewTab).isVisible = isHTTPUrl
                it.menu.findItem(R.id.miOpenInExternalApp).isVisible = isHTTPUrl
                it.menu.findItem(R.id.miDownload).isVisible = isHTTPUrl
                it.menu.findItem(R.id.miCopyToClipboard).isVisible = url != null
                it.menu.findItem(R.id.miShare).isVisible = url != null
                it.setOnMenuItemClickListener { menuItem ->
                    when (menuItem.itemId) {
                        R.id.miRefreshPage -> tab.webEngine.reload()
                        R.id.miOpenInNewTab -> onOpenInNewTabRequested(url!!, true)
                        R.id.miOpenInExternalApp -> onOpenInExternalAppRequested(url!!)
                        R.id.miDownload -> onDownloadRequested(url!!)
                        R.id.miCopyToClipboard -> onCopyTextToClipboardRequested(url!!)
                        R.id.miShare -> onShareUrlRequested(url!!)
                    }
                    true
                }

                it.setOnDismissListener {
                    vb.flWebViewContainer.removeView(anchor)
                    linkActionsMenu = null
                }
                it.show()
            }
        }

        override fun markBookmarkRecommendationAsUseful(bookmarkOrder: Int) {
            viewModel.markBookmarkRecommendationAsUseful(bookmarkOrder)
        }
    }

    private fun askUserAndOpenInExternalApp(url: String, intent: Intent) {
        if (openUrlInExternalAppDialog != null) {
            return
        }
        openUrlInExternalAppDialog = AlertDialog.Builder(this)
            .setTitle(R.string.site_asks_to_open_unknown_url)
            .setMessage(getString(R.string.site_asks_to_open_unknown_url_message) + "\n\n" + url)
            .setPositiveButton(R.string.yes) { _, _ ->
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this@MainActivity, R.string.external_app_open_error, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.no, null)
            .setOnDismissListener {
                openUrlInExternalAppDialog = null
            }
            .show()
    }

    private val downloadServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            val binder = service as? DownloadService.Binder
            if (binder == null) {
                Log.e(TAG, "Download service connection failed")
                //probably service still in another process due to incognito mode process switch
                //so we will try to reconnect in a few seconds
                uiHandler.postDelayed({
                    bindService(Intent(this@MainActivity, DownloadService::class.java),
                        this, Context.BIND_AUTO_CREATE)
                }, 1000)
                return
            }
            downloadService = binder.service
            if (pendingDownloads.isNotEmpty()) {
                val waiting = pendingDownloads.toList()
                pendingDownloads.clear()
                for (d in waiting) {
                    binder.service.startDownload(d)
                    onDownloadStarted(d.filename)
                }
            }
        }

        override fun onServiceDisconnected(p0: ComponentName?) {
            downloadService = null
        }
    }
}
