package com.phlox.tvwebbrowser.sofa

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.webkit.CookieManager
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.net.URL
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Lumen hands web videos to other player apps (Just Player, MX, VLC, ...) through this small proxy
 * on the TV itself (http://127.0.0.1:port/...). Video servers often refuse players with HTTP 403:
 * they want the page's Referer/Origin, its cookies, the browser's name and a Chrome-like
 * connection. The player asks the proxy, and Lumen fetches every playlist and video piece the way
 * the browser did. HLS playlists are rewritten so their segments, keys and subtitles also go
 * through the proxy.
 */
object LumenStreamProxy {
    private const val TAG = "LumenStreamProxy"

    private class Session(val headers: Map<String, String>, val userAgent: String?) {
        @Volatile var lastUse = System.currentTimeMillis()
    }

    private val sessions = ConcurrentHashMap<String, Session>()
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var server: ServerSocket? = null
    @Volatile var lastActivity = 0L
        private set

    /** Network stack like Chrome's when available (see [SofaPlayerActivity]); else Android's basic one. */
    @Volatile private var opener: ((URL) -> java.net.URLConnection)? = null
    @Volatile private var openerName = "basic"

    @SuppressLint("NewApi", "WrongConstant")
    private fun initOpener(context: Context) {
        if (opener != null) return
        //1. Android's own copy of Chrome's network stack (Android 14+, updated 12/13)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                android.os.ext.SdkExtensions.getExtensionVersion(Build.VERSION_CODES.S) >= 7) {
                val engine = android.net.http.HttpEngine.Builder(context)
                    .setEnableHttp2(true).setEnableQuic(true).setEnableBrotli(true).build()
                opener = { url -> engine.openConnection(url) }
                openerName = "Android HttpEngine"
                return
            }
        } catch (e: Throwable) {
        }
        //2. Chrome's network stack from Google Play services
        try {
            val provider = org.chromium.net.CronetProvider.getAllProviders(context).firstOrNull {
                it.isEnabled && it.name.contains("Play-Services", ignoreCase = true)
            }
            if (provider != null) {
                val engine = provider.createBuilder().enableHttp2(true).enableQuic(true).enableBrotli(true).build()
                opener = { url -> engine.openConnection(url) }
                openerName = "Play services Cronet"
                return
            }
        } catch (e: Throwable) {
        }
        opener = { url -> url.openConnection() }
        openerName = "basic"
    }

    @Synchronized
    private fun ensureServer(): Int {
        server?.let { if (!it.isClosed) return it.localPort }
        val s = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
        server = s
        Thread({
            while (!s.isClosed) {
                try {
                    val client = s.accept()
                    pool.execute { handle(client) }
                } catch (e: Exception) {
                    if (!s.isClosed) Log.e(TAG, "accept", e)
                }
            }
        }, "lumen-stream-proxy").apply { isDaemon = true }.start()
        return s.localPort
    }

    /**
     * Returns an address on this TV that plays [url] for any player app, sending [headers]
     * (Referer, Origin, ...) and the browser's [userAgent] and cookies upstream.
     */
    fun wrap(context: Context, url: String, headers: Map<String, String>, userAgent: String?): String {
        initOpener(context.applicationContext)
        val port = ensureServer()
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        sessions[token] = Session(HashMap(headers), userAgent)
        //forget sessions nobody used for a day
        val old = System.currentTimeMillis() - 24 * 3600_000L
        sessions.entries.removeAll { it.value.lastUse < old }
        lastActivity = System.currentTimeMillis()
        LumenProxyService.start(context)
        return proxied(port, token, url)
    }

    private fun b64(s: String) = Base64.encodeToString(s.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    private fun unb64(s: String) = String(Base64.decode(s, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING))

    /**
     * http://127.0.0.1:port/s/<token>/<base64(folder)>/<file?query> - the file name stays readable
     * (players look at ".m3u8" / ".mp4"), and relative addresses inside playlists still work.
     */
    private fun proxied(port: Int, token: String, url: String): String {
        val q = url.indexOf('?').let { if (it < 0) url.length else it }
        val slash = url.lastIndexOf('/', q - 1)
        val dir = if (slash > url.indexOf("://") + 2) url.substring(0, slash + 1) else "$url/"
        var rest = if (slash > url.indexOf("://") + 2) url.substring(slash + 1) else ""
        if (rest.isEmpty() || rest.startsWith("?")) rest = "index$rest"
        return "http://127.0.0.1:$port/s/$token/${b64(dir)}/$rest"
    }

    private fun readHead(input: InputStream): List<String>? {
        val buf = StringBuilder()
        var last4 = 0
        while (true) {
            val b = input.read()
            if (b < 0) return null
            buf.append(b.toChar())
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) break
            if (buf.length > 32768) return null
        }
        return buf.toString().split("\r\n").filter { it.isNotEmpty() }
    }

    private fun handle(client: Socket) {
        client.use { sock ->
            try {
                sock.soTimeout = 60_000
                val input = BufferedInputStream(sock.getInputStream())
                val out = sock.getOutputStream()
                val head = readHead(input) ?: return
                val parts = head[0].split(" ")
                if (parts.size < 2) return
                val method = parts[0].uppercase(Locale.ROOT)
                val path = parts[1]
                val reqHeaders = HashMap<String, String>()
                for (h in head.drop(1)) {
                    val i = h.indexOf(':')
                    if (i > 0) reqHeaders[h.substring(0, i).trim().lowercase(Locale.ROOT)] = h.substring(i + 1).trim()
                }
                val m = Regex("^/s/([A-Za-z0-9]+)/([A-Za-z0-9_-]+)/(.*)$").find(path)
                if (m == null || (method != "GET" && method != "HEAD")) {
                    simple(out, 404, "Not found")
                    return
                }
                val token = m.groupValues[1]
                val session = sessions[token] ?: run { simple(out, 410, "Expired"); return }
                session.lastUse = System.currentTimeMillis()
                lastActivity = session.lastUse
                val upstream = unb64(m.groupValues[2]) + m.groupValues[3]
                forward(out, method, upstream, reqHeaders, session, token, sock.localPort)
            } catch (e: Exception) {
                Log.w(TAG, "request failed: $e")
            }
        }
    }

    private fun simple(out: OutputStream, code: Int, text: String) {
        val body = text.toByteArray()
        out.write("HTTP/1.1 $code $text\r\nContent-Type: text/plain\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(body)
        out.flush()
    }

    private fun isPlaylist(url: String, contentType: String?): Boolean {
        val ct = contentType?.lowercase(Locale.ROOT) ?: ""
        if (ct.contains("mpegurl")) return true
        val path = url.substringBefore('?').lowercase(Locale.ROOT)
        return path.endsWith(".m3u8") || path.endsWith(".m3u")
    }

    private fun forward(out: OutputStream, method: String, upstream: String, req: Map<String, String>,
                        session: Session, token: String, port: Int) {
        val conn = opener!!(URL(upstream)) as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        for ((k, v) in session.headers) {
            if (k.equals("Cookie", true) || k.equals("Range", true) || k.equals("Host", true)) continue
            conn.setRequestProperty(k, v)
        }
        session.userAgent?.let { conn.setRequestProperty("User-Agent", it) }
        if (session.headers.keys.none { it.equals("Accept", true) }) conn.setRequestProperty("Accept", "*/*")
        try {
            CookieManager.getInstance().getCookie(upstream)?.takeIf { it.isNotBlank() }?.let {
                conn.setRequestProperty("Cookie", it)
            }
        } catch (ignored: Exception) {
        }
        req["range"]?.let { conn.setRequestProperty("Range", it) }

        val code = try { conn.responseCode } catch (e: Exception) {
            simple(out, 502, "Upstream failed: ${e.message}")
            return
        }
        val type = conn.contentType
        val stream = (if (code >= 400) conn.errorStream else conn.inputStream)
        if (code in 200..299 && isPlaylist(upstream, type)) {
            //playlists: every address inside goes through the proxy too
            val finalUrl = conn.url?.toString() ?: upstream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            val body = rewritePlaylist(text, finalUrl, port, token).toByteArray()
            out.write(("HTTP/1.1 200 OK\r\nContent-Type: application/vnd.apple.mpegurl\r\n" +
                    "Content-Length: ${body.size}\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
            if (method != "HEAD") out.write(body)
            out.flush()
            conn.disconnect()
            return
        }
        val sb = StringBuilder("HTTP/1.1 $code ${conn.responseMessage ?: ""}\r\n")
        type?.let { sb.append("Content-Type: ").append(it).append("\r\n") }
        conn.getHeaderField("Content-Length")?.let { sb.append("Content-Length: ").append(it).append("\r\n") }
        conn.getHeaderField("Content-Range")?.let { sb.append("Content-Range: ").append(it).append("\r\n") }
        sb.append("Accept-Ranges: ").append(conn.getHeaderField("Accept-Ranges") ?: "bytes").append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray())
        if (method != "HEAD" && stream != null) {
            stream.use { input ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    lastActivity = System.currentTimeMillis()
                }
            }
        }
        out.flush()
        conn.disconnect()
    }

    private fun rewritePlaylist(text: String, base: String, port: Int, token: String): String {
        val baseUri = URI(base)
        fun abs(u: String): String = try { baseUri.resolve(u.trim()).toString() } catch (e: Exception) { u }
        val uriAttr = Regex("URI=\"([^\"]+)\"")
        return text.lines().joinToString("\n") { line ->
            val t = line.trim()
            when {
                t.isEmpty() -> line
                t.startsWith("#") -> uriAttr.replace(line) { mr ->
                    val u = mr.groupValues[1]
                    if (u.startsWith("data:") || u.startsWith("skd:")) mr.value
                    else "URI=\"" + proxied(port, token, abs(u)) + "\""
                }
                else -> proxied(port, token, abs(t))
            }
        }
    }

    fun networkName(): String = openerName
}

/**
 * Keeps Lumen (and so the proxy) running while another app plays a video through it; Android
 * would otherwise close Lumen in the background on TVs with little memory. Stops itself after
 * 20 minutes without any request.
 */
class LumenProxyService : Service() {
    companion object {
        private const val CHANNEL = "lumen_proxy"
        private const val IDLE_MS = 20 * 60_000L

        fun start(context: Context) {
            val i = Intent(context, LumenProxyService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i) else context.startService(i)
            } catch (e: Exception) {
                //not allowed right now (e.g. app in background): the proxy still works while Lumen lives
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val idleCheck = object : Runnable {
        override fun run() {
            if (System.currentTimeMillis() - LumenStreamProxy.lastActivity > IDLE_MS) {
                stopSelf()
                return
            }
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Video to player", NotificationManager.IMPORTANCE_MIN))
        }
        val n: Notification = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL)
            else @Suppress("DEPRECATION") Notification.Builder(this))
            .setContentTitle("Lumen is passing a video to your player")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(4242, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(4242, n)
            }
        } catch (e: Exception) {
            Log.w("LumenProxyService", "foreground: $e")
        }
        handler.removeCallbacks(idleCheck)
        handler.postDelayed(idleCheck, 60_000)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(idleCheck)
        super.onDestroy()
    }
}
