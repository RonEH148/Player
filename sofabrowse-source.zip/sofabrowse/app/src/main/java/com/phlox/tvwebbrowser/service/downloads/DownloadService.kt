package com.phlox.tvwebbrowser.service.downloads

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.*
import android.provider.Settings
import android.text.format.Formatter
import android.util.Log
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.TVBro
import com.phlox.tvwebbrowser.activity.downloads.ActiveDownloadsModel
import com.phlox.tvwebbrowser.model.Download
import com.phlox.tvwebbrowser.singleton.AppDatabase
import com.phlox.tvwebbrowser.utils.activemodel.ActiveModelsRepository
import java.io.File
import java.util.*
import java.util.concurrent.Executors

/**
 * Created by PDT on 23.01.2017.
 */

class DownloadService : Service() {
    private lateinit var model: ActiveDownloadsModel
    private val executor = Executors.newCachedThreadPool()
    private val handler = Handler(Looper.getMainLooper())
    private var notificationBuilder: NotificationCompat.Builder? = null
    private lateinit var notificationManager: NotificationManager

    internal var downloadTasksListener: DownloadTask.Callback = object : DownloadTask.Callback {
        val MIN_NOTIFY_TIMEOUT = 100
        private var lastNotifyTime = System.currentTimeMillis()
        override fun onProgress(task: DownloadTask) {
            val now = System.currentTimeMillis()
            if (now - lastNotifyTime > MIN_NOTIFY_TIMEOUT) {
                lastNotifyTime = now
                handler.post {
                    model.notifyListenersAboutDownloadProgress(task)
                    notificationManager.notify(DOWNLOAD_NOTIFICATION_ID, updateNotification())
                }
            }
        }

        override fun onError(task: DownloadTask, responseCode: Int, responseMessage: String) {
            AppDatabase.db.downloadDao().update(task.downloadInfo)
            handler.post {
                model.notifyListenersAboutError(task, responseCode, responseMessage)
                onTaskEnded(task)
                //shown again once it is no longer running ("Interrupted – press OK to resume")
                model.notifyListenersAboutDownloadProgress(task)
            }
        }

        override fun onDone(task: DownloadTask) {
            AppDatabase.db.downloadDao().update(task.downloadInfo)
            handler.post {
                onTaskEnded(task)
                model.notifyListenersAboutDownloadProgress(task)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        model = ActiveModelsRepository.get(ActiveDownloadsModel::class, this)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    override fun onDestroy() {
        ActiveModelsRepository.markAsNeedless(model, this)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun updateNotification(): Notification {
        var title = ""
        var downloaded = 0L
        var total = 0L
        var hasUnknownSizedFiles = false
        for (download in model.activeDownloads) {
            title += download.downloadInfo.filename + ","
            downloaded += download.downloadInfo.bytesReceived
            if (download.downloadInfo.size > 0) {
                total += download.downloadInfo.size
            } else {
                hasUnknownSizedFiles = true
            }
        }
        title.trim(',')
        val description = if (hasUnknownSizedFiles) {
            Formatter.formatShortFileSize(this, downloaded)
        } else {
            Formatter.formatShortFileSize(this, downloaded) + " of " +
                    Formatter.formatShortFileSize(this, total)
        }
        if (notificationBuilder == null) {
            notificationBuilder = NotificationCompat.Builder(this, TVBro.CHANNEL_ID_DOWNLOADS)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setSmallIcon(R.drawable.ic_launcher)
        }
        notificationBuilder!!.setContentTitle(title)
                .setContentText(description)
                .setSmallIcon(R.drawable.ic_launcher)
        if (hasUnknownSizedFiles || total == 0L) {
            notificationBuilder!!.setProgress(0, 0, true)
        } else {
            notificationBuilder!!.setProgress(100, (downloaded * 100 / total).toInt(), false)
        }
        return notificationBuilder!!.build()
    }

    override fun onBind(intent: Intent): IBinder {
        return Binder(this)
    }

    private fun onTaskEnded(task: DownloadTask) {
        val finished = !task.downloadInfo.paused && task.downloadInfo.size > 0 &&
                task.downloadInfo.bytesReceived == task.downloadInfo.size
        if (finished) when (task.downloadInfo.operationAfterDownload) {
            Download.OperationAfterDownload.INSTALL -> {
                val canInstallFromOtherSources = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    packageManager.canRequestPackageInstalls()
                } else {
                    Settings.Secure.getInt(this.contentResolver, Settings.Secure.INSTALL_NON_MARKET_APPS) == 1
                }
                if (canInstallFromOtherSources) {
                    launchInstallAPKActivity(this, task.downloadInfo)
                }
            }
            Download.OperationAfterDownload.NOP -> {
            }
        }
        model.onDownloadEnded(task)
        if (model.activeDownloads.isEmpty()) {
            stopForeground(true)
            stopSelf()
        }
    }

    fun launchInstallAPKActivity(context: Context, download: Download) {
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk")
        val apkURI = if (com.phlox.tvwebbrowser.sofa.LumenDownloads.isContentPath(download.filepath)) {
            android.net.Uri.parse(download.filepath)
        } else {
            FileProvider.getUriForFile(
                context,
                context.applicationContext.packageName + ".provider", File(download.filepath))
        }

        val install = Intent(Intent.ACTION_INSTALL_PACKAGE)
        install.setDataAndType(apkURI, mimeType)
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(install)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.error, Toast.LENGTH_SHORT).show()
        }
    }

    fun startDownload(download: Download) {
        if (com.phlox.tvwebbrowser.sofa.LumenDownloads.customFolderMissing()) {
            //e.g. the USB drive is unplugged: save to internal storage instead of failing
            Toast.makeText(this, R.string.lumen_folder_missing, Toast.LENGTH_LONG).show()
        }
        //a folder picked in settings is handled by LumenDownloads.openOutput()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && com.phlox.tvwebbrowser.sofa.LumenDownloads.customFolder() == null) {
            val extPos = download.filename.lastIndexOf(".")
            val hasExt = extPos != -1
            var ext: String? = null
            var prefix: String? = null
            if (hasExt) {
                ext = download.filename.substring(extPos + 1)
                prefix = download.filename.substring(0, extPos)
            }
            var fileName = download.filename
            var i = 0
            while (File(com.phlox.tvwebbrowser.sofa.LumenDownloads.defaultFolderFile(), fileName).exists()) {
                i++
                if (hasExt) {
                    fileName = prefix + "_(" + i + ")." + ext
                } else {
                    fileName = download.filename + "_(" + i + ")"
                }
            }
            download.filename = fileName

            if (Environment.MEDIA_MOUNTED != Environment.getExternalStorageState()) {
                Toast.makeText(this, R.string.storage_not_mounted, Toast.LENGTH_SHORT).show()
                return
            }
            val downloadsDir = com.phlox.tvwebbrowser.sofa.LumenDownloads.defaultFolderFile()
            if (!downloadsDir.exists() && !downloadsDir.mkdirs()) {
                Toast.makeText(this, R.string.can_not_create_downloads, Toast.LENGTH_SHORT)
                    .show()
                return
            }
            download.filepath = downloadsDir.toString() + File.separator + fileName
        }

        download.time = Date().time
        Log.d(TAG, "Start to downloading url: ${download.url}")
        val downloadTask = if (download.base64BlobData != null) {
            BlobDownloadTask(download, download.base64BlobData!!, downloadTasksListener)
        } else if (download.stream != null) {
            StreamDownloadTask(download, download.stream!!, downloadTasksListener)
        } else {
            FileDownloadTask(download, download.userAgentString, downloadTasksListener)
        }
        model.activeDownloads.add(downloadTask)
        executor.execute(downloadTask)

        startService(Intent(this, DownloadService::class.java))
        startForeground(DOWNLOAD_NOTIFICATION_ID, updateNotification())
    }

    /** Lumen: continues a paused or interrupted download from where it stopped. */
    fun resumeDownload(download: Download): Boolean {
        val state = com.phlox.tvwebbrowser.sofa.LumenDownloadState.get(download.id) ?: return false
        if (model.activeDownloads.any { it.downloadInfo.id == download.id }) return true
        download.paused = false
        download.cancelled = false
        download.url = state.url
        val task = FileDownloadTask(download, state.userAgent, downloadTasksListener, state)
        model.activeDownloads.add(task)
        executor.execute(task)
        startService(Intent(this, DownloadService::class.java))
        startForeground(DOWNLOAD_NOTIFICATION_ID, updateNotification())
        return true
    }

    class Binder(val service: DownloadService) : android.os.Binder()

    companion object {
        val TAG: String = DownloadService::class.java.simpleName
        const val DOWNLOAD_NOTIFICATION_ID = 101101
    }
}
