package com.phlox.tvwebbrowser.activity.main

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R

/**
 * Wisp (phone build): the ⋮ menu, the tab list and site info. Built in code so the TV build
 * carries no extra layouts.
 */
object WispSheets {

    /** A button in the menu. [active]: a switch that is on (shown in the accent colour). */
    class Action(
        val icon: Int,
        val label: String,
        val active: Boolean = false,
        val enabled: Boolean = true,
        val badge: String? = null,
        val onClick: () -> Unit
    )


    private class Palette(a: Activity) {
        val sheet = ContextCompat.getColor(a, R.color.wisp_sheet)
        val text = ContextCompat.getColor(a, R.color.wisp_text)
        val secondary = ContextCompat.getColor(a, R.color.wisp_text_secondary)
        val icon = ContextCompat.getColor(a, R.color.wisp_icon)
        val accent = ContextCompat.getColor(a, R.color.wisp_accent)
        val accentSoft = ContextCompat.getColor(a, R.color.wisp_accent_soft)
        val pill = ContextCompat.getColor(a, R.color.wisp_pill)
        val divider = ContextCompat.getColor(a, R.color.wisp_divider)
        val card = ContextCompat.getColor(a, R.color.wisp_card)
        val onAccent = ContextCompat.getColor(a, R.color.wisp_on_accent)
    }

    private fun dp(a: Activity, v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, a.resources.displayMetrics).toInt()

    private fun rounded(color: Int, radius: Float, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            if (topOnly) cornerRadii = floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f)
            else cornerRadius = radius
        }

    private fun ripple(a: Activity): android.graphics.drawable.Drawable? {
        val tv = TypedValue()
        a.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return if (tv.resourceId != 0) ContextCompat.getDrawable(a, tv.resourceId) else null
    }

    /** A dialog that slides up from the bottom of the screen, full width, with rounded top corners. */
    private fun sheet(a: Activity, content: View): Dialog {
        val p = Palette(a)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.background = rounded(p.sheet, dp(a, 22f).toFloat(), topOnly = true)
        root.setPadding(0, dp(a, 10f), 0, dp(a, 14f))
        val handle = View(a)
        handle.background = rounded(p.divider, dp(a, 2f).toFloat())
        val hlp = LinearLayout.LayoutParams(dp(a, 36f), dp(a, 4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.bottomMargin = dp(a, 10f)
        root.addView(handle, hlp)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(root)
        d.setCanceledOnTouchOutside(true)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.setDimAmount(0.35f)
            w.attributes = w.attributes.also { it.windowAnimations = android.R.style.Animation_InputMethod }
        }
        return d
    }

    private fun tinted(a: Activity, res: Int, color: Int): ImageView {
        val iv = ImageView(a)
        iv.setImageResource(res)
        iv.setColorFilter(color)
        iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
        return iv
    }

    /** A full-width row: icon, title (and a second line), and on the right a switch, a badge or nothing. */
    class Row(
        val icon: Int,
        val title: String,
        val subtitle: String? = null,
        /** non-null: the row is a switch in this state; tapping it calls [onClick] with the new state */
        val switchOn: Boolean? = null,
        val badge: String? = null,
        val enabled: Boolean = true,
        val danger: Boolean = false,
        val onClick: (Boolean) -> Unit
    )

    private fun rowView(a: Activity, p: Palette, r: Row, dismiss: () -> Unit): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(a, 50f)
        row.setPadding(dp(a, 18f), dp(a, 6f), dp(a, 16f), dp(a, 6f))
        row.background = ripple(a)
        row.isEnabled = r.enabled
        row.alpha = if (r.enabled) 1f else 0.38f
        val color = if (r.danger) DANGER else p.icon
        row.addView(tinted(a, r.icon, color), LinearLayout.LayoutParams(dp(a, 22f), dp(a, 22f)))
        val texts = LinearLayout(a)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(a, 18f), 0, dp(a, 10f), 0)
        val t = TextView(a)
        t.text = r.title
        t.textSize = 15f
        t.setTextColor(if (r.danger) color else p.text)
        texts.addView(t)
        if (!r.subtitle.isNullOrEmpty()) {
            val st = TextView(a)
            st.text = r.subtitle
            st.textSize = 12.5f
            st.setTextColor(p.secondary)
            texts.addView(st)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        var sw: android.widget.Switch? = null
        if (r.switchOn != null) {
            val s = android.widget.Switch(a)
            s.isChecked = r.switchOn
            s.isClickable = false
            s.isFocusable = false
            tintSwitch(s, p)
            row.addView(s)
            sw = s
        } else if (!r.badge.isNullOrEmpty()) {
            val b = TextView(a)
            b.text = r.badge
            b.textSize = 11f
            b.setTypeface(b.typeface, Typeface.BOLD)
            b.setTextColor(p.accent)
            b.background = rounded(p.accentSoft, dp(a, 10f).toFloat())
            b.setPadding(dp(a, 8f), dp(a, 2f), dp(a, 8f), dp(a, 2f))
            row.addView(b)
        }
        val theSwitch = sw
        row.setOnClickListener {
            if (theSwitch != null) {
                theSwitch.isChecked = !theSwitch.isChecked
                r.onClick(theSwitch.isChecked)
            } else {
                dismiss()
                r.onClick(true)
            }
        }
        return row
    }

    private const val DANGER = 0xFFD84343.toInt()

    /** Accent-coloured switch (the platform one has the system's colours otherwise). */
    fun tintSwitch(sw: android.widget.Switch, a: Activity) = tintSwitch(sw, Palette(a))

    private fun tintSwitch(sw: android.widget.Switch, p: Palette) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(p.accent, 0xFFF2F1F6.toInt()))
        sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(p.accentSoft, p.divider))
    }

    /**
     * Site info, like Chrome's page info: the site's name, whether the connection is secure, its
     * settings as switches and buttons to delete its data.
     */
    fun showSiteInfo(a: Activity, site: String, secure: Boolean, rows: List<Row>): Dialog {
        val p = Palette(a)
        lateinit var dialog: Dialog
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(a)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(a, 22f), 0, dp(a, 22f), dp(a, 10f))
        val t = TextView(a)
        t.text = site
        t.textSize = 19f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(p.text)
        t.isSingleLine = true
        t.ellipsize = TextUtils.TruncateAt.MIDDLE
        head.addView(t)
        val sec = TextView(a)
        sec.text = a.getString(if (secure) R.string.wisp_site_secure else R.string.wisp_site_not_secure)
        sec.textSize = 13f
        sec.setTextColor(if (secure) p.secondary else DANGER)
        sec.setPadding(0, dp(a, 2f), 0, 0)
        head.addView(sec)
        box.addView(head)
        for (r in rows) box.addView(rowView(a, p, r) { dialog.dismiss() })
        dialog = sheet(a, box)
        dialog.show()
        return dialog
    }

    // ---------------- the ⋮ menu (Fennec style) ----------------

    /** A row in the menu's grouped list. [toggle]: shows an On/Off pill in this state. */
    class MenuItem(
        val icon: Int,
        val title: String,
        val subtitle: String? = null,
        val toggle: Boolean? = null,
        val badge: String? = null,
        val enabled: Boolean = true,
        val danger: Boolean = false,
        val onClick: () -> Unit
    )

    private fun groupBg(p: Palette, a: Activity, first: Boolean, last: Boolean, color: Int = p.card): GradientDrawable {
        val big = dp(a, 22f).toFloat()
        val small = dp(a, 5f).toFloat()
        val t = if (first) big else small
        val b = if (last) big else small
        return GradientDrawable().apply {
            setColor(color)
            cornerRadii = floatArrayOf(t, t, t, t, b, b, b, b)
        }
    }

    private fun pill(a: Activity, p: Palette, text: String, on: Boolean): TextView {
        val v = TextView(a)
        v.text = text
        v.textSize = 13f
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.setTextColor(if (on) p.onAccent else p.secondary)
        v.background = rounded(if (on) p.accent else p.pill, dp(a, 16f).toFloat())
        v.setPadding(dp(a, 14f), dp(a, 6f), dp(a, 14f), dp(a, 6f))
        return v
    }

    private fun menuRow(a: Activity, p: Palette, item: MenuItem, first: Boolean, last: Boolean, dismiss: () -> Unit,
                        extra: View? = null): LinearLayout {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(a, 54f)
        row.setPadding(dp(a, 18f), dp(a, 8f), dp(a, 14f), dp(a, 8f))
        row.background = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x33888888), groupBg(p, a, first, last), null)
        row.isEnabled = item.enabled
        row.alpha = if (item.enabled) 1f else 0.4f
        val iconColor = if (item.danger) DANGER else p.icon
        val icon = tinted(a, item.icon, iconColor)
        row.addView(icon, LinearLayout.LayoutParams(dp(a, 24f), dp(a, 24f)))
        val texts = LinearLayout(a)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(a, 18f), 0, dp(a, 8f), 0)
        val t = TextView(a)
        t.text = item.title
        t.textSize = 16f
        t.setTextColor(if (item.danger) DANGER else p.text)
        texts.addView(t)
        if (!item.subtitle.isNullOrEmpty()) {
            val s = TextView(a)
            s.text = item.subtitle
            s.textSize = 13f
            s.setTextColor(p.secondary)
            s.isSingleLine = true
            s.ellipsize = TextUtils.TruncateAt.END
            texts.addView(s)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (item.toggle != null) {
            row.addView(pill(a, p, a.getString(if (item.toggle) R.string.wisp_on else R.string.wisp_off), item.toggle))
        } else if (!item.badge.isNullOrEmpty()) {
            row.addView(pill(a, p, item.badge, true))
        }
        if (extra != null) row.addView(extra)
        row.setOnClickListener { dismiss(); item.onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(a, 12f), 0, dp(a, 12f), dp(a, 3f))
        row.layoutParams = lp
        return row
    }

    /**
     * The ⋮ menu as a bottom sheet like Fennec's: back / forward / share / reload with labels,
     * a group of page actions with a "More" part that opens in place, four tiles (history,
     * bookmarks, downloads, passwords), settings and quit.
     */
    fun showMenu(a: Activity, title: String?, top: List<Action>, main: List<MenuItem>, more: List<MenuItem>,
                 tiles: List<Action>, settings: MenuItem, quit: MenuItem): Dialog {
        val p = Palette(a)
        lateinit var dialog: Dialog
        val dismiss = { dialog.dismiss() }
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL

        if (!title.isNullOrBlank()) {
            val t = TextView(a)
            t.text = title
            t.setTextColor(p.secondary)
            t.textSize = 12.5f
            t.gravity = Gravity.CENTER_HORIZONTAL
            t.isSingleLine = true
            t.ellipsize = TextUtils.TruncateAt.MIDDLE
            t.setPadding(dp(a, 22f), 0, dp(a, 22f), dp(a, 6f))
            box.addView(t)
        }
        //back / forward / share / reload, icon above label
        val bar = LinearLayout(a)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(a, 8f), 0, dp(a, 8f), dp(a, 8f))
        for (act in top) {
            val cell = LinearLayout(a)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(0, dp(a, 8f), 0, dp(a, 8f))
            cell.background = ripple(a)
            cell.isEnabled = act.enabled
            cell.alpha = if (act.enabled) 1f else 0.35f
            cell.contentDescription = act.label
            cell.addView(tinted(a, act.icon, p.icon), LinearLayout.LayoutParams(dp(a, 26f), dp(a, 26f)))
            val l = TextView(a)
            l.text = act.label
            l.textSize = 12.5f
            l.setTextColor(p.text)
            l.setPadding(0, dp(a, 4f), 0, 0)
            cell.addView(l)
            cell.setOnClickListener { dismiss(); act.onClick() }
            bar.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        box.addView(bar)

        //page actions, then "More" (opens in place)
        val group = LinearLayout(a)
        group.orientation = LinearLayout.VERTICAL
        main.forEachIndexed { i, item -> group.addView(menuRow(a, p, item, i == 0, false, dismiss)) }
        val moreRows = more.mapIndexed { i, item -> menuRow(a, p, item, false, i == more.size - 1, dismiss) }
        val chevron = tinted(a, R.drawable.ic_wisp_down, p.icon)
        chevron.background = rounded(p.pill, dp(a, 14f).toFloat())
        chevron.setPadding(dp(a, 3f), dp(a, 3f), dp(a, 3f), dp(a, 3f))
        val moreRow = menuRow(a, p, MenuItem(R.drawable.ic_wisp_more, a.getString(R.string.wisp_more)) {}, main.isEmpty(), true, {},
            extra = chevron)
        (chevron.layoutParams as? LinearLayout.LayoutParams)?.let { it.width = dp(a, 28f); it.height = dp(a, 28f); chevron.layoutParams = it }
        moreRow.setOnClickListener {
            //"More" stays in the list; its items appear under it and it loses its rounded bottom
            moreRow.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x33888888), groupBg(p, a, main.isEmpty(), false), null)
            moreRow.isClickable = false
            chevron.animate().rotation(180f).setDuration(150).start()
            val at = group.indexOfChild(moreRow) + 1
            moreRows.forEachIndexed { i, r -> group.addView(r, at + i) }
        }
        group.addView(moreRow)
        box.addView(group)

        //history / bookmarks / downloads / passwords
        val tileRow = LinearLayout(a)
        tileRow.orientation = LinearLayout.HORIZONTAL
        tileRow.setPadding(dp(a, 12f), dp(a, 10f), dp(a, 12f), dp(a, 10f))
        tiles.forEachIndexed { i, act ->
            val tile = LinearLayout(a)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER
            tile.setPadding(0, dp(a, 12f), 0, dp(a, 12f))
            val big = dp(a, 22f).toFloat()
            val small = dp(a, 5f).toFloat()
            val l = if (i == 0) big else small
            val r = if (i == tiles.size - 1) big else small
            tile.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x33888888),
                GradientDrawable().apply { setColor(p.card); cornerRadii = floatArrayOf(l, l, r, r, r, r, l, l) }, null)
            tile.addView(tinted(a, act.icon, p.icon), LinearLayout.LayoutParams(dp(a, 26f), dp(a, 26f)))
            val tl = TextView(a)
            tl.text = act.label
            tl.textSize = 12.5f
            tl.setTextColor(p.text)
            tl.isSingleLine = true
            tl.setPadding(dp(a, 4f), dp(a, 6f), dp(a, 4f), 0)
            tile.addView(tl)
            tile.setOnClickListener { dismiss(); act.onClick() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.marginStart = dp(a, 3f)
            tileRow.addView(tile, lp)
        }
        box.addView(tileRow)

        box.addView(menuRow(a, p, settings, true, true, dismiss).also {
            (it.layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(a, 10f)
        })
        box.addView(menuRow(a, p, quit, true, true, dismiss))

        val maxH = (a.resources.displayMetrics.heightPixels * 0.85f).toInt()
        val scroll = object : ScrollView(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
            }
        }
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(box)
        dialog = sheet(a, scroll)
        dialog.show()
        return dialog
    }

    // ---------------- tab grid ----------------

    class TabCard(val title: String, val address: String, val current: Boolean, val thumbnail: Bitmap?, val home: Boolean)

    /**
     * Tabs as a two-column grid of cards (page preview, site icon, title, ✕), like Fennec's tab
     * tray: bigger targets than a list, so the wrong tab isn't closed by accident.
     * Returns the dialog and a setter that fills in a tab's site icon (index, bitmap) once loaded.
     */
    fun showTabs(
        a: Activity,
        privateMode: Boolean,
        tabs: List<TabCard>,
        onPick: (Int) -> Unit,
        onClose: (Int) -> Unit,
        onNew: () -> Unit,
        onCloseAll: () -> Unit
    ): Pair<Dialog, (Int, Bitmap?) -> Unit> {
        val p = Palette(a)
        lateinit var dialog: Dialog
        val root = FrameLayout(a)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(a)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(a, 20f), 0, dp(a, 8f), dp(a, 8f))
        val title = TextView(a)
        title.text = a.getString(if (privateMode) R.string.wisp_tabs_private_title else R.string.wisp_tabs_title, tabs.size)
        title.textSize = 19f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(p.text)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (tabs.size > 1) {
            val closeAll = TextView(a)
            closeAll.text = a.getString(R.string.wisp_close_all_tabs)
            closeAll.textSize = 14f
            closeAll.setTextColor(p.accent)
            closeAll.background = ripple(a)
            closeAll.setPadding(dp(a, 12f), dp(a, 8f), dp(a, 12f), dp(a, 8f))
            closeAll.setOnClickListener { dialog.dismiss(); onCloseAll() }
            header.addView(closeAll)
        }
        box.addView(header)

        val grid = LinearLayout(a)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(dp(a, 10f), 0, dp(a, 10f), dp(a, 84f))
        val icons = ArrayList<ImageView>()
        var currentCard: View? = null
        var row: LinearLayout? = null
        val thumbH = dp(a, 168f)
        tabs.forEachIndexed { i, t ->
            if (i % 2 == 0) {
                row = LinearLayout(a).also {
                    it.orientation = LinearLayout.HORIZONTAL
                    grid.addView(it)
                }
            }
            val card = LinearLayout(a)
            card.orientation = LinearLayout.VERTICAL
            card.background = GradientDrawable().apply {
                setColor(p.card)
                cornerRadius = dp(a, 16f).toFloat()
                if (t.current) setStroke(dp(a, 2.5f), p.accent)
            }
            card.clipToOutline = true
            card.setPadding(dp(a, 3f), dp(a, 3f), dp(a, 3f), dp(a, 3f))
            card.setOnClickListener { dialog.dismiss(); onPick(i) }

            val head = LinearLayout(a)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            head.setPadding(dp(a, 9f), dp(a, 2f), 0, dp(a, 2f))
            val icon = tinted(a, R.drawable.ic_wisp_globe, p.secondary)
            icons.add(icon)
            head.addView(icon, LinearLayout.LayoutParams(dp(a, 16f), dp(a, 16f)))
            val tt = TextView(a)
            tt.text = t.title
            tt.textSize = 13f
            tt.setTextColor(if (t.current) p.accent else p.text)
            tt.isSingleLine = true
            tt.ellipsize = TextUtils.TruncateAt.END
            tt.setPadding(dp(a, 8f), 0, dp(a, 4f), 0)
            head.addView(tt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val close = tinted(a, R.drawable.ic_close_grey_900_24dp, p.icon)
            close.contentDescription = a.getString(R.string.wisp_close_tab)
            close.background = ripple(a)
            close.setPadding(dp(a, 9f), dp(a, 9f), dp(a, 9f), dp(a, 9f))
            close.setOnClickListener { dialog.dismiss(); onClose(i) }
            head.addView(close, LinearLayout.LayoutParams(dp(a, 38f), dp(a, 38f)))
            card.addView(head)

            val preview = ImageView(a)
            preview.scaleType = ImageView.ScaleType.CENTER_CROP
            preview.background = rounded(p.sheet, dp(a, 13f).toFloat())
            preview.clipToOutline = true
            if (t.thumbnail != null) {
                preview.setImageBitmap(t.thumbnail)
            } else {
                //no preview yet: the site's address (or Wisp's start page) in the middle
                preview.scaleType = ImageView.ScaleType.CENTER
                preview.setImageResource(if (t.home) R.drawable.ic_wisp_find else R.drawable.ic_wisp_globe)
                preview.setColorFilter(p.divider)
            }
            card.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, thumbH))

            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(a, 5f), dp(a, 5f), dp(a, 5f), dp(a, 5f))
            row?.addView(card, lp)
            if (t.current) currentCard = card
        }
        if (tabs.size % 2 == 1) row?.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f).also {
            it.setMargins(dp(a, 5f), 0, dp(a, 5f), 0)
        })

        val scroll = ScrollView(a)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(grid)
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        //"+ New tab" floating at the bottom right
        val fab = TextView(a)
        fab.text = "+  " + a.getString(R.string.wisp_new_tab)
        fab.textSize = 15f
        fab.setTypeface(fab.typeface, Typeface.BOLD)
        fab.setTextColor(p.onAccent)
        fab.background = rounded(p.accent, dp(a, 18f).toFloat())
        fab.elevation = dp(a, 6f).toFloat()
        fab.setPadding(dp(a, 20f), dp(a, 14f), dp(a, 22f), dp(a, 14f))
        fab.setOnClickListener { dialog.dismiss(); onNew() }
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.gravity = Gravity.BOTTOM or Gravity.END
        flp.setMargins(0, 0, dp(a, 18f), dp(a, 18f))
        root.addView(fab, flp)

        val height = (a.resources.displayMetrics.heightPixels * 0.86f).toInt()
        root.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
        val holder = FrameLayout(a)
        holder.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height))
        dialog = sheet(a, holder)
        dialog.show()
        currentCard?.let { c -> scroll.post { scroll.scrollTo(0, ((c.parent as View).top - dp(a, 12f)).coerceAtLeast(0)) } }
        val setIcon: (Int, Bitmap?) -> Unit = { i, bmp ->
            if (bmp != null && i in icons.indices) {
                icons[i].clearColorFilter()
                icons[i].setImageBitmap(bmp)
            }
        }
        return Pair(dialog, setIcon)
    }
}
