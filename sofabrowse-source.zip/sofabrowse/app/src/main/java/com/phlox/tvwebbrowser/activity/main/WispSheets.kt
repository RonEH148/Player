package com.phlox.tvwebbrowser.activity.main

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R

/**
 * Wisp (phone build): the ⋮ menu, the tab list and site info. Built in code so the TV build
 * carries no extra layouts.
 */
object WispSheets {

    /** A button in the menu. [active]: a switch that is on (shown in the accent colour). */
    class Action(
        val icon: Int,
        val label: String,
        val active: Boolean = false,
        val enabled: Boolean = true,
        val badge: String? = null,
        val onClick: () -> Unit
    )

    class TabRow(val title: String, val address: String, val current: Boolean)

    private class Palette(a: Activity) {
        val sheet = ContextCompat.getColor(a, R.color.wisp_sheet)
        val text = ContextCompat.getColor(a, R.color.wisp_text)
        val secondary = ContextCompat.getColor(a, R.color.wisp_text_secondary)
        val icon = ContextCompat.getColor(a, R.color.wisp_icon)
        val accent = ContextCompat.getColor(a, R.color.wisp_accent)
        val accentSoft = ContextCompat.getColor(a, R.color.wisp_accent_soft)
        val pill = ContextCompat.getColor(a, R.color.wisp_pill)
        val divider = ContextCompat.getColor(a, R.color.wisp_divider)
    }

    private fun dp(a: Activity, v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, a.resources.displayMetrics).toInt()

    private fun rounded(color: Int, radius: Float, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            if (topOnly) cornerRadii = floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f)
            else cornerRadius = radius
        }

    private fun ripple(a: Activity): android.graphics.drawable.Drawable? {
        val tv = TypedValue()
        a.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return if (tv.resourceId != 0) ContextCompat.getDrawable(a, tv.resourceId) else null
    }

    /** A dialog that slides up from the bottom of the screen, full width, with rounded top corners. */
    private fun sheet(a: Activity, content: View): Dialog {
        val p = Palette(a)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.background = rounded(p.sheet, dp(a, 22f).toFloat(), topOnly = true)
        root.setPadding(0, dp(a, 10f), 0, dp(a, 14f))
        val handle = View(a)
        handle.background = rounded(p.divider, dp(a, 2f).toFloat())
        val hlp = LinearLayout.LayoutParams(dp(a, 36f), dp(a, 4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.bottomMargin = dp(a, 10f)
        root.addView(handle, hlp)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(root)
        d.setCanceledOnTouchOutside(true)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.setDimAmount(0.35f)
            w.attributes = w.attributes.also { it.windowAnimations = android.R.style.Animation_InputMethod }
        }
        return d
    }

    private fun tinted(a: Activity, res: Int, color: Int): ImageView {
        val iv = ImageView(a)
        iv.setImageResource(res)
        iv.setColorFilter(color)
        iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
        return iv
    }

    /** A full-width row: icon, title (and a second line), and on the right a switch, a badge or nothing. */
    class Row(
        val icon: Int,
        val title: String,
        val subtitle: String? = null,
        /** non-null: the row is a switch in this state; tapping it calls [onClick] with the new state */
        val switchOn: Boolean? = null,
        val badge: String? = null,
        val enabled: Boolean = true,
        val danger: Boolean = false,
        val onClick: (Boolean) -> Unit
    )

    private fun rowView(a: Activity, p: Palette, r: Row, dismiss: () -> Unit): View {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(a, 50f)
        row.setPadding(dp(a, 18f), dp(a, 6f), dp(a, 16f), dp(a, 6f))
        row.background = ripple(a)
        row.isEnabled = r.enabled
        row.alpha = if (r.enabled) 1f else 0.38f
        val color = if (r.danger) DANGER else p.icon
        row.addView(tinted(a, r.icon, color), LinearLayout.LayoutParams(dp(a, 22f), dp(a, 22f)))
        val texts = LinearLayout(a)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(a, 18f), 0, dp(a, 10f), 0)
        val t = TextView(a)
        t.text = r.title
        t.textSize = 15f
        t.setTextColor(if (r.danger) color else p.text)
        texts.addView(t)
        if (!r.subtitle.isNullOrEmpty()) {
            val st = TextView(a)
            st.text = r.subtitle
            st.textSize = 12.5f
            st.setTextColor(p.secondary)
            texts.addView(st)
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        var sw: android.widget.Switch? = null
        if (r.switchOn != null) {
            val s = android.widget.Switch(a)
            s.isChecked = r.switchOn
            s.isClickable = false
            s.isFocusable = false
            tintSwitch(s, p)
            row.addView(s)
            sw = s
        } else if (!r.badge.isNullOrEmpty()) {
            val b = TextView(a)
            b.text = r.badge
            b.textSize = 11f
            b.setTypeface(b.typeface, Typeface.BOLD)
            b.setTextColor(p.accent)
            b.background = rounded(p.accentSoft, dp(a, 10f).toFloat())
            b.setPadding(dp(a, 8f), dp(a, 2f), dp(a, 8f), dp(a, 2f))
            row.addView(b)
        }
        val theSwitch = sw
        row.setOnClickListener {
            if (theSwitch != null) {
                theSwitch.isChecked = !theSwitch.isChecked
                r.onClick(theSwitch.isChecked)
            } else {
                dismiss()
                r.onClick(true)
            }
        }
        return row
    }

    private const val DANGER = 0xFFD84343.toInt()

    /** Accent-coloured switch (the platform one has the system's colours otherwise). */
    fun tintSwitch(sw: android.widget.Switch, a: Activity) = tintSwitch(sw, Palette(a))

    private fun tintSwitch(sw: android.widget.Switch, p: Palette) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(p.accent, 0xFFF2F1F6.toInt()))
        sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(p.accentSoft, p.divider))
    }

    /**
     * The ⋮ menu, dropping down from the top-right corner like Chrome's: page buttons in a row
     * (back, forward, reload, bookmark, share), then a list.
     */
    fun showMenu(a: Activity, topOffsetPx: Int, title: String?, top: List<Action>, rows: List<Row>): Dialog {
        val p = Palette(a)
        lateinit var dialog: Dialog
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(a, 6f), 0, dp(a, 8f))

        val bar = LinearLayout(a)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(a, 6f), 0, dp(a, 6f), 0)
        for (act in top) {
            val b = tinted(a, act.icon, if (act.active) p.accent else p.icon)
            b.contentDescription = act.label
            b.background = ripple(a)
            b.isEnabled = act.enabled
            b.alpha = if (act.enabled) 1f else 0.3f
            b.setOnClickListener { dialog.dismiss(); act.onClick() }
            bar.addView(b, LinearLayout.LayoutParams(0, dp(a, 48f), 1f))
        }
        box.addView(bar)

        if (!title.isNullOrBlank()) {
            val t = TextView(a)
            t.text = title
            t.setTextColor(p.secondary)
            t.textSize = 12f
            t.isSingleLine = true
            t.ellipsize = TextUtils.TruncateAt.MIDDLE
            t.setPadding(dp(a, 18f), dp(a, 2f), dp(a, 18f), dp(a, 4f))
            box.addView(t)
        }
        val line = View(a)
        line.setBackgroundColor(p.divider)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 1f))
        llp.setMargins(0, dp(a, 2f), 0, dp(a, 4f))
        box.addView(line, llp)
        for (r in rows) box.addView(rowView(a, p, r) { dialog.dismiss() })

        val maxH = a.resources.displayMetrics.heightPixels - topOffsetPx - dp(a, 24f)
        val scroll = object : ScrollView(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
            }
        }
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(box)
        scroll.background = rounded(p.sheet, dp(a, 18f).toFloat())
        scroll.elevation = dp(a, 10f).toFloat()
        scroll.clipToOutline = true

        //transparent frame around the card, so its shadow isn't cut off
        val frame = FrameLayout(a)
        val m = dp(a, 8f)
        frame.setPadding(m, m, m, m)
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.setContentView(frame)
        d.setCanceledOnTouchOutside(true)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(minOf(dp(a, 300f), a.resources.displayMetrics.widthPixels - dp(a, 16f)), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.TOP or Gravity.END)
            w.attributes = w.attributes.also {
                it.y = (topOffsetPx - m).coerceAtLeast(0)
                it.x = 0
                it.windowAnimations = android.R.style.Animation_Dialog
            }
            w.setDimAmount(0.12f)
        }
        dialog = d
        d.show()
        return d
    }

    /**
     * Site info, like Chrome's page info: the site's name, whether the connection is secure, its
     * settings as switches and buttons to delete its data.
     */
    fun showSiteInfo(a: Activity, site: String, secure: Boolean, rows: List<Row>): Dialog {
        val p = Palette(a)
        lateinit var dialog: Dialog
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(a)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(a, 22f), 0, dp(a, 22f), dp(a, 10f))
        val t = TextView(a)
        t.text = site
        t.textSize = 19f
        t.setTypeface(t.typeface, Typeface.BOLD)
        t.setTextColor(p.text)
        t.isSingleLine = true
        t.ellipsize = TextUtils.TruncateAt.MIDDLE
        head.addView(t)
        val sec = TextView(a)
        sec.text = a.getString(if (secure) R.string.wisp_site_secure else R.string.wisp_site_not_secure)
        sec.textSize = 13f
        sec.setTextColor(if (secure) p.secondary else DANGER)
        sec.setPadding(0, dp(a, 2f), 0, 0)
        head.addView(sec)
        box.addView(head)
        for (r in rows) box.addView(rowView(a, p, r) { dialog.dismiss() })
        dialog = sheet(a, box)
        dialog.show()
        return dialog
    }

    /**
     * The tab list: every tab with its site icon, title and address; tap to switch, ✕ to close.
     * Returns the dialog and a setter that fills in a tab's site icon (index, bitmap) once it is loaded.
     */
    fun showTabs(
        a: Activity,
        privateMode: Boolean,
        tabs: List<TabRow>,
        onPick: (Int) -> Unit,
        onClose: (Int) -> Unit,
        onNew: () -> Unit,
        onCloseAll: () -> Unit
    ): Pair<Dialog, (Int, Bitmap?) -> Unit> {
        val p = Palette(a)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        lateinit var dialog: Dialog

        //header: "Tabs (3)" ............ [+ New tab]
        val header = LinearLayout(a)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(a, 22f), 0, dp(a, 12f), dp(a, 8f))
        val title = TextView(a)
        title.text = a.getString(if (privateMode) R.string.wisp_tabs_private_title else R.string.wisp_tabs_title, tabs.size)
        title.textSize = 18f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(p.text)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val add = TextView(a)
        add.text = "+  " + a.getString(R.string.wisp_new_tab)
        add.textSize = 14f
        add.setTypeface(add.typeface, Typeface.BOLD)
        add.setTextColor(p.accent)
        add.background = rounded(p.accentSoft, dp(a, 18f).toFloat())
        add.setPadding(dp(a, 14f), dp(a, 8f), dp(a, 14f), dp(a, 8f))
        add.setOnClickListener { dialog.dismiss(); onNew() }
        header.addView(add)
        box.addView(header)

        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        val iconViews = ArrayList<ImageView>()
        var currentRow: View? = null
        tabs.forEachIndexed { i, t ->
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(a, 14f), dp(a, 8f), dp(a, 4f), dp(a, 8f))
            row.background = if (t.current) rounded(p.accentSoft, dp(a, 16f).toFloat()) else ripple(a)
            row.setOnClickListener { dialog.dismiss(); onPick(i) }

            val icon = tinted(a, R.drawable.ic_wisp_globe, p.secondary)
            iconViews.add(icon)
            row.addView(icon, LinearLayout.LayoutParams(dp(a, 22f), dp(a, 22f)))

            val texts = LinearLayout(a)
            texts.orientation = LinearLayout.VERTICAL
            texts.setPadding(dp(a, 14f), 0, dp(a, 8f), 0)
            val tt = TextView(a)
            tt.text = t.title
            tt.textSize = 15f
            tt.setTextColor(if (t.current) p.accent else p.text)
            tt.isSingleLine = true
            tt.ellipsize = TextUtils.TruncateAt.END
            texts.addView(tt)
            val ta = TextView(a)
            ta.text = t.address
            ta.textSize = 12f
            ta.setTextColor(p.secondary)
            ta.isSingleLine = true
            ta.ellipsize = TextUtils.TruncateAt.MIDDLE
            texts.addView(ta)
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val close = tinted(a, R.drawable.ic_close_grey_900_24dp, p.icon)
            close.contentDescription = a.getString(R.string.wisp_close_tab)
            close.background = ripple(a)
            close.setOnClickListener { dialog.dismiss(); onClose(i) }
            row.addView(close, LinearLayout.LayoutParams(dp(a, 44f), dp(a, 44f)))

            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rlp.setMargins(dp(a, 8f), dp(a, 1f), dp(a, 8f), dp(a, 1f))
            list.addView(row, rlp)
            if (t.current) currentRow = row
        }
        //at most ~60 % of the screen for the list; it scrolls inside
        val maxH = (a.resources.displayMetrics.heightPixels * 0.6f).toInt()
        val scroll = object : ScrollView(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
            }
        }
        scroll.addView(list)
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (tabs.size > 1) {
            val closeAll = TextView(a)
            closeAll.text = a.getString(R.string.wisp_close_all_tabs)
            closeAll.textSize = 14f
            closeAll.setTextColor(p.secondary)
            closeAll.background = ripple(a)
            closeAll.setPadding(dp(a, 22f), dp(a, 12f), dp(a, 22f), dp(a, 4f))
            closeAll.setOnClickListener { dialog.dismiss(); onCloseAll() }
            box.addView(closeAll)
        }

        dialog = sheet(a, box)
        dialog.show()
        currentRow?.let { r -> scroll.post { scroll.scrollTo(0, (r.top - dp(a, 40f)).coerceAtLeast(0)) } }
        val setIcon: (Int, Bitmap?) -> Unit = { i, bmp ->
            if (bmp != null && i in iconViews.indices) {
                iconViews[i].clearColorFilter()
                iconViews[i].setImageBitmap(bmp)
            }
        }
        return Pair(dialog, setIcon)
    }
}
