package com.phlox.tvwebbrowser.activity.main

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R

/**
 * Wisp (phone build): the bottom sheets that replace Lumen's TV toolbar rows - the ⋮ menu and the
 * tab list. Built in code so the TV build carries no extra layouts.
 */
object WispSheets {

    /** A button in the menu. [active]: a switch that is on (shown in the accent colour). */
    class Action(
        val icon: Int,
        val label: String,
        val active: Boolean = false,
        val enabled: Boolean = true,
        val badge: String? = null,
        val onClick: () -> Unit
    )

    class TabRow(val title: String, val address: String, val current: Boolean)

    private class Palette(a: Activity) {
        val sheet = ContextCompat.getColor(a, R.color.wisp_sheet)
        val text = ContextCompat.getColor(a, R.color.wisp_text)
        val secondary = ContextCompat.getColor(a, R.color.wisp_text_secondary)
        val icon = ContextCompat.getColor(a, R.color.wisp_icon)
        val accent = ContextCompat.getColor(a, R.color.wisp_accent)
        val accentSoft = ContextCompat.getColor(a, R.color.wisp_accent_soft)
        val pill = ContextCompat.getColor(a, R.color.wisp_pill)
        val divider = ContextCompat.getColor(a, R.color.wisp_divider)
    }

    private fun dp(a: Activity, v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, a.resources.displayMetrics).toInt()

    private fun rounded(color: Int, radius: Float, topOnly: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            if (topOnly) cornerRadii = floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f)
            else cornerRadius = radius
        }

    private fun ripple(a: Activity): android.graphics.drawable.Drawable? {
        val tv = TypedValue()
        a.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return if (tv.resourceId != 0) ContextCompat.getDrawable(a, tv.resourceId) else null
    }

    /** A dialog that slides up from the bottom of the screen, full width, with rounded top corners. */
    private fun sheet(a: Activity, content: View): Dialog {
        val p = Palette(a)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = LinearLayout(a)
        root.orientation = LinearLayout.VERTICAL
        root.background = rounded(p.sheet, dp(a, 22f).toFloat(), topOnly = true)
        root.setPadding(0, dp(a, 10f), 0, dp(a, 14f))
        val handle = View(a)
        handle.background = rounded(p.divider, dp(a, 2f).toFloat())
        val hlp = LinearLayout.LayoutParams(dp(a, 36f), dp(a, 4f))
        hlp.gravity = Gravity.CENTER_HORIZONTAL
        hlp.bottomMargin = dp(a, 10f)
        root.addView(handle, hlp)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(root)
        d.setCanceledOnTouchOutside(true)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.setDimAmount(0.35f)
            w.attributes = w.attributes.also { it.windowAnimations = android.R.style.Animation_InputMethod }
        }
        return d
    }

    private fun tinted(a: Activity, res: Int, color: Int): ImageView {
        val iv = ImageView(a)
        iv.setImageResource(res)
        iv.setColorFilter(color)
        iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
        return iv
    }

    /**
     * The ⋮ menu: a row of page buttons (back, forward, reload, bookmark, share) and a grid
     * of everything else, four per row.
     */
    fun showMenu(a: Activity, title: String?, top: List<Action>, grid: List<Action>): Dialog {
        val p = Palette(a)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        lateinit var dialog: Dialog

        if (!title.isNullOrBlank()) {
            val t = TextView(a)
            t.text = title
            t.setTextColor(p.secondary)
            t.textSize = 13f
            t.isSingleLine = true
            t.ellipsize = TextUtils.TruncateAt.MIDDLE
            t.setPadding(dp(a, 22f), 0, dp(a, 22f), dp(a, 6f))
            box.addView(t)
        }

        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(a, 8f), 0, dp(a, 8f), dp(a, 4f))
        for (act in top) {
            val b = tinted(a, act.icon, if (act.active) p.accent else p.icon)
            b.contentDescription = act.label
            b.background = ripple(a)
            b.isEnabled = act.enabled
            b.alpha = if (act.enabled) 1f else 0.3f
            b.setOnClickListener { dialog.dismiss(); act.onClick() }
            row.addView(b, LinearLayout.LayoutParams(0, dp(a, 52f), 1f))
        }
        box.addView(row)

        val line = View(a)
        line.setBackgroundColor(p.divider)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 1f))
        llp.setMargins(dp(a, 18f), dp(a, 2f), dp(a, 18f), dp(a, 8f))
        box.addView(line, llp)

        var gridRow: LinearLayout? = null
        grid.forEachIndexed { i, act ->
            if (i % 4 == 0) {
                gridRow = LinearLayout(a).also {
                    it.orientation = LinearLayout.HORIZONTAL
                    it.setPadding(dp(a, 8f), 0, dp(a, 8f), 0)
                    box.addView(it)
                }
            }
            gridRow?.addView(gridCell(a, p, act) { dialog.dismiss(); act.onClick() },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        //fill the last row so the cells keep their width
        val rest = (4 - grid.size % 4) % 4
        repeat(rest) { gridRow?.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f)) }

        val scroll = ScrollView(a)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(box)
        dialog = sheet(a, scroll)
        dialog.show()
        return dialog
    }

    private fun gridCell(a: Activity, p: Palette, act: Action, onClick: () -> Unit): View {
        val cell = LinearLayout(a)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(a, 2f), dp(a, 8f), dp(a, 2f), dp(a, 8f))
        cell.background = ripple(a)
        cell.isEnabled = act.enabled
        cell.alpha = if (act.enabled) 1f else 0.35f
        cell.contentDescription = act.label
        cell.setOnClickListener { onClick() }

        val frame = FrameLayout(a)
        val iconBox = tinted(a, act.icon, if (act.active) p.accent else p.icon)
        iconBox.background = rounded(if (act.active) p.accentSoft else p.pill, dp(a, 16f).toFloat())
        val pad = dp(a, 12f)
        iconBox.setPadding(pad, pad, pad, pad)
        frame.addView(iconBox, FrameLayout.LayoutParams(dp(a, 48f), dp(a, 48f)))
        if (!act.badge.isNullOrEmpty()) {
            val badge = TextView(a)
            badge.text = act.badge
            badge.textSize = 10f
            badge.setTypeface(badge.typeface, Typeface.BOLD)
            badge.setTextColor(Color.WHITE)
            badge.gravity = Gravity.CENTER
            badge.minWidth = dp(a, 18f)
            badge.setPadding(dp(a, 4f), 0, dp(a, 4f), 0)
            badge.background = rounded(p.accent, dp(a, 9f).toFloat())
            val blp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(a, 18f))
            blp.gravity = Gravity.TOP or Gravity.END
            frame.addView(badge, blp)
        }
        val flp = LinearLayout.LayoutParams(dp(a, 54f), dp(a, 50f))
        cell.addView(frame, flp)

        val label = TextView(a)
        label.text = act.label
        label.textSize = 12f
        label.setTextColor(if (act.active) p.accent else p.text)
        label.gravity = Gravity.CENTER
        label.maxLines = 2
        label.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(a, 4f)
        cell.addView(label, lp)
        return cell
    }

    /**
     * The tab list: every tab with its site icon, title and address; tap to switch, ✕ to close.
     * Returns the dialog and a setter that fills in a tab's site icon (index, bitmap) once it is loaded.
     */
    fun showTabs(
        a: Activity,
        privateMode: Boolean,
        tabs: List<TabRow>,
        onPick: (Int) -> Unit,
        onClose: (Int) -> Unit,
        onNew: () -> Unit,
        onCloseAll: () -> Unit
    ): Pair<Dialog, (Int, Bitmap?) -> Unit> {
        val p = Palette(a)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        lateinit var dialog: Dialog

        //header: "Tabs (3)" ............ [+ New tab]
        val header = LinearLayout(a)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(a, 22f), 0, dp(a, 12f), dp(a, 8f))
        val title = TextView(a)
        title.text = a.getString(if (privateMode) R.string.wisp_tabs_private_title else R.string.wisp_tabs_title, tabs.size)
        title.textSize = 18f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.setTextColor(p.text)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val add = TextView(a)
        add.text = "+  " + a.getString(R.string.wisp_new_tab)
        add.textSize = 14f
        add.setTypeface(add.typeface, Typeface.BOLD)
        add.setTextColor(p.accent)
        add.background = rounded(p.accentSoft, dp(a, 18f).toFloat())
        add.setPadding(dp(a, 14f), dp(a, 8f), dp(a, 14f), dp(a, 8f))
        add.setOnClickListener { dialog.dismiss(); onNew() }
        header.addView(add)
        box.addView(header)

        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        val iconViews = ArrayList<ImageView>()
        var currentRow: View? = null
        tabs.forEachIndexed { i, t ->
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(a, 14f), dp(a, 8f), dp(a, 4f), dp(a, 8f))
            row.background = if (t.current) rounded(p.accentSoft, dp(a, 16f).toFloat()) else ripple(a)
            row.setOnClickListener { dialog.dismiss(); onPick(i) }

            val icon = tinted(a, R.drawable.ic_wisp_globe, p.secondary)
            iconViews.add(icon)
            row.addView(icon, LinearLayout.LayoutParams(dp(a, 22f), dp(a, 22f)))

            val texts = LinearLayout(a)
            texts.orientation = LinearLayout.VERTICAL
            texts.setPadding(dp(a, 14f), 0, dp(a, 8f), 0)
            val tt = TextView(a)
            tt.text = t.title
            tt.textSize = 15f
            tt.setTextColor(if (t.current) p.accent else p.text)
            tt.isSingleLine = true
            tt.ellipsize = TextUtils.TruncateAt.END
            texts.addView(tt)
            val ta = TextView(a)
            ta.text = t.address
            ta.textSize = 12f
            ta.setTextColor(p.secondary)
            ta.isSingleLine = true
            ta.ellipsize = TextUtils.TruncateAt.MIDDLE
            texts.addView(ta)
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val close = tinted(a, R.drawable.ic_close_grey_900_24dp, p.icon)
            close.contentDescription = a.getString(R.string.wisp_close_tab)
            close.background = ripple(a)
            close.setOnClickListener { dialog.dismiss(); onClose(i) }
            row.addView(close, LinearLayout.LayoutParams(dp(a, 44f), dp(a, 44f)))

            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            rlp.setMargins(dp(a, 8f), dp(a, 1f), dp(a, 8f), dp(a, 1f))
            list.addView(row, rlp)
            if (t.current) currentRow = row
        }
        //at most ~60 % of the screen for the list; it scrolls inside
        val maxH = (a.resources.displayMetrics.heightPixels * 0.6f).toInt()
        val scroll = object : ScrollView(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
            }
        }
        scroll.addView(list)
        box.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (tabs.size > 1) {
            val closeAll = TextView(a)
            closeAll.text = a.getString(R.string.wisp_close_all_tabs)
            closeAll.textSize = 14f
            closeAll.setTextColor(p.secondary)
            closeAll.background = ripple(a)
            closeAll.setPadding(dp(a, 22f), dp(a, 12f), dp(a, 22f), dp(a, 4f))
            closeAll.setOnClickListener { dialog.dismiss(); onCloseAll() }
            box.addView(closeAll)
        }

        dialog = sheet(a, box)
        dialog.show()
        currentRow?.let { r -> scroll.post { scroll.scrollTo(0, (r.top - dp(a, 40f)).coerceAtLeast(0)) } }
        val setIcon: (Int, Bitmap?) -> Unit = { i, bmp ->
            if (bmp != null && i in iconViews.indices) {
                iconViews[i].clearColorFilter()
                iconViews[i].setImageBitmap(bmp)
            }
        }
        return Pair(dialog, setIcon)
    }
}
