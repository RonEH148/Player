package com.phlox.tvwebbrowser.service.downloads

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor.AutoCloseOutputStream
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.os.ParcelFileDescriptor
import android.webkit.CookieManager
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.sofa.LumenDownloads
import android.os.StatFs
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import com.phlox.tvwebbrowser.TVBro
import com.phlox.tvwebbrowser.model.Download
import com.phlox.tvwebbrowser.singleton.AppDatabase
import com.phlox.tvwebbrowser.utils.DownloadUtils
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

/**
 * Created by PDT on 23.01.2017.
 */

const val MAX_CONNECT_RETRIES = 5

interface DownloadTask {
    var downloadInfo: Download

    interface Callback {
        fun onProgress(task: DownloadTask)
        fun onError(task: DownloadTask, responseCode: Int, responseMessage: String)
        fun onDone(task: DownloadTask)
    }
}

class FileDownloadTask(override var downloadInfo: Download, private val userAgent: String?, val callback: DownloadTask.Callback) : Runnable, DownloadTask {
    companion object {
        val TAG = FileDownloadTask::class.java.simpleName
        /** Files smaller than this are downloaded with one connection. */
        const val MIN_SIZE_FOR_PARTS = 2L * 1024 * 1024
        private const val FAT32_LIMIT = 4L * 1024 * 1024 * 1024 - 1
        private const val BUFFER = 256 * 1024
    }

    //servers often reject Java's default "Dalvik/..." user agent
    private val effectiveUserAgent: String by lazy {
        userAgent?.takeIf { it.isNotBlank() } ?: try {
            android.webkit.WebSettings.getDefaultUserAgent(AppContext.get())
        } catch (e: Exception) {
            "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
        }
    }

    private fun openConnection(url: URL, range: String? = null): HttpURLConnection {
        val connection = url.openConnection() as HttpURLConnection
        connection.readTimeout = 30000
        connection.connectTimeout = 20000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", effectiveUserAgent)
        if (downloadInfo.mimeType != null && downloadInfo.mimeType != "application/octet-stream") {
            connection.setRequestProperty("Accept", downloadInfo.mimeType)
        }
        downloadInfo.referer?.takeIf { it.isNotBlank() }?.let { connection.setRequestProperty("Referer", it) }
        connection.useCaches = false
        val cookie = CookieManager.getInstance().getCookie(url.toString())
        if (cookie != null) connection.setRequestProperty("cookie", cookie)
        if (range != null) {
            connection.setRequestProperty("Range", range)
            //byte ranges must refer to the raw file, not a compressed transfer
            connection.setRequestProperty("Accept-Encoding", "identity")
        }
        connection.connect()
        return connection
    }

    /** Message for the downloads list, with hints for typical USB-drive problems. */
    private fun storageError(e: Exception, written: Long): String {
        val target = if (LumenDownloads.customFolder() != null) "the chosen folder" else "internal storage"
        return when {
            written >= FAT32_LIMIT - BUFFER -> "Stopped at 4 GB: the USB drive is probably formatted as FAT32, " +
                    "which can't hold files over 4 GB. Format it as exFAT or NTFS, or save to internal storage."
            e.message?.contains("ENOSPC", true) == true || e.message?.contains("No space", true) == true ->
                "Not enough free space in $target."
            e.message?.contains("EIO", true) == true || e.message?.contains("ENODEV", true) == true ||
                    e.message?.contains("ENOENT", true) == true -> "The storage was removed or became unavailable."
            else -> e.toString()
        }
    }

    override fun run() {
        downloadInfo.id = AppDatabase.db.downloadDao().insert(downloadInfo)

        var fd: ParcelFileDescriptor? = null
        val url = URL(downloadInfo.url)
        var connection: HttpURLConnection? = null
        var written = 0L
        try {
            var retries = 0
            do {
                if (retries > 0) {
                    //trust me, sometimes this helps! Don't ask me how...
                    Thread.sleep(3000)
                }
                connection = openConnection(url)

                when (connection.responseCode) {
                    HttpURLConnection.HTTP_OK -> break
                    HttpURLConnection.HTTP_GATEWAY_TIMEOUT,
                    HttpURLConnection.HTTP_UNAVAILABLE -> {
                        retries++
                        connection.disconnect()
                        if (retries >= MAX_CONNECT_RETRIES) {
                            downloadInfo.size = Download.BROKEN_MARK
                            callback.onError(this, connection.responseCode, connection.responseMessage)
                            return
                        }
                    }
                    else -> {
                        downloadInfo.size = Download.BROKEN_MARK
                        callback.onError(this, connection.responseCode, connection.responseMessage)
                        return
                    }
                }
            } while (true)

            val fileLength = connection!!.contentLengthLong
            downloadInfo.size = fileLength

            if (connection.headerFields.containsKey("Content-Disposition")) {
                val mime = connection.getHeaderField("Content-Type")
                downloadInfo.filename = DownloadUtils.guessFileName(downloadInfo.url, connection.getHeaderField("Content-Disposition"), mime)
                if (!LumenDownloads.isContentPath(downloadInfo.filepath) && downloadInfo.filepath.isNotEmpty()) {
                    downloadInfo.filepath = File(File(downloadInfo.filepath).parentFile, downloadInfo.filename).absolutePath
                }
            }
            if (downloadInfo.mimeType.isNullOrBlank()) {
                downloadInfo.mimeType = connection.getHeaderField("Content-Type")?.substringBefore(';')?.trim()
            }

            fd = LumenDownloads.openOutput(downloadInfo)
            AppDatabase.db.downloadDao().update(downloadInfo)
            Log.d(TAG, "URI: " + downloadInfo.filename)

            val acceptsRanges = connection.getHeaderField("Accept-Ranges")?.contains("bytes", true) == true
            val compressed = connection.getHeaderField("Content-Encoding")?.let { !it.equals("identity", true) } == true
            val resumable = acceptsRanges && !compressed && fileLength > 0

            //Lumen: like a download manager, fetch big files over several connections at once
            val parts = AppContext.provideConfig().lumenDownloadParts
            if (parts > 1 && resumable && fileLength >= MIN_SIZE_FOR_PARTS) {
                connection.disconnect()
                connection = null
                when (downloadInParts(url, fd, fileLength, parts)) {
                    PartsResult.DONE -> {
                        downloadInfo.size = fileLength
                        downloadInfo.bytesReceived = fileLength
                        return //finally{} publishes the file
                    }
                    PartsResult.CANCELLED -> {
                        downloadInfo.bytesReceived = 0
                        downloadInfo.size = Download.CANCELLED_MARK
                        return
                    }
                    PartsResult.UNSUPPORTED -> {
                        Log.w(TAG, "Multi-part download not possible, using one connection")
                        try {
                            FileOutputStream(fd.fileDescriptor).channel.truncate(0)
                        } catch (ignored: Exception) {
                        }
                        connection = openConnection(url)
                        if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                            downloadInfo.size = Download.BROKEN_MARK
                            callback.onError(this, connection.responseCode, connection.responseMessage)
                            return
                        }
                    }
                }
            }

            //single connection, resuming from the last byte after network drops when possible
            val output = FileOutputStream(fd.fileDescriptor)
            val data = ByteArray(BUFFER)
            var drops = 0
            var input: InputStream = connection!!.inputStream
            while (true) {
                if (downloadInfo.cancelled) {
                    downloadInfo.bytesReceived = 0
                    downloadInfo.size = Download.CANCELLED_MARK
                    return
                }
                val count = try {
                    input.read(data)
                } catch (e: IOException) {
                    if (!resumable || drops >= 20) throw e
                    drops++
                    Log.w(TAG, "Connection dropped at $written bytes, resuming ($drops)")
                    try { input.close() } catch (ignored: IOException) {}
                    connection?.disconnect()
                    Thread.sleep(1500L * drops.coerceAtMost(5))
                    connection = openConnection(url, "bytes=$written-")
                    if (connection.responseCode != HttpURLConnection.HTTP_PARTIAL) throw e
                    input = connection.inputStream
                    continue
                }
                if (count == -1) break
                try {
                    output.write(data, 0, count)
                } catch (e: IOException) {
                    throw IOException(storageError(e, written), e)
                }
                written += count
                downloadInfo.bytesReceived = written
                callback.onProgress(this)
            }
            try { input.close() } catch (ignored: IOException) {}
            output.flush()
            if (fileLength > 0 && written != fileLength) {
                throw IOException("Download incomplete ($written of $fileLength bytes)")
            }
            downloadInfo.size = downloadInfo.bytesReceived
        } catch (e: Exception) {
            e.printStackTrace()
            downloadInfo.size = Download.BROKEN_MARK
            callback.onError(this, 0, e.message ?: e.toString())
            return
        } finally {
            try {
                fd?.close()
            } catch (ignored: IOException) {
            }

            connection?.disconnect()
            cancelDownloadIfNeeded(downloadInfo)
            if (downloadInfo.size != Download.BROKEN_MARK) {
                callback.onDone(this)
            }
        }
    }

    private enum class PartsResult { DONE, CANCELLED, UNSUPPORTED }

    /** Can this file be written at any position? Some USB/SD providers only allow writing in order. */
    private fun supportsRandomAccess(channel: FileChannel, length: Long): Boolean = try {
        channel.write(ByteBuffer.wrap(byteArrayOf(0)), length - 1)
        channel.position(0)
        true
    } catch (e: Exception) {
        Log.w(TAG, "Target does not support random access: $e")
        false
    }

    /**
     * Downloads [length] bytes as [parts] byte ranges in parallel. Parts are written straight to the
     * target file when it allows random access; otherwise (some USB drives) they go to a temporary
     * file on internal storage that is copied over at the end.
     */
    private fun downloadInParts(url: URL, fd: ParcelFileDescriptor, length: Long, parts: Int): PartsResult {
        val targetChannel = FileOutputStream(fd.fileDescriptor).channel
        var tempFile: File? = null
        var tempRaf: RandomAccessFile? = null
        val channel: FileChannel = if (supportsRandomAccess(targetChannel, length)) {
            targetChannel
        } else {
            val dir = AppContext.get().getExternalFilesDir(null) ?: AppContext.get().filesDir
            if (StatFs(dir.absolutePath).availableBytes < length + 64L * 1024 * 1024) {
                return PartsResult.UNSUPPORTED //not enough room for a temporary copy: one connection
            }
            tempFile = File(dir, "lumen_part_${downloadInfo.id}.tmp")
            tempRaf = RandomAccessFile(tempFile, "rw")
            tempRaf.setLength(length)
            tempRaf.channel
        }
        try {
            val received = AtomicLong(0)
            val unsupported = AtomicBoolean(false)
            val failure = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
            val chunk = length / parts
            val workers = (0 until parts).map { index ->
                val start = index * chunk
                val end = if (index == parts - 1) length - 1 else start + chunk - 1
                Thread {
                    var pos = start
                    var attempts = 0
                    val buffer = ByteArray(BUFFER)
                    while (pos <= end && failure.get() == null && !unsupported.get() && !downloadInfo.cancelled) {
                        var c: HttpURLConnection? = null
                        try {
                            c = openConnection(url, "bytes=$pos-$end")
                            if (c.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                                unsupported.set(true) //server ignored the range request
                                break
                            }
                            c.inputStream.use { inp ->
                                while (pos <= end) {
                                    if (downloadInfo.cancelled || failure.get() != null || unsupported.get()) break
                                    val n = inp.read(buffer)
                                    if (n == -1) break
                                    val bb = ByteBuffer.wrap(buffer, 0, n)
                                    var writePos = pos
                                    try {
                                        while (bb.hasRemaining()) writePos += channel.write(bb, writePos)
                                    } catch (e: IOException) {
                                        failure.compareAndSet(null, IOException(storageError(e, pos), e))
                                        break
                                    }
                                    pos += n
                                    received.addAndGet(n.toLong())
                                }
                            }
                            attempts = 0
                        } catch (e: Exception) {
                            attempts++
                            if (attempts > 10) {
                                failure.compareAndSet(null, e)
                            } else {
                                Thread.sleep(1000L * attempts.coerceAtMost(5)) //resume this part where it stopped
                            }
                        } finally {
                            c?.disconnect()
                        }
                    }
                }.also { it.start() }
            }
            while (workers.any { it.isAlive }) {
                downloadInfo.bytesReceived = received.get()
                callback.onProgress(this)
                Thread.sleep(300)
            }
            workers.forEach { it.join() }
            downloadInfo.bytesReceived = received.get()
            callback.onProgress(this)
            if (downloadInfo.cancelled) return PartsResult.CANCELLED
            if (unsupported.get() && received.get() == 0L) return PartsResult.UNSUPPORTED
            failure.get()?.let { throw it }
            if (unsupported.get() || received.get() != length) {
                throw IOException("Download interrupted (" + received.get() + " of " + length + " bytes)")
            }
            if (tempRaf != null) {
                //copy the finished temporary file to the USB/SD folder in order
                tempRaf.channel.position(0)
                targetChannel.position(0)
                var copied = 0L
                while (copied < length) {
                    val n = try {
                        targetChannel.transferFrom(tempRaf.channel, copied, minOf(8L * 1024 * 1024, length - copied))
                    } catch (e: IOException) {
                        throw IOException(storageError(e, copied), e)
                    }
                    if (n <= 0) throw IOException("Copy to the chosen folder failed")
                    copied += n
                }
            }
            return PartsResult.DONE
        } finally {
            try { tempRaf?.close() } catch (ignored: IOException) {}
            tempFile?.delete()
        }
    }
}

class BlobDownloadTask(override var downloadInfo: Download, val blobBase64Data: String, val callback: DownloadTask.Callback) : Runnable, DownloadTask {

    override fun run() {
        downloadInfo.id = AppDatabase.db.downloadDao().insert(downloadInfo)

        try {
            val blobAsBytes: ByteArray = Base64.decode(blobBase64Data.replaceFirst("data:${downloadInfo.mimeType};base64,", ""), 0)
            val output = AutoCloseOutputStream(LumenDownloads.openOutput(downloadInfo))
            AppDatabase.db.downloadDao().update(downloadInfo)
            output.buffered().use{ it.write(blobAsBytes) }
            downloadInfo.size = blobAsBytes.size.toLong()
            downloadInfo.bytesReceived = downloadInfo.size
        } catch (e: Exception) {
            downloadInfo.size = Download.BROKEN_MARK
            callback.onError(this, 0, e.toString())
            return
        } finally {
            cancelDownloadIfNeeded(downloadInfo)
        }
        callback.onDone(this)
    }
}

class StreamDownloadTask(override var downloadInfo: Download, val stream: InputStream, val callback: DownloadTask.Callback) : Runnable, DownloadTask {
    override fun run() {
        downloadInfo.id = AppDatabase.db.downloadDao().insert(downloadInfo)

        var output: OutputStream? = null
        try {
            output = AutoCloseOutputStream(LumenDownloads.openOutput(downloadInfo))
            AppDatabase.db.downloadDao().update(downloadInfo)
            val data = ByteArray(4096)
            var total: Long = 0
            var count = stream.read(data)
            while (count != -1) {
                if (downloadInfo.cancelled) {
                    downloadInfo.bytesReceived = 0
                    downloadInfo.size = Download.CANCELLED_MARK
                    callback.onDone(this)
                    return
                }
                total += count.toLong()
                output.write(data, 0, count)
                downloadInfo.bytesReceived = total
                callback.onProgress(this)
                count = stream.read(data)
            }
        } catch (e: Exception) {
            downloadInfo.size = Download.BROKEN_MARK
            callback.onError(this, 0, e.toString())
            return
        } finally {
            try {
                output?.close()
                stream.close()
            } catch (ignored: IOException) {
            }

            cancelDownloadIfNeeded(downloadInfo)
        }
        downloadInfo.size = downloadInfo.bytesReceived
        callback.onDone(this)
    }
}

private fun cancelDownloadIfNeeded(downloadInfo: Download) {
    val filePath = downloadInfo.filepath
    if (filePath.isEmpty()) return
    if (downloadInfo.cancelled) {
        if (!LumenDownloads.delete(filePath)) {
            Log.e(FileDownloadTask.TAG, "Download cancelled but content not deleted??")
        }
    } else {
        LumenDownloads.publish(downloadInfo)
    }
}
