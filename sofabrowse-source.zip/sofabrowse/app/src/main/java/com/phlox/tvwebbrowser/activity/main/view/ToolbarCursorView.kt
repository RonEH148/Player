package com.phlox.tvwebbrowser.activity.main.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup

/**
 * Lumen: the remote's pointer above the top bar. The page has its own pointer (inside the web view);
 * when it reaches the top edge it continues here, so the bar's buttons, tabs and their ✕ can be
 * pointed at and clicked like with a mouse. Moving below the bar hands the pointer back to the page.
 */
class ToolbarCursorView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    interface Host {
        /** Lower edge of the area this pointer may move in (the bar's bottom), in this view's coordinates. */
        fun toolbarBottom(): Int
        /** The pointer left the bar downwards at [x]: give it back to the page. */
        fun onLeaveToPage(x: Float)
        /** The pointer was put away (Back, or a text field got the keyboard). */
        fun onCursorClosed()
        /** Where to deliver the simulated clicks. */
        fun touchTarget(): ViewGroup
    }

    var host: Host? = null
    var active = false
        private set
    private var x = 0f
    private var y = 0f
    private var pressedDownTime = 0L
    private val radius = context.resources.displayMetrics.widthPixels / 100f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dirX = 0
    private var dirY = 0
    private var speed = 0f
    private var lastStep = 0L

    init {
        isFocusable = false
        isClickable = false
        setWillNotDraw(false)
    }

    fun show(atX: Float, atY: Float) {
        x = atX.coerceIn(0f, (width - 1).coerceAtLeast(0).toFloat())
        y = atY
        active = true
        invalidate()
    }

    fun close(notify: Boolean = true) {
        if (!active) return
        active = false
        dirX = 0; dirY = 0; speed = 0f
        removeCallbacks(mover)
        invalidate()
        if (notify) host?.onCursorClosed()
    }

    private val mover = object : Runnable {
        override fun run() {
            if (!active || (dirX == 0 && dirY == 0)) return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastStep).coerceIn(1, 50)
            lastStep = now
            //accelerates while the key is held, like the page pointer
            val max = width / 40f
            speed = (speed + dt * width / 40000f).coerceAtMost(max)
            x = (x + dirX * speed * dt / 16f).coerceIn(0f, (width - 1).toFloat())
            y = (y + dirY * speed * dt / 16f).coerceAtLeast(0f)
            val bottom = host?.toolbarBottom() ?: height
            if (y >= bottom) {
                val leaveX = x
                close(notify = false)
                host?.onLeaveToPage(leaveX)
                return
            }
            invalidate()
            postOnAnimation(this)
        }
    }

    /** Remote keys while the pointer is shown. Returns true when the key was used. */
    fun handleKey(event: KeyEvent): Boolean {
        if (!active) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                val dx = when (event.keyCode) { KeyEvent.KEYCODE_DPAD_LEFT -> -1; KeyEvent.KEYCODE_DPAD_RIGHT -> 1; else -> 0 }
                val dy = when (event.keyCode) { KeyEvent.KEYCODE_DPAD_UP -> -1; KeyEvent.KEYCODE_DPAD_DOWN -> 1; else -> 0 }
                if (down) {
                    if (event.repeatCount == 0) {
                        if (dx != 0) dirX = dx
                        if (dy != 0) dirY = dy
                        if (speed == 0f) speed = width / 400f
                        lastStep = SystemClock.uptimeMillis()
                        removeCallbacks(mover)
                        postOnAnimation(mover)
                    }
                } else {
                    if (dx != 0) dirX = 0
                    if (dy != 0) dirY = 0
                    if (dirX == 0 && dirY == 0) speed = 0f
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A -> {
                if (down && event.repeatCount == 0) {
                    pressedDownTime = SystemClock.uptimeMillis()
                    touch(MotionEvent.ACTION_DOWN)
                } else if (!down) {
                    touch(MotionEvent.ACTION_UP)
                }
                invalidate()
                return true
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_B -> {
                if (!down) close()
                return true
            }
        }
        return false
    }

    private fun touch(action: Int) {
        val target = host?.touchTarget() ?: return
        val now = SystemClock.uptimeMillis()
        val e = MotionEvent.obtain(if (action == MotionEvent.ACTION_DOWN) now else pressedDownTime, now, action, x, y, 0)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        target.dispatchTouchEvent(e)
        e.recycle()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!active) return
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(150, 255, 255, 255)
        canvas.drawCircle(x, y, radius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (radius / 4f).coerceAtLeast(2f)
        paint.color = Color.rgb(0x20, 0xC9, 0x97)
        canvas.drawCircle(x, y, radius, paint)
    }
}
