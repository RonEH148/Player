package com.phlox.tvwebbrowser.webengine.webview

import android.net.http.SslError
import android.webkit.JavascriptInterface
import com.phlox.tvwebbrowser.AppContext
import com.phlox.tvwebbrowser.Config
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.TVBro
import com.phlox.tvwebbrowser.model.Download
import com.phlox.tvwebbrowser.utils.DownloadUtils
import org.json.JSONArray


class AndroidJSInterface(private val webEngine: WebViewWebEngine) {
    @JavascriptInterface
    fun currentUrl(): String {
        if (!webEngine.tab.url.startsWith(WebViewEx.INTERNAL_SCHEME)) return ""
        return webEngine.tab.url
    }

    @JavascriptInterface
    fun reloadWithSslTrust() {
        val callback = webEngine.callback ?: return
        if ((webEngine.getView() as WebViewEx).currentOriginalUrl?.scheme != "file") return
        callback.getActivity().runOnUiThread {
            val webview = webEngine.getView() as? WebViewEx ?: return@runOnUiThread
            webview.trustSsl = true
            webEngine.tab.url.apply { webEngine.loadUrl(this) }
        }
    }

    @JavascriptInterface
    fun getStringByName(name: String): String {
        val ctx = TVBro.instance
        //val resId = ctx.resources.getIdentifier(name, "string", ctx.packageName)
        //return ctx.getString(resId)
        when (name) {
            "connection_isnt_secure" -> return ctx.getString(R.string.connection_isnt_secure)
            "hostname" -> return ctx.getString(R.string.hostname)
            "err_desk" -> return ctx.getString(R.string.err_desk)
            "details" -> return ctx.getString(R.string.details)
            "back_to_safety" -> return ctx.getString(R.string.back_to_safety)
            "go_im_aware" -> return ctx.getString(R.string.go_im_aware)
            else -> return ""
        }
    }

    @JavascriptInterface
    fun startVoiceSearch() {
        //Lumen: voice search removed (no microphone access)
    }

    @JavascriptInterface
    fun setSearchEngine(engine: String, customSearchEngineURL: String) {
        if (!isHomePage()) return
        AppContext.provideConfig().searchEngineURL.value = customSearchEngineURL
    }

    @JavascriptInterface
    fun onEditBookmark(index: Int) {
        if (!isHomePage()) return
        val callback = webEngine.callback ?: return
        callback.getActivity().runOnUiThread { callback.onEditHomePageBookmarkSelected(index) }
    }

    @JavascriptInterface
    fun onHomePageLoaded() {
        if (!isHomePage()) return
        val callback = webEngine.callback ?: return
        callback.getActivity().runOnUiThread {
            val cfg = AppContext.provideConfig()
            val jsArr = JSONArray()
            for (item in callback.getHomePageLinks()) {
                jsArr.put(item.toJsonObj())
            }
            var links = jsArr.toString()
            links = links.replace("'", "\\'")
            webEngine.evaluateJavascript("renderLinks('${cfg.homePageLinksMode.name}', $links)")
            webEngine.evaluateJavascript(
                "applySearchEngine(\"${cfg.guessSearchEngineName()}\", \"${cfg.searchEngineURL.value}\")")
        }
    }

    @JavascriptInterface
    fun lastSSLError(getDetails: Boolean): String {
        val lastSSLError = (webEngine.getView() as? WebViewEx)?.lastSSLError ?: return "unknown"
        return if (getDetails) {
            lastSSLError.toString()
        } else {
            when (lastSSLError.primaryError) {
                SslError.SSL_EXPIRED -> TVBro.instance.getString(R.string.ssl_expired)
                SslError.SSL_IDMISMATCH -> TVBro.instance.getString(R.string.ssl_idmismatch)
                SslError.SSL_DATE_INVALID -> TVBro.instance.getString(R.string.ssl_date_invalid)
                SslError.SSL_INVALID -> TVBro.instance.getString(R.string.ssl_invalid)
                else -> "unknown"
            }
        }
    }

    @JavascriptInterface
    fun takeBlobDownloadData(base64BlobData: String, fileName: String?, url: String, mimetype: String) {
        val callback = webEngine.callback ?: return
        val finalFileName = fileName ?: DownloadUtils.guessFileName(url, null, mimetype)
        callback.onDownloadRequested(url, "",
                finalFileName, "TV Bro",
            mimetype, Download.OperationAfterDownload.NOP, base64BlobData)
    }

    @JavascriptInterface
    fun markBookmarkRecommendationAsUseful(bookmarkOrder: Int) {
        if (!isHomePage()) return
        val callback = webEngine.callback ?: return
        callback.getActivity().runOnUiThread { callback.markBookmarkRecommendationAsUseful(bookmarkOrder) }
    }

    //SofaBrowse: read by assets/sofa_enhancements.js in every frame. Exposes only on/off switches.
    @JavascriptInterface
    fun sofaSettings(frameHost: String?): String {
        //per-site settings follow the top-level page, like the ad blocker does
        val pageHost = try { android.net.Uri.parse(webEngine.tab.url).host } catch (e: Exception) { null }
        return WebViewEx.sofaSettingsJson(AppContext.provideConfig(), pageHost ?: frameHost)
    }

    /** Desktop-site check for the frame's own host (asked at document start, before the tab URL updates). */
    @JavascriptInterface
    fun sofaIsDesktopSite(host: String?): Boolean = AppContext.provideConfig().isDesktopSite(host)

    /** Video bar buttons: mode is "native" (4K/HDR player) or "external" (app chooser). */
    @JavascriptInterface
    fun sofaOpenVideo(mode: String, src: String?, pageUrl: String?, title: String?, positionSec: Double) {
        val callback = webEngine.callback ?: return
        val activity = callback.getActivity()
        activity.runOnUiThread {
            val webView = webEngine.getView() as? WebViewEx
            com.phlox.tvwebbrowser.sofa.SofaVideoHandoff.open(
                activity, mode, src, pageUrl ?: webEngine.tab.url, title ?: webEngine.tab.title,
                positionSec, webView?.settings?.userAgentString, webView?.mediaLog
            )
        }
    }

    /** A full-size inner box of a web app scrolled (CSS px); see "auto-hiding top bar" in the page script. */
    @JavascriptInterface
    fun sofaPageScroll(y: Int, dy: Int) {
        val callback = webEngine.callback ?: return
        val activity = callback.getActivity()
        activity.runOnUiThread {
            val webView = webEngine.getView() as? WebViewEx ?: return@runOnUiThread
            val density = activity.resources.displayMetrics.density
            webView.boxScrollY = (y * density).toInt()
            webEngine.callback?.onPageScrolled(webView.boxScrollY + webView.scrollY, (dy * density).toInt())
        }
    }

    /** In-page deband couldn't run for a video: tell the user once. */
    @JavascriptInterface
    fun sofaDebandStatus(code: String?) {
        val callback = webEngine.callback ?: return
        val activity = callback.getActivity()
        activity.runOnUiThread {
            val webView = webEngine.getView() as? WebViewEx ?: return@runOnUiThread
            if (!webView.pageDeband) return@runOnUiThread
            val c = code ?: return@runOnUiThread
            if (c.startsWith("ok:")) {
                //confirmation that the filter really runs, once per page
                if (webView.debandConfirmed) return@runOnUiThread
                webView.debandConfirmed = true
                android.widget.Toast.makeText(activity,
                    activity.getString(R.string.lumen_deband_running, c.substring(3).replace('x', '×')),
                    android.widget.Toast.LENGTH_LONG).show()
                return@runOnUiThread
            }
            val now = System.currentTimeMillis()
            if (now - webView.lastDebandReport < 5000) return@runOnUiThread
            webView.lastDebandReport = now
            val text = when {
                c == "nogl" -> activity.getString(R.string.lumen_deband_no_gl)
                c == "fsvideo" -> activity.getString(R.string.lumen_deband_reenter_fullscreen)
                c.startsWith("error:") -> activity.getString(R.string.lumen_deband_error_s, c.substring(6).take(160))
                else -> activity.getString(R.string.lumen_deband_blocked)
            }
            android.widget.Toast.makeText(activity, text, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Called by the page script after a login form is submitted in the top frame. */
    @JavascriptInterface
    fun sofaOfferSaveLogin(username: String?, password: String?) {
        if (password.isNullOrEmpty()) return
        val callback = webEngine.callback ?: return
        val activity = callback.getActivity()
        activity.runOnUiThread {
            val webView = webEngine.getView() as? WebViewEx ?: return@runOnUiThread
            com.phlox.tvwebbrowser.sofa.SofaPasswords.offerToSave(activity, webView, username ?: "", password)
        }
    }

    @JavascriptInterface
    fun sofaSetDeinterlace(enabled: Boolean) {
        AppContext.provideConfig().sofaDeinterlace = enabled
    }

    private fun isHomePage(): Boolean {
        return webEngine.tab.url == Config.HOME_PAGE_URL || webEngine.tab.url == Config.HOME_URL_ALIAS
    }
}
