package com.phlox.tvwebbrowser.sofa

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Lumen video clean-up for the built-in player. The player offers the anime deband (see
 * [Level]); the deblock and dering passes below are kept for possible later use.
 * Filters:
 *
 *  1. **Dering** (Strong): edge-preserving smoothing that removes "mosquito" noise and ringing
 *     around edges and text, without blurring the edges themselves.
 *  2. **Deblock** (Medium, Strong): finds the 8×8 block grid of the codec and smooths a step at a
 *     block border only when both sides of the border are flat - i.e. when the step is a
 *     compression artifact (macroblocking) and not a real edge.
 *  3. **Deband** (all levels): multi-radius, luma/chroma-aware smoothing of flat gradients with an
 *     adaptive threshold (stronger in dark areas where banding is most visible), plus fine dither
 *     so new steps don't appear.
 *
 * Every filter measures the local picture detail first and leaves textures and real edges alone,
 * so the picture is cleaned without looking soft.
 */
@OptIn(UnstableApi::class)
object LumenVideoCleanup {
    /** Off, or debanding tuned for anime (only used when you switch it on for a video). */
    enum class Level(val label: String) { OFF("Off"), ANIME("Anime") }

    fun effectsFor(level: Level): List<Effect> = when (level) {
        Level.OFF -> emptyList()
        //anime: big flat areas and wide gradients -> wide search radius, 3 passes, firm colour
        //smoothing; dark outlines differ far more than the threshold, so line art stays crisp.
        //Radius is given for 1080p and scaled to the video's resolution in the shader.
        Level.ANIME -> listOf(
            CleanupEffect(debandShader(iterations = 3), floatArrayOf(4f / 255f, 7f / 255f, 22f))
        )
    }

    /** One GPU pass. [params] are passed to the shader as uParams (meaning depends on the pass). */
    private class CleanupEffect(private val fragmentShader: String, private val params: FloatArray) : GlEffect {
        override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
            CleanupShaderProgram(fragmentShader, params, useHdr)
    }

    private class CleanupShaderProgram(fragmentShader: String, params: FloatArray, useHdr: Boolean) :
        BaseGlShaderProgram(/* useHighPrecisionColorComponents= */ useHdr, /* texturePoolCapacity= */ 1) {

        private val glProgram: GlProgram
        private var frameIndex = 0f

        init {
            try {
                glProgram = GlProgram(VERTEX_SHADER, fragmentShader)
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e)
            }
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.setFloatsUniformIfPresent("uParams", params)
        }

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            glProgram.setFloatsUniformIfPresent("uTexSize", floatArrayOf(inputWidth.toFloat(), inputHeight.toFloat()))
            return Size(inputWidth, inputHeight)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            try {
                glProgram.use()
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
                frameIndex = (frameIndex + 1f) % 1024f
                glProgram.setFloatsUniformIfPresent("uFrame", floatArrayOf(frameIndex))
                glProgram.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            }
        }

        override fun release() {
            super.release()
            try {
                glProgram.delete()
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e)
            }
        }
    }

    private const val VERTEX_SHADER = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    private const val COMMON = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform vec2 uTexSize;
uniform vec3 uParams;
varying vec2 vTexSamplingCoord;
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }
"""

    /**
     * Dering: 3×3 edge-preserving (bilateral) filter. Neighbours that differ a lot (real edges)
     * get almost no weight, small differences (mosquito noise, ringing) are averaged away.
     * uParams.x = range threshold.
     */
    private const val DERING_SHADER = COMMON + """
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  float sigma = uParams.x;
  vec3 sum = c.rgb;
  float wsum = 1.0;
  for (int dy = -1; dy <= 1; dy++) {
    for (int dx = -1; dx <= 1; dx++) {
      if (dx == 0 && dy == 0) continue;
      vec3 n = at(px + vec2(float(dx), float(dy))).rgb;
      float d = luma(n - c.rgb);
      float w = exp(-(d * d) / (2.0 * sigma * sigma)) * (dx == 0 || dy == 0 ? 1.0 : 0.7);
      sum += n * w;
      wsum += w;
    }
  }
  gl_FragColor = vec4(sum / wsum, c.a);
}
"""

    /**
     * Deblock: works on the 8×8 codec block grid. For a pixel next to a block border it compares the
     * step across the border (|p0-q0|) with the variation inside each side (|p1-p0|, |q1-q0|). A big
     * step between two flat sides is a block artifact and is smoothed; anything else is detail.
     * uParams = (alpha: max border step, beta: max inside variation, strength 0..1).
     */
    private const val DEBLOCK_SHADER = COMMON + """
vec3 deblockAxis(vec2 px, vec3 c, vec2 axis) {
  float pos = dot(px, axis);                 // coordinate along the axis (pixel centres at k+0.5)
  float border = floor(pos / 8.0 + 0.5) * 8.0;
  float d = pos - border;                    // -1.5, -0.5 (p1, p0) | 0.5, 1.5 (q0, q1)
  if (abs(d) > 1.6) return c;
  vec2 base = px - axis * d;                 // point on the border line
  vec3 p1 = at(base - axis * 1.5).rgb;
  vec3 p0 = at(base - axis * 0.5).rgb;
  vec3 q0 = at(base + axis * 0.5).rgb;
  vec3 q1 = at(base + axis * 1.5).rgb;
  float edgeStep = abs(luma(p0) - luma(q0));
  float flatP = abs(luma(p1) - luma(p0));
  float flatQ = abs(luma(q1) - luma(q0));
  float alpha = uParams.x;
  float beta = uParams.y;
  if (edgeStep < 0.5 / 255.0 || edgeStep > alpha || flatP > beta || flatQ > beta) return c;
  // the closer to the border, the stronger the smoothing
  vec3 target = abs(d) < 1.0
      ? (p1 + 2.0 * p0 + 2.0 * q0 + q1) / 6.0
      : (d < 0.0 ? (2.0 * p1 + p0 + q0) / 4.0 : (2.0 * q1 + q0 + p0) / 4.0);
  float amount = uParams.z * (1.0 - smoothstep(alpha * 0.6, alpha, edgeStep));
  return mix(c, target, amount);
}
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  vec3 r = deblockAxis(px, c.rgb, vec2(1.0, 0.0));  // vertical block borders
  r = deblockAxis(px, r, vec2(0.0, 1.0));           // horizontal block borders
  gl_FragColor = vec4(r, c.a);
}
"""

    /**
     * Deband: for several radii, picks 4 neighbours at a random angle. Luma and colour are handled
     * separately (colour bands are wider). Only where all neighbours are within the threshold - a
     * smooth gradient - the pixel moves towards their average. Darker areas use a slightly higher
     * threshold because banding there is most visible. uParams = (luma thr, chroma thr, max radius px).
     */
    private fun debandShader(iterations: Int) = COMMON + """
uniform float uFrame;
float rand(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 toYcc(vec3 c) {
  float y = luma(c);
  return vec3(y, (c.b - y) / 1.8556, (c.r - y) / 1.5748);
}
vec3 toRgb(vec3 v) {
  float r = v.x + 1.5748 * v.z;
  float b = v.x + 1.8556 * v.y;
  float g = (v.x - 0.2126 * r - 0.0722 * b) / 0.7152;
  return vec3(r, g, b);
}
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  vec3 ycc = toYcc(c.rgb);
  float darkBoost = 1.0 + 0.6 * (1.0 - smoothstep(0.05, 0.5, ycc.x));
  float thrY = uParams.x * darkBoost;
  float thrC = uParams.y;
  float smoothed = 0.0;
  vec3 result = ycc;
  for (int i = 1; i <= $iterations; i++) {
    float fi = float(i);
    float radius = uParams.z * (uTexSize.y / 1080.0) * fi / float($iterations);
    float ang = rand(vTexSamplingCoord + vec2(uFrame * 0.0137, fi * 0.31)) * 6.2831853;
    float dist = radius * mix(0.5, 1.0, rand(vTexSamplingCoord.yx + vec2(fi * 0.17, uFrame * 0.029)));
    vec2 o = vec2(cos(ang), sin(ang)) * dist;
    vec2 p = vec2(-o.y, o.x);
    vec3 a = toYcc(at(px + o).rgb);
    vec3 b = toYcc(at(px - o).rgb);
    vec3 cc = toYcc(at(px + p).rgb);
    vec3 d = toYcc(at(px - p).rgb);
    vec3 avg = (a + b + cc + d) * 0.25;
    vec3 diff = max(max(abs(a - ycc), abs(b - ycc)), max(abs(cc - ycc), abs(d - ycc)));
    float flatY = 1.0 - smoothstep(thrY * 0.5, thrY, diff.x);
    float flatC = 1.0 - smoothstep(thrC * 0.5, thrC, max(diff.y, diff.z));
    // a larger radius only counts if the area is flat that far out
    result.x = mix(result.x, avg.x, flatY);
    result.yz = mix(result.yz, avg.yz, flatC);
    smoothed = max(smoothed, flatY);
  }
  vec3 rgb = toRgb(result);
  float noise = (rand(vTexSamplingCoord * 1.73 + vec2(uFrame * 0.071, uFrame * 0.053)) - 0.5) * (1.5 / 255.0);
  gl_FragColor = vec4(rgb + noise * smoothed, c.a);
}
"""
}
