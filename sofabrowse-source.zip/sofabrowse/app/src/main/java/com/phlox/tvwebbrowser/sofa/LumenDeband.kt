package com.phlox.tvwebbrowser.sofa

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Lumen video clean-up for the built-in player. The player offers the anime deband (see
 * [Level]); the deblock and dering passes below are kept for possible later use.
 * Filters:
 *
 *  1. **Dering** (Strong): edge-preserving smoothing that removes "mosquito" noise and ringing
 *     around edges and text, without blurring the edges themselves.
 *  2. **Deblock** (Medium, Strong): finds the 8×8 block grid of the codec and smooths a step at a
 *     block border only when both sides of the border are flat - i.e. when the step is a
 *     compression artifact (macroblocking) and not a real edge.
 *  3. **Deband** (all levels): multi-radius, luma/chroma-aware smoothing of flat gradients with an
 *     adaptive threshold (stronger in dark areas where banding is most visible), plus fine dither
 *     so new steps don't appear.
 *
 * Every filter measures the local picture detail first and leaves textures and real edges alone,
 * so the picture is cleaned without looking soft.
 */
@OptIn(UnstableApi::class)
object LumenVideoCleanup {
    /**
     * Off; Anime = Hayase's settings; Strong = for heavily compressed streams; Compare = Strong on
     * the left half only, so the difference can be seen side by side.
     */
    enum class Level(val label: String) { OFF("Off"), ANIME("On"), STRONG("Strong"), COMPARE("Compare") }

    /** Frames that went through the filters (shown in the player to prove the filter really runs). */
    @Volatile var framesFiltered = 0L

    fun effectsFor(level: Level): List<Effect> = when (level) {
        Level.OFF -> emptyList()
        //anime: big flat areas and wide gradients -> wide search radius, 3 passes, firm colour
        //smoothing; dark outlines differ far more than the threshold, so line art stays crisp.
        //Radius is given for 1080p and scaled to the video's resolution in the shader.
        //first remove interlacing "comb" lines (only where they are found, so progressive video is
        //left untouched), then deband: the deband pass would otherwise smear the combs
        Level.ANIME -> listOf(
            CleanupEffect(DEINTERLACE_SHADER, floatArrayOf(2f / 255f, 6f / 255f, 2f / 255f)),
            CleanupEffect(mpvDebandShader(threshold = 88, range = 17, grain = 12, split = false), floatArrayOf(0f, 0f, 0f))
        )
        Level.STRONG -> listOf(
            CleanupEffect(DEINTERLACE_SHADER, floatArrayOf(2f / 255f, 6f / 255f, 2f / 255f)),
            CleanupEffect(mpvDebandShader(threshold = 200, range = 24, grain = 28, split = false), floatArrayOf(0f, 0f, 0f))
        )
        Level.COMPARE -> listOf(
            CleanupEffect(mpvDebandShader(threshold = 200, range = 24, grain = 28, split = true), floatArrayOf(0f, 0f, 0f))
        )
    }

    /** One GPU pass. [params] are passed to the shader as uParams (meaning depends on the pass). */
    private class CleanupEffect(private val fragmentShader: String, private val params: FloatArray) : GlEffect {
        override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
            CleanupShaderProgram(fragmentShader, params, useHdr)
    }

    private class CleanupShaderProgram(fragmentShader: String, params: FloatArray, useHdr: Boolean) :
        BaseGlShaderProgram(/* useHighPrecisionColorComponents= */ useHdr, /* texturePoolCapacity= */ 1) {

        private val glProgram: GlProgram
        private var frameIndex = 0f

        init {
            try {
                glProgram = GlProgram(VERTEX_SHADER, fragmentShader)
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e)
            }
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.setFloatsUniformIfPresent("uParams", params)
        }

        override fun configure(inputWidth: Int, inputHeight: Int): Size {
            glProgram.setFloatsUniformIfPresent("uTexSize", floatArrayOf(inputWidth.toFloat(), inputHeight.toFloat()))
            return Size(inputWidth, inputHeight)
        }

        override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
            try {
                glProgram.use()
                glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
                frameIndex = (frameIndex + 1f) % 1024f
                framesFiltered++
                glProgram.setFloatsUniformIfPresent("uFrame", floatArrayOf(frameIndex))
                glProgram.bindAttributesAndUniforms()
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e, presentationTimeUs)
            }
        }

        override fun release() {
            super.release()
            try {
                glProgram.delete()
            } catch (e: GlUtil.GlException) {
                throw VideoFrameProcessingException(e)
            }
        }
    }

    private const val VERTEX_SHADER = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

    private const val COMMON = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform vec2 uTexSize;
uniform vec3 uParams;
varying vec2 vTexSamplingCoord;
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }
"""

    /**
     * mpv's deband algorithm (as used by Hayase's "video-deband", MIT, github.com/ThaUnknown/video-deband):
     * for 4 growing radii, average 4 random samples around the pixel; where the pixel differs from
     * that average by less than a small threshold (a banding step), take the average. Then add fine
     * grain. [split]: only the left half is filtered (side-by-side comparison).
     */
    private fun mpvDebandShader(threshold: Int, range: Int, grain: Int, split: Boolean) = COMMON + """
uniform float uFrame;
#define THRESHOLD $threshold
#define RANGE $range
#define ITERATIONS 4
#define GRAIN $grain
#define SPLIT ${if (split) 1 else 0}
float mod289(float x)  { return x - floor(x / 289.0) * 289.0; }
float permute(float x) { return mod289((34.0 * x + 1.0) * x); }
float rand(float x)    { return fract(x / 41.0); }
vec4 average(vec2 pos, float range, inout float h) {
  float dist = rand(h) * range;     h = permute(h);
  float dir  = rand(h) * 6.2831853; h = permute(h);
  vec2 pt = dist / uTexSize;
  vec2 o = vec2(cos(dir), sin(dir));
  vec4 r0 = texture2D(uTexSampler, pos + pt * vec2( o.x,  o.y));
  vec4 r1 = texture2D(uTexSampler, pos + pt * vec2(-o.y,  o.x));
  vec4 r2 = texture2D(uTexSampler, pos + pt * vec2(-o.x, -o.y));
  vec4 r3 = texture2D(uTexSampler, pos + pt * vec2( o.y, -o.x));
  return (r0 + r1 + r2 + r3) * 0.25;
}
void main() {
  vec2 pos = vTexSamplingCoord;
  vec4 col = texture2D(uTexSampler, pos);
#if SPLIT
  if (pos.x > 0.5) {
    // divider line, then the untouched picture
    gl_FragColor = (pos.x - 0.5) * uTexSize.x < 2.0 ? vec4(1.0) : vec4(col.rgb, 1.0);
    return;
  }
#endif
  float random = fract(uFrame * 0.61803398875 + 0.1);
  vec3 m = vec3(pos, random) + vec3(1.0);
  float h = permute(permute(permute(m.x) + m.y) + m.z);
  for (int i = 1; i <= ITERATIONS; i++) {
    vec4 avg = average(pos, float(i * RANGE), h);
    vec4 diff = abs(col - avg);
    col = mix(avg, col, step(vec4(float(THRESHOLD) / (float(i) * 16384.0)), diff));
  }
  vec3 noise;
  noise.x = rand(h); h = permute(h);
  noise.y = rand(h); h = permute(h);
  noise.z = rand(h); h = permute(h);
  col.rgb += (float(GRAIN) / 8192.0) * (noise - vec3(0.5));
  gl_FragColor = vec4(col.rgb, 1.0);
}
"""

    /**
     * Adaptive comb/interlace remover. Interlaced or telecined anime (often a DVD/TV master) shows
     * fine horizontal lines on movement - brightness lines and, from the 4:2:0 colour, red/green
     * stripes twice as wide. When such a video was scaled up (480i → 720p/1080p) the lines are
     * scaled too, so they repeat every 2 lines at native size but every ~4.5 (brightness) and ~9
     * (colour) lines in a 1080p stream.
     * For several possible repeat distances P the shader measures how strongly the column of
     * pixels oscillates with exactly that period (phase independent: samples at P/4, P/2) and
     * checks that the pattern really repeats (same value P lines away). Where it does, the
     * oscillation is removed with a notch (½·x + ¼·(x[+P/2] + x[-P/2])), separately for brightness
     * and colour. Edges, thin lines, gradients and still areas don't oscillate and stay untouched.
     * uParams = (brightness threshold low, high, colour threshold).
     */
    private const val DEINTERLACE_SHADER = COMMON + """
void evalP(float p, vec2 px, float yc, vec3 cc, inout float bestY, inout float outY, inout float bestC, inout vec3 outC) {
  vec3 q1 = at(px + vec2(0.0, p * 0.25)).rgb;
  vec3 q2 = at(px - vec2(0.0, p * 0.25)).rgb;
  vec3 b1 = at(px + vec2(0.0, p * 0.5)).rgb;
  vec3 b2 = at(px - vec2(0.0, p * 0.5)).rgb;
  vec3 r1 = at(px + vec2(0.0, p)).rgb;
  vec3 r2 = at(px - vec2(0.0, p)).rgb;
  float lb1 = luma(b1); float lb2 = luma(b2);
  float lq1 = luma(q1); float lq2 = luma(q2);
  float lr1 = luma(r1); float lr2 = luma(r2);
  float ii = 0.5 * (yc - 0.5 * (lb1 + lb2));
  float qq = 0.5 * (lq1 - lq2);
  float amp = sqrt(ii * ii + qq * qq);
  float rep = max(abs(yc - lr1), abs(yc - lr2));
  float m = smoothstep(uParams.x, uParams.y, amp) * (1.0 - smoothstep(0.4, 0.8, rep / max(2.0 * amp, 0.004)));
  if (m * amp > bestY) { bestY = m * amp; outY = mix(yc, 0.5 * yc + 0.25 * (lb1 + lb2), m); }
  vec3 kb1 = b1 - vec3(lb1); vec3 kb2 = b2 - vec3(lb2);
  vec3 kq1 = q1 - vec3(lq1); vec3 kq2 = q2 - vec3(lq2);
  vec3 kr1 = r1 - vec3(lr1); vec3 kr2 = r2 - vec3(lr2);
  vec3 ic = 0.5 * (cc - 0.5 * (kb1 + kb2));
  vec3 qc = 0.5 * (kq1 - kq2);
  float ampC = sqrt(dot(ic, ic) + dot(qc, qc));
  float repC = max(length(cc - kr1), length(cc - kr2));
  float mc = smoothstep(uParams.z, uParams.z * 3.0, ampC) * (1.0 - smoothstep(0.4, 0.8, repC / max(2.0 * ampC, 0.004)));
  if (mc * ampC > bestC) { bestC = mc * ampC; outC = mix(cc, 0.5 * cc + 0.25 * (kb1 + kb2), mc); }
}
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c4 = at(px);
  float yc = luma(c4.rgb);
  vec3 cc = c4.rgb - vec3(yc);
  float bestY = 0.0; float outY = yc;
  float bestC = 0.0; vec3 outC = cc;
  evalP(2.0, px, yc, cc, bestY, outY, bestC, outC);
  evalP(2.5, px, yc, cc, bestY, outY, bestC, outC);
  evalP(3.0, px, yc, cc, bestY, outY, bestC, outC);
  evalP(3.75, px, yc, cc, bestY, outY, bestC, outC);
  evalP(4.0, px, yc, cc, bestY, outY, bestC, outC);
  evalP(4.5, px, yc, cc, bestY, outY, bestC, outC);
  evalP(5.0, px, yc, cc, bestY, outY, bestC, outC);
  evalP(6.0, px, yc, cc, bestY, outY, bestC, outC);
  evalP(7.5, px, yc, cc, bestY, outY, bestC, outC);
  evalP(9.0, px, yc, cc, bestY, outY, bestC, outC);
  gl_FragColor = vec4(vec3(outY) + outC, c4.a);
}
"""

    /**
     * Dering: 3×3 edge-preserving (bilateral) filter. Neighbours that differ a lot (real edges)
     * get almost no weight, small differences (mosquito noise, ringing) are averaged away.
     * uParams.x = range threshold.
     */
    private const val DERING_SHADER = COMMON + """
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  float sigma = uParams.x;
  vec3 sum = c.rgb;
  float wsum = 1.0;
  for (int dy = -1; dy <= 1; dy++) {
    for (int dx = -1; dx <= 1; dx++) {
      if (dx == 0 && dy == 0) continue;
      vec3 n = at(px + vec2(float(dx), float(dy))).rgb;
      float d = luma(n - c.rgb);
      float w = exp(-(d * d) / (2.0 * sigma * sigma)) * (dx == 0 || dy == 0 ? 1.0 : 0.7);
      sum += n * w;
      wsum += w;
    }
  }
  gl_FragColor = vec4(sum / wsum, c.a);
}
"""

    /**
     * Deblock: works on the 8×8 codec block grid. For a pixel next to a block border it compares the
     * step across the border (|p0-q0|) with the variation inside each side (|p1-p0|, |q1-q0|). A big
     * step between two flat sides is a block artifact and is smoothed; anything else is detail.
     * uParams = (alpha: max border step, beta: max inside variation, strength 0..1).
     */
    private const val DEBLOCK_SHADER = COMMON + """
vec3 deblockAxis(vec2 px, vec3 c, vec2 axis) {
  float pos = dot(px, axis);                 // coordinate along the axis (pixel centres at k+0.5)
  float border = floor(pos / 8.0 + 0.5) * 8.0;
  float d = pos - border;                    // -1.5, -0.5 (p1, p0) | 0.5, 1.5 (q0, q1)
  if (abs(d) > 1.6) return c;
  vec2 base = px - axis * d;                 // point on the border line
  vec3 p1 = at(base - axis * 1.5).rgb;
  vec3 p0 = at(base - axis * 0.5).rgb;
  vec3 q0 = at(base + axis * 0.5).rgb;
  vec3 q1 = at(base + axis * 1.5).rgb;
  float edgeStep = abs(luma(p0) - luma(q0));
  float flatP = abs(luma(p1) - luma(p0));
  float flatQ = abs(luma(q1) - luma(q0));
  float alpha = uParams.x;
  float beta = uParams.y;
  if (edgeStep < 0.5 / 255.0 || edgeStep > alpha || flatP > beta || flatQ > beta) return c;
  // the closer to the border, the stronger the smoothing
  vec3 target = abs(d) < 1.0
      ? (p1 + 2.0 * p0 + 2.0 * q0 + q1) / 6.0
      : (d < 0.0 ? (2.0 * p1 + p0 + q0) / 4.0 : (2.0 * q1 + q0 + p0) / 4.0);
  float amount = uParams.z * (1.0 - smoothstep(alpha * 0.6, alpha, edgeStep));
  return mix(c, target, amount);
}
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  vec3 r = deblockAxis(px, c.rgb, vec2(1.0, 0.0));  // vertical block borders
  r = deblockAxis(px, r, vec2(0.0, 1.0));           // horizontal block borders
  gl_FragColor = vec4(r, c.a);
}
"""

    /**
     * Deband: for several radii, picks 4 neighbours at a random angle. Luma and colour are handled
     * separately (colour bands are wider). Only where all neighbours are within the threshold - a
     * smooth gradient - the pixel moves towards their average. Darker areas use a slightly higher
     * threshold because banding there is most visible. uParams = (luma thr, chroma thr, max radius px).
     */
    private fun debandShader(iterations: Int) = COMMON + """
uniform float uFrame;
float rand(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 toYcc(vec3 c) {
  float y = luma(c);
  return vec3(y, (c.b - y) / 1.8556, (c.r - y) / 1.5748);
}
vec3 toRgb(vec3 v) {
  float r = v.x + 1.5748 * v.z;
  float b = v.x + 1.8556 * v.y;
  float g = (v.x - 0.2126 * r - 0.0722 * b) / 0.7152;
  return vec3(r, g, b);
}
void main() {
  vec2 px = vTexSamplingCoord * uTexSize;
  vec4 c = at(px);
  vec3 ycc = toYcc(c.rgb);
  float darkBoost = 1.0 + 0.6 * (1.0 - smoothstep(0.05, 0.5, ycc.x));
  float thrY = uParams.x * darkBoost;
  float thrC = uParams.y;
  float smoothed = 0.0;
  vec3 result = ycc;
  for (int i = 1; i <= $iterations; i++) {
    float fi = float(i);
    float radius = uParams.z * (uTexSize.y / 1080.0) * fi / float($iterations);
    float ang = rand(vTexSamplingCoord + vec2(uFrame * 0.0137, fi * 0.31)) * 6.2831853;
    float dist = radius * mix(0.5, 1.0, rand(vTexSamplingCoord.yx + vec2(fi * 0.17, uFrame * 0.029)));
    vec2 o = vec2(cos(ang), sin(ang)) * dist;
    vec2 p = vec2(-o.y, o.x);
    vec3 a = toYcc(at(px + o).rgb);
    vec3 b = toYcc(at(px - o).rgb);
    vec3 cc = toYcc(at(px + p).rgb);
    vec3 d = toYcc(at(px - p).rgb);
    vec3 avg = (a + b + cc + d) * 0.25;
    vec3 diff = max(max(abs(a - ycc), abs(b - ycc)), max(abs(cc - ycc), abs(d - ycc)));
    float flatY = 1.0 - smoothstep(thrY * 0.5, thrY, diff.x);
    float flatC = 1.0 - smoothstep(thrC * 0.5, thrC, max(diff.y, diff.z));
    // a larger radius only counts if the area is flat that far out
    result.x = mix(result.x, avg.x, flatY);
    result.yz = mix(result.yz, avg.yz, flatC);
    smoothed = max(smoothed, flatY);
  }
  vec3 rgb = toRgb(result);
  float noise = (rand(vTexSamplingCoord * 1.73 + vec2(uFrame * 0.071, uFrame * 0.053)) - 0.5) * (1.5 / 255.0);
  gl_FragColor = vec4(rgb + noise * smoothed, c.a);
}
"""
}
