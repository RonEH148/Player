package com.phlox.tvwebbrowser.sofa

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * GPU deband filter for the built-in player (similar in spirit to mpv's "deband").
 *
 * For every pixel it looks at four neighbours at a random angle and distance. If they all differ
 * from the pixel by less than a small threshold, the area is a smooth gradient and the pixel is
 * replaced by their average - which melts the visible steps ("banding") in skies, shadows and dark
 * scenes. Real edges and detail differ by more than the threshold and are left alone. A tiny amount
 * of dither noise is added so new steps don't appear.
 */
@OptIn(UnstableApi::class)
class LumenDeband : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        DebandShaderProgram(useHdr)
}

@OptIn(UnstableApi::class)
private class DebandShaderProgram(useHdr: Boolean) :
    BaseGlShaderProgram(/* useHighPrecisionColorComponents= */ useHdr, /* texturePoolCapacity= */ 1) {

    private val glProgram: GlProgram
    private var frameIndex = 0f

    init {
        try {
            glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
        //draw on the whole normalized device coordinate space (-1..1)
        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        glProgram.setFloatsUniform("uTexelSize", floatArrayOf(1f / inputWidth, 1f / inputHeight))
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, /* texUnitIndex= */ 0)
            //changes the random pattern every frame so the dither looks like fine film grain
            frameIndex = (frameIndex + 1f) % 1024f
            glProgram.setFloatUniform("uFrame", frameIndex)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

        private const val FRAGMENT_SHADER = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform vec2 uTexelSize;
uniform float uFrame;
varying vec2 vTexSamplingCoord;

float rand(vec2 co) {
  return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec4 center = texture2D(uTexSampler, uv);
  // random direction and distance (4..16 px) per pixel and frame
  float r1 = rand(uv + vec2(uFrame * 0.0137, 0.31));
  float r2 = rand(uv.yx + vec2(0.71, uFrame * 0.0291));
  float angle = r1 * 6.2831853;
  float dist = mix(4.0, 16.0, r2);
  vec2 o = vec2(cos(angle), sin(angle)) * dist * uTexelSize;
  vec2 p = vec2(-o.y, o.x);
  vec3 a = texture2D(uTexSampler, uv + o).rgb;
  vec3 b = texture2D(uTexSampler, uv - o).rgb;
  vec3 c = texture2D(uTexSampler, uv + p).rgb;
  vec3 d = texture2D(uTexSampler, uv - p).rgb;
  vec3 avg = (a + b + c + d) * 0.25;
  vec3 maxDiff = max(max(abs(a - center.rgb), abs(b - center.rgb)), max(abs(c - center.rgb), abs(d - center.rgb)));
  float threshold = 3.0 / 255.0;
  float m = max(maxDiff.r, max(maxDiff.g, maxDiff.b));
  // smooth transition between "flat area" (use average) and "detail" (keep pixel)
  float flatness = 1.0 - smoothstep(threshold * 0.5, threshold, m);
  vec3 color = mix(center.rgb, avg, flatness);
  // light dither only where smoothing happened
  float noise = (rand(uv * 1.73 + vec2(uFrame * 0.071, uFrame * 0.053)) - 0.5) * (1.5 / 255.0);
  gl_FragColor = vec4(color + noise * flatness, center.a);
}
"""
    }
}
