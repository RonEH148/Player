/*
 * SofaBrowse page enhancements (runs in every frame at document start when supported).
 * Features: cosmetic ad hiding, pop-up blocking, TV video controls (skip / speed /
 * quality / deinterlace), automatic highest video quality, forced dark mode.
 * Based on TV Bro (https://github.com/truefedex/tv-bro).
 */
(function () {
    'use strict';
    if (window.__sofaInstalled) return;
    window.__sofaInstalled = true;

    var host = location.hostname || '';
    // Never touch human-verification frames: modifying them makes checks fail.
    if (/(^|\.)challenges\.cloudflare\.com$/.test(host) || /(^|\.)hcaptcha\.com$/.test(host) ||
        location.pathname.indexOf('/cdn-cgi/challenge-platform') === 0 ||
        location.pathname.indexOf('/recaptcha/') === 0) {
        return;
    }

    // ---------------- settings ----------------
    var cfg = window.__sofaCfg || {};
    try {
        if (window.TVBro && typeof TVBro.sofaSettings === 'function') {
            var live = JSON.parse(TVBro.sofaSettings());
            if (live && typeof live === 'object') cfg = live;
        }
    } catch (e) { /* use embedded settings */ }

    var isTop = (window.top === window);
    var origOpen = window.open;
    var challengePage = false;

    function isChallengePage() {
        try {
            if (window._cf_chl_opt) return true;
            var t = (document.title || '').toLowerCase();
            if (t.indexOf('just a moment') === 0 || t.indexOf('attention required') === 0) return true;
            if (document.querySelector('#challenge-form, #challenge-running, .cf-turnstile, iframe[src*="challenges.cloudflare.com"]')) {
                // a Turnstile widget inside a normal page is fine; only the full interstitial matters
                return !!document.querySelector('#challenge-form, #challenge-running') || t.indexOf('just a moment') !== -1;
            }
        } catch (e) {}
        return false;
    }

    function onReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    }

    function addStyle(id, css) {
        var root = document.head || document.documentElement;
        if (!root) return null;
        var el = document.getElementById(id);
        if (!el) {
            el = document.createElement('style');
            el.id = id;
            root.appendChild(el);
        }
        el.textContent = css;
        return el;
    }

    // ---------------- pop-up blocker ----------------
    var lastClick = { time: 0, href: null };
    var isAppHomePage = location.href.indexOf('https://tvbro.phlox.dev/appcontent/home') === 0;
    if (cfg.popups && !isAppHomePage) {
        document.addEventListener('click', function (e) {
            if (!e.isTrusted) return;
            lastClick.time = Date.now();
            var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
            lastClick.href = a ? a.href : null;
        }, true);

        // sign-in and payment pop-ups opened by buttons must keep working
        var POPUP_ALLOW = /(^|\.)(accounts\.google\.com|appleid\.apple\.com|facebook\.com|login\.microsoftonline\.com|login\.live\.com|github\.com|x\.com|twitter\.com|paypal\.com|discord\.com|amazon\.[a-z.]+|steamcommunity\.com)$/i;
        var allowedHost = function (url) {
            try { return POPUP_ALLOW.test(new URL(url, location.href).hostname); } catch (e) { return false; }
        };

        var sameSite = function (url) {
            try {
                var u = new URL(url, location.href);
                var a = u.hostname.split('.').slice(-2).join('.');
                var b = location.hostname.split('.').slice(-2).join('.');
                return a === b;
            } catch (e) { return false; }
        };

        window.open = function (url, target, features) {
            if (challengePage) return origOpen.apply(window, arguments);
            // opening in the same tab is navigation, not a pop-up (used e.g. by the home page search)
            var t = (target || '').toLowerCase();
            if (t === '_self' || t === '_top' || t === '_parent') return origOpen.apply(window, arguments);
            var recentClick = (Date.now() - lastClick.time) < 1500;
            var full = '';
            try { full = url ? new URL(url, location.href).href : ''; } catch (e) {}
            var clickedThatLink = lastClick.href && full && lastClick.href === full;
            if (!recentClick || (!sameSite(full || location.href) && !clickedThatLink && !allowedHost(full))) {
                console.log('SofaBrowse blocked pop-up: ' + full);
                return null;
            }
            return origOpen.apply(window, arguments);
        };

        // pop-under links: invisible full-page anchors that open ads in a new tab
        document.addEventListener('click', function (e) {
            if (challengePage) return;
            var a = e.target && e.target.closest ? e.target.closest('a[target="_blank"]') : null;
            if (!a || sameSite(a.href)) return;
            var r = a.getBoundingClientRect();
            var hugeInvisible = r.width >= window.innerWidth * 0.8 && r.height >= window.innerHeight * 0.6 &&
                (a.textContent || '').trim().length === 0 && !a.querySelector('img,video,picture');
            if (hugeInvisible) {
                e.preventDefault();
                e.stopPropagation();
                a.remove();
                console.log('SofaBrowse blocked pop-under link: ' + a.href);
            }
        }, true);
    }

    // ---------------- cosmetic ad hiding ----------------
    var AD_SELECTORS = [
        'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="div-gpt-ad"]',
        'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
        'iframe[src*="amazon-adsystem.com"]', 'iframe[src*="adnxs.com"]', 'iframe[src*="taboola.com"]',
        'amp-ad', 'amp-embed[type="taboola"]', '[data-ad-slot]', '[data-ad-unit]', '[data-adunit]',
        '[id^="taboola-"]', '.trc_related_container', '.OUTBRAIN', '[data-widget-id^="AR_"]',
        '.ad-banner', '.ad-container', '.ad-wrapper', '.ad-slot', '.ad-unit', '.ad_unit', '.adBanner',
        '.advertisement', '.advert', '.sponsored-ad', '.banner-ad', '.sticky-ad', '.ad-sticky',
        '#ad-banner', '#ad_banner', '#adContainer', '#sticky-ad', '[aria-label="Advertisement"]',
        'a[href*="doubleclick.net/"]', 'a[href*="/aclk?"]'
    ];

    function removeAntiAdblockOverlays() {
        var re = /ad.?block|disable your ad|turn off your ad|whitelist (our|this) site|adblocker detected/i;
        var nodes = document.querySelectorAll('body > div, body > section, body > aside');
        for (var i = 0; i < nodes.length; i++) {
            var el = nodes[i];
            var st = getComputedStyle(el);
            if (st.position !== 'fixed' && st.position !== 'absolute') continue;
            var r = el.getBoundingClientRect();
            if (r.width < window.innerWidth * 0.5 || r.height < window.innerHeight * 0.4) continue;
            if (!re.test((el.innerText || '').slice(0, 2000))) continue;
            el.remove();
            [document.documentElement, document.body].forEach(function (n) {
                if (!n) return;
                n.style.setProperty('overflow', 'auto', 'important');
                n.style.removeProperty('position');
            });
        }
    }

    if (cfg.cosmetic) {
        onReady(function () {
            if (challengePage) return;
            addStyle('sofa-cosmetic', AD_SELECTORS.join(',\n') +
                ' { display: none !important; visibility: hidden !important; }');
            if (isTop) {
                setTimeout(removeAntiAdblockOverlays, 1500);
                setTimeout(removeAntiAdblockOverlays, 5000);
            }
        });
    }

    // ---------------- forced dark mode ----------------
    function luminance(color) {
        var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(color || '');
        if (!m) return -1;
        if (m[4] !== undefined && parseFloat(m[4]) === 0) return -1; // transparent
        return (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255;
    }

    if (cfg.dark && isTop) {
        onReady(function () {
            if (challengePage) return;
            var bg = luminance(getComputedStyle(document.body || document.documentElement).backgroundColor);
            if (bg === -1) bg = luminance(getComputedStyle(document.documentElement).backgroundColor);
            if (bg !== -1 && bg < 0.45) return; // page is already dark
            addStyle('sofa-dark',
                'html.sofa-dark { filter: invert(1) hue-rotate(180deg) !important; background: #fff !important; }\n' +
                'html.sofa-dark img, html.sofa-dark video, html.sofa-dark picture, html.sofa-dark canvas,' +
                ' html.sofa-dark iframe, html.sofa-dark embed, html.sofa-dark object,' +
                ' html.sofa-dark [style*="background-image"], html.sofa-dark .sofa-player-bar' +
                ' { filter: invert(1) hue-rotate(180deg) !important; }\n' +
                'html.sofa-dark picture img, html.sofa-dark picture video { filter: none !important; }');
            document.documentElement.classList.add('sofa-dark');
            document.addEventListener('fullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.fullscreenElement);
            });
            document.addEventListener('webkitfullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.webkitFullscreenElement);
            });
        });
    }

    // ---------------- highest quality ----------------
    function pickHighestIndex(levels, getHeight, getBitrate) {
        var best = -1, bestH = -1, bestB = -1;
        for (var i = 0; i < levels.length; i++) {
            var h = getHeight(levels[i]) || 0;
            var b = getBitrate(levels[i]) || 0;
            if (h > bestH || (h === bestH && b > bestB)) { best = i; bestH = h; bestB = b; }
        }
        return best;
    }

    function labelHeight(label) {
        var m = /(\d{3,4})\s*p/i.exec(label || '');
        if (m) return parseInt(m[1], 10);
        if (/4k|uhd|2160/i.test(label || '')) return 2160;
        if (/hd/i.test(label || '')) return 720;
        return 0;
    }

    function patchHls(H) {
        if (!H || !H.prototype || H.prototype.__sofaPatched) return;
        H.prototype.__sofaPatched = true;
        var origLoad = H.prototype.loadSource;
        if (typeof origLoad !== 'function') return;
        H.prototype.loadSource = function () {
            var hls = this;
            try {
                if (!hls.__sofaHooked && cfg.maxQuality && hls.on && H.Events) {
                    hls.__sofaHooked = true;
                    hls.on(H.Events.MANIFEST_PARSED, function () {
                        try {
                            var idx = pickHighestIndex(hls.levels || [],
                                function (l) { return l.height; }, function (l) { return l.bitrate; });
                            if (idx >= 0) {
                                hls.autoLevelCapping = -1;
                                hls.currentLevel = idx;
                                hls.loadLevel = idx;
                            }
                        } catch (e) {}
                    });
                }
            } catch (e) {}
            return origLoad.apply(this, arguments);
        };
    }

    function patchShaka(shaka) {
        if (!shaka || !shaka.Player || !shaka.Player.prototype || shaka.Player.prototype.__sofaPatched) return;
        var P = shaka.Player.prototype;
        P.__sofaPatched = true;
        var origLoad = P.load;
        if (typeof origLoad !== 'function') return;
        P.load = function () {
            var player = this;
            var result = origLoad.apply(this, arguments);
            var apply = function () {
                if (!cfg.maxQuality) return;
                try {
                    var tracks = player.getVariantTracks();
                    var idx = pickHighestIndex(tracks, function (t) { return t.height; }, function (t) { return t.bandwidth; });
                    if (idx >= 0) {
                        player.configure({ abr: { enabled: false } });
                        player.selectVariantTrack(tracks[idx], true);
                    }
                } catch (e) {}
            };
            if (result && typeof result.then === 'function') result.then(apply, function () {});
            else setTimeout(apply, 2000);
            return result;
        };
    }

    function patchDash(dashjs) {
        if (!dashjs || typeof dashjs.MediaPlayer !== 'function' || dashjs.MediaPlayer.__sofaPatched) return;
        var origFactory = dashjs.MediaPlayer;
        var wrapped = function () {
            var f = origFactory.apply(this, arguments);
            try {
                var origCreate = f.create;
                f.create = function () {
                    var p = origCreate.apply(this, arguments);
                    try {
                        p.on('streamInitialized', function () {
                            if (!cfg.maxQuality) return;
                            try {
                                p.updateSettings({ streaming: { abr: { autoSwitchBitrate: { video: false } } } });
                                if (typeof p.getBitrateInfoListFor === 'function') { // dash.js v3/v4
                                    var list = p.getBitrateInfoListFor('video') || [];
                                    var i = pickHighestIndex(list, function (l) { return l.height; }, function (l) { return l.bitrate; });
                                    if (i >= 0) p.setQualityFor('video', i, true);
                                } else if (typeof p.getRepresentationsByType === 'function') { // dash.js v5
                                    var reps = p.getRepresentationsByType('video') || [];
                                    var j = pickHighestIndex(reps, function (l) { return l.height; }, function (l) { return l.bandwidth; });
                                    if (j >= 0) p.setRepresentationForTypeByIndex('video', j, true);
                                }
                            } catch (e) {}
                        });
                    } catch (e) {}
                    return p;
                };
            } catch (e) {}
            return f;
        };
        for (var k in origFactory) { try { wrapped[k] = origFactory[k]; } catch (e) {} }
        wrapped.__sofaPatched = true;
        try { dashjs.MediaPlayer = wrapped; } catch (e) {}
    }

    function hookGlobal(name, patcher) {
        try {
            var current = window[name];
            if (current) { patcher(current); return; }
            var desc = Object.getOwnPropertyDescriptor(window, name);
            if (desc && !desc.configurable) return;
            var value;
            Object.defineProperty(window, name, {
                configurable: true,
                enumerable: true,
                get: function () { return value; },
                set: function (v) { value = v; try { patcher(v); } catch (e) {} }
            });
        } catch (e) {}
    }

    function applyPlayerApiQuality() {
        if (!cfg.maxQuality) return;
        // YouTube (desktop, mobile and embeds)
        try {
            var yt = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
            if (yt && typeof yt.getAvailableQualityLevels === 'function') {
                var levels = yt.getAvailableQualityLevels().filter(function (q) { return q !== 'auto'; });
                var key = levels[0] + '|' + location.href;
                if (levels.length && yt.__sofaQ !== key) {
                    if (typeof yt.setPlaybackQualityRange === 'function') yt.setPlaybackQualityRange(levels[0], levels[0]);
                    if (typeof yt.setPlaybackQuality === 'function') yt.setPlaybackQuality(levels[0]);
                    yt.__sofaQ = key;
                }
            }
        } catch (e) {}
        // JW Player
        try {
            if (typeof window.jwplayer === 'function') {
                var jw = window.jwplayer();
                if (jw && typeof jw.getQualityLevels === 'function') {
                    var q = jw.getQualityLevels() || [];
                    var idx = pickHighestIndex(q, function (l) { return l.height || labelHeight(l.label); },
                        function (l) { return l.bitrate; });
                    if (idx >= 0 && jw.getCurrentQuality() !== idx) jw.setCurrentQuality(idx);
                }
            }
        } catch (e) {}
        // Video.js (quality-levels plugin)
        try {
            if (window.videojs && typeof window.videojs.getPlayers === 'function') {
                var players = window.videojs.getPlayers();
                Object.keys(players).forEach(function (id) {
                    var p = players[id];
                    if (!p || typeof p.qualityLevels !== 'function') return;
                    var ql = p.qualityLevels();
                    if (!ql || !ql.length) return;
                    var arr = [];
                    for (var i = 0; i < ql.length; i++) arr.push(ql[i]);
                    var best = pickHighestIndex(arr, function (l) { return l.height; }, function (l) { return l.bitrate; });
                    for (var j = 0; j < arr.length; j++) arr[j].enabled = (j === best);
                });
            }
        } catch (e) {}
        // Plyr
        try {
            var plyrEls = document.querySelectorAll('.plyr');
            for (var n = 0; n < plyrEls.length; n++) {
                var pl = plyrEls[n].plyr;
                if (pl && pl.options && pl.options.quality && pl.options.quality.length) {
                    var max = Math.max.apply(null, pl.options.quality.map(Number).filter(isFinite));
                    if (isFinite(max) && pl.quality !== max) pl.quality = max;
                }
            }
        } catch (e) {}
        // late-loaded libraries
        try { patchHls(window.Hls); } catch (e) {}
        try { patchShaka(window.shaka); } catch (e) {}
    }

    if (cfg.maxQuality) {
        hookGlobal('Hls', patchHls);
        hookGlobal('shaka', patchShaka);
        hookGlobal('dashjs', patchDash);
    }

    // ---------------- media helpers ----------------
    function allMedia() {
        var list = Array.prototype.slice.call(document.querySelectorAll('video, audio'));
        // same-origin iframes
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try {
                var d = frames[i].contentDocument;
                if (d) list = list.concat(Array.prototype.slice.call(d.querySelectorAll('video, audio')));
            } catch (e) {}
        }
        return list;
    }

    function isPlaying(m) {
        return m.currentTime > 0 && !m.paused && !m.ended && m.readyState > 2;
    }

    function bestMedia() {
        var list = allMedia();
        var best = null, bestScore = -1;
        list.forEach(function (m) {
            var r = m.getBoundingClientRect();
            var area = Math.max(0, r.width) * Math.max(0, r.height);
            var score = area + (isPlaying(m) ? 1e9 : 0) + (m.tagName === 'VIDEO' ? 1 : 0);
            if (score > bestScore) { best = m; bestScore = score; }
        });
        return best;
    }

    var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    function mediaCommand(cmd, m) {
        m = m || bestMedia();
        if (!m) return false;
        switch (cmd) {
            case 'toggle': if (m.paused || m.ended) m.play(); else m.pause(); break;
            case 'stop': m.pause(); m.currentTime = 0; break;
            case 'rewind': m.currentTime = Math.max(0, m.currentTime - 10); break;
            case 'forward': m.currentTime = m.currentTime + 10; break;
            case 'speed':
                var i = SPEEDS.indexOf(m.playbackRate);
                m.playbackRate = SPEEDS[(i + 1) % SPEEDS.length] || 1;
                break;
        }
        return true;
    }

    // Called by remote-control media keys (see generic_injects.js). Falls back to
    // asking cross-origin iframes (video embeds) to handle the command.
    window.__sofaMedia = function (cmd) {
        if (mediaCommand(cmd)) return true;
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'media', cmd: cmd }, '*'); } catch (e) {}
        }
        return true;
    };

    window.addEventListener('message', function (e) {
        var d = e.data;
        if (!d || d.__sofa !== 'media') return;
        if (!mediaCommand(d.cmd)) {
            var frames = document.querySelectorAll('iframe');
            for (var i = 0; i < frames.length; i++) {
                try { frames[i].contentWindow.postMessage(d, '*'); } catch (err) {}
            }
        }
    });

    // ---------------- deinterlace ----------------
    var deinterlace = !!cfg.deinterlace;

    function ensureDeinterlaceFilter(doc) {
        if (doc.getElementById('sofa-deint-svg')) return;
        var ns = 'http://www.w3.org/2000/svg';
        var svg = doc.createElementNS(ns, 'svg');
        svg.setAttribute('id', 'sofa-deint-svg');
        svg.setAttribute('width', '0');
        svg.setAttribute('height', '0');
        svg.setAttribute('aria-hidden', 'true');
        svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
        // "blend" deinterlacing: mix every line with its neighbours (1/4, 1/2, 1/4)
        svg.innerHTML = '<filter id="sofa-deint" x="0" y="0" width="1" height="1" color-interpolation-filters="sRGB">' +
            '<feConvolveMatrix order="1 3" kernelMatrix="0.25 0.5 0.25" divisor="1" preserveAlpha="true" edgeMode="duplicate"/>' +
            '</filter>';
        (doc.body || doc.documentElement).appendChild(svg);
    }

    function applyDeinterlace(v) {
        if (!v || v.tagName !== 'VIDEO') return;
        if (deinterlace) {
            ensureDeinterlaceFilter(v.ownerDocument);
            v.style.setProperty('filter', 'url(#sofa-deint)', 'important');
        } else if (v.style.getPropertyValue('filter').indexOf('sofa-deint') !== -1) {
            v.style.removeProperty('filter');
        }
    }

    // ---------------- TV video controls ----------------
    var bar = null, barVideo = null, hideTimer = null, labels = {};

    function fmtSpeed(r) { return (Math.round(r * 100) / 100) + 'x'; }

    function qualityLabel(v) {
        var h = v && v.videoHeight;
        return h ? (h >= 2160 ? '4K' : h + 'p') : '—';
    }

    function buildBar() {
        bar = document.createElement('div');
        bar.className = 'sofa-player-bar';
        bar.setAttribute('data-sofa', '1');
        addStyle('sofa-player-style',
            '.sofa-player-bar{position:fixed;left:50%;bottom:6vh;transform:translateX(-50%);z-index:2147483647;' +
            'display:flex;flex-wrap:wrap;justify-content:center;max-width:94vw;box-sizing:border-box;gap:10px;padding:10px 14px;border-radius:18px;background:rgba(18,18,22,.86);' +
            'box-shadow:0 8px 30px rgba(0,0,0,.45);font:600 18px/1 system-ui,Roboto,sans-serif;color:#fff;' +
            'opacity:0;pointer-events:none;transition:opacity .2s ease;}' +
            '.sofa-player-bar.sofa-show{opacity:1;pointer-events:auto;}' +
            '.sofa-player-bar button{all:unset;cursor:pointer;min-width:58px;padding:12px 14px;border-radius:12px;' +
            'text-align:center;background:rgba(255,255,255,.08);color:#fff;font:600 18px/1 system-ui,Roboto,sans-serif;}' +
            '.sofa-player-bar button:hover,.sofa-player-bar button:focus{background:#ff7a45;color:#fff;}' +
            '.sofa-player-bar button.sofa-on{background:#d6336c;}' +
            '.sofa-player-bar small{display:block;font-size:12px;opacity:.75;margin-top:4px;font-weight:500;}');

        function btn(key, text, title, onClick) {
            var b = document.createElement('button');
            b.type = 'button';
            b.title = title;
            b.innerHTML = text;
            ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'dblclick'].forEach(function (ev) {
                b.addEventListener(ev, function (e) {
                    e.stopPropagation();
                    if (ev === 'click') { e.preventDefault(); onClick(); refreshBar(); showBar(); }
                }, true);
            });
            labels[key] = b;
            bar.appendChild(b);
            return b;
        }

        btn('back', '⏪<small>10s</small>', 'Back 10 seconds', function () { mediaCommand('rewind', barVideo); });
        btn('play', '⏯<small>play</small>', 'Play / pause', function () { mediaCommand('toggle', barVideo); });
        btn('fwd', '⏩<small>10s</small>', 'Forward 10 seconds', function () { mediaCommand('forward', barVideo); });
        btn('speed', '1x<small>speed</small>', 'Playback speed', function () { mediaCommand('speed', barVideo); });
        btn('quality', '—<small>quality</small>', 'Switch to highest quality', function () {
            var saved = cfg.maxQuality; cfg.maxQuality = true;
            var yt = document.getElementById('movie_player'); if (yt) yt.__sofaQ = null;
            applyPlayerApiQuality();
            cfg.maxQuality = saved;
        });
        btn('native', '4K<small>TV player</small>', 'Play in the native 4K / HDR player (uses the TV hardware)', function () {
            handOff('native');
        });
        btn('external', '↗<small>other app</small>', 'Open in another video player app', function () {
            handOff('external');
        });
        btn('deint', 'Off<small>deinterlace</small>', 'Deinterlace (blend) filter', function () {
            deinterlace = !deinterlace;
            allMedia().forEach(applyDeinterlace);
            try { if (window.TVBro && TVBro.sofaSetDeinterlace) TVBro.sofaSetDeinterlace(deinterlace); } catch (e) {}
        });

        bar.addEventListener('mousemove', function () { showBar(); });
    }

    function handOff(mode) {
        var v = barVideo;
        if (!v || !(window.TVBro && TVBro.sofaOpenVideo)) return;
        var src = v.currentSrc || v.src || '';
        if (!src) {
            var source = v.querySelector('source[src]');
            if (source) src = source.src;
        }
        var title = '';
        try { title = (window.top === window ? document.title : '') || ''; } catch (e) {}
        try { v.pause(); } catch (e) {}
        TVBro.sofaOpenVideo(mode, src, location.href, title, v.currentTime || 0);
    }

    function refreshBar() {
        if (!bar || !barVideo) return;
        labels.play.innerHTML = (barVideo.paused ? '▶' : '⏸') + '<small>' + (barVideo.paused ? 'play' : 'pause') + '</small>';
        labels.speed.innerHTML = fmtSpeed(barVideo.playbackRate) + '<small>speed</small>';
        labels.quality.innerHTML = qualityLabel(barVideo) + '<small>quality</small>';
        labels.deint.innerHTML = (deinterlace ? 'On' : 'Off') + '<small>deinterlace</small>';
        labels.deint.classList.toggle('sofa-on', deinterlace);
    }

    function barParent() {
        var fs = document.fullscreenElement || document.webkitFullscreenElement;
        if (fs && fs.tagName !== 'VIDEO') return fs;
        return document.body || document.documentElement;
    }

    function showBar() {
        if (!cfg.overlay || !barVideo || challengePage) return;
        if (!bar) buildBar();
        var parent = barParent();
        if (bar.parentNode !== parent) parent.appendChild(bar);
        refreshBar();
        bar.classList.add('sofa-show');
        clearTimeout(hideTimer);
        hideTimer = setTimeout(function () {
            if (bar && !bar.matches(':hover')) bar.classList.remove('sofa-show');
            else if (bar) showBar();
        }, 3500);
    }

    function isOverVideo(v, x, y) {
        var r = v.getBoundingClientRect();
        return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    }

    function trackVideo(v) {
        if (!v || v.tagName !== 'VIDEO') return;
        applyDeinterlace(v);
        if (v.__sofaTracked) return;
        v.__sofaTracked = true;
        ['ratechange', 'pause', 'play', 'resize', 'loadedmetadata'].forEach(function (ev) {
            v.addEventListener(ev, function () { if (barVideo === v) refreshBar(); });
        });
    }

    document.addEventListener('play', function (e) {
        var v = e.target;
        if (!v || v.tagName !== 'VIDEO') return;
        trackVideo(v);
        var r = v.getBoundingClientRect();
        if (r.width < 200 || r.height < 120) return; // ignore tiny preview clips
        barVideo = v;
        applyPlayerApiQuality();
        setTimeout(applyPlayerApiQuality, 1500);
        setTimeout(applyPlayerApiQuality, 5000);
        showBar();
    }, true);

    document.addEventListener('loadedmetadata', function (e) {
        if (e.target && e.target.tagName === 'VIDEO') trackVideo(e.target);
    }, true);

    var onPointer = function (e) {
        if (!barVideo || !cfg.overlay) return;
        var x = e.clientX, y = e.clientY;
        if (e.touches && e.touches[0]) { x = e.touches[0].clientX; y = e.touches[0].clientY; }
        if (x === undefined) return;
        var fs = document.fullscreenElement || document.webkitFullscreenElement;
        if (fs || isOverVideo(barVideo, x, y)) showBar();
    };
    document.addEventListener('mousemove', onPointer, true);
    document.addEventListener('pointermove', onPointer, true);
    document.addEventListener('touchstart', onPointer, true);
    document.addEventListener('fullscreenchange', function () { if (barVideo) showBar(); });
    document.addEventListener('webkitfullscreenchange', function () { if (barVideo) showBar(); });

    // ---------------- passwords ----------------
    function visible(el) {
        if (!el) return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    }

    function findUserField(pass) {
        var scope = pass.form || document;
        var inputs = Array.prototype.slice.call(scope.querySelectorAll(
            'input[type=email], input[type=text], input[type=tel], input:not([type]), input[autocomplete=username]'));
        var before = inputs.filter(function (i) {
            return visible(i) && (pass.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_PRECEDING);
        });
        var pick = before.length ? before[before.length - 1] : inputs.filter(visible)[0];
        return pick || null;
    }

    var lastOffer = 0;
    function captureLogin(scope) {
        if (!cfg.passwords || !isTop || !/^https?:$/.test(location.protocol)) return;
        var passes = Array.prototype.slice.call((scope || document).querySelectorAll('input[type=password]'))
            .filter(function (p) { return p.value; });
        if (!passes.length) return;
        if (passes.length > 1) return; // sign-up or change-password forms: don't offer
        if (Date.now() - lastOffer < 3000) return;
        lastOffer = Date.now();
        var pass = passes[0];
        var user = findUserField(pass);
        try { TVBro.sofaOfferSaveLogin(user ? user.value : '', pass.value); } catch (e) {}
    }

    if (isTop) {
        document.addEventListener('submit', function (e) { captureLogin(e.target); }, true);
        document.addEventListener('click', function (e) {
            var b = e.target && e.target.closest ? e.target.closest('button, input[type=submit], [role=button]') : null;
            if (!b) return;
            var form = b.form || b.closest('form');
            setTimeout(function () { captureLogin(form || document); }, 0);
        }, true);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && e.target && e.target.type === 'password') captureLogin(e.target.form || document);
        }, true);

        // Called by the app with the login saved for this site. Fills visible fields,
        // also ones that appear later (sign-in dialogs), for up to one minute.
        window.__sofaFill = function (username, password) {
            var done = false;
            var setValue = function (el, value) {
                var proto = Object.getPrototypeOf(el);
                var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                if (setter && setter.set) setter.set.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
            var tryFill = function () {
                if (done) return;
                var pass = Array.prototype.slice.call(document.querySelectorAll('input[type=password]')).filter(visible)[0];
                var user = null;
                if (!pass) {
                    // two-step logins: username page first
                    user = document.querySelector('input[autocomplete=username], input[type=email], input[name*=user i], input[name*=login i], input[id*=email i]');
                    if (user && visible(user) && !user.value && username) setValue(user, username);
                    return;
                }
                user = findUserField(pass);
                if (user && !user.value && username) setValue(user, username);
                if (!pass.value) setValue(pass, password);
                done = true;
                observer.disconnect();
            };
            var observer = new MutationObserver(tryFill);
            observer.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(function () { observer.disconnect(); }, 60000);
            tryFill();
        };
    }

    // ---------------- start-up ----------------
    onReady(function () {
        challengePage = isChallengePage();
        if (challengePage) {
            window.open = origOpen;
            return;
        }
        Array.prototype.forEach.call(document.querySelectorAll('video'), trackVideo);
        if (cfg.maxQuality) {
            applyPlayerApiQuality();
            // single-page sites (YouTube) change videos without reloading
            setInterval(applyPlayerApiQuality, 4000);
        }
    });
})();
