/*
 * Lumen page enhancements (runs in every frame at document start when supported).
 * Features: cosmetic ad hiding, pop-up blocking, automatic highest video quality,
 * built-in player fallback for HLS/DASH, forced dark mode, passwords, desktop site.
 * Based on TV Bro (https://github.com/truefedex/tv-bro).
 */
(function () {
    'use strict';
    var host = location.hostname || '';
    // Never touch human-verification frames: modifying them makes checks fail.
    // (checked before anything is written to the page, so those frames stay untouched)
    if (/(^|\.)challenges\.cloudflare\.com$/.test(host) || /(^|\.)hcaptcha\.com$/.test(host) ||
        location.pathname.indexOf('/cdn-cgi/challenge-platform') === 0 ||
        location.pathname.indexOf('/recaptcha/') === 0) {
        return;
    }
    // "Clean mode" while a site's verification runs: the app removes its bridge and reloads,
    // and the page must then see a completely unmodified browser.
    if (!window.TVBro) return;
    if (window.__sofaInstalled) return;
    try {
        Object.defineProperty(window, '__sofaInstalled', { value: true, enumerable: false });
    } catch (e) { return; }

    // ---------------- settings ----------------
    var cfg = (typeof __sofaCfgEmbedded !== 'undefined' && __sofaCfgEmbedded) || {};
    try {
        if (window.TVBro && typeof TVBro.sofaSettings === 'function') {
            var live = JSON.parse(TVBro.sofaSettings(location.hostname));
            if (live && typeof live === 'object') cfg = live;
        }
    } catch (e) { /* use embedded settings */ }

    var isTop = (window.top === window);
    var origOpen = window.open;
    var challengePage = false;

    function isChallengePage() {
        try {
            // only Cloudflare's own markers: fake "verify you are human" ad pages copy the title
            if (window._cf_chl_opt) return true;
            // the challenge page itself (not Cloudflare's background bot script on normal pages)
            if (document.querySelector('script[src*="/cdn-cgi/challenge-platform/h/"]')) return true;
        } catch (e) {}
        return false;
    }

    function onReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    }

    function addStyle(id, css) {
        var root = document.head || document.documentElement;
        if (!root) return null;
        var el = document.getElementById(id);
        if (!el) {
            el = document.createElement('style');
            el.id = id;
            root.appendChild(el);
        }
        el.textContent = css;
        return el;
    }

    // ---------------- pop-up blocker ----------------
    var lastClick = { time: 0, href: null, overlay: false, anchor: null };
    var isAppHomePage = location.href.indexOf('https://tvbro.phlox.dev/appcontent/home') === 0;
    if (cfg.popups && !isAppHomePage) {
        // Remember what was clicked. A pop-up is only refused when there was no click at all, or when
        // the click landed on an invisible overlay (the usual pop-under trick). Clicks on real links,
        // buttons and text may open new tabs - download sites rely on that.
        var isOverlayElement = function (el) {
            try {
                var node = el;
                for (var depth = 0; node && node !== document.body && depth < 6; depth++, node = node.parentElement) {
                    var st = getComputedStyle(node);
                    if (st.position !== 'fixed' && st.position !== 'absolute') continue;
                    var r = node.getBoundingClientRect();
                    var big = r.width >= window.innerWidth * 0.7 && r.height >= window.innerHeight * 0.5;
                    var empty = (node.innerText || '').trim().length === 0 && !node.querySelector('img,video,canvas,svg,picture,iframe');
                    var see = parseFloat(st.opacity) < 0.1 || st.backgroundColor === 'rgba(0, 0, 0, 0)' || st.backgroundColor === 'transparent';
                    if (big && empty && see) return true;
                }
            } catch (e) {}
            return false;
        };

        document.addEventListener('click', function (e) {
            if (!e.isTrusted) return;
            lastClick.time = Date.now();
            var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
            lastClick.href = a ? a.href : null;
            lastClick.anchor = a;
            lastClick.overlay = isOverlayElement(e.target);
        }, true);

        var showBlockedBanner = function (url) {
            try {
                var old = document.getElementById('lumen-popup-banner');
                if (old) old.remove();
                var bar = document.createElement('div');
                bar.id = 'lumen-popup-banner';
                bar.style.cssText = 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483647;' +
                    'background:rgba(15,29,32,.95);color:#e8f5f2;font:500 16px/1.3 system-ui,Roboto,sans-serif;' +
                    'padding:10px 12px 10px 16px;border-radius:14px;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.4)';
                var text = document.createElement('span');
                var host = '';
                try { host = new URL(url, location.href).hostname; } catch (e) {}
                text.textContent = 'Pop-up blocked' + (host ? ' (' + host + ')' : '');
                var open = document.createElement('button');
                open.textContent = 'Open';
                open.style.cssText = 'all:unset;cursor:pointer;background:#20c997;color:#062b2f;font-weight:700;padding:8px 14px;border-radius:10px';
                open.addEventListener('click', function (e) {
                    e.stopPropagation();
                    bar.remove();
                    origOpen.call(window, url, '_blank');
                }, true);
                var close = document.createElement('button');
                close.textContent = '✕';
                close.style.cssText = 'all:unset;cursor:pointer;padding:6px 8px;opacity:.7';
                close.addEventListener('click', function (e) { e.stopPropagation(); bar.remove(); }, true);
                bar.appendChild(text); bar.appendChild(open); bar.appendChild(close);
                (document.body || document.documentElement).appendChild(bar);
                setTimeout(function () { if (bar.parentNode) bar.remove(); }, 8000);
            } catch (e) {}
        };

        var siteOf = function (host) { return (host || '').toLowerCase().split('.').slice(-2).join('.'); };
        var sameSite = function (url) {
            try {
                var u = new URL(url, location.href);
                return u.protocol === 'about:' || u.protocol === 'javascript:' || siteOf(u.hostname) === siteOf(location.hostname);
            } catch (e) { return false; }
        };
        // sign-in and payment windows that sites open on purpose
        var TRUSTED_POPUP = /(^|\.)(google\.com|apple\.com|microsoftonline\.com|live\.com|facebook\.com|paypal\.com|github\.com|discord\.com|twitter\.com|x\.com|twitch\.tv|steamcommunity\.com|stripe\.com|amazon\.com)$/i;
        var trustedHost = function (url) {
            try { return TRUSTED_POPUP.test(new URL(url, location.href).hostname); } catch (e) { return false; }
        };
        var sameUrlHost = function (a, b) {
            try { return new URL(a, location.href).hostname === new URL(b, location.href).hostname; } catch (e) { return false; }
        };

        // A new window is allowed only when it is what was clicked: the clicked link's own address,
        // the same site, or a sign-in/payment provider. Ad scripts open other sites on any click
        // ("click anywhere → ad tab"); those are refused and offered in the "Pop-up blocked" bar.
        var popupAllowed = function (full) {
            var recentClick = (Date.now() - lastClick.time) < 2000;
            if (!recentClick || lastClick.overlay) return false;
            if (!full || sameSite(full) || trustedHost(full)) return true;
            if (lastClick.href && sameUrlHost(lastClick.href, full)) return true;
            return false;
        };

        var blockedPopup = function (full) {
            console.log('Lumen blocked pop-up: ' + full);
            if (full) {
                if (isTop) showBlockedBanner(full);
                else try { window.top.postMessage({ __sofa: 'popup', url: full }, '*'); } catch (e) {}
            }
        };
        if (isTop) {
            window.addEventListener('message', function (e) {
                if (e.data && e.data.__sofa === 'popup' && typeof e.data.url === 'string') showBlockedBanner(e.data.url);
            });
        }

        var lumenOpen = function (url, target, features) {
            // opening in the same tab is navigation, not a pop-up (used e.g. by the home page search)
            var t = (target || '').toLowerCase();
            if (t === '_self' || t === '_top' || t === '_parent') return origOpen.apply(window, arguments);
            var full = '';
            try { full = url ? new URL(url, location.href).href : ''; } catch (e) {}
            if (!popupAllowed(full)) {
                blockedPopup(full);
                return null;
            }
            return origOpen.apply(window, arguments);
        };
        window.open = lumenOpen;

        // ad scripts also click a hidden <a target="_blank"> from code, or call open() of a fresh
        // invisible frame, to get around window.open.
        // Not on sites with a human-verification widget: these prototype changes are visible to it.
        if (!cfg.verifySafe) try {
            var origAnchorClick = HTMLAnchorElement.prototype.click;
            HTMLAnchorElement.prototype.click = function () {
                var t = (this.target || '').toLowerCase();
                if (t && t !== '_self' && t !== '_top' && t !== '_parent' && this !== lastClick.anchor &&
                    this.href && !sameSite(this.href) && !trustedHost(this.href)) {
                    blockedPopup(this.href);
                    return;
                }
                return origAnchorClick.apply(this, arguments);
            };
        } catch (e) {}
        if (!cfg.verifySafe) try {
            var cwDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow');
            if (cwDesc && cwDesc.get) {
                Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
                    configurable: true, enumerable: cwDesc.enumerable,
                    get: function () {
                        var w = cwDesc.get.call(this);
                        try { if (w && w.open !== lumenOpen && w.location.href === 'about:blank') w.open = lumenOpen; } catch (e) {}
                        return w;
                    }
                });
            }
        } catch (e) {}

        // pop-under links: invisible full-page anchors that open ads in a new tab
        document.addEventListener('click', function (e) {
            var a = e.target && e.target.closest ? e.target.closest('a[target="_blank"]') : null;
            if (!a || sameSite(a.href)) return;
            var r = a.getBoundingClientRect();
            var hugeInvisible = r.width >= window.innerWidth * 0.8 && r.height >= window.innerHeight * 0.6 &&
                (a.textContent || '').trim().length === 0 && !a.querySelector('img,video,picture');
            if (hugeInvisible) {
                e.preventDefault();
                e.stopPropagation();
                a.remove();
                console.log('Lumen blocked pop-under link: ' + a.href);
            }
        }, true);
    }

    // ---------------- cosmetic ad hiding ----------------
    var AD_SELECTORS = [
        'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="div-gpt-ad"]',
        'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
        'iframe[src*="amazon-adsystem.com"]', 'iframe[src*="adnxs.com"]', 'iframe[src*="taboola.com"]',
        'amp-ad', 'amp-embed[type="taboola"]', '[data-ad-slot]', '[data-ad-unit]', '[data-adunit]',
        '[id^="taboola-"]', '.trc_related_container', '.OUTBRAIN', '[data-widget-id^="AR_"]',
        '.ad-banner', '.ad-container', '.ad-wrapper', '.ad-slot', '.ad-unit', '.ad_unit', '.adBanner',
        '.advertisement', '.advert', '.sponsored-ad', '.banner-ad', '.sticky-ad', '.ad-sticky',
        '#ad-banner', '#ad_banner', '#adContainer', '#sticky-ad', '[aria-label="Advertisement"]',
        'a[href*="doubleclick.net/"]', 'a[href*="/aclk?"]'
    ];

    function removeAntiAdblockOverlays() {
        var re = /ad.?block|disable your ad|turn off your ad|whitelist (our|this) site|adblocker detected/i;
        var nodes = document.querySelectorAll('body > div, body > section, body > aside');
        for (var i = 0; i < nodes.length; i++) {
            var el = nodes[i];
            var st = getComputedStyle(el);
            if (st.position !== 'fixed' && st.position !== 'absolute') continue;
            var r = el.getBoundingClientRect();
            if (r.width < window.innerWidth * 0.5 || r.height < window.innerHeight * 0.4) continue;
            if (!re.test((el.innerText || '').slice(0, 2000))) continue;
            el.remove();
            [document.documentElement, document.body].forEach(function (n) {
                if (!n) return;
                n.style.setProperty('overflow', 'auto', 'important');
                n.style.removeProperty('position');
            });
        }
    }

    if (cfg.cosmetic) {
        onReady(function () {
            if (challengePage || (challengePage = isChallengePage())) return;
            addStyle('sofa-cosmetic', AD_SELECTORS.join(',\n') +
                ' { display: none !important; visibility: hidden !important; }');
            if (isTop) {
                setTimeout(removeAntiAdblockOverlays, 1500);
                setTimeout(removeAntiAdblockOverlays, 5000);
            }
        });
    }

    // ---------------- YouTube ads ----------------
    // YouTube serves ads from the same servers as the videos, so filter lists can't block them.
    // Instead: (1) remove the ad schedule from the player data before the player reads it,
    // (2) if an ad still starts, mute it and jump to its end / press "Skip",
    // (3) hide banner/feed ads and the "ad blockers are not allowed" pop-up.
    var isYouTube = /(^|\.)(youtube\.com|youtube-nocookie\.com)$/i.test(host);
    if (cfg.cosmetic && isYouTube) {
        var AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams', 'adParams'];
        var prune = function (o, depth) {
            if (!o || typeof o !== 'object' || depth > 6) return o;
            for (var i = 0; i < AD_KEYS.length; i++) {
                if (Object.prototype.hasOwnProperty.call(o, AD_KEYS[i])) {
                    try { delete o[AD_KEYS[i]]; } catch (e) {}
                }
            }
            // player data can be nested (e.g. inside "playerResponse")
            if (o.playerResponse) prune(o.playerResponse, depth + 1);
            if (Array.isArray(o)) for (var j = 0; j < o.length && j < 20; j++) prune(o[j], depth + 1);
            return o;
        };
        try {
            var origParse = JSON.parse;
            JSON.parse = function () {
                var r = origParse.apply(this, arguments);
                try { if (r && typeof r === 'object' && (r.adPlacements || r.playerAds || r.adSlots || r.playerResponse)) prune(r, 0); } catch (e) {}
                return r;
            };
            JSON.parse.toString = function () { return origParse.toString(); };
        } catch (e) {}
        try {
            var origJson = Response.prototype.json;
            Response.prototype.json = function () {
                return origJson.apply(this, arguments).then(function (r) {
                    try { prune(r, 0); } catch (e) {}
                    return r;
                });
            };
        } catch (e) {}
        // first page load: the data comes in a global variable
        ['ytInitialPlayerResponse', 'ytInitialData'].forEach(function (name) {
            try {
                var value;
                Object.defineProperty(window, name, {
                    configurable: true,
                    get: function () { return value; },
                    set: function (v) { value = prune(v, 0); }
                });
            } catch (e) {}
        });

        var skipAds = function () {
            var player = document.querySelector('#movie_player, .html5-video-player');
            var video = player ? player.querySelector('video') : null;
            var adShowing = player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'));
            if (adShowing && video) {
                video.muted = true;
                if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.2) {
                    try { video.currentTime = video.duration - 0.1; } catch (e) {}
                }
                try { video.playbackRate = 16; } catch (e) {}
            } else if (video && video.__lumenWasAd) {
                video.muted = false;
                if (video.playbackRate === 16) video.playbackRate = 1;
            }
            if (video) video.__lumenWasAd = !!adShowing;
            var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, ' +
                'button[class*="skip-ad"], .ytm-skip-ad-button, ytm-skip-ad-button button');
            if (skip) try { skip.click(); } catch (e) {}
            // anti-adblock dialog: remove it and keep playing
            var nag = document.querySelector('ytd-enforcement-message-view-model, ytm-enforcement-message-view-model');
            if (nag) {
                var dlg = nag.closest('tp-yt-paper-dialog, ytd-popup-container, bottom-sheet-container') || nag;
                dlg.remove();
                var backdrop = document.querySelector('tp-yt-iron-overlay-backdrop');
                if (backdrop) backdrop.remove();
                if (video && video.paused) try { video.play(); } catch (e) {}
            }
        };
        setInterval(skipAds, 300);
        onReady(function () {
            addStyle('lumen-youtube-ads',
                '#player-ads, #masthead-ad, ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-banner-promo-renderer,' +
                ' ytd-promoted-sparkles-web-renderer, ytd-promoted-video-renderer, ytd-display-ad-renderer,' +
                ' ytd-companion-slot-renderer, ytd-action-companion-ad-renderer, ytd-statement-banner-renderer,' +
                ' ytd-rich-item-renderer:has(ytd-ad-slot-renderer), ytd-search-pyv-renderer, .ytd-merch-shelf-renderer,' +
                ' .ytp-ad-overlay-container, .ytp-ad-overlay-slot, .ytp-ad-image-overlay, .video-ads.ytp-ad-module,' +
                ' ytm-promoted-sparkles-web-renderer, ytm-companion-ad-renderer, ytm-promoted-video-renderer,' +
                ' ad-slot-renderer, ytm-ad-slot-renderer, .ytm-promoted-sparkles-text-search-root,' +
                ' ytd-enforcement-message-view-model, ytm-enforcement-message-view-model' +
                ' { display: none !important; }');
        });
    }

    // ---------------- forced dark mode ----------------
    function luminance(color) {
        var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(color || '');
        if (!m) return -1;
        if (m[4] !== undefined && parseFloat(m[4]) === 0) return -1; // transparent
        return (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255;
    }

    if (cfg.dark && isTop) {
        onReady(function () {
            if (challengePage || (challengePage = isChallengePage())) return;
            var bg = luminance(getComputedStyle(document.body || document.documentElement).backgroundColor);
            if (bg === -1) bg = luminance(getComputedStyle(document.documentElement).backgroundColor);
            if (bg !== -1 && bg < 0.45) return; // page is already dark
            addStyle('sofa-dark',
                'html.sofa-dark { filter: invert(1) hue-rotate(180deg) !important; background: #fff !important; }\n' +
                'html.sofa-dark img, html.sofa-dark video, html.sofa-dark picture, html.sofa-dark canvas,' +
                ' html.sofa-dark iframe, html.sofa-dark embed, html.sofa-dark object,' +
                ' html.sofa-dark [style*="background-image"], html.sofa-dark .sofa-player-bar' +
                ' { filter: invert(1) hue-rotate(180deg) !important; }\n' +
                'html.sofa-dark picture img, html.sofa-dark picture video { filter: none !important; }');
            document.documentElement.classList.add('sofa-dark');
            document.addEventListener('fullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.fullscreenElement);
            });
            document.addEventListener('webkitfullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.webkitFullscreenElement);
            });
        });
    }

    // ---------------- highest quality ----------------
    function pickHighestIndex(levels, getHeight, getBitrate) {
        var best = -1, bestH = -1, bestB = -1;
        for (var i = 0; i < levels.length; i++) {
            var h = getHeight(levels[i]) || 0;
            var b = getBitrate(levels[i]) || 0;
            if (h > bestH || (h === bestH && b > bestB)) { best = i; bestH = h; bestB = b; }
        }
        return best;
    }

    function labelHeight(label) {
        var m = /(\d{3,4})\s*p/i.exec(label || '');
        if (m) return parseInt(m[1], 10);
        if (/4k|uhd|2160/i.test(label || '')) return 2160;
        if (/hd/i.test(label || '')) return 720;
        return 0;
    }

    function patchHls(H) {
        if (!H || !H.prototype || H.prototype.__sofaPatched) return;
        H.prototype.__sofaPatched = true;
        var origLoad = H.prototype.loadSource;
        if (typeof origLoad !== 'function') return;
        H.prototype.loadSource = function () {
            var hls = this;
            try {
                if (!hls.__sofaHooked && cfg.maxQuality && hls.on && H.Events) {
                    hls.__sofaHooked = true;
                    hls.on(H.Events.MANIFEST_PARSED, function () {
                        try {
                            var idx = pickHighestIndex(hls.levels || [],
                                function (l) { return l.height; }, function (l) { return l.bitrate; });
                            if (idx >= 0) {
                                hls.autoLevelCapping = -1;
                                hls.currentLevel = idx;
                                hls.loadLevel = idx;
                            }
                        } catch (e) {}
                    });
                }
            } catch (e) {}
            return origLoad.apply(this, arguments);
        };
    }

    function patchShaka(shaka) {
        if (!shaka || !shaka.Player || !shaka.Player.prototype || shaka.Player.prototype.__sofaPatched) return;
        var P = shaka.Player.prototype;
        P.__sofaPatched = true;
        var origLoad = P.load;
        if (typeof origLoad !== 'function') return;
        P.load = function () {
            var player = this;
            var result = origLoad.apply(this, arguments);
            var apply = function () {
                if (!cfg.maxQuality) return;
                try {
                    var tracks = player.getVariantTracks();
                    var idx = pickHighestIndex(tracks, function (t) { return t.height; }, function (t) { return t.bandwidth; });
                    if (idx >= 0) {
                        player.configure({ abr: { enabled: false } });
                        player.selectVariantTrack(tracks[idx], true);
                    }
                } catch (e) {}
            };
            if (result && typeof result.then === 'function') result.then(apply, function () {});
            else setTimeout(apply, 2000);
            return result;
        };
    }

    function patchDash(dashjs) {
        if (!dashjs || typeof dashjs.MediaPlayer !== 'function' || dashjs.MediaPlayer.__sofaPatched) return;
        var origFactory = dashjs.MediaPlayer;
        var wrapped = function () {
            var f = origFactory.apply(this, arguments);
            try {
                var origCreate = f.create;
                f.create = function () {
                    var p = origCreate.apply(this, arguments);
                    try {
                        p.on('streamInitialized', function () {
                            if (!cfg.maxQuality) return;
                            try {
                                p.updateSettings({ streaming: { abr: { autoSwitchBitrate: { video: false } } } });
                                if (typeof p.getBitrateInfoListFor === 'function') { // dash.js v3/v4
                                    var list = p.getBitrateInfoListFor('video') || [];
                                    var i = pickHighestIndex(list, function (l) { return l.height; }, function (l) { return l.bitrate; });
                                    if (i >= 0) p.setQualityFor('video', i, true);
                                } else if (typeof p.getRepresentationsByType === 'function') { // dash.js v5
                                    var reps = p.getRepresentationsByType('video') || [];
                                    var j = pickHighestIndex(reps, function (l) { return l.height; }, function (l) { return l.bandwidth; });
                                    if (j >= 0) p.setRepresentationForTypeByIndex('video', j, true);
                                }
                            } catch (e) {}
                        });
                    } catch (e) {}
                    return p;
                };
            } catch (e) {}
            return f;
        };
        for (var k in origFactory) { try { wrapped[k] = origFactory[k]; } catch (e) {} }
        wrapped.__sofaPatched = true;
        try { dashjs.MediaPlayer = wrapped; } catch (e) {}
    }

    function hookGlobal(name, patcher) {
        try {
            var current = window[name];
            if (current) { patcher(current); return; }
            var desc = Object.getOwnPropertyDescriptor(window, name);
            if (desc && !desc.configurable) return;
            var value;
            Object.defineProperty(window, name, {
                configurable: true,
                enumerable: true,
                get: function () { return value; },
                set: function (v) { value = v; try { patcher(v); } catch (e) {} }
            });
        } catch (e) {}
    }

    function applyPlayerApiQuality() {
        if (!cfg.maxQuality) return;
        // YouTube (desktop, mobile and embeds)
        try {
            var yt = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
            if (yt && typeof yt.getAvailableQualityLevels === 'function') {
                var levels = yt.getAvailableQualityLevels().filter(function (q) { return q !== 'auto'; });
                var key = levels[0] + '|' + location.href;
                if (levels.length && yt.__sofaQ !== key) {
                    if (typeof yt.setPlaybackQualityRange === 'function') yt.setPlaybackQualityRange(levels[0], levels[0]);
                    if (typeof yt.setPlaybackQuality === 'function') yt.setPlaybackQuality(levels[0]);
                    yt.__sofaQ = key;
                }
            }
        } catch (e) {}
        // JW Player
        try {
            if (typeof window.jwplayer === 'function') {
                var jw = window.jwplayer();
                if (jw && typeof jw.getQualityLevels === 'function') {
                    var q = jw.getQualityLevels() || [];
                    var idx = pickHighestIndex(q, function (l) { return l.height || labelHeight(l.label); },
                        function (l) { return l.bitrate; });
                    if (idx >= 0 && jw.getCurrentQuality() !== idx) jw.setCurrentQuality(idx);
                }
            }
        } catch (e) {}
        // Video.js (quality-levels plugin)
        try {
            if (window.videojs && typeof window.videojs.getPlayers === 'function') {
                var players = window.videojs.getPlayers();
                Object.keys(players).forEach(function (id) {
                    var p = players[id];
                    if (!p || typeof p.qualityLevels !== 'function') return;
                    var ql = p.qualityLevels();
                    if (!ql || !ql.length) return;
                    var arr = [];
                    for (var i = 0; i < ql.length; i++) arr.push(ql[i]);
                    var best = pickHighestIndex(arr, function (l) { return l.height; }, function (l) { return l.bitrate; });
                    for (var j = 0; j < arr.length; j++) arr[j].enabled = (j === best);
                });
            }
        } catch (e) {}
        // Plyr
        try {
            var plyrEls = document.querySelectorAll('.plyr');
            for (var n = 0; n < plyrEls.length; n++) {
                var pl = plyrEls[n].plyr;
                if (pl && pl.options && pl.options.quality && pl.options.quality.length) {
                    var max = Math.max.apply(null, pl.options.quality.map(Number).filter(isFinite));
                    if (isFinite(max) && pl.quality !== max) pl.quality = max;
                }
            }
        } catch (e) {}
        // late-loaded libraries
        try { patchHls(window.Hls); } catch (e) {}
        try { patchShaka(window.shaka); } catch (e) {}
    }

    if (cfg.maxQuality) {
        hookGlobal('Hls', patchHls);
        hookGlobal('shaka', patchShaka);
        hookGlobal('dashjs', patchDash);
    }

    // Most sites bundle their player (hls.js, video.js, JW, Shaka, Clappr, ...) inside their own
    // code, where the hooks above can't reach it, and the player's automatic quality only climbs to
    // a 10+ Mbit/s version after measuring a fast connection for a while - often never. So the
    // stream's quality list itself (HLS master playlist / DASH manifest) is trimmed to the best
    // version this device can play before any player reads it; every player then has to use it.
    var lumenCodecOk = function (mime, codecs) {
        if (!codecs) return true;
        try {
            if (window.MediaSource && typeof MediaSource.isTypeSupported === 'function') {
                return MediaSource.isTypeSupported(mime + '; codecs="' + codecs + '"');
            }
        } catch (e) {}
        return true;
    };

    var hlsAttr = function (attrs, name) {
        var m = new RegExp('(?:^|,)' + name + '=("([^"]*)"|[^,]*)').exec(attrs);
        if (!m) return null;
        return m[2] !== undefined ? m[2] : m[1];
    };

    window.__lumenBestHls = function (text) {
        if (typeof text !== 'string' || text.indexOf('#EXT-X-STREAM-INF') < 0) return null;
        var lines = text.split(/\r?\n/);
        var variants = [];
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].indexOf('#EXT-X-STREAM-INF:') !== 0) continue;
            var j = i + 1;
            while (j < lines.length && (lines[j].trim() === '' || lines[j].charAt(0) === '#')) j++;
            if (j >= lines.length) break;
            var attrs = lines[i].substring(18);
            var res = hlsAttr(attrs, 'RESOLUTION') || '';
            var rm = /(\d+)x(\d+)/i.exec(res);
            var codecs = hlsAttr(attrs, 'CODECS');
            var onlyAudio = codecs && !/(avc|hvc|hev|av01|vp0?9|vp8|dvh|dva)/i.test(codecs);
            variants.push({
                tag: i, uri: j,
                h: rm ? parseInt(rm[2], 10) : 0,
                bw: parseInt(hlsAttr(attrs, 'BANDWIDTH') || '0', 10) || 0,
                ok: !onlyAudio && lumenCodecOk('video/mp4', codecs)
            });
            i = j;
        }
        if (variants.length < 2) return null;
        var best = null;
        for (var k = 0; k < variants.length; k++) {
            var v = variants[k];
            if (!v.ok) continue;
            if (!best || v.h > best.h || (v.h === best.h && v.bw > best.bw)) best = v;
        }
        if (!best) return null;
        var drop = {};
        for (var d = 0; d < variants.length; d++) {
            if (variants[d] === best) continue;
            drop[variants[d].tag] = true;
            drop[variants[d].uri] = true;
        }
        var out = [];
        for (var n = 0; n < lines.length; n++) if (!drop[n]) out.push(lines[n]);
        return out.join('\n');
    };

    window.__lumenBestMpd = function (text) {
        if (typeof text !== 'string' || !/<MPD[\s>]/.test(text) || typeof DOMParser !== 'function') return null;
        var doc;
        try { doc = new DOMParser().parseFromString(text, 'application/xml'); } catch (e) { return null; }
        if (!doc || doc.getElementsByTagName('parsererror').length) return null;
        var sets = doc.getElementsByTagNameNS('*', 'AdaptationSet');
        var changed = false;
        for (var i = 0; i < sets.length; i++) {
            var set = sets[i];
            var reps = [];
            for (var c = set.firstElementChild; c; c = c.nextElementSibling) {
                if (c.localName === 'Representation') reps.push(c);
            }
            if (reps.length < 2) continue;
            var setMime = set.getAttribute('mimeType') || '';
            var isVideo = set.getAttribute('contentType') === 'video' || /video/i.test(setMime) ||
                /video/i.test(reps[0].getAttribute('mimeType') || '') ||
                (!!(reps[0].getAttribute('height') || set.getAttribute('height')) && !/audio|text/i.test(setMime));
            if (!isVideo) continue;
            var best = null, bestH = -1, bestB = -1;
            for (var r = 0; r < reps.length; r++) {
                var rep = reps[r];
                var mime = rep.getAttribute('mimeType') || setMime || 'video/mp4';
                var codecs = rep.getAttribute('codecs') || set.getAttribute('codecs');
                if (!lumenCodecOk(mime, codecs)) continue;
                var h = parseInt(rep.getAttribute('height') || set.getAttribute('height') || '0', 10) || 0;
                var b = parseInt(rep.getAttribute('bandwidth') || '0', 10) || 0;
                if (h > bestH || (h === bestH && b > bestB)) { best = rep; bestH = h; bestB = b; }
            }
            if (!best) continue;
            for (var x = 0; x < reps.length; x++) {
                if (reps[x] !== best) { set.removeChild(reps[x]); changed = true; }
            }
        }
        if (!changed) return null;
        try { return new XMLSerializer().serializeToString(doc); } catch (e) { return null; }
    };

    var lumenTrimManifest = function (text) {
        if (typeof text !== 'string' || text.length > 4000000) return null;
        var head = text.substring(0, 2000).replace(/^﻿/, '').replace(/^\s+/, '');
        try {
            if (head.indexOf('#EXTM3U') === 0) return window.__lumenBestHls(text);
            if (/<MPD[\s>]/.test(head)) return window.__lumenBestMpd(text);
        } catch (e) {}
        return null;
    };

    if (cfg.maxQuality) {
        (function () {
            // XMLHttpRequest (hls.js, video.js, dash.js, JW Player, Clappr, ...)
            try {
                var XP = XMLHttpRequest.prototype;
                var txtDesc = Object.getOwnPropertyDescriptor(XP, 'responseText');
                var resDesc = Object.getOwnPropertyDescriptor(XP, 'response');
                var decoder = (typeof TextDecoder === 'function') ? new TextDecoder() : null;
                var encoder = (typeof TextEncoder === 'function') ? new TextEncoder() : null;
                var transformed = function (xhr) {
                    if (xhr.readyState !== 4) return undefined;
                    if (xhr.__lumenQ) return xhr.__lumenQ.out;
                    var st = { out: null };
                    xhr.__lumenQ = st;
                    try {
                        var type = xhr.responseType;
                        if (type === '' || type === 'text') {
                            st.out = lumenTrimManifest(txtDesc.get.call(xhr));
                        } else if (type === 'arraybuffer' && decoder && encoder) {
                            var buf = resDesc.get.call(xhr);
                            if (buf && buf.byteLength < 4000000) {
                                var first = decoder.decode(new Uint8Array(buf, 0, Math.min(buf.byteLength, 64)));
                                if (/#EXTM3U|<\?xml|<MPD/.test(first)) {
                                    var t = lumenTrimManifest(decoder.decode(new Uint8Array(buf)));
                                    if (t != null) { var u8 = encoder.encode(t); st.out = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength); st.text = t; }
                                }
                            }
                        }
                    } catch (e) { st.out = null; }
                    return st.out;
                };
                if (txtDesc && txtDesc.get && resDesc && resDesc.get) {
                    Object.defineProperty(XP, 'responseText', {
                        configurable: true, enumerable: txtDesc.enumerable,
                        get: function () {
                            var t = transformed(this);
                            if (typeof t === 'string') return t;
                            return txtDesc.get.call(this);
                        }
                    });
                    Object.defineProperty(XP, 'response', {
                        configurable: true, enumerable: resDesc.enumerable,
                        get: function () {
                            var t = transformed(this);
                            if (t != null) return t;
                            return resDesc.get.call(this);
                        }
                    });
                }
            } catch (e) {}
            // fetch (Shaka Player, newer hls.js setups)
            try {
                var origFetch = window.fetch;
                if (typeof origFetch === 'function') {
                    var looksLikeManifest = /\.(m3u8|mpd)(\?|#|$)|m3u8|manifest|master|playlist/i;
                    window.fetch = function (input, init) {
                        var p = origFetch.apply(this, arguments);
                        var url = '';
                        try { url = typeof input === 'string' ? input : (input && input.url) || String(input); } catch (e) {}
                        return p.then(function (res) {
                            try {
                                if (!res || !res.ok || res.type === 'opaque') return res;
                                var ct = (res.headers && res.headers.get('content-type')) || '';
                                if (!/mpegurl|dash\+xml/i.test(ct) && !looksLikeManifest.test(url)) return res;
                                if (/^(video|audio|image)\//i.test(ct)) return res;
                                var len = parseInt((res.headers && res.headers.get('content-length')) || '0', 10);
                                if (len > 4000000) return res;
                                return res.clone().text().then(function (t) {
                                    var out = lumenTrimManifest(t);
                                    if (out == null) return res;
                                    var nr = new Response(out, { status: res.status, statusText: res.statusText, headers: res.headers });
                                    try {
                                        Object.defineProperty(nr, 'url', { value: res.url });
                                        Object.defineProperty(nr, 'redirected', { value: res.redirected });
                                    } catch (e) {}
                                    return nr;
                                }, function () { return res; });
                            } catch (e) { return res; }
                        });
                    };
                }
            } catch (e) {}
        })();
    }

    // ---------------- media helpers ----------------
    function allMedia() {
        var list = Array.prototype.slice.call(document.querySelectorAll('video, audio'));
        // same-origin iframes
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try {
                var d = frames[i].contentDocument;
                if (d) list = list.concat(Array.prototype.slice.call(d.querySelectorAll('video, audio')));
            } catch (e) {}
        }
        return list;
    }

    function isPlaying(m) {
        return m.currentTime > 0 && !m.paused && !m.ended && m.readyState > 2;
    }

    function bestMedia() {
        var list = allMedia();
        var best = null, bestScore = -1;
        list.forEach(function (m) {
            var r = m.getBoundingClientRect();
            var area = Math.max(0, r.width) * Math.max(0, r.height);
            var score = area + (isPlaying(m) ? 1e9 : 0) + (m.tagName === 'VIDEO' ? 1 : 0);
            if (score > bestScore) { best = m; bestScore = score; }
        });
        return best;
    }

    var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    function mediaCommand(cmd, m) {
        m = m || bestMedia();
        if (!m) return false;
        switch (cmd) {
            case 'toggle': if (m.paused || m.ended) m.play(); else m.pause(); break;
            case 'stop': m.pause(); m.currentTime = 0; break;
            case 'pause': m.pause(); break;
            case 'handoff-deband':
                // open this video in Lumen's own player with anime deband, at the same position
                try {
                    TVBro.sofaOpenVideo('native_deband', m.currentSrc || m.src || '', location.href,
                        (isTop ? document.title : '') || '', m.currentTime || 0);
                    m.pause();
                } catch (e) {}
                break;
            case 'rewind': m.currentTime = Math.max(0, m.currentTime - 10); break;
            case 'forward': m.currentTime = m.currentTime + 10; break;
            case 'speed':
                var i = SPEEDS.indexOf(m.playbackRate);
                m.playbackRate = SPEEDS[(i + 1) % SPEEDS.length] || 1;
                break;
        }
        return true;
    }

    // Called by remote-control media keys (see generic_injects.js). Falls back to
    // asking cross-origin iframes (video embeds) to handle the command.
    window.__sofaMedia = function (cmd) {
        if (mediaCommand(cmd)) return true;
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'media', cmd: cmd }, '*'); } catch (e) {}
        }
        return true;
    };

    window.addEventListener('message', function (e) {
        var d = e.data;
        if (!d || d.__sofa !== 'media') return;
        if (!mediaCommand(d.cmd)) {
            var frames = document.querySelectorAll('iframe');
            for (var i = 0; i < frames.length; i++) {
                try { frames[i].contentWindow.postMessage(d, '*'); } catch (err) {}
            }
        }
    });

    // ---------------- video playback ----------------
    // No on-screen controls: the site's own player is used. Lumen only picks the best quality and,
    // when the web engine can't play an HLS/DASH stream (".m3u8"/".mpd"), opens it in Lumen's
    // built-in hardware player instead.
    var handedOff = {};

    function streamSrc(v) {
        var src = v.currentSrc || v.src || '';
        if (!src) {
            var source = v.querySelector('source[src]');
            if (source) src = source.src;
        }
        return src;
    }

    function isManifestUrl(u) {
        return /\.(m3u8|mpd)(\?|#|$)/i.test(u || '');
    }

    document.addEventListener('play', function (e) {
        var v = e.target;
        if (!v || v.tagName !== 'VIDEO') return;
        applyPlayerApiQuality();
        setTimeout(applyPlayerApiQuality, 1500);
        setTimeout(applyPlayerApiQuality, 5000);
    }, true);

    // media errors don't bubble, so listen in the capture phase
    document.addEventListener('error', function (e) {
        var v = e.target;
        if (!v || (v.tagName !== 'VIDEO' && v.tagName !== 'SOURCE')) return;
        if (v.tagName === 'SOURCE') v = v.parentElement;
        if (!v || v.tagName !== 'VIDEO') return;
        var src = streamSrc(v);
        if (!isManifestUrl(src) || handedOff[src]) return;
        handedOff[src] = true;
        try {
            if (window.TVBro && TVBro.sofaOpenVideo) {
                TVBro.sofaOpenVideo('native', src, location.href, (isTop ? document.title : '') || '', v.currentTime || 0);
            }
        } catch (err) {}
    }, true);

    // ---------------- grab links ----------------
    // Read by the Grab button: media addresses written in the page itself (video/audio/<track>).
    window.__lumenDomMedia = function () {
        var out = [];
        var add = function (k, u) { if (u && /^https?:/i.test(u)) out.push({ k: k, u: u }); };
        var docs = [document];
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { if (frames[i].contentDocument) docs.push(frames[i].contentDocument); } catch (e) {}
        }
        docs.forEach(function (d) {
            Array.prototype.forEach.call(d.querySelectorAll('video'), function (v) {
                add('v', v.currentSrc || v.src);
                Array.prototype.forEach.call(v.querySelectorAll('source[src]'), function (x) { add('v', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('audio'), function (a) {
                add('a', a.currentSrc || a.src);
                Array.prototype.forEach.call(a.querySelectorAll('source[src]'), function (x) { add('a', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('track[src]'), function (t) { add('s', t.src); });
        });
        return out;
    };

    // ---------------- anime deband for videos in web pages ----------------
    // Toolbar "Deband" button: draws the video through a WebGL deband filter on a canvas placed
    // exactly over the <video>. Works for normal and MSE (blob:) videos; DRM-protected videos and
    // cross-origin videos without CORS can't be read by the browser and are left as they are.
    var DEBAND_VERT = "\nattribute vec4 aFramePosition;\nvarying vec2 vTexSamplingCoord;\nvoid main() {\n  gl_Position = aFramePosition;\n  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;\n}\n";
    var DEBAND_FRAG = "\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform sampler2D uTexSampler;\nuniform vec2 uTexSize;\nuniform vec3 uParams;\nvarying vec2 vTexSamplingCoord;\nfloat luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\nvec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }\n\n// mpv's deband algorithm (as used by Hayase's \"video-deband\", MIT, github.com/ThaUnknown/video-deband):\n// for 4 growing radii, average 4 random samples around the pixel; where the pixel differs from that\n// average by less than a tiny threshold (a banding step), take the average. Then add fine grain.\nuniform float uFrame;\n#define THRESHOLD 88\n#define RANGE 17\n#define ITERATIONS 4\n#define GRAIN 12\nfloat mod289(float x)  { return x - floor(x / 289.0) * 289.0; }\nfloat permute(float x) { return mod289((34.0 * x + 1.0) * x); }\nfloat rand(float x)    { return fract(x / 41.0); }\nvec4 average(vec2 pos, float range, inout float h) {\n  float dist = rand(h) * range;     h = permute(h);\n  float dir  = rand(h) * 6.2831853; h = permute(h);\n  vec2 pt = dist / uTexSize;\n  vec2 o = vec2(cos(dir), sin(dir));\n  vec4 r0 = texture2D(uTexSampler, pos + pt * vec2( o.x,  o.y));\n  vec4 r1 = texture2D(uTexSampler, pos + pt * vec2(-o.y,  o.x));\n  vec4 r2 = texture2D(uTexSampler, pos + pt * vec2(-o.x, -o.y));\n  vec4 r3 = texture2D(uTexSampler, pos + pt * vec2( o.y, -o.x));\n  return (r0 + r1 + r2 + r3) * 0.25;\n}\nvoid main() {\n  vec2 pos = vTexSamplingCoord;\n  float random = fract(uFrame * 0.61803398875 + 0.1);\n  vec3 m = vec3(pos, random) + vec3(1.0);\n  float h = permute(permute(permute(m.x) + m.y) + m.z);\n  vec4 col = texture2D(uTexSampler, pos);\n  for (int i = 1; i <= ITERATIONS; i++) {\n    vec4 avg = average(pos, float(i * RANGE), h);\n    vec4 diff = abs(col - avg);\n    col = mix(avg, col, step(vec4(float(THRESHOLD) / (float(i) * 16384.0)), diff));\n  }\n  vec3 noise;\n  noise.x = rand(h); h = permute(h);\n  noise.y = rand(h); h = permute(h);\n  noise.z = rand(h); h = permute(h);\n  col.rgb += (float(GRAIN) / 8192.0) * (noise - vec3(0.5));\n  gl_FragColor = vec4(col.rgb, 1.0);\n}\n";
    var debandWanted = false;
    var debandLayers = [];

    function debandReport(code) {
        try { if (window.TVBro && TVBro.sofaDebandStatus) TVBro.sofaDebandStatus(code); } catch (e) {}
    }

    var DEINTERLACE_FRAG = "\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform sampler2D uTexSampler;\nuniform vec2 uTexSize;\nuniform vec3 uParams;\nvarying vec2 vTexSamplingCoord;\nfloat luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\nvec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }\n\nvec3 chroma(vec3 c) { return c - vec3(luma(c)); }\nvec3 S(vec2 px, float dy) { return at(px + vec2(0.0, dy)).rgb; }\n// one full period, averaged (luma and colour of the average = average of luma and colour)\nvec3 box(vec2 px, float p) {\n  return 0.25 * (S(px, -0.375 * p) + S(px, -0.125 * p) + S(px, 0.125 * p) + S(px, 0.375 * p));\n}\nvoid metY(float yc, float lq1, float lq2, float lb1, float lb2, float lr1, float lr2, float p,\n          inout float best, inout float bestP, inout float bestM) {\n  float ii = 0.5 * (yc - 0.5 * (lb1 + lb2));\n  float qq = 0.5 * (lq1 - lq2);\n  float amp = sqrt(ii * ii + qq * qq);\n  float rep = max(abs(yc - lr1), abs(yc - lr2));\n  float m = smoothstep(uParams.x, uParams.y, amp) * (1.0 - smoothstep(0.6, 1.2, rep / max(2.0 * amp, 0.004)));\n  if (m * amp > best) { best = m * amp; bestP = p; bestM = m; }\n}\nvoid metC(vec3 cc, vec3 kq1, vec3 kq2, vec3 kb1, vec3 kb2, vec3 kr1, vec3 kr2, float p,\n          inout float best, inout float bestP, inout float bestM) {\n  vec3 ic = 0.5 * (cc - 0.5 * (kb1 + kb2));\n  vec3 qc = 0.5 * (kq1 - kq2);\n  float amp = sqrt(dot(ic, ic) + dot(qc, qc));\n  float rep = max(length(cc - kr1), length(cc - kr2));\n  float m = smoothstep(uParams.z, uParams.z * 3.0, amp) * (1.0 - smoothstep(0.6, 1.2, rep / max(2.0 * amp, 0.004)));\n  if (m * amp > best) { best = m * amp; bestP = p; bestM = m; }\n}\n// tests line spacing p for brightness and colour, and 2p for colour (4:2:0). The 2p test reuses\n// the p samples (its quarter and half period are p's half and full period): 8 reads instead of 18.\nvoid period(vec2 px, float p, float yc, vec3 cc,\n            inout float bY, inout float pY, inout float mY, inout float bC, inout float pC, inout float mC) {\n  vec3 q1 = S(px, 0.25 * p); vec3 q2 = S(px, -0.25 * p);\n  vec3 b1 = S(px, 0.5 * p);  vec3 b2 = S(px, -0.5 * p);\n  vec3 r1 = S(px, p);        vec3 r2 = S(px, -p);\n  vec3 d1 = S(px, 2.0 * p);  vec3 d2 = S(px, -2.0 * p);\n  metY(yc, luma(q1), luma(q2), luma(b1), luma(b2), luma(r1), luma(r2), p, bY, pY, mY);\n  vec3 cb1 = chroma(b1); vec3 cb2 = chroma(b2); vec3 cr1 = chroma(r1); vec3 cr2 = chroma(r2);\n  metC(cc, chroma(q1), chroma(q2), cb1, cb2, cr1, cr2, p, bC, pC, mC);\n  metC(cc, cb1, cb2, cr1, cr2, chroma(d1), chroma(d2), 2.0 * p, bC, pC, mC);\n}\nvoid main() {\n  vec2 px = vTexSamplingCoord * uTexSize;\n  vec4 c4 = at(px);\n  float yc = luma(c4.rgb);\n  vec3 cc = c4.rgb - vec3(yc);\n  // line spacing: native interlace, and interlace of a 576- or 480-line master scaled to this height\n  float pA = 2.0;\n  float pB = max(2.0, 2.0 * uTexSize.y / 576.0);\n  float pCc = max(2.0, 2.0 * uTexSize.y / 480.0);\n  float bY = 0.0; float pY = 0.0; float mY = 0.0;\n  float bC = 0.0; float pC = 0.0; float mC = 0.0;\n  period(px, pA, yc, cc, bY, pY, mY, bC, pC, mC);\n  if (pB != pA) period(px, pB, yc, cc, bY, pY, mY, bC, pC, mC);\n  if (pCc != pB) period(px, pCc, yc, cc, bY, pY, mY, bC, pC, mC);\n  float outY = yc; vec3 outC = cc;\n  if (bY > 0.0) {\n    vec3 bx = box(px, pY);\n    outY = mix(yc, luma(bx), mY);\n    if (bC > 0.0 && pC == pY) outC = mix(cc, chroma(bx), mC);\n  }\n  if (bC > 0.0 && !(bY > 0.0 && pC == pY)) outC = mix(cc, chroma(box(px, pC)), mC);\n  gl_FragColor = vec4(vec3(outY) + outC, c4.a);\n}\n";

    // Builds the two-pass GPU filter (deinterlace, then deband) on a WebGL context.
    // render(source, w, h) draws one frame of [source] (video, canvas or image of size w×h).
    function makeDebandRenderer(gl) {
        var compile = function (type, src) {
            var sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh);
            if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh));
            return sh;
        };
        var link = function (frag) {
            var prog = gl.createProgram();
            gl.attachShader(prog, compile(gl.VERTEX_SHADER, DEBAND_VERT));
            gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, frag));
            gl.bindAttribLocation(prog, 0, 'aFramePosition');
            gl.linkProgram(prog);
            if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
            return {
                prog: prog,
                uTexSize: gl.getUniformLocation(prog, 'uTexSize'),
                uFrame: gl.getUniformLocation(prog, 'uFrame'),
                uParams: gl.getUniformLocation(prog, 'uParams'),
                uTex: gl.getUniformLocation(prog, 'uTexSampler')
            };
        };
        var deint = link(DEINTERLACE_FRAG);
        var deband = link(DEBAND_FRAG);
        // light: 2 instead of 4 deband rounds (TVs, or when the device can't keep up)
        var debandLight = link(DEBAND_FRAG.replace('#define ITERATIONS 4', '#define ITERATIONS 2'));
        var buf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 0, 1, 1, -1, 0, 1, -1, 1, 0, 1, 1, 1, 0, 1]), gl.STATIC_DRAW);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 0, 0);
        var makeTex = function () {
            var t = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, t);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            return t;
        };
        var srcTex = makeTex();
        var midTex = makeTex();
        var fbo = gl.createFramebuffer();
        var midW = 0, midH = 0, frame = 0;
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        return {
            render: function (source, w, h, outW, outH, light) {
                gl.activeTexture(gl.TEXTURE0);
                gl.bindTexture(gl.TEXTURE_2D, srcTex);
                gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, source);
                frame = (frame + 1) % 1024;
                var input = srcTex;
                // interlaced video is never above 1080 lines; skip the pass for bigger videos
                if (h <= 1200) {
                    if (midW !== w || midH !== h) {
                        gl.bindTexture(gl.TEXTURE_2D, midTex);
                        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, w, h, 0, gl.RGB, gl.UNSIGNED_BYTE, null);
                        gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
                        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, midTex, 0);
                        midW = w; midH = h;
                    }
                    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
                    gl.viewport(0, 0, w, h);
                    gl.useProgram(deint.prog);
                    gl.bindTexture(gl.TEXTURE_2D, srcTex);
                    gl.uniform1i(deint.uTex, 0);
                    gl.uniform2f(deint.uTexSize, w, h);
                    gl.uniform3f(deint.uParams, 0.7 / 255, 2.5 / 255, 0.8 / 255);
                    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
                    input = midTex;
                }
                gl.bindFramebuffer(gl.FRAMEBUFFER, null);
                gl.viewport(0, 0, outW, outH);
                var db = light ? debandLight : deband;
                gl.useProgram(db.prog);
                gl.bindTexture(gl.TEXTURE_2D, input);
                gl.uniform1i(db.uTex, 0);
                gl.uniform2f(db.uTexSize, w, h);
                gl.uniform1f(db.uFrame, frame + Math.random() * 1000);
                gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
            }
        };
    }
    window.__lumenMakeDebandRenderer = makeDebandRenderer;

    function attachDeband(v) {
        if (!v || v.__lumenDeband || v.__lumenDebandTooSlow || !v.parentNode) return;
        if (v.mediaKeys) { debandReport('drm'); return; }
        var canvas = document.createElement('canvas');
        canvas.className = 'lumen-deband-layer';
        canvas.style.cssText = 'position:absolute;pointer-events:none;display:block;margin:0;padding:0;border:0;background:transparent;visibility:hidden;';
        var gl = canvas.getContext('webgl', { alpha: false, antialias: false, depth: false, stencil: false, premultipliedAlpha: false });
        if (!gl) { debandReport('nogl'); return; }
        var renderer;
        try { renderer = makeDebandRenderer(gl); }
        catch (e) { console.log('Lumen deband: ' + e); debandReport('nogl'); return; }

        v.parentNode.insertBefore(canvas, v.nextSibling);
        var layer = { v: v, canvas: canvas, running: true, light: !!cfg.tv };
        // safety net: frames the screen showed without our filter in between mean the device
        // can't keep up; first go light, then stop (instead of freezing the whole TV)
        var perf = { since: 0, seen: 0, missed: 0, last: -1 };
        var checkPerf = function (now, meta) {
            if (!meta || typeof meta.presentedFrames !== 'number' || v.paused) { perf.last = -1; return true; }
            if (perf.last >= 0) {
                var gap = Math.max(0, meta.presentedFrames - perf.last - 1);
                perf.missed += gap;
                perf.seen += 1 + gap;
            }
            perf.last = meta.presentedFrames;
            if (!perf.since) perf.since = now;
            if (now - perf.since < 3000) return true;
            var slow = perf.seen > 30 && perf.missed / perf.seen > 0.25;
            perf.since = now; perf.seen = 0; perf.missed = 0;
            if (!slow) return true;
            if (!layer.light) { layer.light = true; debandReport('slow:light'); return true; }
            v.__lumenDebandTooSlow = true;
            detachDeband(layer);
            debandReport('slow:off');
            return false;
        };
        v.__lumenDeband = layer;
        debandLayers.push(layer);

        // position the canvas over the video (not every frame: reading styles each frame costs time)
        var place = function () {
            var cs = getComputedStyle(v);
            canvas.style.left = v.offsetLeft + 'px';
            canvas.style.top = v.offsetTop + 'px';
            canvas.style.width = v.offsetWidth + 'px';
            canvas.style.height = v.offsetHeight + 'px';
            canvas.style.objectFit = cs.objectFit || 'contain';
            canvas.style.objectPosition = cs.objectPosition || '50% 50%';
            canvas.style.zIndex = cs.zIndex === 'auto' ? '' : cs.zIndex;
            canvas.style.transform = cs.transform === 'none' ? '' : cs.transform;
            var shown = v.offsetWidth > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' &&
                v.readyState >= 2 && layer.drawn;
            canvas.style.visibility = shown ? 'visible' : 'hidden';
        };
        layer.placeTimer = setInterval(place, 400);
        try {
            layer.resizeObs = new ResizeObserver(place);
            layer.resizeObs.observe(v);
        } catch (e) {}

        var draw = function (now, meta) {
            if (!layer.running) return;
            if (layer.drawn && !checkPerf(now, meta)) return;
            try {
                if (v.readyState >= 2 && v.videoWidth) {
                    var scale = Math.min(1, 1920 / v.videoWidth);
                    var w = Math.round(v.videoWidth * scale), h = Math.round(v.videoHeight * scale);
                    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
                    renderer.render(v, v.videoWidth, v.videoHeight, w, h, layer.light);
                    if (!layer.drawn) {
                        layer.drawn = true;
                        place();
                        debandReport('ok:' + v.videoWidth + 'x' + v.videoHeight);
                    }
                }
            } catch (e) {
                // the browser refuses to let pages read this video (protected or cross-site)
                detachDeband(layer);
                debandReport(e && e.name === 'SecurityError' ? 'blocked' : 'error:' + ((e && (e.name + ': ' + e.message)) || e));
                return;
            }
            if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(draw); else requestAnimationFrame(draw);
        };
        draw();
        v.addEventListener('seeked', function () { if (layer.running) requestAnimationFrame(draw); });
    }

    function detachDeband(layer) {
        layer.running = false;
        clearInterval(layer.placeTimer);
        try { if (layer.resizeObs) layer.resizeObs.disconnect(); } catch (e) {}
        if (layer.canvas.parentNode) layer.canvas.parentNode.removeChild(layer.canvas);
        layer.v.__lumenDeband = null;
        var i = debandLayers.indexOf(layer);
        if (i >= 0) debandLayers.splice(i, 1);
    }

    // all <video> elements, also inside web components (shadow DOM), which querySelectorAll misses
    function allVideos() {
        var out = Array.prototype.slice.call(document.querySelectorAll('video'));
        var walk = function (root, depth) {
            if (depth > 6) return;
            var all = root.querySelectorAll('*');
            for (var i = 0; i < all.length; i++) {
                var sr = all[i].shadowRoot;
                if (sr) {
                    out = out.concat(Array.prototype.slice.call(sr.querySelectorAll('video')));
                    walk(sr, depth + 1);
                }
            }
        };
        try { walk(document, 0); } catch (e) {}
        return out;
    }

    var debandScanTimer = 0, debandReportTimer = 0;
    function setDebandLocal(on) {
        debandWanted = !!on;
        clearInterval(debandScanTimer);
        if (debandWanted) {
            allVideos().forEach(attachDeband);
            // players often create their <video> (or replace it) later
            debandScanTimer = setInterval(function () { allVideos().forEach(attachDeband); }, 1500);
            // a short report from every frame, so the browser can say what it found where
            clearTimeout(debandReportTimer);
            debandReportTimer = setTimeout(function () {
                if (!debandWanted) return;
                var vids = allVideos(), playing = 0, filtered = 0, drm = 0;
                vids.forEach(function (v) {
                    if (!v.paused && v.readyState >= 2) playing++;
                    if (v.__lumenDeband && v.__lumenDeband.drawn) filtered++;
                    if (v.mediaKeys) drm++;
                });
                debandReport('scan:' + JSON.stringify({
                    h: location.host || String(location.href).slice(0, 40), top: isTop,
                    v: vids.length, p: playing, f: filtered, d: drm,
                    gl: !!document.createElement('canvas').getContext('webgl')
                }));
            }, 4000);
        } else {
            debandLayers.slice().forEach(detachDeband);
        }
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'deband', on: debandWanted }, '*'); } catch (e) {}
        }
        return document.querySelectorAll('video').length;
    }

    // A video that is itself made full screen hides everything else, including the deband layer.
    // While deband is on, full screen goes to the video's parent instead, with the video filling it.
    var fsOrig = {};
    ['requestFullscreen', 'webkitRequestFullscreen', 'webkitRequestFullScreen'].forEach(function (name) {
        var orig = Element.prototype[name];
        if (typeof orig !== 'function') return;
        fsOrig[name] = orig;
        Element.prototype[name] = function () {
            if (debandWanted && this.tagName === 'VIDEO' && this.__lumenDeband && this.parentElement) {
                var host = this.parentElement;
                host.classList.add('lumen-fs-host');
                addStyle('lumen-fs-style',
                    '.lumen-fs-host:fullscreen,.lumen-fs-host:-webkit-full-screen{background:#000!important;width:100%!important;height:100%!important}' +
                    '.lumen-fs-host:fullscreen>video,.lumen-fs-host:-webkit-full-screen>video{width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;left:0!important;top:0!important;object-fit:contain!important}');
                return orig.apply(host, arguments);
            }
            return orig.apply(this, arguments);
        };
    });

    var origSetDebandLocal = setDebandLocal;
    setDebandLocal = function (on) {
        var n = origSetDebandLocal(on);
        if (on) {
            var fs = document.fullscreenElement || document.webkitFullscreenElement;
            if (fs && fs.tagName === 'VIDEO') debandReport('fsvideo');
        }
        return n;
    };
    window.__lumenSetDeband = setDebandLocal;

    // ---- automatic deband ----
    // 1. Sites set to "always use deband" (top page): on from the start.
    if (isTop && cfg.deband) {
        setDebandLocal(true);
        debandReport('auto:site');
    }

    // 2. Interlacing lines: every 1.5 s a 256×192 piece from the middle of each playing video is
    //    checked for a column-wise brightness oscillation at exactly the line spacing interlacing
    //    produces for this video height (2 lines, or a 480/576-line master scaled up). Videos
    //    with lines score 14-20 on a real interlaced anime; normal video stays below 3.
    var lineTables = {};
    var lineCanvas = null, lineCtx = null, lineHits = [];
    var lineAmp = function (Y, cols, rows, p) {
        var key = rows + ':' + p, t = lineTables[key];
        if (!t) {
            t = { c: new Float32Array(rows), s: new Float32Array(rows) };
            for (var i = 0; i < rows; i++) { t.c[i] = Math.cos(2 * Math.PI * i / p); t.s[i] = Math.sin(2 * Math.PI * i / p); }
            lineTables[key] = t;
        }
        var total = 0;
        for (var x = 0; x < cols; x++) {
            var I = 0, Q = 0;
            for (var y = 0; y < rows; y++) { var v = Y[y * cols + x]; I += v * t.c[y]; Q += v * t.s[y]; }
            total += Math.sqrt(I * I + Q * Q) / rows;
        }
        return total / cols;
    };
    var lineScore = function (v) {
        var W = v.videoWidth, H = v.videoHeight;
        var cw = Math.min(256, W), ch = Math.min(192, H);
        if (!lineCanvas) {
            lineCanvas = document.createElement('canvas');
            lineCtx = lineCanvas.getContext('2d', { willReadFrequently: true });
        }
        if (!lineCtx) return 0;
        lineCanvas.width = cw; lineCanvas.height = ch;
        lineCtx.drawImage(v, Math.floor((W - cw) / 2), Math.floor((H - ch) / 2), cw, ch, 0, 0, cw, ch);
        var d = lineCtx.getImageData(0, 0, cw, ch).data; // throws for videos pages can't read
        var cols = Math.floor(cw / 2), Y = new Float32Array(cols * ch);
        for (var x = 0; x < cols; x++) {
            var sum = 0;
            for (var y = 0; y < ch; y++) {
                var i = (y * cw + x * 2) * 4;
                var l = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
                Y[y * cols + x] = l; sum += l;
            }
            var mean = sum / ch;
            for (var y2 = 0; y2 < ch; y2++) Y[y2 * cols + x] -= mean;
        }
        var periods = [2, 2 * H / 576, 2 * H / 480].map(function (q) { return Math.max(2, q); });
        var best = 0;
        periods.forEach(function (p) {
            var a = lineAmp(Y, cols, ch, p);
            var ref = p * 0.72 >= 2 ? (lineAmp(Y, cols, ch, p * 1.4) + lineAmp(Y, cols, ch, p * 0.72)) / 2 : lineAmp(Y, cols, ch, p * 1.4);
            if (a > 1.0) best = Math.max(best, a / (ref + 0.05));
        });
        return best;
    };
    window.__lumenLineScore = lineScore;
    if (cfg.autoLines) {
        setInterval(function () {
            if (debandWanted || document.hidden) return;
            var vids = allVideos();
            for (var k = 0; k < vids.length; k++) {
                var v = vids[k];
                if (v.paused || v.readyState < 2 || v.videoWidth < 320 || v.mediaKeys || v.__lumenNoRead) continue;
                var score = 0;
                try { score = lineScore(v); } catch (e) { v.__lumenNoRead = true; continue; }
                var now = Date.now();
                lineHits = lineHits.filter(function (t) { return now - t < 60000; });
                if (score > 10 || (score > 6 && lineHits.length > 0)) {
                    setDebandLocal(true);
                    debandReport('auto:lines');
                    return;
                }
                if (score > 6) lineHits.push(now);
            }
        }, 1500);
    }
    window.addEventListener('message', function (e) {
        if (!e.data) return;
        if (e.data.__sofa === 'deband') setDebandLocal(e.data.on);
        // a frame that loaded after deband was switched on (players often load their frame on
        // "play") asks its parent for the current state
        if (e.data.__sofa === 'deband?' && debandWanted && e.source) {
            try { e.source.postMessage({ __sofa: 'deband', on: true }, '*'); } catch (err) {}
        }
    });
    if (!isTop) {
        var askDeband = function () {
            try { window.parent.postMessage({ __sofa: 'deband?' }, '*'); } catch (e) {}
        };
        askDeband();
        onReady(askDeband);
        document.addEventListener('play', function () { if (!debandWanted) askDeband(); }, true);
    }
    document.addEventListener('play', function (e) {
        if (debandWanted && e.target && e.target.tagName === 'VIDEO') attachDeband(e.target);
    }, true);

    // ---------------- passwords ----------------
    function visible(el) {
        if (!el) return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    }

    function findUserField(pass) {
        var scope = pass.form || document;
        var inputs = Array.prototype.slice.call(scope.querySelectorAll(
            'input[type=email], input[type=text], input[type=tel], input:not([type]), input[autocomplete=username]'));
        var before = inputs.filter(function (i) {
            return visible(i) && (pass.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_PRECEDING);
        });
        var pick = before.length ? before[before.length - 1] : inputs.filter(visible)[0];
        return pick || null;
    }

    // sign-up / new-password fields (not the password of a normal login)
    function isSignupField(p) {
        if (!p || p.type !== 'password') return false;
        var ac = (p.getAttribute('autocomplete') || '').toLowerCase();
        if (ac.indexOf('new-password') >= 0) return true;
        if (ac.indexOf('current-password') >= 0) return false;
        var scope = p.form || document;
        var others = Array.prototype.slice.call(scope.querySelectorAll('input[type=password]')).filter(visible);
        if (others.length >= 2) return true; // password + repeat password
        var f = p.form;
        // the page address only counts when it has just this one password form (not login + sign-up)
        var pwForms = 0;
        Array.prototype.forEach.call(document.forms, function (form) {
            if (form.querySelector('input[type=password]')) pwForms++;
        });
        var hint = [p.name, p.id, p.placeholder, p.getAttribute('aria-label'),
            f && f.id, f && f.className, f && f.getAttribute('action'),
            pwForms <= 1 ? location.pathname : ''].join(' ').toLowerCase();
        return /regist|sign.?up|create|new.?pass|join|confirm|repeat|retype/.test(hint);
    }

    function findSignupUser(scope) {
        scope = scope || document;
        var sel = ['input[autocomplete~=username]', 'input[autocomplete~=email]', 'input[type=email]',
            'input[name*=email i]', 'input[id*=email i]', 'input[name*=user i]', 'input[id*=user i]',
            'input[name*=login i]', 'input[id*=login i]'];
        for (var i = 0; i < sel.length; i++) {
            var list = Array.prototype.slice.call(scope.querySelectorAll(sel[i])).filter(function (el) {
                return visible(el) && el.type !== 'password' && el.type !== 'hidden' && el.value;
            });
            if (list.length) return list[0];
        }
        return null;
    }

    function strongPassword() {
        var sets = ['ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnopqrstuvwxyz', '23456789', '!@#$%&*-_=+?'];
        var all = sets.join('');
        var r = new Uint32Array(32);
        crypto.getRandomValues(r);
        var out = [];
        for (var i = 0; i < 16; i++) {
            var set = i < sets.length ? sets[i] : all; // at least one of every kind
            out.push(set.charAt(r[i] % set.length));
        }
        for (var j = out.length - 1; j > 0; j--) { // shuffle
            var k = r[16 + j] % (j + 1);
            var t = out[j]; out[j] = out[k]; out[k] = t;
        }
        return out.join('');
    }

    function setFieldValue(el, value) {
        var setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
        if (setter && setter.set) setter.set.call(el, value); else el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function autoSave(user, pass) {
        try { TVBro.sofaAutoSaveLogin(user || '', pass); } catch (e) {}
    }

    // "Use a strong password" suggestion under sign-up password fields
    var suggestion = null;
    function hideSuggestion() {
        if (suggestion) { suggestion.host.remove(); suggestion = null; }
    }
    function showSuggestion(field) {
        if (suggestion && suggestion.field === field) return;
        hideSuggestion();
        var pw = strongPassword();
        var host = document.createElement('lumen-password');
        host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:0;top:0';
        var root = host.attachShadow({ mode: 'closed' });
        root.innerHTML = '<style>' +
            '.b{font:15px/1.3 system-ui,sans-serif;background:#0f1d20;color:#e8f5f2;border-radius:12px;' +
            'box-shadow:0 6px 24px rgba(0,0,0,.45);padding:10px 12px;display:flex;align-items:center;gap:10px;max-width:92vw}' +
            '.t{display:flex;flex-direction:column;min-width:0}.s{font-size:12px;opacity:.75}' +
            '.p{font:600 16px/1.3 ui-monospace,monospace;letter-spacing:.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
            'button{all:unset;cursor:pointer;border-radius:9px;padding:9px 14px;font:600 15px system-ui,sans-serif}' +
            '.u{background:#20c997;color:#062b2f}.x{opacity:.7;padding:9px 8px}</style>' +
            '<div class="b"><span>🔑</span><div class="t"><span class="s">Use a strong password (saved for this site)</span>' +
            '<span class="p"></span></div><button class="u">Use</button><button class="x">✕</button></div>';
        root.querySelector('.p').textContent = pw;
        var keep = function (e) { e.preventDefault(); e.stopPropagation(); };
        root.querySelector('.b').addEventListener('mousedown', keep, true);
        root.querySelector('.b').addEventListener('touchstart', function (e) { e.stopPropagation(); }, true);
        root.querySelector('.u').addEventListener('click', function (e) {
            keep(e);
            var scope = field.form || document;
            var targets = Array.prototype.slice.call(scope.querySelectorAll('input[type=password]'))
                .filter(function (p) { return visible(p) && isSignupField(p); });
            if (targets.indexOf(field) < 0) targets.unshift(field);
            targets.forEach(function (p) { setFieldValue(p, pw); });
            var user = findSignupUser(scope);
            autoSave(user ? user.value : '', pw);
            hideSuggestion();
        }, true);
        root.querySelector('.x').addEventListener('click', function (e) { keep(e); hideSuggestion(); }, true);
        document.documentElement.appendChild(host);
        suggestion = { host: host, field: field };
        placeSuggestion();
    }
    function placeSuggestion() {
        if (!suggestion) return;
        if (!suggestion.field.isConnected || !visible(suggestion.field)) { hideSuggestion(); return; }
        var r = suggestion.field.getBoundingClientRect();
        var h = suggestion.host.getBoundingClientRect().height || 60;
        var top = r.bottom + 6;
        if (top + h > window.innerHeight - 4) top = Math.max(4, r.top - h - 6);
        suggestion.host.style.left = Math.max(4, Math.min(r.left, window.innerWidth - 320)) + 'px';
        suggestion.host.style.top = top + 'px';
    }

    var lastOffer = 0;
    function captureLogin(scope) {
        if (!cfg.passwords || !isTop || !/^https?:$/.test(location.protocol)) return;
        var passes = Array.prototype.slice.call((scope || document).querySelectorAll('input[type=password]'))
            .filter(function (p) { return p.value; });
        if (!passes.length) return;
        if (Date.now() - lastOffer < 3000) return;
        var signup = passes.length > 1 || isSignupField(passes[0]);
        if (signup) {
            // new account: saved automatically (the new password, not an old one in a change form)
            var newPass = passes.filter(isSignupField).pop() || passes[passes.length - 1];
            var u = findSignupUser(scope) || findUserField(newPass);
            lastOffer = Date.now();
            autoSave(u ? u.value : '', newPass.value);
            return;
        }
        lastOffer = Date.now();
        var pass = passes[0];
        var user = findUserField(pass);
        try { TVBro.sofaOfferSaveLogin(user ? user.value : '', pass.value); } catch (e) {}
    }

    if (isTop && cfg.passwords) {
        document.addEventListener('focusin', function (e) {
            var t = e.target;
            if (t && t.tagName === 'INPUT' && isSignupField(t) && !t.value && /^https?:$/.test(location.protocol)) {
                showSuggestion(t);
            } else if (suggestion && t !== suggestion.field) {
                hideSuggestion();
            }
        }, true);
        document.addEventListener('input', function (e) {
            // typing an own password: the suggestion goes away
            if (suggestion && e.target === suggestion.field && e.isTrusted) hideSuggestion();
        }, true);
        window.addEventListener('scroll', placeSuggestion, true);
        window.addEventListener('resize', placeSuggestion);
    }

    if (isTop) {
        document.addEventListener('submit', function (e) { captureLogin(e.target); }, true);
        document.addEventListener('click', function (e) {
            var b = e.target && e.target.closest ? e.target.closest('button, input[type=submit], [role=button]') : null;
            if (!b) return;
            var form = b.form || b.closest('form');
            setTimeout(function () { captureLogin(form || document); }, 0);
        }, true);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && e.target && e.target.type === 'password') captureLogin(e.target.form || document);
        }, true);

        // Called by the app with the login saved for this site. Fills visible fields,
        // also ones that appear later (sign-in dialogs), for up to one minute.
        window.__sofaFill = function (username, password) {
            var done = false;
            var setValue = function (el, value) {
                var proto = Object.getPrototypeOf(el);
                var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                if (setter && setter.set) setter.set.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
            var tryFill = function () {
                if (done) return;
                var pass = Array.prototype.slice.call(document.querySelectorAll('input[type=password]')).filter(visible)[0];
                var user = null;
                if (!pass) {
                    // two-step logins: username page first
                    user = document.querySelector('input[autocomplete=username], input[type=email], input[name*=user i], input[name*=login i], input[id*=email i]');
                    if (user && visible(user) && !user.value && username) setValue(user, username);
                    return;
                }
                user = findUserField(pass);
                if (user && !user.value && username) setValue(user, username);
                if (!pass.value) setValue(pass, password);
                done = true;
                observer.disconnect();
            };
            var observer = new MutationObserver(tryFill);
            observer.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(function () { observer.disconnect(); }, 60000);
            tryFill();
        };
    }

    // ---------------- long press: select & copy text, paste into fields ----------------
    // Called by the app when the remote's OK is held on the page (x, y in view pixels).
    if (isTop) {
        var lp = { edit: null, start: null, end: null };
        var toCss = function (x, y, viewW) {
            var f = viewW > 0 ? window.innerWidth / viewW : 1;
            return [x * f, y * f];
        };
        var caretAt = function (cx, cy) {
            try {
                if (document.caretRangeFromPoint) {
                    var r = document.caretRangeFromPoint(cx, cy);
                    return r ? { node: r.startContainer, offset: r.startOffset } : null;
                }
                if (document.caretPositionFromPoint) {
                    var p = document.caretPositionFromPoint(cx, cy);
                    return p ? { node: p.offsetNode, offset: p.offset } : null;
                }
            } catch (e) {}
            return null;
        };
        var editableOf = function (el) {
            var f = el && el.closest ? el.closest('input, textarea, [contenteditable]') : null;
            if (!f) return null;
            if (f.isContentEditable === false && f.tagName !== 'INPUT' && f.tagName !== 'TEXTAREA') return null;
            if (f.tagName === 'INPUT' && /^(button|submit|reset|checkbox|radio|file|image|range|color|hidden)$/i.test(f.type)) return null;
            if (f.disabled || f.readOnly) return null;
            return f;
        };
        window.__lumenLongPress = function (x, y, viewW) {
            var c = toCss(x, y, viewW);
            var el = document.elementFromPoint(c[0], c[1]);
            var link = el && el.closest ? el.closest('a[href]') : null;
            var ed = editableOf(el);
            if (ed) { lp.edit = ed; return JSON.stringify({ kind: 'edit' }); }
            var pos = caretAt(c[0], c[1]);
            if (pos && pos.node && pos.node.nodeType === 3 && /\S/.test(pos.node.data)) {
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.collapse(pos.node, pos.offset);
                try {
                    sel.modify('move', 'backward', 'word');
                    sel.modify('extend', 'forward', 'word');
                } catch (e) {}
                lp.start = { node: sel.anchorNode, offset: sel.anchorOffset };
                lp.end = { node: sel.focusNode, offset: sel.focusOffset };
                return JSON.stringify({ kind: 'text', text: sel.toString(), href: link ? link.href : null });
            }
            return JSON.stringify({ kind: link ? 'link' : 'none', href: link ? link.href : null });
        };
        // the pointer moved while selecting: the selection runs from the first word to the pointer
        window.__lumenSelExtend = function (x, y, viewW) {
            if (!lp.start) return '';
            var c = toCss(x, y, viewW);
            var pos = caretAt(c[0], c[1]);
            if (!pos || !pos.node) return '';
            var sel = window.getSelection();
            try {
                var word = document.createRange();
                word.setStart(lp.start.node, lp.start.offset);
                word.setEnd(lp.end.node, lp.end.offset);
                var where = word.comparePoint(pos.node, pos.offset);
                if (where === 0) sel.setBaseAndExtent(lp.start.node, lp.start.offset, lp.end.node, lp.end.offset);
                else if (where < 0) {
                    sel.setBaseAndExtent(lp.end.node, lp.end.offset, pos.node, pos.offset);
                    sel.modify('extend', 'backward', 'word');
                } else {
                    sel.setBaseAndExtent(lp.start.node, lp.start.offset, pos.node, pos.offset);
                    sel.modify('extend', 'forward', 'word');
                }
            } catch (e) {}
            return String(sel.toString().length);
        };
        window.__lumenSelCopy = function (cancel) {
            var sel = window.getSelection();
            var t = cancel ? '' : sel.toString();
            sel.removeAllRanges();
            lp.start = lp.end = null;
            return t;
        };
        window.__lumenPaste = function (text) {
            var f = lp.edit;
            if (!f || !f.isConnected) return 'none';
            var wasFocused = document.activeElement === f;
            f.focus();
            if (f.tagName === 'INPUT' || f.tagName === 'TEXTAREA') {
                try {
                    var s = f.selectionStart, e = f.selectionEnd;
                    // a field that wasn't being typed in: add at the end
                    if (!wasFocused && s !== null && s !== undefined) { s = e = (f.value || '').length; }
                    if (s === null || s === undefined) throw new Error('no caret');
                    f.setRangeText(text, s, e, 'end');
                    f.dispatchEvent(new Event('input', { bubbles: true }));
                    f.dispatchEvent(new Event('change', { bubbles: true }));
                } catch (err) {
                    setFieldValue(f, (f.value || '') + text); // email / number fields have no caret API
                }
            } else {
                document.execCommand('insertText', false, text);
            }
            return 'ok';
        };
    }

    // ---------------- desktop site ----------------
    // A desktop user agent alone still leaves "width=device-width" pages squeezed on a TV or
    // tablet, so lay the page out at a desktop width and let the browser zoom it to fit.
    try {
        if (isTop && window.TVBro && typeof TVBro.sofaIsDesktopSite === 'function') cfg.desktop = TVBro.sofaIsDesktopSite(location.hostname);
    } catch (e) {}
    if (cfg.desktop && isTop) {
        var fixViewport = function () {
            var metas = document.querySelectorAll('meta[name="viewport" i]');
            for (var i = 0; i < metas.length; i++) {
                if (metas[i].getAttribute('content') !== 'width=1280') metas[i].setAttribute('content', 'width=1280');
            }
        };
        var vpObserver = new MutationObserver(fixViewport);
        vpObserver.observe(document.documentElement || document, { childList: true, subtree: true });
        onReady(function () { fixViewport(); setTimeout(function () { vpObserver.disconnect(); }, 3000); });
    }

    // ---------------- scrolling inside the page ----------------
    // TV remotes move a virtual cursor; a page only scrolls when the cursor reaches the screen edge,
    // so long submenus, lists and side panels in the middle of the screen never scrolled. The
    // browser asks which scrollable box is under the cursor (__lumenScrollProbe) and scrolls it
    // when the cursor pushes against that box's edge (__lumenInnerScroll).
    if (isTop) {
        var innerBox = null; // { el, ox, oy, frameDoc }

        var viewportBox = function () {
            var v = window.visualViewport;
            if (v && v.width > 0) return { x: v.offsetLeft, y: v.offsetTop, w: v.width, h: v.height };
            return { x: 0, y: 0, w: window.innerWidth || 1, h: window.innerHeight || 1 };
        };

        var overflows = function (el, axis) {
            var st;
            try { st = (el.ownerDocument.defaultView || window).getComputedStyle(el); } catch (e) { return false; }
            if (!st) return false;
            var o = axis === 'y' ? st.overflowY : st.overflowX;
            if (!/(auto|scroll|overlay)/.test(o)) return false;
            return axis === 'y' ? el.scrollHeight > el.clientHeight + 4 : el.scrollWidth > el.clientWidth + 4;
        };

        // the scrolling element of a same-origin frame counts as a box of the top page
        var frameScrolls = function (el, axis) {
            return axis === 'y' ? el.scrollHeight > el.clientHeight + 4 : el.scrollWidth > el.clientWidth + 4;
        };

        var boxState = function (b) {
            var el = b.el, vp = viewportBox();
            if (!el.isConnected) return null;
            var r;
            if (b.frameDoc) {
                r = { left: b.ox, top: b.oy, right: b.ox + el.clientWidth, bottom: b.oy + el.clientHeight };
            } else {
                var br = el.getBoundingClientRect();
                r = { left: br.left + b.ox, top: br.top + b.oy, right: br.right + b.ox, bottom: br.bottom + b.oy };
            }
            // only the visible part (so the edges can be reached with the cursor)
            var l = Math.max(r.left, vp.x), t = Math.max(r.top, vp.y);
            var rr = Math.min(r.right, vp.x + vp.w), bb = Math.min(r.bottom, vp.y + vp.h);
            if (rr - l < 24 || bb - t < 24) return null;
            // a box that fills the screen is the page itself; the normal page scrolling handles it
            if ((rr - l) >= vp.w * 0.9 && (bb - t) >= vp.h * 0.9) return null;
            var maxY = el.scrollHeight - el.clientHeight, maxX = el.scrollWidth - el.clientWidth;
            var sy = el.scrollTop, sx = el.scrollLeft;
            var rtl = false;
            try { rtl = (el.ownerDocument.defaultView || window).getComputedStyle(el).direction === 'rtl'; } catch (e) {}
            var left, right;
            if (rtl && sx <= 0) { left = b.x && sx > -maxX + 1; right = b.x && sx < -0.5; }
            else { left = b.x && sx > 0.5; right = b.x && sx < maxX - 1; }
            return JSON.stringify({
                l: (l - vp.x) / vp.w, t: (t - vp.y) / vp.h, r: (rr - vp.x) / vp.w, b: (bb - vp.y) / vp.h,
                up: !!(b.y && sy > 0.5), down: !!(b.y && sy < maxY - 1), left: !!left, right: !!right
            });
        };

        window.__lumenScrollProbe = function (fx, fy) {
            innerBox = null;
            try {
                var vp = viewportBox();
                var x = vp.x + fx * vp.w, y = vp.y + fy * vp.h;
                var doc = document, ox = 0, oy = 0;
                var el = doc.elementFromPoint(x, y);
                // look into same-origin frames
                for (var depth = 0; el && (el.tagName === 'IFRAME' || el.tagName === 'FRAME') && depth < 4; depth++) {
                    var idoc = null;
                    try { idoc = el.contentDocument; } catch (e) { idoc = null; }
                    if (!idoc) break;
                    var fr = el.getBoundingClientRect();
                    var fox = ox + fr.left + el.clientLeft, foy = oy + fr.top + el.clientTop;
                    var inner = idoc.elementFromPoint(x - fox, y - foy);
                    if (!inner) break;
                    doc = idoc; ox = fox; oy = foy; el = inner;
                }
                // and into shadow DOM (web components)
                for (var sd = 0; el && el.shadowRoot && sd < 8; sd++) {
                    var se = el.shadowRoot.elementFromPoint(x - ox, y - oy);
                    if (!se || se === el) break;
                    el = se;
                }
                for (var n = el; n; n = n.parentElement || (n.parentNode && n.parentNode.host) || null) {
                    if (n.nodeType !== 1) continue;
                    var nd = n.ownerDocument;
                    var isDocScroller = (n === nd.scrollingElement || n === nd.documentElement || n === nd.body);
                    if (isDocScroller) {
                        if (nd === document) break; // the page itself
                        var se2 = nd.scrollingElement || nd.documentElement;
                        if (n !== se2) continue;
                        var fy2 = frameScrolls(se2, 'y'), fx2 = frameScrolls(se2, 'x');
                        if (fy2 || fx2) {
                            innerBox = { el: se2, ox: ox, oy: oy, frameDoc: true, x: fx2, y: fy2 };
                            break;
                        }
                        continue;
                    }
                    var ay = overflows(n, 'y'), ax = overflows(n, 'x');
                    if (ay || ax) {
                        innerBox = { el: n, ox: ox, oy: oy, frameDoc: false, x: ax, y: ay };
                        break;
                    }
                }
                if (!innerBox) return '';
                var st = boxState(innerBox);
                if (!st) innerBox = null;
                return st || '';
            } catch (e) {
                innerBox = null;
                return '';
            }
        };

        window.__lumenInnerScroll = function (fdx, fdy) {
            var b = innerBox;
            if (!b) return '';
            try {
                var vp = viewportBox();
                var dx = b.x ? fdx * vp.w : 0, dy = b.y ? fdy * vp.h : 0;
                var el = b.el;
                // 'instant' so a CSS "scroll-behavior: smooth" doesn't swallow the small steps
                try { el.scrollBy({ left: dx, top: dy, behavior: 'instant' }); }
                catch (e) { el.scrollTop += dy; el.scrollLeft += dx; }
                var st = boxState(b);
                if (!st) innerBox = null;
                return st || '';
            } catch (e) {
                innerBox = null;
                return '';
            }
        };

        // ---- auto-hiding top bar ----
        // The browser sees ordinary page scrolling itself. Many web apps scroll a full-size inner
        // box instead (the page itself never moves), so report those boxes' scrolling as well.
        var boxY = (typeof WeakMap === 'function') ? new WeakMap() : null, pendingDy = 0, lastSent = 0;
        document.addEventListener('scroll', function (e) {
            var t = e.target;
            if (!t || t === document || t.nodeType !== 1) return;
            if (!window.TVBro || typeof TVBro.sofaPageScroll !== 'function') return;
            var r = t.getBoundingClientRect();
            var vw = window.innerWidth || 1, vh = window.innerHeight || 1;
            if (r.width < vw * 0.6 || r.height < vh * 0.6) return; // menus, carousels, ...
            var y = t.scrollTop;
            var prev = boxY && boxY.has(t) ? boxY.get(t) : 0;
            if (boxY) boxY.set(t, y);
            pendingDy += y - prev;
            var now = Date.now();
            if (y <= 0 || now - lastSent > 80) {
                lastSent = now;
                try { TVBro.sofaPageScroll(Math.round(y), Math.round(pendingDy)); } catch (err) {}
                pendingDy = 0;
            }
        }, { capture: true, passive: true });
    }

    // ---------------- start-up ----------------
    onReady(function () {
        challengePage = isChallengePage();
        if (challengePage) {
            // ask the app to reload this page in clean mode (nothing injected, ad blocking off)
            if (isTop) { try { TVBro.sofaChallenge(location.href); } catch (e) {} }
            return;
        }
        if (cfg.maxQuality) {
            applyPlayerApiQuality();
            // single-page sites (YouTube) change videos without reloading
            setInterval(applyPlayerApiQuality, 4000);
        }
    });
})();
