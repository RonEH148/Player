/*
 * SofaBrowse page enhancements (runs in every frame at document start when supported).
 * Features: cosmetic ad hiding, pop-up blocking, automatic highest video quality,
 * built-in player fallback for HLS/DASH, forced dark mode, passwords, desktop site.
 * Based on TV Bro (https://github.com/truefedex/tv-bro).
 */
(function () {
    'use strict';
    if (window.__sofaInstalled) return;
    window.__sofaInstalled = true;

    var host = location.hostname || '';
    // Never touch human-verification frames: modifying them makes checks fail.
    if (/(^|\.)challenges\.cloudflare\.com$/.test(host) || /(^|\.)hcaptcha\.com$/.test(host) ||
        location.pathname.indexOf('/cdn-cgi/challenge-platform') === 0 ||
        location.pathname.indexOf('/recaptcha/') === 0) {
        return;
    }

    // ---------------- settings ----------------
    var cfg = window.__sofaCfg || {};
    try {
        if (window.TVBro && typeof TVBro.sofaSettings === 'function') {
            var live = JSON.parse(TVBro.sofaSettings(location.hostname));
            if (live && typeof live === 'object') cfg = live;
        }
    } catch (e) { /* use embedded settings */ }

    var isTop = (window.top === window);
    var origOpen = window.open;
    var challengePage = false;

    function isChallengePage() {
        try {
            if (window._cf_chl_opt) return true;
            var t = (document.title || '').toLowerCase();
            if (t.indexOf('just a moment') === 0 || t.indexOf('attention required') === 0) return true;
            if (document.querySelector('#challenge-form, #challenge-running, .cf-turnstile, iframe[src*="challenges.cloudflare.com"]')) {
                // a Turnstile widget inside a normal page is fine; only the full interstitial matters
                return !!document.querySelector('#challenge-form, #challenge-running') || t.indexOf('just a moment') !== -1;
            }
        } catch (e) {}
        return false;
    }

    function onReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    }

    function addStyle(id, css) {
        var root = document.head || document.documentElement;
        if (!root) return null;
        var el = document.getElementById(id);
        if (!el) {
            el = document.createElement('style');
            el.id = id;
            root.appendChild(el);
        }
        el.textContent = css;
        return el;
    }

    // ---------------- pop-up blocker ----------------
    var lastClick = { time: 0, href: null, overlay: false };
    var isAppHomePage = location.href.indexOf('https://tvbro.phlox.dev/appcontent/home') === 0;
    if (cfg.popups && !isAppHomePage) {
        // Remember what was clicked. A pop-up is only refused when there was no click at all, or when
        // the click landed on an invisible overlay (the usual pop-under trick). Clicks on real links,
        // buttons and text may open new tabs - download sites rely on that.
        var isOverlayElement = function (el) {
            try {
                var node = el;
                for (var depth = 0; node && node !== document.body && depth < 6; depth++, node = node.parentElement) {
                    var st = getComputedStyle(node);
                    if (st.position !== 'fixed' && st.position !== 'absolute') continue;
                    var r = node.getBoundingClientRect();
                    var big = r.width >= window.innerWidth * 0.7 && r.height >= window.innerHeight * 0.5;
                    var empty = (node.innerText || '').trim().length === 0 && !node.querySelector('img,video,canvas,svg,picture,iframe');
                    var see = parseFloat(st.opacity) < 0.1 || st.backgroundColor === 'rgba(0, 0, 0, 0)' || st.backgroundColor === 'transparent';
                    if (big && empty && see) return true;
                }
            } catch (e) {}
            return false;
        };

        document.addEventListener('click', function (e) {
            if (!e.isTrusted) return;
            lastClick.time = Date.now();
            var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
            lastClick.href = a ? a.href : null;
            lastClick.overlay = isOverlayElement(e.target);
        }, true);

        var showBlockedBanner = function (url) {
            try {
                var old = document.getElementById('lumen-popup-banner');
                if (old) old.remove();
                var bar = document.createElement('div');
                bar.id = 'lumen-popup-banner';
                bar.style.cssText = 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483647;' +
                    'background:rgba(15,29,32,.95);color:#e8f5f2;font:500 16px/1.3 system-ui,Roboto,sans-serif;' +
                    'padding:10px 12px 10px 16px;border-radius:14px;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.4)';
                var text = document.createElement('span');
                var host = '';
                try { host = new URL(url, location.href).hostname; } catch (e) {}
                text.textContent = 'Pop-up blocked' + (host ? ' (' + host + ')' : '');
                var open = document.createElement('button');
                open.textContent = 'Open';
                open.style.cssText = 'all:unset;cursor:pointer;background:#20c997;color:#062b2f;font-weight:700;padding:8px 14px;border-radius:10px';
                open.addEventListener('click', function (e) {
                    e.stopPropagation();
                    bar.remove();
                    origOpen.call(window, url, '_blank');
                }, true);
                var close = document.createElement('button');
                close.textContent = '✕';
                close.style.cssText = 'all:unset;cursor:pointer;padding:6px 8px;opacity:.7';
                close.addEventListener('click', function (e) { e.stopPropagation(); bar.remove(); }, true);
                bar.appendChild(text); bar.appendChild(open); bar.appendChild(close);
                (document.body || document.documentElement).appendChild(bar);
                setTimeout(function () { if (bar.parentNode) bar.remove(); }, 8000);
            } catch (e) {}
        };

        window.open = function (url, target, features) {
            if (challengePage) return origOpen.apply(window, arguments);
            // opening in the same tab is navigation, not a pop-up (used e.g. by the home page search)
            var t = (target || '').toLowerCase();
            if (t === '_self' || t === '_top' || t === '_parent') return origOpen.apply(window, arguments);
            var recentClick = (Date.now() - lastClick.time) < 2000;
            var full = '';
            try { full = url ? new URL(url, location.href).href : ''; } catch (e) {}
            if (!recentClick || lastClick.overlay) {
                console.log('Lumen blocked pop-up: ' + full);
                if (full && isTop) showBlockedBanner(full);
                return null;
            }
            return origOpen.apply(window, arguments);
        };

        var sameSite = function (url) {
            try {
                var u = new URL(url, location.href);
                return u.hostname.split('.').slice(-2).join('.') === location.hostname.split('.').slice(-2).join('.');
            } catch (e) { return false; }
        };

        // pop-under links: invisible full-page anchors that open ads in a new tab
        document.addEventListener('click', function (e) {
            if (challengePage) return;
            var a = e.target && e.target.closest ? e.target.closest('a[target="_blank"]') : null;
            if (!a || sameSite(a.href)) return;
            var r = a.getBoundingClientRect();
            var hugeInvisible = r.width >= window.innerWidth * 0.8 && r.height >= window.innerHeight * 0.6 &&
                (a.textContent || '').trim().length === 0 && !a.querySelector('img,video,picture');
            if (hugeInvisible) {
                e.preventDefault();
                e.stopPropagation();
                a.remove();
                console.log('SofaBrowse blocked pop-under link: ' + a.href);
            }
        }, true);
    }

    // ---------------- cosmetic ad hiding ----------------
    var AD_SELECTORS = [
        'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="div-gpt-ad"]',
        'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
        'iframe[src*="amazon-adsystem.com"]', 'iframe[src*="adnxs.com"]', 'iframe[src*="taboola.com"]',
        'amp-ad', 'amp-embed[type="taboola"]', '[data-ad-slot]', '[data-ad-unit]', '[data-adunit]',
        '[id^="taboola-"]', '.trc_related_container', '.OUTBRAIN', '[data-widget-id^="AR_"]',
        '.ad-banner', '.ad-container', '.ad-wrapper', '.ad-slot', '.ad-unit', '.ad_unit', '.adBanner',
        '.advertisement', '.advert', '.sponsored-ad', '.banner-ad', '.sticky-ad', '.ad-sticky',
        '#ad-banner', '#ad_banner', '#adContainer', '#sticky-ad', '[aria-label="Advertisement"]',
        'a[href*="doubleclick.net/"]', 'a[href*="/aclk?"]'
    ];

    function removeAntiAdblockOverlays() {
        var re = /ad.?block|disable your ad|turn off your ad|whitelist (our|this) site|adblocker detected/i;
        var nodes = document.querySelectorAll('body > div, body > section, body > aside');
        for (var i = 0; i < nodes.length; i++) {
            var el = nodes[i];
            var st = getComputedStyle(el);
            if (st.position !== 'fixed' && st.position !== 'absolute') continue;
            var r = el.getBoundingClientRect();
            if (r.width < window.innerWidth * 0.5 || r.height < window.innerHeight * 0.4) continue;
            if (!re.test((el.innerText || '').slice(0, 2000))) continue;
            el.remove();
            [document.documentElement, document.body].forEach(function (n) {
                if (!n) return;
                n.style.setProperty('overflow', 'auto', 'important');
                n.style.removeProperty('position');
            });
        }
    }

    if (cfg.cosmetic) {
        onReady(function () {
            if (challengePage) return;
            addStyle('sofa-cosmetic', AD_SELECTORS.join(',\n') +
                ' { display: none !important; visibility: hidden !important; }');
            if (isTop) {
                setTimeout(removeAntiAdblockOverlays, 1500);
                setTimeout(removeAntiAdblockOverlays, 5000);
            }
        });
    }

    // ---------------- forced dark mode ----------------
    function luminance(color) {
        var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(color || '');
        if (!m) return -1;
        if (m[4] !== undefined && parseFloat(m[4]) === 0) return -1; // transparent
        return (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255;
    }

    if (cfg.dark && isTop) {
        onReady(function () {
            if (challengePage) return;
            var bg = luminance(getComputedStyle(document.body || document.documentElement).backgroundColor);
            if (bg === -1) bg = luminance(getComputedStyle(document.documentElement).backgroundColor);
            if (bg !== -1 && bg < 0.45) return; // page is already dark
            addStyle('sofa-dark',
                'html.sofa-dark { filter: invert(1) hue-rotate(180deg) !important; background: #fff !important; }\n' +
                'html.sofa-dark img, html.sofa-dark video, html.sofa-dark picture, html.sofa-dark canvas,' +
                ' html.sofa-dark iframe, html.sofa-dark embed, html.sofa-dark object,' +
                ' html.sofa-dark [style*="background-image"], html.sofa-dark .sofa-player-bar' +
                ' { filter: invert(1) hue-rotate(180deg) !important; }\n' +
                'html.sofa-dark picture img, html.sofa-dark picture video { filter: none !important; }');
            document.documentElement.classList.add('sofa-dark');
            document.addEventListener('fullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.fullscreenElement);
            });
            document.addEventListener('webkitfullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.webkitFullscreenElement);
            });
        });
    }

    // ---------------- highest quality ----------------
    function pickHighestIndex(levels, getHeight, getBitrate) {
        var best = -1, bestH = -1, bestB = -1;
        for (var i = 0; i < levels.length; i++) {
            var h = getHeight(levels[i]) || 0;
            var b = getBitrate(levels[i]) || 0;
            if (h > bestH || (h === bestH && b > bestB)) { best = i; bestH = h; bestB = b; }
        }
        return best;
    }

    function labelHeight(label) {
        var m = /(\d{3,4})\s*p/i.exec(label || '');
        if (m) return parseInt(m[1], 10);
        if (/4k|uhd|2160/i.test(label || '')) return 2160;
        if (/hd/i.test(label || '')) return 720;
        return 0;
    }

    function patchHls(H) {
        if (!H || !H.prototype || H.prototype.__sofaPatched) return;
        H.prototype.__sofaPatched = true;
        var origLoad = H.prototype.loadSource;
        if (typeof origLoad !== 'function') return;
        H.prototype.loadSource = function () {
            var hls = this;
            try {
                if (!hls.__sofaHooked && cfg.maxQuality && hls.on && H.Events) {
                    hls.__sofaHooked = true;
                    hls.on(H.Events.MANIFEST_PARSED, function () {
                        try {
                            var idx = pickHighestIndex(hls.levels || [],
                                function (l) { return l.height; }, function (l) { return l.bitrate; });
                            if (idx >= 0) {
                                hls.autoLevelCapping = -1;
                                hls.currentLevel = idx;
                                hls.loadLevel = idx;
                            }
                        } catch (e) {}
                    });
                }
            } catch (e) {}
            return origLoad.apply(this, arguments);
        };
    }

    function patchShaka(shaka) {
        if (!shaka || !shaka.Player || !shaka.Player.prototype || shaka.Player.prototype.__sofaPatched) return;
        var P = shaka.Player.prototype;
        P.__sofaPatched = true;
        var origLoad = P.load;
        if (typeof origLoad !== 'function') return;
        P.load = function () {
            var player = this;
            var result = origLoad.apply(this, arguments);
            var apply = function () {
                if (!cfg.maxQuality) return;
                try {
                    var tracks = player.getVariantTracks();
                    var idx = pickHighestIndex(tracks, function (t) { return t.height; }, function (t) { return t.bandwidth; });
                    if (idx >= 0) {
                        player.configure({ abr: { enabled: false } });
                        player.selectVariantTrack(tracks[idx], true);
                    }
                } catch (e) {}
            };
            if (result && typeof result.then === 'function') result.then(apply, function () {});
            else setTimeout(apply, 2000);
            return result;
        };
    }

    function patchDash(dashjs) {
        if (!dashjs || typeof dashjs.MediaPlayer !== 'function' || dashjs.MediaPlayer.__sofaPatched) return;
        var origFactory = dashjs.MediaPlayer;
        var wrapped = function () {
            var f = origFactory.apply(this, arguments);
            try {
                var origCreate = f.create;
                f.create = function () {
                    var p = origCreate.apply(this, arguments);
                    try {
                        p.on('streamInitialized', function () {
                            if (!cfg.maxQuality) return;
                            try {
                                p.updateSettings({ streaming: { abr: { autoSwitchBitrate: { video: false } } } });
                                if (typeof p.getBitrateInfoListFor === 'function') { // dash.js v3/v4
                                    var list = p.getBitrateInfoListFor('video') || [];
                                    var i = pickHighestIndex(list, function (l) { return l.height; }, function (l) { return l.bitrate; });
                                    if (i >= 0) p.setQualityFor('video', i, true);
                                } else if (typeof p.getRepresentationsByType === 'function') { // dash.js v5
                                    var reps = p.getRepresentationsByType('video') || [];
                                    var j = pickHighestIndex(reps, function (l) { return l.height; }, function (l) { return l.bandwidth; });
                                    if (j >= 0) p.setRepresentationForTypeByIndex('video', j, true);
                                }
                            } catch (e) {}
                        });
                    } catch (e) {}
                    return p;
                };
            } catch (e) {}
            return f;
        };
        for (var k in origFactory) { try { wrapped[k] = origFactory[k]; } catch (e) {} }
        wrapped.__sofaPatched = true;
        try { dashjs.MediaPlayer = wrapped; } catch (e) {}
    }

    function hookGlobal(name, patcher) {
        try {
            var current = window[name];
            if (current) { patcher(current); return; }
            var desc = Object.getOwnPropertyDescriptor(window, name);
            if (desc && !desc.configurable) return;
            var value;
            Object.defineProperty(window, name, {
                configurable: true,
                enumerable: true,
                get: function () { return value; },
                set: function (v) { value = v; try { patcher(v); } catch (e) {} }
            });
        } catch (e) {}
    }

    function applyPlayerApiQuality() {
        if (!cfg.maxQuality) return;
        // YouTube (desktop, mobile and embeds)
        try {
            var yt = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
            if (yt && typeof yt.getAvailableQualityLevels === 'function') {
                var levels = yt.getAvailableQualityLevels().filter(function (q) { return q !== 'auto'; });
                var key = levels[0] + '|' + location.href;
                if (levels.length && yt.__sofaQ !== key) {
                    if (typeof yt.setPlaybackQualityRange === 'function') yt.setPlaybackQualityRange(levels[0], levels[0]);
                    if (typeof yt.setPlaybackQuality === 'function') yt.setPlaybackQuality(levels[0]);
                    yt.__sofaQ = key;
                }
            }
        } catch (e) {}
        // JW Player
        try {
            if (typeof window.jwplayer === 'function') {
                var jw = window.jwplayer();
                if (jw && typeof jw.getQualityLevels === 'function') {
                    var q = jw.getQualityLevels() || [];
                    var idx = pickHighestIndex(q, function (l) { return l.height || labelHeight(l.label); },
                        function (l) { return l.bitrate; });
                    if (idx >= 0 && jw.getCurrentQuality() !== idx) jw.setCurrentQuality(idx);
                }
            }
        } catch (e) {}
        // Video.js (quality-levels plugin)
        try {
            if (window.videojs && typeof window.videojs.getPlayers === 'function') {
                var players = window.videojs.getPlayers();
                Object.keys(players).forEach(function (id) {
                    var p = players[id];
                    if (!p || typeof p.qualityLevels !== 'function') return;
                    var ql = p.qualityLevels();
                    if (!ql || !ql.length) return;
                    var arr = [];
                    for (var i = 0; i < ql.length; i++) arr.push(ql[i]);
                    var best = pickHighestIndex(arr, function (l) { return l.height; }, function (l) { return l.bitrate; });
                    for (var j = 0; j < arr.length; j++) arr[j].enabled = (j === best);
                });
            }
        } catch (e) {}
        // Plyr
        try {
            var plyrEls = document.querySelectorAll('.plyr');
            for (var n = 0; n < plyrEls.length; n++) {
                var pl = plyrEls[n].plyr;
                if (pl && pl.options && pl.options.quality && pl.options.quality.length) {
                    var max = Math.max.apply(null, pl.options.quality.map(Number).filter(isFinite));
                    if (isFinite(max) && pl.quality !== max) pl.quality = max;
                }
            }
        } catch (e) {}
        // late-loaded libraries
        try { patchHls(window.Hls); } catch (e) {}
        try { patchShaka(window.shaka); } catch (e) {}
    }

    if (cfg.maxQuality) {
        hookGlobal('Hls', patchHls);
        hookGlobal('shaka', patchShaka);
        hookGlobal('dashjs', patchDash);
    }

    // ---------------- media helpers ----------------
    function allMedia() {
        var list = Array.prototype.slice.call(document.querySelectorAll('video, audio'));
        // same-origin iframes
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try {
                var d = frames[i].contentDocument;
                if (d) list = list.concat(Array.prototype.slice.call(d.querySelectorAll('video, audio')));
            } catch (e) {}
        }
        return list;
    }

    function isPlaying(m) {
        return m.currentTime > 0 && !m.paused && !m.ended && m.readyState > 2;
    }

    function bestMedia() {
        var list = allMedia();
        var best = null, bestScore = -1;
        list.forEach(function (m) {
            var r = m.getBoundingClientRect();
            var area = Math.max(0, r.width) * Math.max(0, r.height);
            var score = area + (isPlaying(m) ? 1e9 : 0) + (m.tagName === 'VIDEO' ? 1 : 0);
            if (score > bestScore) { best = m; bestScore = score; }
        });
        return best;
    }

    var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    function mediaCommand(cmd, m) {
        m = m || bestMedia();
        if (!m) return false;
        switch (cmd) {
            case 'toggle': if (m.paused || m.ended) m.play(); else m.pause(); break;
            case 'stop': m.pause(); m.currentTime = 0; break;
            case 'rewind': m.currentTime = Math.max(0, m.currentTime - 10); break;
            case 'forward': m.currentTime = m.currentTime + 10; break;
            case 'speed':
                var i = SPEEDS.indexOf(m.playbackRate);
                m.playbackRate = SPEEDS[(i + 1) % SPEEDS.length] || 1;
                break;
        }
        return true;
    }

    // Called by remote-control media keys (see generic_injects.js). Falls back to
    // asking cross-origin iframes (video embeds) to handle the command.
    window.__sofaMedia = function (cmd) {
        if (mediaCommand(cmd)) return true;
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'media', cmd: cmd }, '*'); } catch (e) {}
        }
        return true;
    };

    window.addEventListener('message', function (e) {
        var d = e.data;
        if (!d || d.__sofa !== 'media') return;
        if (!mediaCommand(d.cmd)) {
            var frames = document.querySelectorAll('iframe');
            for (var i = 0; i < frames.length; i++) {
                try { frames[i].contentWindow.postMessage(d, '*'); } catch (err) {}
            }
        }
    });

    // ---------------- video playback ----------------
    // No on-screen controls: the site's own player is used. Lumen only picks the best quality and,
    // when the web engine can't play an HLS/DASH stream (".m3u8"/".mpd"), opens it in Lumen's
    // built-in hardware player instead.
    var handedOff = {};

    function streamSrc(v) {
        var src = v.currentSrc || v.src || '';
        if (!src) {
            var source = v.querySelector('source[src]');
            if (source) src = source.src;
        }
        return src;
    }

    function isManifestUrl(u) {
        return /\.(m3u8|mpd)(\?|#|$)/i.test(u || '');
    }

    document.addEventListener('play', function (e) {
        var v = e.target;
        if (!v || v.tagName !== 'VIDEO') return;
        applyPlayerApiQuality();
        setTimeout(applyPlayerApiQuality, 1500);
        setTimeout(applyPlayerApiQuality, 5000);
    }, true);

    // media errors don't bubble, so listen in the capture phase
    document.addEventListener('error', function (e) {
        var v = e.target;
        if (!v || (v.tagName !== 'VIDEO' && v.tagName !== 'SOURCE')) return;
        if (v.tagName === 'SOURCE') v = v.parentElement;
        if (!v || v.tagName !== 'VIDEO') return;
        var src = streamSrc(v);
        if (!isManifestUrl(src) || handedOff[src]) return;
        handedOff[src] = true;
        try {
            if (window.TVBro && TVBro.sofaOpenVideo) {
                TVBro.sofaOpenVideo('native', src, location.href, (isTop ? document.title : '') || '', v.currentTime || 0);
            }
        } catch (err) {}
    }, true);

    // ---------------- grab links ----------------
    // Read by the Grab button: media addresses written in the page itself (video/audio/<track>).
    window.__lumenDomMedia = function () {
        var out = [];
        var add = function (k, u) { if (u && /^https?:/i.test(u)) out.push({ k: k, u: u }); };
        var docs = [document];
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { if (frames[i].contentDocument) docs.push(frames[i].contentDocument); } catch (e) {}
        }
        docs.forEach(function (d) {
            Array.prototype.forEach.call(d.querySelectorAll('video'), function (v) {
                add('v', v.currentSrc || v.src);
                Array.prototype.forEach.call(v.querySelectorAll('source[src]'), function (x) { add('v', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('audio'), function (a) {
                add('a', a.currentSrc || a.src);
                Array.prototype.forEach.call(a.querySelectorAll('source[src]'), function (x) { add('a', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('track[src]'), function (t) { add('s', t.src); });
        });
        return out;
    };

    // ---------------- passwords ----------------
    function visible(el) {
        if (!el) return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    }

    function findUserField(pass) {
        var scope = pass.form || document;
        var inputs = Array.prototype.slice.call(scope.querySelectorAll(
            'input[type=email], input[type=text], input[type=tel], input:not([type]), input[autocomplete=username]'));
        var before = inputs.filter(function (i) {
            return visible(i) && (pass.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_PRECEDING);
        });
        var pick = before.length ? before[before.length - 1] : inputs.filter(visible)[0];
        return pick || null;
    }

    var lastOffer = 0;
    function captureLogin(scope) {
        if (!cfg.passwords || !isTop || !/^https?:$/.test(location.protocol)) return;
        var passes = Array.prototype.slice.call((scope || document).querySelectorAll('input[type=password]'))
            .filter(function (p) { return p.value; });
        if (!passes.length) return;
        if (passes.length > 1) return; // sign-up or change-password forms: don't offer
        if (Date.now() - lastOffer < 3000) return;
        lastOffer = Date.now();
        var pass = passes[0];
        var user = findUserField(pass);
        try { TVBro.sofaOfferSaveLogin(user ? user.value : '', pass.value); } catch (e) {}
    }

    if (isTop) {
        document.addEventListener('submit', function (e) { captureLogin(e.target); }, true);
        document.addEventListener('click', function (e) {
            var b = e.target && e.target.closest ? e.target.closest('button, input[type=submit], [role=button]') : null;
            if (!b) return;
            var form = b.form || b.closest('form');
            setTimeout(function () { captureLogin(form || document); }, 0);
        }, true);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && e.target && e.target.type === 'password') captureLogin(e.target.form || document);
        }, true);

        // Called by the app with the login saved for this site. Fills visible fields,
        // also ones that appear later (sign-in dialogs), for up to one minute.
        window.__sofaFill = function (username, password) {
            var done = false;
            var setValue = function (el, value) {
                var proto = Object.getPrototypeOf(el);
                var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                if (setter && setter.set) setter.set.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
            var tryFill = function () {
                if (done) return;
                var pass = Array.prototype.slice.call(document.querySelectorAll('input[type=password]')).filter(visible)[0];
                var user = null;
                if (!pass) {
                    // two-step logins: username page first
                    user = document.querySelector('input[autocomplete=username], input[type=email], input[name*=user i], input[name*=login i], input[id*=email i]');
                    if (user && visible(user) && !user.value && username) setValue(user, username);
                    return;
                }
                user = findUserField(pass);
                if (user && !user.value && username) setValue(user, username);
                if (!pass.value) setValue(pass, password);
                done = true;
                observer.disconnect();
            };
            var observer = new MutationObserver(tryFill);
            observer.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(function () { observer.disconnect(); }, 60000);
            tryFill();
        };
    }

    // ---------------- desktop site ----------------
    // A desktop user agent alone still leaves "width=device-width" pages squeezed on a TV or
    // tablet, so lay the page out at a desktop width and let the browser zoom it to fit.
    try {
        if (isTop && window.TVBro && typeof TVBro.sofaIsDesktopSite === 'function') cfg.desktop = TVBro.sofaIsDesktopSite(location.hostname);
    } catch (e) {}
    if (cfg.desktop && isTop) {
        var fixViewport = function () {
            var metas = document.querySelectorAll('meta[name="viewport" i]');
            for (var i = 0; i < metas.length; i++) {
                if (metas[i].getAttribute('content') !== 'width=1280') metas[i].setAttribute('content', 'width=1280');
            }
        };
        var vpObserver = new MutationObserver(fixViewport);
        vpObserver.observe(document.documentElement || document, { childList: true, subtree: true });
        onReady(function () { fixViewport(); setTimeout(function () { vpObserver.disconnect(); }, 3000); });
    }

    // ---------------- start-up ----------------
    onReady(function () {
        challengePage = isChallengePage();
        if (challengePage) {
            window.open = origOpen;
            return;
        }
        if (cfg.maxQuality) {
            applyPlayerApiQuality();
            // single-page sites (YouTube) change videos without reloading
            setInterval(applyPlayerApiQuality, 4000);
        }
    });
})();
