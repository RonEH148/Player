/*
 * SofaBrowse page enhancements (runs in every frame at document start when supported).
 * Features: cosmetic ad hiding, pop-up blocking, automatic highest video quality,
 * built-in player fallback for HLS/DASH, forced dark mode, passwords, desktop site.
 * Based on TV Bro (https://github.com/truefedex/tv-bro).
 */
(function () {
    'use strict';
    if (window.__sofaInstalled) return;
    window.__sofaInstalled = true;

    var host = location.hostname || '';
    // Never touch human-verification frames: modifying them makes checks fail.
    if (/(^|\.)challenges\.cloudflare\.com$/.test(host) || /(^|\.)hcaptcha\.com$/.test(host) ||
        location.pathname.indexOf('/cdn-cgi/challenge-platform') === 0 ||
        location.pathname.indexOf('/recaptcha/') === 0) {
        return;
    }

    // ---------------- settings ----------------
    var cfg = window.__sofaCfg || {};
    try {
        if (window.TVBro && typeof TVBro.sofaSettings === 'function') {
            var live = JSON.parse(TVBro.sofaSettings(location.hostname));
            if (live && typeof live === 'object') cfg = live;
        }
    } catch (e) { /* use embedded settings */ }

    var isTop = (window.top === window);
    var origOpen = window.open;
    var challengePage = false;

    function isChallengePage() {
        try {
            if (window._cf_chl_opt) return true;
            var t = (document.title || '').toLowerCase();
            if (t.indexOf('just a moment') === 0 || t.indexOf('attention required') === 0) return true;
            if (document.querySelector('#challenge-form, #challenge-running, .cf-turnstile, iframe[src*="challenges.cloudflare.com"]')) {
                // a Turnstile widget inside a normal page is fine; only the full interstitial matters
                return !!document.querySelector('#challenge-form, #challenge-running') || t.indexOf('just a moment') !== -1;
            }
        } catch (e) {}
        return false;
    }

    function onReady(fn) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', fn, { once: true });
        } else {
            fn();
        }
    }

    function addStyle(id, css) {
        var root = document.head || document.documentElement;
        if (!root) return null;
        var el = document.getElementById(id);
        if (!el) {
            el = document.createElement('style');
            el.id = id;
            root.appendChild(el);
        }
        el.textContent = css;
        return el;
    }

    // ---------------- pop-up blocker ----------------
    var lastClick = { time: 0, href: null, overlay: false };
    var isAppHomePage = location.href.indexOf('https://tvbro.phlox.dev/appcontent/home') === 0;
    if (cfg.popups && !isAppHomePage) {
        // Remember what was clicked. A pop-up is only refused when there was no click at all, or when
        // the click landed on an invisible overlay (the usual pop-under trick). Clicks on real links,
        // buttons and text may open new tabs - download sites rely on that.
        var isOverlayElement = function (el) {
            try {
                var node = el;
                for (var depth = 0; node && node !== document.body && depth < 6; depth++, node = node.parentElement) {
                    var st = getComputedStyle(node);
                    if (st.position !== 'fixed' && st.position !== 'absolute') continue;
                    var r = node.getBoundingClientRect();
                    var big = r.width >= window.innerWidth * 0.7 && r.height >= window.innerHeight * 0.5;
                    var empty = (node.innerText || '').trim().length === 0 && !node.querySelector('img,video,canvas,svg,picture,iframe');
                    var see = parseFloat(st.opacity) < 0.1 || st.backgroundColor === 'rgba(0, 0, 0, 0)' || st.backgroundColor === 'transparent';
                    if (big && empty && see) return true;
                }
            } catch (e) {}
            return false;
        };

        document.addEventListener('click', function (e) {
            if (!e.isTrusted) return;
            lastClick.time = Date.now();
            var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
            lastClick.href = a ? a.href : null;
            lastClick.overlay = isOverlayElement(e.target);
        }, true);

        var showBlockedBanner = function (url) {
            try {
                var old = document.getElementById('lumen-popup-banner');
                if (old) old.remove();
                var bar = document.createElement('div');
                bar.id = 'lumen-popup-banner';
                bar.style.cssText = 'position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483647;' +
                    'background:rgba(15,29,32,.95);color:#e8f5f2;font:500 16px/1.3 system-ui,Roboto,sans-serif;' +
                    'padding:10px 12px 10px 16px;border-radius:14px;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.4)';
                var text = document.createElement('span');
                var host = '';
                try { host = new URL(url, location.href).hostname; } catch (e) {}
                text.textContent = 'Pop-up blocked' + (host ? ' (' + host + ')' : '');
                var open = document.createElement('button');
                open.textContent = 'Open';
                open.style.cssText = 'all:unset;cursor:pointer;background:#20c997;color:#062b2f;font-weight:700;padding:8px 14px;border-radius:10px';
                open.addEventListener('click', function (e) {
                    e.stopPropagation();
                    bar.remove();
                    origOpen.call(window, url, '_blank');
                }, true);
                var close = document.createElement('button');
                close.textContent = '✕';
                close.style.cssText = 'all:unset;cursor:pointer;padding:6px 8px;opacity:.7';
                close.addEventListener('click', function (e) { e.stopPropagation(); bar.remove(); }, true);
                bar.appendChild(text); bar.appendChild(open); bar.appendChild(close);
                (document.body || document.documentElement).appendChild(bar);
                setTimeout(function () { if (bar.parentNode) bar.remove(); }, 8000);
            } catch (e) {}
        };

        window.open = function (url, target, features) {
            if (challengePage) return origOpen.apply(window, arguments);
            // opening in the same tab is navigation, not a pop-up (used e.g. by the home page search)
            var t = (target || '').toLowerCase();
            if (t === '_self' || t === '_top' || t === '_parent') return origOpen.apply(window, arguments);
            var recentClick = (Date.now() - lastClick.time) < 2000;
            var full = '';
            try { full = url ? new URL(url, location.href).href : ''; } catch (e) {}
            if (!recentClick || lastClick.overlay) {
                console.log('Lumen blocked pop-up: ' + full);
                if (full && isTop) showBlockedBanner(full);
                return null;
            }
            return origOpen.apply(window, arguments);
        };

        var sameSite = function (url) {
            try {
                var u = new URL(url, location.href);
                return u.hostname.split('.').slice(-2).join('.') === location.hostname.split('.').slice(-2).join('.');
            } catch (e) { return false; }
        };

        // pop-under links: invisible full-page anchors that open ads in a new tab
        document.addEventListener('click', function (e) {
            if (challengePage) return;
            var a = e.target && e.target.closest ? e.target.closest('a[target="_blank"]') : null;
            if (!a || sameSite(a.href)) return;
            var r = a.getBoundingClientRect();
            var hugeInvisible = r.width >= window.innerWidth * 0.8 && r.height >= window.innerHeight * 0.6 &&
                (a.textContent || '').trim().length === 0 && !a.querySelector('img,video,picture');
            if (hugeInvisible) {
                e.preventDefault();
                e.stopPropagation();
                a.remove();
                console.log('SofaBrowse blocked pop-under link: ' + a.href);
            }
        }, true);
    }

    // ---------------- cosmetic ad hiding ----------------
    var AD_SELECTORS = [
        'ins.adsbygoogle', '.adsbygoogle', '[id^="google_ads_iframe"]', '[id^="div-gpt-ad"]',
        'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
        'iframe[src*="amazon-adsystem.com"]', 'iframe[src*="adnxs.com"]', 'iframe[src*="taboola.com"]',
        'amp-ad', 'amp-embed[type="taboola"]', '[data-ad-slot]', '[data-ad-unit]', '[data-adunit]',
        '[id^="taboola-"]', '.trc_related_container', '.OUTBRAIN', '[data-widget-id^="AR_"]',
        '.ad-banner', '.ad-container', '.ad-wrapper', '.ad-slot', '.ad-unit', '.ad_unit', '.adBanner',
        '.advertisement', '.advert', '.sponsored-ad', '.banner-ad', '.sticky-ad', '.ad-sticky',
        '#ad-banner', '#ad_banner', '#adContainer', '#sticky-ad', '[aria-label="Advertisement"]',
        'a[href*="doubleclick.net/"]', 'a[href*="/aclk?"]'
    ];

    function removeAntiAdblockOverlays() {
        var re = /ad.?block|disable your ad|turn off your ad|whitelist (our|this) site|adblocker detected/i;
        var nodes = document.querySelectorAll('body > div, body > section, body > aside');
        for (var i = 0; i < nodes.length; i++) {
            var el = nodes[i];
            var st = getComputedStyle(el);
            if (st.position !== 'fixed' && st.position !== 'absolute') continue;
            var r = el.getBoundingClientRect();
            if (r.width < window.innerWidth * 0.5 || r.height < window.innerHeight * 0.4) continue;
            if (!re.test((el.innerText || '').slice(0, 2000))) continue;
            el.remove();
            [document.documentElement, document.body].forEach(function (n) {
                if (!n) return;
                n.style.setProperty('overflow', 'auto', 'important');
                n.style.removeProperty('position');
            });
        }
    }

    if (cfg.cosmetic) {
        onReady(function () {
            if (challengePage) return;
            addStyle('sofa-cosmetic', AD_SELECTORS.join(',\n') +
                ' { display: none !important; visibility: hidden !important; }');
            if (isTop) {
                setTimeout(removeAntiAdblockOverlays, 1500);
                setTimeout(removeAntiAdblockOverlays, 5000);
            }
        });
    }

    // ---------------- YouTube ads ----------------
    // YouTube serves ads from the same servers as the videos, so filter lists can't block them.
    // Instead: (1) remove the ad schedule from the player data before the player reads it,
    // (2) if an ad still starts, mute it and jump to its end / press "Skip",
    // (3) hide banner/feed ads and the "ad blockers are not allowed" pop-up.
    var isYouTube = /(^|\.)(youtube\.com|youtube-nocookie\.com)$/i.test(host);
    if (cfg.cosmetic && isYouTube) {
        var AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams', 'adParams'];
        var prune = function (o, depth) {
            if (!o || typeof o !== 'object' || depth > 6) return o;
            for (var i = 0; i < AD_KEYS.length; i++) {
                if (Object.prototype.hasOwnProperty.call(o, AD_KEYS[i])) {
                    try { delete o[AD_KEYS[i]]; } catch (e) {}
                }
            }
            // player data can be nested (e.g. inside "playerResponse")
            if (o.playerResponse) prune(o.playerResponse, depth + 1);
            if (Array.isArray(o)) for (var j = 0; j < o.length && j < 20; j++) prune(o[j], depth + 1);
            return o;
        };
        try {
            var origParse = JSON.parse;
            JSON.parse = function () {
                var r = origParse.apply(this, arguments);
                try { if (r && typeof r === 'object' && (r.adPlacements || r.playerAds || r.adSlots || r.playerResponse)) prune(r, 0); } catch (e) {}
                return r;
            };
            JSON.parse.toString = function () { return origParse.toString(); };
        } catch (e) {}
        try {
            var origJson = Response.prototype.json;
            Response.prototype.json = function () {
                return origJson.apply(this, arguments).then(function (r) {
                    try { prune(r, 0); } catch (e) {}
                    return r;
                });
            };
        } catch (e) {}
        // first page load: the data comes in a global variable
        ['ytInitialPlayerResponse', 'ytInitialData'].forEach(function (name) {
            try {
                var value;
                Object.defineProperty(window, name, {
                    configurable: true,
                    get: function () { return value; },
                    set: function (v) { value = prune(v, 0); }
                });
            } catch (e) {}
        });

        var skipAds = function () {
            var player = document.querySelector('#movie_player, .html5-video-player');
            var video = player ? player.querySelector('video') : null;
            var adShowing = player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'));
            if (adShowing && video) {
                video.muted = true;
                if (isFinite(video.duration) && video.duration > 0 && video.currentTime < video.duration - 0.2) {
                    try { video.currentTime = video.duration - 0.1; } catch (e) {}
                }
                try { video.playbackRate = 16; } catch (e) {}
            } else if (video && video.__lumenWasAd) {
                video.muted = false;
                if (video.playbackRate === 16) video.playbackRate = 1;
            }
            if (video) video.__lumenWasAd = !!adShowing;
            var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, ' +
                'button[class*="skip-ad"], .ytm-skip-ad-button, ytm-skip-ad-button button');
            if (skip) try { skip.click(); } catch (e) {}
            // anti-adblock dialog: remove it and keep playing
            var nag = document.querySelector('ytd-enforcement-message-view-model, ytm-enforcement-message-view-model');
            if (nag) {
                var dlg = nag.closest('tp-yt-paper-dialog, ytd-popup-container, bottom-sheet-container') || nag;
                dlg.remove();
                var backdrop = document.querySelector('tp-yt-iron-overlay-backdrop');
                if (backdrop) backdrop.remove();
                if (video && video.paused) try { video.play(); } catch (e) {}
            }
        };
        setInterval(skipAds, 300);
        onReady(function () {
            addStyle('lumen-youtube-ads',
                '#player-ads, #masthead-ad, ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-banner-promo-renderer,' +
                ' ytd-promoted-sparkles-web-renderer, ytd-promoted-video-renderer, ytd-display-ad-renderer,' +
                ' ytd-companion-slot-renderer, ytd-action-companion-ad-renderer, ytd-statement-banner-renderer,' +
                ' ytd-rich-item-renderer:has(ytd-ad-slot-renderer), ytd-search-pyv-renderer, .ytd-merch-shelf-renderer,' +
                ' .ytp-ad-overlay-container, .ytp-ad-overlay-slot, .ytp-ad-image-overlay, .video-ads.ytp-ad-module,' +
                ' ytm-promoted-sparkles-web-renderer, ytm-companion-ad-renderer, ytm-promoted-video-renderer,' +
                ' ad-slot-renderer, ytm-ad-slot-renderer, .ytm-promoted-sparkles-text-search-root,' +
                ' ytd-enforcement-message-view-model, ytm-enforcement-message-view-model' +
                ' { display: none !important; }');
        });
    }

    // ---------------- forced dark mode ----------------
    function luminance(color) {
        var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(color || '');
        if (!m) return -1;
        if (m[4] !== undefined && parseFloat(m[4]) === 0) return -1; // transparent
        return (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255;
    }

    if (cfg.dark && isTop) {
        onReady(function () {
            if (challengePage) return;
            var bg = luminance(getComputedStyle(document.body || document.documentElement).backgroundColor);
            if (bg === -1) bg = luminance(getComputedStyle(document.documentElement).backgroundColor);
            if (bg !== -1 && bg < 0.45) return; // page is already dark
            addStyle('sofa-dark',
                'html.sofa-dark { filter: invert(1) hue-rotate(180deg) !important; background: #fff !important; }\n' +
                'html.sofa-dark img, html.sofa-dark video, html.sofa-dark picture, html.sofa-dark canvas,' +
                ' html.sofa-dark iframe, html.sofa-dark embed, html.sofa-dark object,' +
                ' html.sofa-dark [style*="background-image"], html.sofa-dark .sofa-player-bar' +
                ' { filter: invert(1) hue-rotate(180deg) !important; }\n' +
                'html.sofa-dark picture img, html.sofa-dark picture video { filter: none !important; }');
            document.documentElement.classList.add('sofa-dark');
            document.addEventListener('fullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.fullscreenElement);
            });
            document.addEventListener('webkitfullscreenchange', function () {
                document.documentElement.classList.toggle('sofa-dark', !document.webkitFullscreenElement);
            });
        });
    }

    // ---------------- highest quality ----------------
    function pickHighestIndex(levels, getHeight, getBitrate) {
        var best = -1, bestH = -1, bestB = -1;
        for (var i = 0; i < levels.length; i++) {
            var h = getHeight(levels[i]) || 0;
            var b = getBitrate(levels[i]) || 0;
            if (h > bestH || (h === bestH && b > bestB)) { best = i; bestH = h; bestB = b; }
        }
        return best;
    }

    function labelHeight(label) {
        var m = /(\d{3,4})\s*p/i.exec(label || '');
        if (m) return parseInt(m[1], 10);
        if (/4k|uhd|2160/i.test(label || '')) return 2160;
        if (/hd/i.test(label || '')) return 720;
        return 0;
    }

    function patchHls(H) {
        if (!H || !H.prototype || H.prototype.__sofaPatched) return;
        H.prototype.__sofaPatched = true;
        var origLoad = H.prototype.loadSource;
        if (typeof origLoad !== 'function') return;
        H.prototype.loadSource = function () {
            var hls = this;
            try {
                if (!hls.__sofaHooked && cfg.maxQuality && hls.on && H.Events) {
                    hls.__sofaHooked = true;
                    hls.on(H.Events.MANIFEST_PARSED, function () {
                        try {
                            var idx = pickHighestIndex(hls.levels || [],
                                function (l) { return l.height; }, function (l) { return l.bitrate; });
                            if (idx >= 0) {
                                hls.autoLevelCapping = -1;
                                hls.currentLevel = idx;
                                hls.loadLevel = idx;
                            }
                        } catch (e) {}
                    });
                }
            } catch (e) {}
            return origLoad.apply(this, arguments);
        };
    }

    function patchShaka(shaka) {
        if (!shaka || !shaka.Player || !shaka.Player.prototype || shaka.Player.prototype.__sofaPatched) return;
        var P = shaka.Player.prototype;
        P.__sofaPatched = true;
        var origLoad = P.load;
        if (typeof origLoad !== 'function') return;
        P.load = function () {
            var player = this;
            var result = origLoad.apply(this, arguments);
            var apply = function () {
                if (!cfg.maxQuality) return;
                try {
                    var tracks = player.getVariantTracks();
                    var idx = pickHighestIndex(tracks, function (t) { return t.height; }, function (t) { return t.bandwidth; });
                    if (idx >= 0) {
                        player.configure({ abr: { enabled: false } });
                        player.selectVariantTrack(tracks[idx], true);
                    }
                } catch (e) {}
            };
            if (result && typeof result.then === 'function') result.then(apply, function () {});
            else setTimeout(apply, 2000);
            return result;
        };
    }

    function patchDash(dashjs) {
        if (!dashjs || typeof dashjs.MediaPlayer !== 'function' || dashjs.MediaPlayer.__sofaPatched) return;
        var origFactory = dashjs.MediaPlayer;
        var wrapped = function () {
            var f = origFactory.apply(this, arguments);
            try {
                var origCreate = f.create;
                f.create = function () {
                    var p = origCreate.apply(this, arguments);
                    try {
                        p.on('streamInitialized', function () {
                            if (!cfg.maxQuality) return;
                            try {
                                p.updateSettings({ streaming: { abr: { autoSwitchBitrate: { video: false } } } });
                                if (typeof p.getBitrateInfoListFor === 'function') { // dash.js v3/v4
                                    var list = p.getBitrateInfoListFor('video') || [];
                                    var i = pickHighestIndex(list, function (l) { return l.height; }, function (l) { return l.bitrate; });
                                    if (i >= 0) p.setQualityFor('video', i, true);
                                } else if (typeof p.getRepresentationsByType === 'function') { // dash.js v5
                                    var reps = p.getRepresentationsByType('video') || [];
                                    var j = pickHighestIndex(reps, function (l) { return l.height; }, function (l) { return l.bandwidth; });
                                    if (j >= 0) p.setRepresentationForTypeByIndex('video', j, true);
                                }
                            } catch (e) {}
                        });
                    } catch (e) {}
                    return p;
                };
            } catch (e) {}
            return f;
        };
        for (var k in origFactory) { try { wrapped[k] = origFactory[k]; } catch (e) {} }
        wrapped.__sofaPatched = true;
        try { dashjs.MediaPlayer = wrapped; } catch (e) {}
    }

    function hookGlobal(name, patcher) {
        try {
            var current = window[name];
            if (current) { patcher(current); return; }
            var desc = Object.getOwnPropertyDescriptor(window, name);
            if (desc && !desc.configurable) return;
            var value;
            Object.defineProperty(window, name, {
                configurable: true,
                enumerable: true,
                get: function () { return value; },
                set: function (v) { value = v; try { patcher(v); } catch (e) {} }
            });
        } catch (e) {}
    }

    function applyPlayerApiQuality() {
        if (!cfg.maxQuality) return;
        // YouTube (desktop, mobile and embeds)
        try {
            var yt = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
            if (yt && typeof yt.getAvailableQualityLevels === 'function') {
                var levels = yt.getAvailableQualityLevels().filter(function (q) { return q !== 'auto'; });
                var key = levels[0] + '|' + location.href;
                if (levels.length && yt.__sofaQ !== key) {
                    if (typeof yt.setPlaybackQualityRange === 'function') yt.setPlaybackQualityRange(levels[0], levels[0]);
                    if (typeof yt.setPlaybackQuality === 'function') yt.setPlaybackQuality(levels[0]);
                    yt.__sofaQ = key;
                }
            }
        } catch (e) {}
        // JW Player
        try {
            if (typeof window.jwplayer === 'function') {
                var jw = window.jwplayer();
                if (jw && typeof jw.getQualityLevels === 'function') {
                    var q = jw.getQualityLevels() || [];
                    var idx = pickHighestIndex(q, function (l) { return l.height || labelHeight(l.label); },
                        function (l) { return l.bitrate; });
                    if (idx >= 0 && jw.getCurrentQuality() !== idx) jw.setCurrentQuality(idx);
                }
            }
        } catch (e) {}
        // Video.js (quality-levels plugin)
        try {
            if (window.videojs && typeof window.videojs.getPlayers === 'function') {
                var players = window.videojs.getPlayers();
                Object.keys(players).forEach(function (id) {
                    var p = players[id];
                    if (!p || typeof p.qualityLevels !== 'function') return;
                    var ql = p.qualityLevels();
                    if (!ql || !ql.length) return;
                    var arr = [];
                    for (var i = 0; i < ql.length; i++) arr.push(ql[i]);
                    var best = pickHighestIndex(arr, function (l) { return l.height; }, function (l) { return l.bitrate; });
                    for (var j = 0; j < arr.length; j++) arr[j].enabled = (j === best);
                });
            }
        } catch (e) {}
        // Plyr
        try {
            var plyrEls = document.querySelectorAll('.plyr');
            for (var n = 0; n < plyrEls.length; n++) {
                var pl = plyrEls[n].plyr;
                if (pl && pl.options && pl.options.quality && pl.options.quality.length) {
                    var max = Math.max.apply(null, pl.options.quality.map(Number).filter(isFinite));
                    if (isFinite(max) && pl.quality !== max) pl.quality = max;
                }
            }
        } catch (e) {}
        // late-loaded libraries
        try { patchHls(window.Hls); } catch (e) {}
        try { patchShaka(window.shaka); } catch (e) {}
    }

    if (cfg.maxQuality) {
        hookGlobal('Hls', patchHls);
        hookGlobal('shaka', patchShaka);
        hookGlobal('dashjs', patchDash);
    }

    // Most sites bundle their player (hls.js, video.js, JW, Shaka, Clappr, ...) inside their own
    // code, where the hooks above can't reach it, and the player's automatic quality only climbs to
    // a 10+ Mbit/s version after measuring a fast connection for a while - often never. So the
    // stream's quality list itself (HLS master playlist / DASH manifest) is trimmed to the best
    // version this device can play before any player reads it; every player then has to use it.
    var lumenCodecOk = function (mime, codecs) {
        if (!codecs) return true;
        try {
            if (window.MediaSource && typeof MediaSource.isTypeSupported === 'function') {
                return MediaSource.isTypeSupported(mime + '; codecs="' + codecs + '"');
            }
        } catch (e) {}
        return true;
    };

    var hlsAttr = function (attrs, name) {
        var m = new RegExp('(?:^|,)' + name + '=("([^"]*)"|[^,]*)').exec(attrs);
        if (!m) return null;
        return m[2] !== undefined ? m[2] : m[1];
    };

    window.__lumenBestHls = function (text) {
        if (typeof text !== 'string' || text.indexOf('#EXT-X-STREAM-INF') < 0) return null;
        var lines = text.split(/\r?\n/);
        var variants = [];
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].indexOf('#EXT-X-STREAM-INF:') !== 0) continue;
            var j = i + 1;
            while (j < lines.length && (lines[j].trim() === '' || lines[j].charAt(0) === '#')) j++;
            if (j >= lines.length) break;
            var attrs = lines[i].substring(18);
            var res = hlsAttr(attrs, 'RESOLUTION') || '';
            var rm = /(\d+)x(\d+)/i.exec(res);
            var codecs = hlsAttr(attrs, 'CODECS');
            var onlyAudio = codecs && !/(avc|hvc|hev|av01|vp0?9|vp8|dvh|dva)/i.test(codecs);
            variants.push({
                tag: i, uri: j,
                h: rm ? parseInt(rm[2], 10) : 0,
                bw: parseInt(hlsAttr(attrs, 'BANDWIDTH') || '0', 10) || 0,
                ok: !onlyAudio && lumenCodecOk('video/mp4', codecs)
            });
            i = j;
        }
        if (variants.length < 2) return null;
        var best = null;
        for (var k = 0; k < variants.length; k++) {
            var v = variants[k];
            if (!v.ok) continue;
            if (!best || v.h > best.h || (v.h === best.h && v.bw > best.bw)) best = v;
        }
        if (!best) return null;
        var drop = {};
        for (var d = 0; d < variants.length; d++) {
            if (variants[d] === best) continue;
            drop[variants[d].tag] = true;
            drop[variants[d].uri] = true;
        }
        var out = [];
        for (var n = 0; n < lines.length; n++) if (!drop[n]) out.push(lines[n]);
        return out.join('\n');
    };

    window.__lumenBestMpd = function (text) {
        if (typeof text !== 'string' || !/<MPD[\s>]/.test(text) || typeof DOMParser !== 'function') return null;
        var doc;
        try { doc = new DOMParser().parseFromString(text, 'application/xml'); } catch (e) { return null; }
        if (!doc || doc.getElementsByTagName('parsererror').length) return null;
        var sets = doc.getElementsByTagNameNS('*', 'AdaptationSet');
        var changed = false;
        for (var i = 0; i < sets.length; i++) {
            var set = sets[i];
            var reps = [];
            for (var c = set.firstElementChild; c; c = c.nextElementSibling) {
                if (c.localName === 'Representation') reps.push(c);
            }
            if (reps.length < 2) continue;
            var setMime = set.getAttribute('mimeType') || '';
            var isVideo = set.getAttribute('contentType') === 'video' || /video/i.test(setMime) ||
                /video/i.test(reps[0].getAttribute('mimeType') || '') ||
                (!!(reps[0].getAttribute('height') || set.getAttribute('height')) && !/audio|text/i.test(setMime));
            if (!isVideo) continue;
            var best = null, bestH = -1, bestB = -1;
            for (var r = 0; r < reps.length; r++) {
                var rep = reps[r];
                var mime = rep.getAttribute('mimeType') || setMime || 'video/mp4';
                var codecs = rep.getAttribute('codecs') || set.getAttribute('codecs');
                if (!lumenCodecOk(mime, codecs)) continue;
                var h = parseInt(rep.getAttribute('height') || set.getAttribute('height') || '0', 10) || 0;
                var b = parseInt(rep.getAttribute('bandwidth') || '0', 10) || 0;
                if (h > bestH || (h === bestH && b > bestB)) { best = rep; bestH = h; bestB = b; }
            }
            if (!best) continue;
            for (var x = 0; x < reps.length; x++) {
                if (reps[x] !== best) { set.removeChild(reps[x]); changed = true; }
            }
        }
        if (!changed) return null;
        try { return new XMLSerializer().serializeToString(doc); } catch (e) { return null; }
    };

    var lumenTrimManifest = function (text) {
        if (typeof text !== 'string' || text.length > 4000000) return null;
        var head = text.substring(0, 2000).replace(/^﻿/, '').replace(/^\s+/, '');
        try {
            if (head.indexOf('#EXTM3U') === 0) return window.__lumenBestHls(text);
            if (/<MPD[\s>]/.test(head)) return window.__lumenBestMpd(text);
        } catch (e) {}
        return null;
    };

    if (cfg.maxQuality) {
        (function () {
            // XMLHttpRequest (hls.js, video.js, dash.js, JW Player, Clappr, ...)
            try {
                var XP = XMLHttpRequest.prototype;
                var txtDesc = Object.getOwnPropertyDescriptor(XP, 'responseText');
                var resDesc = Object.getOwnPropertyDescriptor(XP, 'response');
                var decoder = (typeof TextDecoder === 'function') ? new TextDecoder() : null;
                var encoder = (typeof TextEncoder === 'function') ? new TextEncoder() : null;
                var transformed = function (xhr) {
                    if (xhr.readyState !== 4) return undefined;
                    if (xhr.__lumenQ) return xhr.__lumenQ.out;
                    var st = { out: null };
                    xhr.__lumenQ = st;
                    try {
                        var type = xhr.responseType;
                        if (type === '' || type === 'text') {
                            st.out = lumenTrimManifest(txtDesc.get.call(xhr));
                        } else if (type === 'arraybuffer' && decoder && encoder) {
                            var buf = resDesc.get.call(xhr);
                            if (buf && buf.byteLength < 4000000) {
                                var first = decoder.decode(new Uint8Array(buf, 0, Math.min(buf.byteLength, 64)));
                                if (/#EXTM3U|<\?xml|<MPD/.test(first)) {
                                    var t = lumenTrimManifest(decoder.decode(new Uint8Array(buf)));
                                    if (t != null) { var u8 = encoder.encode(t); st.out = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength); st.text = t; }
                                }
                            }
                        }
                    } catch (e) { st.out = null; }
                    return st.out;
                };
                if (txtDesc && txtDesc.get && resDesc && resDesc.get) {
                    Object.defineProperty(XP, 'responseText', {
                        configurable: true, enumerable: txtDesc.enumerable,
                        get: function () {
                            var t = transformed(this);
                            if (typeof t === 'string') return t;
                            return txtDesc.get.call(this);
                        }
                    });
                    Object.defineProperty(XP, 'response', {
                        configurable: true, enumerable: resDesc.enumerable,
                        get: function () {
                            var t = transformed(this);
                            if (t != null) return t;
                            return resDesc.get.call(this);
                        }
                    });
                }
            } catch (e) {}
            // fetch (Shaka Player, newer hls.js setups)
            try {
                var origFetch = window.fetch;
                if (typeof origFetch === 'function') {
                    var looksLikeManifest = /\.(m3u8|mpd)(\?|#|$)|m3u8|manifest|master|playlist/i;
                    window.fetch = function (input, init) {
                        var p = origFetch.apply(this, arguments);
                        var url = '';
                        try { url = typeof input === 'string' ? input : (input && input.url) || String(input); } catch (e) {}
                        return p.then(function (res) {
                            try {
                                if (!res || !res.ok || res.type === 'opaque') return res;
                                var ct = (res.headers && res.headers.get('content-type')) || '';
                                if (!/mpegurl|dash\+xml/i.test(ct) && !looksLikeManifest.test(url)) return res;
                                if (/^(video|audio|image)\//i.test(ct)) return res;
                                var len = parseInt((res.headers && res.headers.get('content-length')) || '0', 10);
                                if (len > 4000000) return res;
                                return res.clone().text().then(function (t) {
                                    var out = lumenTrimManifest(t);
                                    if (out == null) return res;
                                    var nr = new Response(out, { status: res.status, statusText: res.statusText, headers: res.headers });
                                    try {
                                        Object.defineProperty(nr, 'url', { value: res.url });
                                        Object.defineProperty(nr, 'redirected', { value: res.redirected });
                                    } catch (e) {}
                                    return nr;
                                }, function () { return res; });
                            } catch (e) { return res; }
                        });
                    };
                }
            } catch (e) {}
        })();
    }

    // ---------------- media helpers ----------------
    function allMedia() {
        var list = Array.prototype.slice.call(document.querySelectorAll('video, audio'));
        // same-origin iframes
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try {
                var d = frames[i].contentDocument;
                if (d) list = list.concat(Array.prototype.slice.call(d.querySelectorAll('video, audio')));
            } catch (e) {}
        }
        return list;
    }

    function isPlaying(m) {
        return m.currentTime > 0 && !m.paused && !m.ended && m.readyState > 2;
    }

    function bestMedia() {
        var list = allMedia();
        var best = null, bestScore = -1;
        list.forEach(function (m) {
            var r = m.getBoundingClientRect();
            var area = Math.max(0, r.width) * Math.max(0, r.height);
            var score = area + (isPlaying(m) ? 1e9 : 0) + (m.tagName === 'VIDEO' ? 1 : 0);
            if (score > bestScore) { best = m; bestScore = score; }
        });
        return best;
    }

    var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    function mediaCommand(cmd, m) {
        m = m || bestMedia();
        if (!m) return false;
        switch (cmd) {
            case 'toggle': if (m.paused || m.ended) m.play(); else m.pause(); break;
            case 'stop': m.pause(); m.currentTime = 0; break;
            case 'pause': m.pause(); break;
            case 'handoff-deband':
                // open this video in Lumen's own player with anime deband, at the same position
                try {
                    TVBro.sofaOpenVideo('native_deband', m.currentSrc || m.src || '', location.href,
                        (isTop ? document.title : '') || '', m.currentTime || 0);
                    m.pause();
                } catch (e) {}
                break;
            case 'rewind': m.currentTime = Math.max(0, m.currentTime - 10); break;
            case 'forward': m.currentTime = m.currentTime + 10; break;
            case 'speed':
                var i = SPEEDS.indexOf(m.playbackRate);
                m.playbackRate = SPEEDS[(i + 1) % SPEEDS.length] || 1;
                break;
        }
        return true;
    }

    // Called by remote-control media keys (see generic_injects.js). Falls back to
    // asking cross-origin iframes (video embeds) to handle the command.
    window.__sofaMedia = function (cmd) {
        if (mediaCommand(cmd)) return true;
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'media', cmd: cmd }, '*'); } catch (e) {}
        }
        return true;
    };

    window.addEventListener('message', function (e) {
        var d = e.data;
        if (!d || d.__sofa !== 'media') return;
        if (!mediaCommand(d.cmd)) {
            var frames = document.querySelectorAll('iframe');
            for (var i = 0; i < frames.length; i++) {
                try { frames[i].contentWindow.postMessage(d, '*'); } catch (err) {}
            }
        }
    });

    // ---------------- video playback ----------------
    // No on-screen controls: the site's own player is used. Lumen only picks the best quality and,
    // when the web engine can't play an HLS/DASH stream (".m3u8"/".mpd"), opens it in Lumen's
    // built-in hardware player instead.
    var handedOff = {};

    function streamSrc(v) {
        var src = v.currentSrc || v.src || '';
        if (!src) {
            var source = v.querySelector('source[src]');
            if (source) src = source.src;
        }
        return src;
    }

    function isManifestUrl(u) {
        return /\.(m3u8|mpd)(\?|#|$)/i.test(u || '');
    }

    document.addEventListener('play', function (e) {
        var v = e.target;
        if (!v || v.tagName !== 'VIDEO') return;
        applyPlayerApiQuality();
        setTimeout(applyPlayerApiQuality, 1500);
        setTimeout(applyPlayerApiQuality, 5000);
    }, true);

    // media errors don't bubble, so listen in the capture phase
    document.addEventListener('error', function (e) {
        var v = e.target;
        if (!v || (v.tagName !== 'VIDEO' && v.tagName !== 'SOURCE')) return;
        if (v.tagName === 'SOURCE') v = v.parentElement;
        if (!v || v.tagName !== 'VIDEO') return;
        var src = streamSrc(v);
        if (!isManifestUrl(src) || handedOff[src]) return;
        handedOff[src] = true;
        try {
            if (window.TVBro && TVBro.sofaOpenVideo) {
                TVBro.sofaOpenVideo('native', src, location.href, (isTop ? document.title : '') || '', v.currentTime || 0);
            }
        } catch (err) {}
    }, true);

    // ---------------- grab links ----------------
    // Read by the Grab button: media addresses written in the page itself (video/audio/<track>).
    window.__lumenDomMedia = function () {
        var out = [];
        var add = function (k, u) { if (u && /^https?:/i.test(u)) out.push({ k: k, u: u }); };
        var docs = [document];
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { if (frames[i].contentDocument) docs.push(frames[i].contentDocument); } catch (e) {}
        }
        docs.forEach(function (d) {
            Array.prototype.forEach.call(d.querySelectorAll('video'), function (v) {
                add('v', v.currentSrc || v.src);
                Array.prototype.forEach.call(v.querySelectorAll('source[src]'), function (x) { add('v', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('audio'), function (a) {
                add('a', a.currentSrc || a.src);
                Array.prototype.forEach.call(a.querySelectorAll('source[src]'), function (x) { add('a', x.src); });
            });
            Array.prototype.forEach.call(d.querySelectorAll('track[src]'), function (t) { add('s', t.src); });
        });
        return out;
    };

    // ---------------- anime deband for videos in web pages ----------------
    // Toolbar "Deband" button: draws the video through a WebGL deband filter on a canvas placed
    // exactly over the <video>. Works for normal and MSE (blob:) videos; DRM-protected videos and
    // cross-origin videos without CORS can't be read by the browser and are left as they are.
    var DEBAND_VERT = "\nattribute vec4 aFramePosition;\nvarying vec2 vTexSamplingCoord;\nvoid main() {\n  gl_Position = aFramePosition;\n  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;\n}\n";
    var DEBAND_FRAG = "\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform sampler2D uTexSampler;\nuniform vec2 uTexSize;\nuniform vec3 uParams;\nvarying vec2 vTexSamplingCoord;\nfloat luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\nvec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }\n\n// mpv's deband algorithm (as used by Hayase's \"video-deband\", MIT, github.com/ThaUnknown/video-deband):\n// for 4 growing radii, average 4 random samples around the pixel; where the pixel differs from that\n// average by less than a tiny threshold (a banding step), take the average. Then add fine grain.\nuniform float uFrame;\n#define THRESHOLD 88\n#define RANGE 17\n#define ITERATIONS 4\n#define GRAIN 12\nfloat mod289(float x)  { return x - floor(x / 289.0) * 289.0; }\nfloat permute(float x) { return mod289((34.0 * x + 1.0) * x); }\nfloat rand(float x)    { return fract(x / 41.0); }\nvec4 average(vec2 pos, float range, inout float h) {\n  float dist = rand(h) * range;     h = permute(h);\n  float dir  = rand(h) * 6.2831853; h = permute(h);\n  vec2 pt = dist / uTexSize;\n  vec2 o = vec2(cos(dir), sin(dir));\n  vec4 r0 = texture2D(uTexSampler, pos + pt * vec2( o.x,  o.y));\n  vec4 r1 = texture2D(uTexSampler, pos + pt * vec2(-o.y,  o.x));\n  vec4 r2 = texture2D(uTexSampler, pos + pt * vec2(-o.x, -o.y));\n  vec4 r3 = texture2D(uTexSampler, pos + pt * vec2( o.y, -o.x));\n  return (r0 + r1 + r2 + r3) * 0.25;\n}\nvoid main() {\n  vec2 pos = vTexSamplingCoord;\n  float random = fract(uFrame * 0.61803398875 + 0.1);\n  vec3 m = vec3(pos, random) + vec3(1.0);\n  float h = permute(permute(permute(m.x) + m.y) + m.z);\n  vec4 col = texture2D(uTexSampler, pos);\n  for (int i = 1; i <= ITERATIONS; i++) {\n    vec4 avg = average(pos, float(i * RANGE), h);\n    vec4 diff = abs(col - avg);\n    col = mix(avg, col, step(vec4(float(THRESHOLD) / (float(i) * 16384.0)), diff));\n  }\n  vec3 noise;\n  noise.x = rand(h); h = permute(h);\n  noise.y = rand(h); h = permute(h);\n  noise.z = rand(h); h = permute(h);\n  col.rgb += (float(GRAIN) / 8192.0) * (noise - vec3(0.5));\n  gl_FragColor = vec4(col.rgb, 1.0);\n}\n";
    var debandWanted = false;
    var debandLayers = [];

    function debandReport(code) {
        try { if (window.TVBro && TVBro.sofaDebandStatus) TVBro.sofaDebandStatus(code); } catch (e) {}
    }

    var DEINTERLACE_FRAG = "\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nuniform sampler2D uTexSampler;\nuniform vec2 uTexSize;\nuniform vec3 uParams;\nvarying vec2 vTexSamplingCoord;\nfloat luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }\nvec4 at(vec2 px) { return texture2D(uTexSampler, px / uTexSize); }\n\nvoid evalP(float p, vec2 px, float yc, vec3 cc, inout float bestY, inout float outY, inout float bestC, inout vec3 outC) {\n  vec3 q1 = at(px + vec2(0.0, p * 0.25)).rgb;\n  vec3 q2 = at(px - vec2(0.0, p * 0.25)).rgb;\n  vec3 b1 = at(px + vec2(0.0, p * 0.5)).rgb;\n  vec3 b2 = at(px - vec2(0.0, p * 0.5)).rgb;\n  vec3 r1 = at(px + vec2(0.0, p)).rgb;\n  vec3 r2 = at(px - vec2(0.0, p)).rgb;\n  float lb1 = luma(b1); float lb2 = luma(b2);\n  float lq1 = luma(q1); float lq2 = luma(q2);\n  float lr1 = luma(r1); float lr2 = luma(r2);\n  float ii = 0.5 * (yc - 0.5 * (lb1 + lb2));\n  float qq = 0.5 * (lq1 - lq2);\n  float amp = sqrt(ii * ii + qq * qq);\n  float rep = max(abs(yc - lr1), abs(yc - lr2));\n  float m = smoothstep(uParams.x, uParams.y, amp) * (1.0 - smoothstep(0.4, 0.8, rep / max(2.0 * amp, 0.004)));\n  if (m * amp > bestY) { bestY = m * amp; outY = mix(yc, 0.5 * yc + 0.25 * (lb1 + lb2), m); }\n  vec3 kb1 = b1 - vec3(lb1); vec3 kb2 = b2 - vec3(lb2);\n  vec3 kq1 = q1 - vec3(lq1); vec3 kq2 = q2 - vec3(lq2);\n  vec3 kr1 = r1 - vec3(lr1); vec3 kr2 = r2 - vec3(lr2);\n  vec3 ic = 0.5 * (cc - 0.5 * (kb1 + kb2));\n  vec3 qc = 0.5 * (kq1 - kq2);\n  float ampC = sqrt(dot(ic, ic) + dot(qc, qc));\n  float repC = max(length(cc - kr1), length(cc - kr2));\n  float mc = smoothstep(uParams.z, uParams.z * 3.0, ampC) * (1.0 - smoothstep(0.4, 0.8, repC / max(2.0 * ampC, 0.004)));\n  if (mc * ampC > bestC) { bestC = mc * ampC; outC = mix(cc, 0.5 * cc + 0.25 * (kb1 + kb2), mc); }\n}\nvoid main() {\n  vec2 px = vTexSamplingCoord * uTexSize;\n  vec4 c4 = at(px);\n  float yc = luma(c4.rgb);\n  vec3 cc = c4.rgb - vec3(yc);\n  float bestY = 0.0; float outY = yc;\n  float bestC = 0.0; vec3 outC = cc;\n  evalP(2.0, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(2.5, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(3.0, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(3.75, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(4.0, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(4.5, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(5.0, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(6.0, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(7.5, px, yc, cc, bestY, outY, bestC, outC);\n  evalP(9.0, px, yc, cc, bestY, outY, bestC, outC);\n  gl_FragColor = vec4(vec3(outY) + outC, c4.a);\n}\n";

    // Builds the two-pass GPU filter (deinterlace, then deband) on a WebGL context.
    // render(source, w, h) draws one frame of [source] (video, canvas or image of size w×h).
    function makeDebandRenderer(gl) {
        var compile = function (type, src) {
            var sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh);
            if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh));
            return sh;
        };
        var link = function (frag) {
            var prog = gl.createProgram();
            gl.attachShader(prog, compile(gl.VERTEX_SHADER, DEBAND_VERT));
            gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, frag));
            gl.bindAttribLocation(prog, 0, 'aFramePosition');
            gl.linkProgram(prog);
            if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
            return {
                prog: prog,
                uTexSize: gl.getUniformLocation(prog, 'uTexSize'),
                uFrame: gl.getUniformLocation(prog, 'uFrame'),
                uParams: gl.getUniformLocation(prog, 'uParams'),
                uTex: gl.getUniformLocation(prog, 'uTexSampler')
            };
        };
        var deint = link(DEINTERLACE_FRAG);
        var deband = link(DEBAND_FRAG);
        var buf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 0, 1, 1, -1, 0, 1, -1, 1, 0, 1, 1, 1, 0, 1]), gl.STATIC_DRAW);
        gl.enableVertexAttribArray(0);
        gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 0, 0);
        var makeTex = function () {
            var t = gl.createTexture();
            gl.bindTexture(gl.TEXTURE_2D, t);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            return t;
        };
        var srcTex = makeTex();
        var midTex = makeTex();
        var fbo = gl.createFramebuffer();
        var midW = 0, midH = 0, frame = 0;
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        return {
            render: function (source, w, h, outW, outH) {
                gl.activeTexture(gl.TEXTURE0);
                gl.bindTexture(gl.TEXTURE_2D, srcTex);
                gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, source);
                frame = (frame + 1) % 1024;
                var input = srcTex;
                // interlaced video is never above 1080 lines; skip the pass for bigger videos
                if (h <= 1200) {
                    if (midW !== w || midH !== h) {
                        gl.bindTexture(gl.TEXTURE_2D, midTex);
                        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, w, h, 0, gl.RGB, gl.UNSIGNED_BYTE, null);
                        gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
                        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, midTex, 0);
                        midW = w; midH = h;
                    }
                    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
                    gl.viewport(0, 0, w, h);
                    gl.useProgram(deint.prog);
                    gl.bindTexture(gl.TEXTURE_2D, srcTex);
                    gl.uniform1i(deint.uTex, 0);
                    gl.uniform2f(deint.uTexSize, w, h);
                    gl.uniform3f(deint.uParams, 2 / 255, 6 / 255, 2 / 255);
                    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
                    input = midTex;
                }
                gl.bindFramebuffer(gl.FRAMEBUFFER, null);
                gl.viewport(0, 0, outW, outH);
                gl.useProgram(deband.prog);
                gl.bindTexture(gl.TEXTURE_2D, input);
                gl.uniform1i(deband.uTex, 0);
                gl.uniform2f(deband.uTexSize, w, h);
                gl.uniform1f(deband.uFrame, frame + Math.random() * 1000);
                gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
            }
        };
    }
    window.__lumenMakeDebandRenderer = makeDebandRenderer;

    function attachDeband(v) {
        if (!v || v.__lumenDeband || !v.parentNode) return;
        if (v.mediaKeys) { debandReport('drm'); return; }
        var canvas = document.createElement('canvas');
        canvas.className = 'lumen-deband-layer';
        canvas.style.cssText = 'position:absolute;pointer-events:none;display:block;margin:0;padding:0;border:0;background:transparent;visibility:hidden;';
        var gl = canvas.getContext('webgl', { alpha: false, antialias: false, depth: false, stencil: false, premultipliedAlpha: false });
        if (!gl) { debandReport('nogl'); return; }
        var renderer;
        try { renderer = makeDebandRenderer(gl); }
        catch (e) { console.log('Lumen deband: ' + e); debandReport('nogl'); return; }

        v.parentNode.insertBefore(canvas, v.nextSibling);
        var layer = { v: v, canvas: canvas, running: true };
        v.__lumenDeband = layer;
        debandLayers.push(layer);

        // position the canvas over the video (not every frame: reading styles each frame costs time)
        var place = function () {
            var cs = getComputedStyle(v);
            canvas.style.left = v.offsetLeft + 'px';
            canvas.style.top = v.offsetTop + 'px';
            canvas.style.width = v.offsetWidth + 'px';
            canvas.style.height = v.offsetHeight + 'px';
            canvas.style.objectFit = cs.objectFit || 'contain';
            canvas.style.objectPosition = cs.objectPosition || '50% 50%';
            canvas.style.zIndex = cs.zIndex === 'auto' ? '' : cs.zIndex;
            canvas.style.transform = cs.transform === 'none' ? '' : cs.transform;
            var shown = v.offsetWidth > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' &&
                v.readyState >= 2 && layer.drawn;
            canvas.style.visibility = shown ? 'visible' : 'hidden';
        };
        layer.placeTimer = setInterval(place, 400);
        try {
            layer.resizeObs = new ResizeObserver(place);
            layer.resizeObs.observe(v);
        } catch (e) {}

        var draw = function () {
            if (!layer.running) return;
            try {
                if (v.readyState >= 2 && v.videoWidth) {
                    var scale = Math.min(1, 1920 / v.videoWidth);
                    var w = Math.round(v.videoWidth * scale), h = Math.round(v.videoHeight * scale);
                    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
                    renderer.render(v, v.videoWidth, v.videoHeight, w, h);
                    if (!layer.drawn) {
                        layer.drawn = true;
                        place();
                        debandReport('ok:' + v.videoWidth + 'x' + v.videoHeight);
                    }
                }
            } catch (e) {
                // the browser refuses to let pages read this video (protected or cross-site)
                detachDeband(layer);
                debandReport(e && e.name === 'SecurityError' ? 'blocked' : 'error:' + ((e && (e.name + ': ' + e.message)) || e));
                return;
            }
            if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(draw); else requestAnimationFrame(draw);
        };
        draw();
        v.addEventListener('seeked', function () { if (layer.running) requestAnimationFrame(draw); });
    }

    function detachDeband(layer) {
        layer.running = false;
        clearInterval(layer.placeTimer);
        try { if (layer.resizeObs) layer.resizeObs.disconnect(); } catch (e) {}
        if (layer.canvas.parentNode) layer.canvas.parentNode.removeChild(layer.canvas);
        layer.v.__lumenDeband = null;
        var i = debandLayers.indexOf(layer);
        if (i >= 0) debandLayers.splice(i, 1);
    }

    // all <video> elements, also inside web components (shadow DOM), which querySelectorAll misses
    function allVideos() {
        var out = Array.prototype.slice.call(document.querySelectorAll('video'));
        var walk = function (root, depth) {
            if (depth > 6) return;
            var all = root.querySelectorAll('*');
            for (var i = 0; i < all.length; i++) {
                var sr = all[i].shadowRoot;
                if (sr) {
                    out = out.concat(Array.prototype.slice.call(sr.querySelectorAll('video')));
                    walk(sr, depth + 1);
                }
            }
        };
        try { walk(document, 0); } catch (e) {}
        return out;
    }

    var debandScanTimer = 0, debandReportTimer = 0;
    function setDebandLocal(on) {
        debandWanted = !!on;
        clearInterval(debandScanTimer);
        if (debandWanted) {
            allVideos().forEach(attachDeband);
            // players often create their <video> (or replace it) later
            debandScanTimer = setInterval(function () { allVideos().forEach(attachDeband); }, 1500);
            // a short report from every frame, so the browser can say what it found where
            clearTimeout(debandReportTimer);
            debandReportTimer = setTimeout(function () {
                if (!debandWanted) return;
                var vids = allVideos(), playing = 0, filtered = 0, drm = 0;
                vids.forEach(function (v) {
                    if (!v.paused && v.readyState >= 2) playing++;
                    if (v.__lumenDeband && v.__lumenDeband.drawn) filtered++;
                    if (v.mediaKeys) drm++;
                });
                debandReport('scan:' + JSON.stringify({
                    h: location.host || String(location.href).slice(0, 40), top: isTop,
                    v: vids.length, p: playing, f: filtered, d: drm,
                    gl: !!document.createElement('canvas').getContext('webgl')
                }));
            }, 4000);
        } else {
            debandLayers.slice().forEach(detachDeband);
        }
        var frames = document.querySelectorAll('iframe');
        for (var i = 0; i < frames.length; i++) {
            try { frames[i].contentWindow.postMessage({ __sofa: 'deband', on: debandWanted }, '*'); } catch (e) {}
        }
        return document.querySelectorAll('video').length;
    }

    // A video that is itself made full screen hides everything else, including the deband layer.
    // While deband is on, full screen goes to the video's parent instead, with the video filling it.
    var fsOrig = {};
    ['requestFullscreen', 'webkitRequestFullscreen', 'webkitRequestFullScreen'].forEach(function (name) {
        var orig = Element.prototype[name];
        if (typeof orig !== 'function') return;
        fsOrig[name] = orig;
        Element.prototype[name] = function () {
            if (debandWanted && this.tagName === 'VIDEO' && this.__lumenDeband && this.parentElement) {
                var host = this.parentElement;
                host.classList.add('lumen-fs-host');
                addStyle('lumen-fs-style',
                    '.lumen-fs-host:fullscreen,.lumen-fs-host:-webkit-full-screen{background:#000!important;width:100%!important;height:100%!important}' +
                    '.lumen-fs-host:fullscreen>video,.lumen-fs-host:-webkit-full-screen>video{width:100%!important;height:100%!important;max-width:none!important;max-height:none!important;left:0!important;top:0!important;object-fit:contain!important}');
                return orig.apply(host, arguments);
            }
            return orig.apply(this, arguments);
        };
    });

    var origSetDebandLocal = setDebandLocal;
    setDebandLocal = function (on) {
        var n = origSetDebandLocal(on);
        if (on) {
            var fs = document.fullscreenElement || document.webkitFullscreenElement;
            if (fs && fs.tagName === 'VIDEO') debandReport('fsvideo');
        }
        return n;
    };
    window.__lumenSetDeband = setDebandLocal;
    window.addEventListener('message', function (e) {
        if (!e.data) return;
        if (e.data.__sofa === 'deband') setDebandLocal(e.data.on);
        // a frame that loaded after deband was switched on (players often load their frame on
        // "play") asks its parent for the current state
        if (e.data.__sofa === 'deband?' && debandWanted && e.source) {
            try { e.source.postMessage({ __sofa: 'deband', on: true }, '*'); } catch (err) {}
        }
    });
    if (!isTop) {
        var askDeband = function () {
            try { window.parent.postMessage({ __sofa: 'deband?' }, '*'); } catch (e) {}
        };
        askDeband();
        onReady(askDeband);
        document.addEventListener('play', function () { if (!debandWanted) askDeband(); }, true);
    }
    document.addEventListener('play', function (e) {
        if (debandWanted && e.target && e.target.tagName === 'VIDEO') attachDeband(e.target);
    }, true);

    // ---------------- passwords ----------------
    function visible(el) {
        if (!el) return false;
        var r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden';
    }

    function findUserField(pass) {
        var scope = pass.form || document;
        var inputs = Array.prototype.slice.call(scope.querySelectorAll(
            'input[type=email], input[type=text], input[type=tel], input:not([type]), input[autocomplete=username]'));
        var before = inputs.filter(function (i) {
            return visible(i) && (pass.compareDocumentPosition(i) & Node.DOCUMENT_POSITION_PRECEDING);
        });
        var pick = before.length ? before[before.length - 1] : inputs.filter(visible)[0];
        return pick || null;
    }

    var lastOffer = 0;
    function captureLogin(scope) {
        if (!cfg.passwords || !isTop || !/^https?:$/.test(location.protocol)) return;
        var passes = Array.prototype.slice.call((scope || document).querySelectorAll('input[type=password]'))
            .filter(function (p) { return p.value; });
        if (!passes.length) return;
        if (passes.length > 1) return; // sign-up or change-password forms: don't offer
        if (Date.now() - lastOffer < 3000) return;
        lastOffer = Date.now();
        var pass = passes[0];
        var user = findUserField(pass);
        try { TVBro.sofaOfferSaveLogin(user ? user.value : '', pass.value); } catch (e) {}
    }

    if (isTop) {
        document.addEventListener('submit', function (e) { captureLogin(e.target); }, true);
        document.addEventListener('click', function (e) {
            var b = e.target && e.target.closest ? e.target.closest('button, input[type=submit], [role=button]') : null;
            if (!b) return;
            var form = b.form || b.closest('form');
            setTimeout(function () { captureLogin(form || document); }, 0);
        }, true);
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && e.target && e.target.type === 'password') captureLogin(e.target.form || document);
        }, true);

        // Called by the app with the login saved for this site. Fills visible fields,
        // also ones that appear later (sign-in dialogs), for up to one minute.
        window.__sofaFill = function (username, password) {
            var done = false;
            var setValue = function (el, value) {
                var proto = Object.getPrototypeOf(el);
                var setter = Object.getOwnPropertyDescriptor(proto, 'value');
                if (setter && setter.set) setter.set.call(el, value); else el.value = value;
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
            var tryFill = function () {
                if (done) return;
                var pass = Array.prototype.slice.call(document.querySelectorAll('input[type=password]')).filter(visible)[0];
                var user = null;
                if (!pass) {
                    // two-step logins: username page first
                    user = document.querySelector('input[autocomplete=username], input[type=email], input[name*=user i], input[name*=login i], input[id*=email i]');
                    if (user && visible(user) && !user.value && username) setValue(user, username);
                    return;
                }
                user = findUserField(pass);
                if (user && !user.value && username) setValue(user, username);
                if (!pass.value) setValue(pass, password);
                done = true;
                observer.disconnect();
            };
            var observer = new MutationObserver(tryFill);
            observer.observe(document.documentElement, { childList: true, subtree: true });
            setTimeout(function () { observer.disconnect(); }, 60000);
            tryFill();
        };
    }

    // ---------------- desktop site ----------------
    // A desktop user agent alone still leaves "width=device-width" pages squeezed on a TV or
    // tablet, so lay the page out at a desktop width and let the browser zoom it to fit.
    try {
        if (isTop && window.TVBro && typeof TVBro.sofaIsDesktopSite === 'function') cfg.desktop = TVBro.sofaIsDesktopSite(location.hostname);
    } catch (e) {}
    if (cfg.desktop && isTop) {
        var fixViewport = function () {
            var metas = document.querySelectorAll('meta[name="viewport" i]');
            for (var i = 0; i < metas.length; i++) {
                if (metas[i].getAttribute('content') !== 'width=1280') metas[i].setAttribute('content', 'width=1280');
            }
        };
        var vpObserver = new MutationObserver(fixViewport);
        vpObserver.observe(document.documentElement || document, { childList: true, subtree: true });
        onReady(function () { fixViewport(); setTimeout(function () { vpObserver.disconnect(); }, 3000); });
    }

    // ---------------- scrolling inside the page ----------------
    // TV remotes move a virtual cursor; a page only scrolls when the cursor reaches the screen edge,
    // so long submenus, lists and side panels in the middle of the screen never scrolled. The
    // browser asks which scrollable box is under the cursor (__lumenScrollProbe) and scrolls it
    // when the cursor pushes against that box's edge (__lumenInnerScroll).
    if (isTop) {
        var innerBox = null; // { el, ox, oy, frameDoc }

        var viewportBox = function () {
            var v = window.visualViewport;
            if (v && v.width > 0) return { x: v.offsetLeft, y: v.offsetTop, w: v.width, h: v.height };
            return { x: 0, y: 0, w: window.innerWidth || 1, h: window.innerHeight || 1 };
        };

        var overflows = function (el, axis) {
            var st;
            try { st = (el.ownerDocument.defaultView || window).getComputedStyle(el); } catch (e) { return false; }
            if (!st) return false;
            var o = axis === 'y' ? st.overflowY : st.overflowX;
            if (!/(auto|scroll|overlay)/.test(o)) return false;
            return axis === 'y' ? el.scrollHeight > el.clientHeight + 4 : el.scrollWidth > el.clientWidth + 4;
        };

        // the scrolling element of a same-origin frame counts as a box of the top page
        var frameScrolls = function (el, axis) {
            return axis === 'y' ? el.scrollHeight > el.clientHeight + 4 : el.scrollWidth > el.clientWidth + 4;
        };

        var boxState = function (b) {
            var el = b.el, vp = viewportBox();
            if (!el.isConnected) return null;
            var r;
            if (b.frameDoc) {
                r = { left: b.ox, top: b.oy, right: b.ox + el.clientWidth, bottom: b.oy + el.clientHeight };
            } else {
                var br = el.getBoundingClientRect();
                r = { left: br.left + b.ox, top: br.top + b.oy, right: br.right + b.ox, bottom: br.bottom + b.oy };
            }
            // only the visible part (so the edges can be reached with the cursor)
            var l = Math.max(r.left, vp.x), t = Math.max(r.top, vp.y);
            var rr = Math.min(r.right, vp.x + vp.w), bb = Math.min(r.bottom, vp.y + vp.h);
            if (rr - l < 24 || bb - t < 24) return null;
            // a box that fills the screen is the page itself; the normal page scrolling handles it
            if ((rr - l) >= vp.w * 0.9 && (bb - t) >= vp.h * 0.9) return null;
            var maxY = el.scrollHeight - el.clientHeight, maxX = el.scrollWidth - el.clientWidth;
            var sy = el.scrollTop, sx = el.scrollLeft;
            var rtl = false;
            try { rtl = (el.ownerDocument.defaultView || window).getComputedStyle(el).direction === 'rtl'; } catch (e) {}
            var left, right;
            if (rtl && sx <= 0) { left = b.x && sx > -maxX + 1; right = b.x && sx < -0.5; }
            else { left = b.x && sx > 0.5; right = b.x && sx < maxX - 1; }
            return JSON.stringify({
                l: (l - vp.x) / vp.w, t: (t - vp.y) / vp.h, r: (rr - vp.x) / vp.w, b: (bb - vp.y) / vp.h,
                up: !!(b.y && sy > 0.5), down: !!(b.y && sy < maxY - 1), left: !!left, right: !!right
            });
        };

        window.__lumenScrollProbe = function (fx, fy) {
            innerBox = null;
            try {
                var vp = viewportBox();
                var x = vp.x + fx * vp.w, y = vp.y + fy * vp.h;
                var doc = document, ox = 0, oy = 0;
                var el = doc.elementFromPoint(x, y);
                // look into same-origin frames
                for (var depth = 0; el && (el.tagName === 'IFRAME' || el.tagName === 'FRAME') && depth < 4; depth++) {
                    var idoc = null;
                    try { idoc = el.contentDocument; } catch (e) { idoc = null; }
                    if (!idoc) break;
                    var fr = el.getBoundingClientRect();
                    var fox = ox + fr.left + el.clientLeft, foy = oy + fr.top + el.clientTop;
                    var inner = idoc.elementFromPoint(x - fox, y - foy);
                    if (!inner) break;
                    doc = idoc; ox = fox; oy = foy; el = inner;
                }
                // and into shadow DOM (web components)
                for (var sd = 0; el && el.shadowRoot && sd < 8; sd++) {
                    var se = el.shadowRoot.elementFromPoint(x - ox, y - oy);
                    if (!se || se === el) break;
                    el = se;
                }
                for (var n = el; n; n = n.parentElement || (n.parentNode && n.parentNode.host) || null) {
                    if (n.nodeType !== 1) continue;
                    var nd = n.ownerDocument;
                    var isDocScroller = (n === nd.scrollingElement || n === nd.documentElement || n === nd.body);
                    if (isDocScroller) {
                        if (nd === document) break; // the page itself
                        var se2 = nd.scrollingElement || nd.documentElement;
                        if (n !== se2) continue;
                        var fy2 = frameScrolls(se2, 'y'), fx2 = frameScrolls(se2, 'x');
                        if (fy2 || fx2) {
                            innerBox = { el: se2, ox: ox, oy: oy, frameDoc: true, x: fx2, y: fy2 };
                            break;
                        }
                        continue;
                    }
                    var ay = overflows(n, 'y'), ax = overflows(n, 'x');
                    if (ay || ax) {
                        innerBox = { el: n, ox: ox, oy: oy, frameDoc: false, x: ax, y: ay };
                        break;
                    }
                }
                if (!innerBox) return '';
                var st = boxState(innerBox);
                if (!st) innerBox = null;
                return st || '';
            } catch (e) {
                innerBox = null;
                return '';
            }
        };

        window.__lumenInnerScroll = function (fdx, fdy) {
            var b = innerBox;
            if (!b) return '';
            try {
                var vp = viewportBox();
                var dx = b.x ? fdx * vp.w : 0, dy = b.y ? fdy * vp.h : 0;
                var el = b.el;
                // 'instant' so a CSS "scroll-behavior: smooth" doesn't swallow the small steps
                try { el.scrollBy({ left: dx, top: dy, behavior: 'instant' }); }
                catch (e) { el.scrollTop += dy; el.scrollLeft += dx; }
                var st = boxState(b);
                if (!st) innerBox = null;
                return st || '';
            } catch (e) {
                innerBox = null;
                return '';
            }
        };

        // ---- auto-hiding top bar ----
        // The browser sees ordinary page scrolling itself. Many web apps scroll a full-size inner
        // box instead (the page itself never moves), so report those boxes' scrolling as well.
        var boxY = (typeof WeakMap === 'function') ? new WeakMap() : null, pendingDy = 0, lastSent = 0;
        document.addEventListener('scroll', function (e) {
            var t = e.target;
            if (!t || t === document || t.nodeType !== 1) return;
            if (!window.TVBro || typeof TVBro.sofaPageScroll !== 'function') return;
            var r = t.getBoundingClientRect();
            var vw = window.innerWidth || 1, vh = window.innerHeight || 1;
            if (r.width < vw * 0.6 || r.height < vh * 0.6) return; // menus, carousels, ...
            var y = t.scrollTop;
            var prev = boxY && boxY.has(t) ? boxY.get(t) : 0;
            if (boxY) boxY.set(t, y);
            pendingDy += y - prev;
            var now = Date.now();
            if (y <= 0 || now - lastSent > 80) {
                lastSent = now;
                try { TVBro.sofaPageScroll(Math.round(y), Math.round(pendingDy)); } catch (err) {}
                pendingDy = 0;
            }
        }, { capture: true, passive: true });
    }

    // ---------------- start-up ----------------
    onReady(function () {
        challengePage = isChallengePage();
        if (challengePage) {
            window.open = origOpen;
            return;
        }
        if (cfg.maxQuality) {
            applyPlayerApiQuality();
            // single-page sites (YouTube) change videos without reloading
            setInterval(applyPlayerApiQuality, 4000);
        }
    });
})();
