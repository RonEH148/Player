plugins {
    id("tvbro.android.application")
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.phlox.tvwebbrowser"

    defaultConfig {
        applicationId = "com.sofabrowse.tv"
        versionCode = 133
        versionName = "2.0.0 Lumen (based on TV Bro 2.1.6)"

        //TVs, sticks and tablets are ARM: leave out the x86 copies of the native libraries
        //(ad blocker, WireGuard) - a smaller APK and less storage used
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }

        javaCompileOptions {
            annotationProcessorOptions {
                arguments += mapOf(
                    "room.incremental" to "true",
                    //used when AppDatabase @Database annotation exportSchema = true. Useful for migrations
                    "room.schemaLocation" to "$projectDir/schemas"
                )
            }
        }
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("KEYSTORE_PATH")
            if (keystorePath != null) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            } else {
                //SofaBrowse personal signing key (keep your repository private).
                //The same key must sign every build, otherwise Android refuses to install updates.
                storeFile = rootProject.file("signing/sofabrowse.jks")
                storePassword = "BR7TAXAr1xDxNJuIN-UKJzsT"
                keyAlias = "sofabrowse"
                keyPassword = "BR7TAXAr1xDxNJuIN-UKJzsT"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            isDebuggable = true
        }
        getByName("release") {
            isDebuggable = false
            isMinifyEnabled = true
            //drop resources nothing uses (smaller APK)
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }

    splits {
        abi {
            isEnable = project.hasProperty("enableAbiSplits")
            reset()
            include("armeabi-v7a", "arm64-v8a", "x86_64")
            isUniversalApk = false
        }
    }

    flavorDimensions += listOf("appstore", "webengine")
    productFlavors {
        create("generic") {
            dimension = "appstore"
            buildConfigField("Boolean", "BUILT_IN_AUTO_UPDATE", "true")
        }
        create("google") {
            dimension = "appstore"
            //now auto-update violates Google Play policies
            buildConfigField("Boolean", "BUILT_IN_AUTO_UPDATE", "false")
        }
        create("foss") {
            dimension = "appstore"
            applicationIdSuffix = ".foss"
            buildConfigField("Boolean", "BUILT_IN_AUTO_UPDATE", "false")
        }

        create("geckoIncluded") {
            dimension = "webengine"
            minSdk = 26 // geckoview requires minSdk 26
        }
        create("geckoExcluded") {
            dimension = "webengine"
        }
    }

    compileOptions {
        //needed by the WireGuard tunnel library
        isCoreLibraryDesugaringEnabled = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }
}

dependencies {
    implementation(project(":app:common"))
    //Lumen: Firefox's engine (GeckoView) in every build, also "geckoExcluded" ones: it can be
    //chosen in Settings → Web browser engine (for sites that only work with Firefox's engine)
    implementation(project(":app:gecko"))

    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar"))))

    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.webkit)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.recyclerview)
    implementation(libs.kotlin.stdlib)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    implementation(libs.androidx.room.runtime)
    annotationProcessor(libs.androidx.room.compiler)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.room.ktx)

    implementation(libs.segmented.button)
    implementation(libs.ad.block)
    implementation(libs.pinned.section.listview)

    //SofaBrowse: native 4K/HDR player and WireGuard VPN
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.exoplayer.hls)
    implementation(libs.media3.exoplayer.dash)
    implementation(libs.media3.ui)
    //Chrome's network stack from Google Play services, for video servers that refuse other players
    implementation(libs.media3.datasource.cronet)
    implementation(libs.play.services.cronet)
    implementation(libs.media3.effect) //GPU video filters (Deband)
    implementation(libs.wireguard.tunnel)
    coreLibraryDesugaring(libs.desugar.jdk.libs)

    testImplementation(libs.junit)
    testImplementation(libs.robolectric)
}