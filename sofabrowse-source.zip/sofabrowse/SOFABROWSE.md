# SofaBrowse

SofaBrowse is a modified version of [TV Bro](https://github.com/truefedex/tv-bro) by Fedir Tsapana,
built for personal use. As TV Bro's license requires, it uses a different name, icon and
application ID (`com.sofabrowse.tv.foss`), and its About screen credits TV Bro.

## What's new compared to TV Bro

All extras can be switched on or off in **Settings → SofaBrowse extras**. They work with the default
WebView engine.

| Feature | What it does |
|---|---|
| Stronger ad blocker | Loads EasyList, EasyPrivacy, uBlock filters and Peter Lowe's list together (you can add more, one URL per line) and also hides leftover ad boxes, sticky ad bars and "disable your ad blocker" overlays. |
| Pop-up / pop-under blocker | Stops new tabs opened by invisible full-page links or scripts. Sign-in pop-ups (Google, Apple, Microsoft, Facebook, PayPal…) still work. |
| TV video controls | When a video plays, an on-screen bar appears when you move the cursor over it: back 10 s, play/pause, forward 10 s, speed (0.5×–2×), quality and deinterlace. It works inside embedded players and, on most sites, in full screen. The remote's media keys also control embedded videos now. |
| Deinterlace toggle | "Deinterlace" button in the video bar. It applies a blend filter (each line mixed with its neighbours) that removes combing on interlaced streams, such as TV recordings and live channels. Your choice is remembered. It can stutter on very slow TV boxes. |
| Always highest quality | Picks the top resolution on YouTube and on sites using JW Player, Video.js, hls.js, dash.js, Shaka Player and Plyr. Sites with their own custom player may ignore it. |
| Force dark mode | Turns light pages dark. Photos and videos keep their colors. Pages that are already dark are left alone. |
| Custom script | Your own JavaScript, run after each page loads. |
| Cloudflare compatibility | Allows the third-party cookies that verification widgets need, removes the "WebView" marker from the browser identity and never ad-blocks challenge resources. If a site still fails, install the "with-firefox-engine" APK and switch **Settings → Web browser engine** to GeckoView. |
| TV home screen | Bigger tiles, a bigger search box and a clear orange highlight on the selected tile. |
| Native 4K / HDR player | The **4K** button in the video bar plays the video in a built-in Media3 (ExoPlayer) player. The video goes straight to the TV's hardware decoder, so 4K, HDR10, HLG and Dolby Vision play as the TV supports them, and Dolby/DTS audio passes through to the TV or soundbar. It can switch the TV's refresh rate to the video's frame rate (and to 4K for 4K videos). A short info line shows resolution, HDR type, frame rate and the TV mode. Optional tunneled playback. |
| External player | The **↗** button opens Android's app chooser every time (VLC, MX Player, Kodi, Just Player…). The page's Referer, cookies and user agent are passed along, so protected streams still load. |
| Stream detection | Many sites play from a `blob:` address no other player can open. SofaBrowse remembers the HLS/DASH/MP4 links each page loads and lets you pick one when there are several. YouTube and DRM services (Netflix, Disney+, …) can't be handed off and keep playing in the page. |
| Tab switching | **Channel Up / Channel Down** on the remote switch to the next or previous tab, with a "Tab 2 of 5: …" notice. You can change the keys in Settings → Shortcuts. |
| Password saving | After you sign in, SofaBrowse offers to save the login (Save / Not now / Never for this site). Logins are encrypted with a key kept in the Android keystore and filled in automatically next time, including on two-step sign-in pages. It saves one login per site, never offers in incognito mode, and you manage logins in Settings → Passwords. |
| Ad blocker per site | The ad-block button in the menu now asks: block ads on this site, allow ads on this site always, or allow ads in this tab only. A site entry also covers its subdomains. Settings → Sites without ad blocking lists them. |
| WireGuard VPN | Settings → WireGuard VPN: import a `.conf` file or paste the config, then Connect. By default only SofaBrowse goes through the VPN, or switch that off to send the whole TV through it. It can connect automatically on start. The config is stored encrypted and uses the official WireGuard library. |

## Building the APK (free, on GitHub, works from a phone)

1. Sign in to github.com and create a **new private repository**. Private matters because it
   contains your signing key.
2. Tap **Add file → Upload files** and upload `sofabrowse-source.zip`, then commit.
3. Tap **Add file → Create new file**, name it `.github/workflows/build.yml`, paste the contents of
   `build-from-zip.yml`, then commit.
4. Open the **Actions** tab. The build starts by itself and takes about 10–15 minutes.
5. When it turns green, open **Releases** (on the repository's main page) and download
   `SofaBrowse-webview.apk`, or the `with-firefox-engine-armeabi-v7a` APK if you want the Firefox
   engine too.

If you put the unzipped project in a repository yourself, `.github/workflows/build-sofabrowse.yml`
does the same job.

### Installing on the TV
Use an app like *Downloader* on the TV to open the release link, or copy the APK with a USB stick,
then allow "install unknown apps" when asked. SofaBrowse installs next to TV Bro and does not
replace it. Every build is signed with the same key in `signing/`, so new builds install as updates.
