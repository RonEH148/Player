> **SofaBrowse fork:** see [SOFABROWSE.md](SOFABROWSE.md) for the added features and build steps.

# TV Bro

Simple web browser optimized to use with TV remote

Features:
- working with TV remote
- tabs and bookmarks support
- voice search support
- switch user agent support
- use Android builtin web rendering engine (WebKit/Blink based)
- built-in download manager
- browsing history
- shortcuts

Discussion pages:
- https://forum.xda-developers.com/android/apps-games/tv-bro-browser-android-based-tvs-t3545295
