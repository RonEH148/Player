# Wisp

Wisp is the phone version of Lumen, built from the same source as a separate app
(`com.sofabrowse.wisp`, its own icon and name, installs next to Lumen). It's light (32-bit ARM
only, no Google Play services) and private by default.

## What's different from Lumen

| | Wisp |
|---|---|
| Interface | One bar at the **bottom**: site button, address (shows the site name; tap for the full address), tab counter, ⋮ menu. It slides away when you scroll down and comes back when you scroll up. No remote cursor. |
| ⋮ menu | Back, forward, reload, bookmark and share at the top, then: new tab, private, bookmarks, history, downloads, desktop site, ad blocker, pop-ups, media links, this site, privacy, settings, home, exit. |
| Tabs | The tab counter opens the tab list: tap to switch, ✕ to close, new tab, close all. |
| Links | Hold a finger on a link or image for open in new tab, copy, share, download. Anywhere else it selects text. |
| Start page | Phone layout: search box (DuckDuckGo by default; tap the icon to change), your bookmarks as tiles. |
| No Google | No Play services (the player uses Android's own network stack), no Safe Browsing, DuckDuckGo as the default search, WebView usage statistics off. |
| HTTPS first | `http://` links open over `https://`; if the site has no working https version, Wisp opens the http address (and says so). |
| Third-party cookies | Blocked, except on sites with a human-verification widget (Cloudflare, hCaptcha, reCAPTCHA) and sites you allow in ⋮ → Privacy. |
| Permissions | No "all files access" and no "see all apps" permission. Microphone stays off for websites (as in Lumen). |
| Kept from Lumen | adblock-rust ad blocker, pop-up blocker, player, media links, downloads (multi-part, resume), password saving, desktop site, site fixes, WireGuard, clear on exit, updates from GitHub. |

## Building and updates

`./gradlew assembleWispGeckoExcludedRelease`. Its build number is `wispVersionCode` at the top of
`app/build.gradle.kts` (raise it for every release you want Wisp to update to).

The workflow in `build-from-zip.yml` builds both apps from the zip and publishes
`Lumen-<n>.apk` (tag `lumen-v…`) and `Wisp-<n>.apk` (tag `wisp-v…`) as separate releases. Each app
installs only its own releases (Settings → Version). The repository is private, so Wisp needs the
same read-only access token once (Settings → Version → Update source).
