package com.brouken.player;

import android.content.Context;
import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * The player's side of "Use USB drive as buffer": reads the video from the drive
 * ({@link DriveBuffer}). Anything the drive can't serve (other files such as subtitles, byte
 * ranges, a drive that's too slow) goes to the network exactly as without the buffer.
 */
final class DriveDataSource implements DataSource {

    static final class Factory implements DataSource.Factory {
        private final Context context;
        private final DataSource.Factory upstream;
        private final DataSource.Factory fallback;

        /**
         * @param upstream the HTTP source the drive download uses
         * @param fallback what the player uses when the drive isn't used (the normal read-ahead)
         */
        private final Uri media;

        Factory(Context context, Uri media, DataSource.Factory upstream, DataSource.Factory fallback) {
            this.context = context.getApplicationContext();
            this.media = media;
            this.upstream = upstream;
            this.fallback = fallback;
        }

        @Override
        public DataSource createDataSource() {
            return new DriveDataSource(context, media, upstream, fallback);
        }
    }

    private final Context context;
    private final DataSource.Factory upstream;
    private final DataSource.Factory fallback;
    private final List<TransferListener> listeners = new java.util.ArrayList<>();

    private DriveBuffer buffer;
    private DataSource direct;
    private DataSpec spec;
    private long pos;
    private long remaining;
    private final RandomAccessFile[] handle = {null};
    private final long[] handleChunk = {-1};

    /** Only the video itself goes onto the drive (not subtitles or other files). */
    private final Uri media;

    DriveDataSource(Context context, Uri media, DataSource.Factory upstream, DataSource.Factory fallback) {
        this.context = context;
        this.media = media;
        this.upstream = upstream;
        this.fallback = fallback;
    }

    @Override
    public void addTransferListener(TransferListener listener) {
        listeners.add(listener);
    }

    private long openDirect(DataSpec s) throws IOException {
        direct = fallback.createDataSource();
        for (TransferListener l : listeners) direct.addTransferListener(l);
        return direct.open(s);
    }

    @Override
    public long open(DataSpec dataSpec) throws IOException {
        spec = dataSpec;
        buffer = null;
        direct = null;
        if (dataSpec.length != C.LENGTH_UNSET) return openDirect(dataSpec);   // byte ranges: as usual
        if (media == null || !media.equals(dataSpec.uri)) return openDirect(dataSpec);
        DriveBuffer b = UsbBuffer.session(context, dataSpec.uri, upstream);
        if (b == null || b.prepare(dataSpec.position) != DriveBuffer.OK) return openDirect(dataSpec);
        buffer = b;
        pos = dataSpec.position;
        remaining = b.length(pos);
        return remaining;
    }

    @Override
    public int read(byte[] target, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (direct != null) return direct.read(target, offset, length);
        DriveBuffer b = buffer;
        if (b == null) throw new IOException("Not opened");
        long avail = b.await(pos);
        if (avail == -3) {
            // the data isn't coming with the current download: start it here (or use the network)
            if (b.prepare(pos) != DriveBuffer.OK) avail = -2;
            else avail = b.await(pos);
            if (avail == -3) throw new IOException("USB buffer: download didn't start");
        }
        if (avail == -1) return C.RESULT_END_OF_INPUT;
        if (avail == -2) {
            // the drive couldn't keep up: continue from the network at this point
            closeHandle();
            buffer = null;
            openDirect(spec.buildUpon().setPosition(pos).build());
            return direct.read(target, offset, length);
        }
        int n = b.readAt(pos, target, offset, (int) Math.min(length, avail), handle, handleChunk);
        if (n <= 0) throw new IOException("USB buffer: couldn't read from the drive");
        pos += n;
        return n;
    }

    @Override
    public Uri getUri() {
        if (direct != null) return direct.getUri();
        DriveBuffer b = buffer;
        if (b != null && b.finalUri() != null) return b.finalUri();
        return spec != null ? spec.uri : null;
    }

    @Override
    public Map<String, List<String>> getResponseHeaders() {
        if (direct != null) return direct.getResponseHeaders();
        DriveBuffer b = buffer;
        return b != null ? b.headers() : Collections.emptyMap();
    }

    private void closeHandle() {
        if (handle[0] != null) {
            try { handle[0].close(); } catch (IOException ignored) { }
            handle[0] = null;
            handleChunk[0] = -1;
        }
    }

    @Override
    public void close() throws IOException {
        closeHandle();
        buffer = null;
        DataSource d = direct;
        direct = null;
        if (d != null) d.close();
    }
}
