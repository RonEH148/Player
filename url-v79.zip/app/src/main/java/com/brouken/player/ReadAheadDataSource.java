package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * mpv/VLC-style stream cache: a background thread keeps reading the HTTP stream into a
 * large ring buffer at full network speed, independent of how fast the extractor pulls.
 * Seeks inside the cached window are served instantly; seeks outside restart the reader.
 */
public final class ReadAheadDataSource implements DataSource {

    /** Heap ring (fallback when native shared memory isn't available): 32–64 MB. */
    static final int HEAP_CAPACITY = Perf.readAheadBytes();
    static final int KEEP_BACK_MIN = 6 * 1024 * 1024;

    // ------------------------------------------------------------------ ring memory

    /** The bytes of the read-ahead: native shared memory (outside the heap) or a heap array. */
    abstract static class Ring {
        final int cap;
        Ring(int cap) { this.cap = cap; }
        abstract void put(int idx, byte[] src, int off, int n);
        abstract void get(int idx, byte[] dst, int off, int n);
    }

    static final class HeapRing extends Ring {
        final byte[] b;
        HeapRing(int cap) { super(cap); b = new byte[cap]; }
        void put(int idx, byte[] src, int off, int n) { System.arraycopy(src, off, b, idx, n); }
        void get(int idx, byte[] dst, int off, int n) { System.arraycopy(b, idx, dst, off, n); }
    }

    /** Android 8.1+: ashmem, counted against the device's RAM but not the app's heap limit. */
    static final class NativeRing extends Ring {
        final java.nio.ByteBuffer buf;
        final Object mem;
        NativeRing(int cap) throws Exception {
            super(cap);
            android.os.SharedMemory m = android.os.SharedMemory.create("read-ahead", cap);
            mem = m;
            buf = m.mapReadWrite();
        }
        void put(int idx, byte[] src, int off, int n) {
            java.nio.ByteBuffer d = buf.duplicate();
            d.position(idx);
            d.put(src, off, n);
        }
        void get(int idx, byte[] dst, int off, int n) {
            java.nio.ByteBuffer d = buf.duplicate();
            d.position(idx);
            d.get(dst, off, n);
        }
    }

    private static Ring shared;
    private static boolean sharedBusy;
    private static boolean nativeTried;

    /** The big ring is used by one download at a time; a second one gets a small heap ring. */
    private static synchronized Ring acquire() {
        if (!nativeTried) {
            nativeTried = true;
            if (android.os.Build.VERSION.SDK_INT >= 27) {
                try {
                    shared = new NativeRing(Perf.nativeReadAheadBytes());
                    Diag.log("Read-ahead: " + shared.cap / (1024 * 1024) + " MB in native memory (outside the 512 MB heap limit)");
                } catch (Throwable t) {
                    shared = null;
                    Diag.log("Read-ahead: native memory unavailable (" + t + "), using the heap");
                }
            }
            if (shared == null) shared = new HeapRing(HEAP_CAPACITY);
        }
        if (!sharedBusy) {
            sharedBusy = true;
            return shared;
        }
        return new HeapRing(16 * 1024 * 1024);
    }

    private static synchronized void release(Ring r) {
        if (r == shared) sharedBusy = false;
    }

    static boolean nativeRing() {
        return android.os.Build.VERSION.SDK_INT >= 27;
    }

    static int capacity() {
        Ring r = shared;
        return r != null ? r.cap : nativeRing() ? Perf.nativeReadAheadBytes() : HEAP_CAPACITY;
    }

    /** A read-ahead is reading the video from the USB drive buffer. */
    static boolean driveReading() {
        synchronized (LIVE) {
            for (Reader r : LIVE) if (r.upstream instanceof DriveDataSource) return true;
        }
        return false;
    }

    /** Bytes downloaded ahead of the player (for the overlay). */
    static long ahead() {
        long a = 0;
        synchronized (LIVE) {
            for (Reader r : LIVE) a = Math.max(a, r.ahead());
        }
        return a;
    }
    static final int CHUNK = 1024 * 1024;
    static final int REUSE_AHEAD = 8 * 1024 * 1024;

    public static final class Factory implements DataSource.Factory {
        private final DataSource.Factory upstream;

        public Factory(DataSource.Factory upstream) {
            this.upstream = upstream;
        }

        @Override
        public DataSource createDataSource() {
            return new ReadAheadDataSource(upstream);
        }
    }

    private static final List<Reader> LIVE = new ArrayList<>();

    /** Bytes read from local files (USB drive …), for the overlay's read speed. */
    static final java.util.concurrent.atomic.AtomicLong LOCAL_BYTES = new java.util.concurrent.atomic.AtomicLong();

    /** Stop every background download right away (player left / stopped). */
    public static void stopAll() {
        final List<Reader> copy;
        synchronized (LIVE) {
            copy = new ArrayList<>(LIVE);
            LIVE.clear();
        }
        for (final Reader r : copy) {
            r.shutdown();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try { r.upstream.close(); } catch (Throwable ignored) { }  // aborts a blocked read
                }
            }, "read-ahead-close").start();
        }
        if (!copy.isEmpty()) Diag.log("Stopped " + copy.size() + " background download(s)");
    }

    private final DataSource.Factory upstreamFactory;
    private final List<TransferListener> listeners = new ArrayList<>();
    private Reader reader;
    private DataSource direct;
    private Uri uri;

    ReadAheadDataSource(DataSource.Factory upstreamFactory) {
        this.upstreamFactory = upstreamFactory;
    }

    @Override
    public void addTransferListener(TransferListener listener) {
        listeners.add(listener);
    }

    private DataSource newUpstream() {
        DataSource ds = upstreamFactory.createDataSource();
        for (TransferListener l : listeners) ds.addTransferListener(l);
        return ds;
    }

    @Override
    public long open(DataSpec spec) throws IOException {
        uri = spec.uri;
        // Bounded requests (manifests, segments) don't need a cache.
        if (spec.length != C.LENGTH_UNSET) {
            stopReader();
            direct = newUpstream();
            return direct.open(spec);
        }
        direct = null;

        Reader r = reader;
        if (r != null && r.canServe(spec.uri, spec.position)) {
            r.reuseAt(spec.position);
            return r.end == C.LENGTH_UNSET ? C.LENGTH_UNSET : r.end - spec.position;
        }

        stopReader();
        DataSource up = newUpstream();
        long length = up.open(spec);   // errors (HTTP 4xx etc.) surface right here
        reader = new Reader(up, spec.uri, spec.position,
                length == C.LENGTH_UNSET ? C.LENGTH_UNSET : spec.position + length, acquire());
        reader.start();
        return length;
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (direct != null) return direct.read(buffer, offset, length);
        Reader r = reader;
        if (r == null) throw new IOException("Not opened");
        return r.read(buffer, offset, length);
    }

    @Override
    public Uri getUri() {
        try {
            if (direct != null) return direct.getUri();
            Reader r = reader;
            if (r != null && r.upstream.getUri() != null) return r.upstream.getUri();
        } catch (Throwable ignored) { }
        return uri;
    }

    @Override
    public Map<String, List<String>> getResponseHeaders() {
        try {
            if (direct != null) return direct.getResponseHeaders();
            Reader r = reader;
            if (r != null) return r.upstream.getResponseHeaders();
        } catch (Throwable ignored) { }
        return Collections.emptyMap();
    }

    @Override
    public void close() throws IOException {
        if (direct != null) {
            DataSource d = direct;
            direct = null;
            d.close();
            return;
        }
        Reader r = reader;
        if (r != null) r.markClosed();   // keep downloading briefly so a quick re-open (seek) can reuse it
    }

    private void stopReader() {
        Reader r = reader;
        reader = null;
        if (r != null) r.shutdown();
    }

    // ------------------------------------------------------------------ reader thread

    private static final class Reader extends Thread {
        final DataSource upstream;
        final Uri uri;
        final long end;           // absolute end of stream, or LENGTH_UNSET
        private final Ring ring;
        private final int cap;
        private final long keepBack;   // kept behind the player for quick jumps back
        private final boolean local;

        private long base;        // oldest byte still in the ring
        private long writePos;    // next byte the network will write
        private long readPos;     // next byte the player will read
        private boolean eof;
        private boolean stopped;
        private boolean closed;
        private long closedAt;
        private IOException error;

        Reader(DataSource upstream, Uri uri, long start, long end, Ring ring) {
            super("read-ahead");
            this.upstream = upstream;
            this.uri = uri;
            this.end = end;
            this.ring = ring;
            this.cap = ring.cap;
            this.keepBack = Math.max(KEEP_BACK_MIN, cap / 8);
            String sc = uri != null ? uri.getScheme() : null;
            this.local = sc == null || !(sc.startsWith("http") || sc.startsWith("rtsp"));
            this.base = start;
            this.writePos = start;
            this.readPos = start;
            setDaemon(true);
            setPriority(Perf.lowEnd() ? Thread.NORM_PRIORITY + 1 : Thread.MAX_PRIORITY);
            synchronized (LIVE) { LIVE.add(this); }
        }

        synchronized long ahead() {
            return Math.max(0, writePos - readPos);
        }

        synchronized boolean canServe(Uri u, long pos) {
            if (stopped || error != null || u == null || !u.equals(uri)) return false;
            if (pos < base) return false;
            if (pos <= writePos) return true;
            return !eof && pos - writePos <= REUSE_AHEAD;
        }

        synchronized void reuseAt(long pos) {
            readPos = pos;
            closed = false;
            notifyAll();
        }

        synchronized void markClosed() {
            closed = true;
            closedAt = System.currentTimeMillis();
            notifyAll();
            if (!isAlive()) {   // download already over: nobody reads this ring any more
                stopped = true;
                freeRing();
            }
        }

        synchronized void shutdown() {
            stopped = true;
            notifyAll();
            freeRing();   // a stopped reader never touches the ring again: the next download can use it
        }

        private boolean ringFreed;

        private synchronized void freeRing() {
            if (ringFreed) return;
            ringFreed = true;
            release(ring);
        }

        private long space() {
            long low = Math.max(base, readPos - keepBack);
            if (low > writePos) low = writePos;
            base = low;
            return cap - (writePos - base);
        }

        @Override
        public void run() {
            // TVs have 4 small cores: don't let downloading compete with the UI and audio threads
            try { android.os.Process.setThreadPriority(Perf.lowEnd() ? android.os.Process.THREAD_PRIORITY_DEFAULT : android.os.Process.THREAD_PRIORITY_FOREGROUND); } catch (Throwable ignored) { }
            byte[] tmp = new byte[CHUNK];
            try {
                while (true) {
                    int want;
                    synchronized (this) {
                        while (!stopped && space() <= 0) {
                            if (closed && System.currentTimeMillis() - closedAt > 3_000) stopped = true;
                            else wait(500);
                        }
                        if (closed && System.currentTimeMillis() - closedAt > 3_000) stopped = true;
                        if (stopped) break;
                        want = (int) Math.min(CHUNK, space());
                    }
                    int n = upstream.read(tmp, 0, want);
                    synchronized (this) {
                        if (stopped) break;
                        if (n == C.RESULT_END_OF_INPUT) {
                            eof = true;
                            notifyAll();
                            break;
                        }
                        int idx = (int) (writePos % cap);
                        int first = Math.min(n, cap - idx);
                        ring.put(idx, tmp, 0, first);
                        if (first < n) ring.put(0, tmp, first, n - first);
                        writePos += n;
                        if (local) LOCAL_BYTES.addAndGet(n);
                        notifyAll();
                    }
                }
            } catch (InterruptedException e) {
                synchronized (this) { stopped = true; notifyAll(); }
            } catch (IOException e) {
                synchronized (this) { error = e; notifyAll(); }
                Diag.log("Read-ahead: " + Diag.describe(e));
            } finally {
                synchronized (LIVE) { LIVE.remove(this); }
                // stopped: the ring goes to the next download. End of file / network error: the
                // player may still be reading what's in it; freed when this source is closed or reopened.
                boolean free;
                synchronized (this) { free = stopped; notifyAll(); }
                if (free) freeRing();
                try { upstream.close(); } catch (Throwable ignored) { }
            }
        }

        int read(byte[] buf, int off, int len) throws IOException {
            synchronized (this) {
                if (stopped && ringFreed) throw new IOException("Read-ahead stopped");
                while (readPos >= writePos) {
                    if (error != null) throw error;
                    if (eof) return C.RESULT_END_OF_INPUT;
                    if (stopped) throw new IOException("Read-ahead stopped");
                    try {
                        wait(1000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new InterruptedIOException();
                    }
                }
                int n = (int) Math.min(len, writePos - readPos);
                int idx = (int) (readPos % cap);
                int first = Math.min(n, cap - idx);
                ring.get(idx, buf, off, first);
                if (first < n) ring.get(0, buf, off + first, n - first);
                readPos += n;
                notifyAll();
                return n;
            }
        }
    }
}
