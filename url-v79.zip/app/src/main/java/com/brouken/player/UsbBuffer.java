package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.TypedValue;
import android.widget.TextView;

import androidx.media3.datasource.DataSource;
import androidx.media3.extractor.SeekMap;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Locale;
import java.util.Random;

/**
 * Settings → "Use USB drive as buffer" and "Test USB drive". Finds the USB drive, measures how
 * fast the TV can write to it, and keeps the one {@link DriveBuffer} of the video that's open.
 */
final class UsbBuffer {

    private UsbBuffer() {}

    static final String KEY = "usbBuffer";
    static final String KEY_TEST = "usbBufferTest";
    private static final String KEY_SPEED = "usbTestSpeed";
    private static final String KEY_DRIVE = "usbTestDrive";

    /** Write speed (MB/s, while reading back) needed: 4K remuxes are 8–11 MB/s. */
    static final float GOOD = 15f, ENOUGH = 10f;
    private static final long MIN_FREE = 6L << 30;

    // ------------------------------------------------------------------ the drive

    /** Just Player's own folder on the USB drive (no permission needed), or null. */
    static File drive(Context c) {
        try {
            File[] dirs = c.getExternalFilesDirs(null);
            for (int i = 1; i < dirs.length; i++) {
                File d = dirs[i];
                if (d == null) continue;
                try {
                    if (Environment.isExternalStorageRemovable(d)
                            && Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState(d))) return d;
                } catch (IllegalArgumentException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** The drive itself ("/storage/1A2B-3C4D"), to know whether the test was done on this one. */
    static String driveId(File d) {
        String p = d.getAbsolutePath();
        int i = p.indexOf("/Android/");
        return i > 0 ? p.substring(0, i) : p;
    }

    static boolean enabled(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY, false);
    }

    /** Tested speed of this drive, or -1. */
    static float testedSpeed(Context c, File d) {
        android.content.SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(c);
        return d != null && driveId(d).equals(p.getString(KEY_DRIVE, null)) ? p.getFloat(KEY_SPEED, -1f) : -1f;
    }

    /** Why the buffer isn't used for the next video, or null when it is. */
    static String notUsedBecause(Context c) {
        if (!enabled(c)) return "off";
        File d = drive(c);
        if (d == null) return "no USB drive connected";
        float s = testedSpeed(c, d);
        if (s < 0) return "this drive hasn't been tested (Settings → Test USB drive)";
        if (s < ENOUGH) return String.format(Locale.US, "this drive is too slow (%.1f MB/s)", s);
        if (d.getUsableSpace() < MIN_FREE) return "less than 6 GB free on the drive";
        return null;
    }

    // ------------------------------------------------------------------ the video's buffer

    private static DriveBuffer current;
    private static boolean cleaned;

    /** The buffer for this link (created on first use); null = read from the network as usual. */
    static synchronized DriveBuffer session(Context c, Uri uri, DataSource.Factory upstream) {
        if (uri == null) return null;
        if (current != null && current.key.equals(uri.toString())) return current;
        if (notUsedBecause(c) != null) return null;
        closeAll();
        File d = drive(c);
        if (d == null) return null;
        File dir = new File(d, "buffer");
        cleanLeftovers(dir);
        long cap = d.getUsableSpace() - DriveBuffer.MARGIN;
        if (cap < (2L << 30)) return null;
        current = new DriveBuffer(new File(dir, Long.toString(System.currentTimeMillis())), uri,
                RangeSupport.isLinear(uri), upstream, cap);
        Diag.log(String.format(Locale.US, "USB buffer: on (%.0f GB usable on the drive)", cap / 1e9));
        return current;
    }

    /** The video was closed: stop and delete its buffer. */
    static synchronized void closeAll() {
        if (current != null) {
            current.close();
            current = null;
        }
    }

    /** Files left by an earlier run (the app was killed): deleted once. */
    private static void cleanLeftovers(final File dir) {
        if (cleaned) return;
        cleaned = true;
        final File[] old = dir.listFiles();
        if (old == null || old.length == 0) return;
        new Thread(() -> { for (File f : old) deleteTree(f); }, "usb-buffer-clean").start();
    }

    static void deleteTree(File f) {
        if (f == null) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    /** Refresh button: restart the download (links that can seek). */
    static void kick() {
        DriveBuffer b = current();
        if (b != null) b.kick();
    }

    static synchronized DriveBuffer current() {
        return current;
    }

    /** Seek points inside what's on the drive (links that can't seek), or null. */
    static SeekMap.SeekPoints seekPoints(long timeUs) {
        DriveBuffer b = current();
        return b != null && b.linear ? b.seekPoints(timeUs) : null;
    }

    /** {from, to} ms the player can jump to on the drive (links that can't seek), or null. */
    static long[] seekableMs(Uri uri) {
        DriveBuffer b = current();
        if (b == null || !b.linear || uri == null || !b.key.equals(uri.toString())) return null;
        return b.seekableMs();
    }

    /** Overlay line, or null. */
    static String status(Context c, long positionMs, long durationMs) {
        DriveBuffer b = current();
        if (b == null) {
            if (!enabled(c)) return null;
            String why = notUsedBecause(c);
            return why == null ? null : "not used – " + why;
        }
        if (b.bypass) return "stopped – the drive couldn't keep up, normal buffer";
        long[] s = b.stats();
        StringBuilder sb = new StringBuilder();
        sb.append(Diag.mb(s[0])).append(" ready ahead");
        long[] seek = b.linear ? b.seekableMs() : null;
        if (seek != null && seek[1] > positionMs) {
            sb.append(" (").append(time(seek[1] - positionMs)).append(")");
        } else {
            long total = Diag.currentSize();
            if (total > 0 && durationMs > 0) sb.append(" (~").append(time(s[0] * durationMs / total)).append(")");
        }
        if (b.isComplete()) sb.append(" · whole file downloaded");
        sb.append(" · ").append(Diag.mb(s[1])).append(" on the drive");
        if (b.writeMBps > 0) sb.append(String.format(Locale.US, " · writes %.0f MB/s", b.writeMBps));
        return sb.toString();
    }

    private static String time(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                : String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    // ------------------------------------------------------------------ settings

    static String testSummary(Context c) {
        File d = drive(c);
        if (d == null) return "No USB drive connected";
        float s = testedSpeed(c, d);
        String free = String.format(Locale.US, "%.0f GB free", d.getUsableSpace() / 1e9);
        if (s < 0) return "Not tested yet · " + free;
        return String.format(Locale.US, "%.1f MB/s · %s · %s", s, verdict(s), free);
    }

    private static String verdict(float s) {
        return s >= GOOD ? "fast enough for 4K remuxes" : s >= ENOUGH ? "enough for most 4K, tight for the biggest remuxes"
                : "too slow for 4K remuxes";
    }

    /** Switch turned on: test the drive first if needed. Returns false to keep it off. */
    static boolean onSwitch(final Activity a, boolean on, final Runnable turnedOn, final Runnable refresh) {
        if (!on) {
            closeAll();
            return true;
        }
        File d = drive(a);
        if (d == null) {
            message(a, "No USB drive", "Connect the USB drive to the TV first.");
            return false;
        }
        float s = testedSpeed(a, d);
        if (s >= ENOUGH) return true;
        if (s >= 0) {
            message(a, "This drive is too slow", String.format(Locale.US,
                    "The TV writes to it at %.1f MB/s; 4K remuxes need at least %.0f MB/s.", s, ENOUGH));
            return false;
        }
        test(a, ok -> {
            if (ok) turnedOn.run();
            refresh.run();
        });
        return false;   // turned on by the test when it passes
    }

    interface Done { void done(boolean ok); }

    /**
     * Writes 256 MB into the same folder, the same way the buffer does, while reading back what
     * was written a moment earlier (as during playback); the time includes flushing to the drive.
     */
    static void test(final Activity a, final Done done) {
        final File d = drive(a);
        if (d == null) {
            message(a, "No USB drive", "Connect the USB drive to the TV first.");
            if (done != null) done.done(false);
            return;
        }
        final TextView text = new TextView(a);
        int pad = (int) (24 * a.getResources().getDisplayMetrics().density);
        text.setPadding(pad, pad / 2, pad, 0);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        text.setText("Writing to the drive…");
        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Testing the USB drive")
                .setView(text)
                .setCancelable(false)
                .setPositiveButton("OK", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            final int MB = 1 << 20, total = 256;
            File dir = new File(d, "speedtest");
            File f = new File(dir, "test.bin");
            float speed = -1f;
            String error = null;
            try {
                if (d.getUsableSpace() < (total + 64L) * MB) throw new java.io.IOException("not enough free space");
                dir.mkdirs();
                byte[] buf = new byte[MB], back = new byte[MB];
                new Random().nextBytes(buf);
                try (RandomAccessFile w = new RandomAccessFile(f, "rw"); RandomAccessFile r = new RandomAccessFile(f, "r")) {
                    long t0 = System.nanoTime();
                    for (int i = 0; i < total; i++) {
                        buf[i % MB] ^= 1;
                        w.write(buf);
                        if (i >= 32) {
                            r.seek((long) (i - 32) * MB);
                            r.readFully(back);
                        }
                        if (i % 32 == 31) {
                            w.getFD().sync();
                            final int done1 = i + 1;
                            final double sofar = done1 / ((System.nanoTime() - t0) / 1e9);
                            ui.post(() -> text.setText(String.format(Locale.US, "Writing to the drive… %d of %d MB (%.1f MB/s)",
                                    done1, total, sofar)));
                        }
                    }
                    w.getFD().sync();
                    speed = (float) (total / ((System.nanoTime() - t0) / 1e9));
                }
            } catch (Throwable t) {
                error = t.getMessage() != null ? t.getMessage() : t.toString();
            } finally {
                f.delete();
                dir.delete();
            }
            final float result = speed;
            final String err = error;
            ui.post(() -> {
                boolean ok = result >= ENOUGH;
                if (result > 0) {
                    PreferenceManager.getDefaultSharedPreferences(a).edit()
                            .putFloat(KEY_SPEED, result).putString(KEY_DRIVE, driveId(d)).apply();
                    text.setText(String.format(Locale.US, "%.1f MB/s – %s.%s", result, verdict(result),
                            ok ? "\n\nThe drive can be used as the buffer." : "\n\nThe buffer stays off for this drive."
                                    + " If it's formatted as NTFS, exFAT is usually much faster on Android TVs."));
                } else {
                    text.setText("The test couldn't write to the drive: " + err);
                }
                dialog.setCancelable(true);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                if (done != null) done.done(ok);
            });
        }, "usb-speed-test").start();
    }

    private static void message(Activity a, String title, String msg) {
        new AlertDialog.Builder(a).setTitle(title).setMessage(msg).setPositiveButton(android.R.string.ok, null).show();
    }
}
