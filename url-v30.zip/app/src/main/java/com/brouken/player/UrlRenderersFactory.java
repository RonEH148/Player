package com.brouken.player;

import android.content.Context;
import android.os.Handler;

import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.video.VideoRendererEventListener;

import java.util.ArrayList;

import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegLibrary;
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegVideoRenderer;

/**
 * Adds the FFmpeg software video decoder (NextLib, built with VC-1, 10-bit AVC, MPEG-4 …).
 *  SW  : FFmpeg first – used for every codec it supports
 *  HW+ / HW : not added (HW+ switches a video to SW when hardware can't play it)
 */
public final class UrlRenderersFactory extends DefaultRenderersFactory {

    private final int mode;

    public UrlRenderersFactory(Context context, int mode) {
        super(context);
        this.mode = mode;
    }

    @Override
    protected void buildVideoRenderers(Context context, int extensionRendererMode,
                                       MediaCodecSelector mediaCodecSelector, boolean enableDecoderFallback,
                                       Handler eventHandler, VideoRendererEventListener eventListener,
                                       long allowedVideoJoiningTimeMs, ArrayList<Renderer> out) {
        super.buildVideoRenderers(context, extensionRendererMode, mediaCodecSelector, enableDecoderFallback,
                eventHandler, eventListener, allowedVideoJoiningTimeMs, out);
        // Only in SW mode: the track selector prefers whichever decoder *claims* the best support,
        // and hardware decoders often under-report (e.g. 4K HEVC), so in HW+/HW FFmpeg would win
        // and software-decode 4K. HW+ switches a video to SW by itself when hardware can't play it.
        if (mode != Decoder.SW) return;
        try {
            Diag.log("FFmpeg video: " + (FfmpegLibrary.isAvailable()
                    ? "loaded " + FfmpegLibrary.getVersion()
                      + " (VC-1 " + yn(FfmpegLibrary.supportsFormat("video/wvc1"))
                      + ", AVC " + yn(FfmpegLibrary.supportsFormat("video/avc"))
                      + ", HEVC " + yn(FfmpegLibrary.supportsFormat("video/hevc")) + ")"
                    : "NOT loaded"));
            Renderer ffmpeg = new FfmpegVideoRenderer(allowedVideoJoiningTimeMs, eventHandler, eventListener,
                    MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY);
            out.add(0, ffmpeg);
        } catch (Throwable t) {
            Diag.log("FFmpeg video decoder unavailable: " + t);
        }
    }

    private static String yn(boolean b) { return b ? "yes" : "no"; }
}
