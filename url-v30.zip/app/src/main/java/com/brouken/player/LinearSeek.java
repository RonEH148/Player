package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.ForwardingPlayer;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorInput;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ExtractorsFactory;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekPoint;
import androidx.media3.extractor.SniffFailure;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.extractor.text.SubtitleParser;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Seeking on servers that can't seek ("linear" links, see RangeSupport), like mpv does it:
 * jumps are allowed only inside what is already downloaded, in 5-second steps, at most half of the
 * buffer ahead (30 s buffered → up to 15 s forward) and a few seconds back. Nothing is reloaded and
 * audio stays in sync because the player just moves within its own buffer.
 *
 * ExoPlayer normally refuses any seek on such a file and restarts it from 0:00; the wrapped
 * extractor reports the file as seekable so in-buffer jumps work, and SeekGuard keeps every jump
 * inside the buffer so a reload from the start never happens.
 */
public final class LinearSeek {

    private LinearSeek() {}

    static final int STEP_MS = 5_000;

    static int backBufferMs() {
        return Perf.lowEnd() ? 5_000 : 15_000;
    }

    static boolean active() {
        try {
            ExoPlayer p = PlayerActivity.player;
            if (p == null || p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return false;
            return RangeSupport.isLinear(p.getCurrentMediaItem().localConfiguration.uri);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Seek step for remote / D-pad: 5 s on linear links, Just Player's 10 s otherwise. */
    public static long step() {
        return active() ? STEP_MS : 10_000;
    }

    /** Where a seek to {@code target} may go. Normal links: anywhere. */
    public static long clamp(Player p, long target) {
        if (p == null || !active()) return target;
        long cur = p.getCurrentPosition();
        long buffered = p.getBufferedPosition();
        long maxForward = cur + Math.max(0, (buffered - cur) / 2);
        long minBack = Math.max(0, cur - backBufferMs() + 500);
        long delta = target - cur;
        long steps = Math.round(delta / (double) STEP_MS);
        long t = cur + steps * STEP_MS;
        if (t > maxForward) t = cur + ((maxForward - cur) / STEP_MS) * STEP_MS;
        if (t < minBack) t = cur - ((cur - minBack) / STEP_MS) * STEP_MS;
        if (t != target) Diag.log("Linear seek: " + (target - cur) / 1000 + " s → " + (t - cur) / 1000 + " s (inside buffer)");
        return Math.max(0, t);
    }

    /** All seeks from Just Player's own gestures and keys go through here. */
    public static void seekTo(ExoPlayer p, long target) {
        if (p == null) return;
        long t = clamp(p, target);
        if (active() && t == p.getCurrentPosition()) return;   // nothing buffered that far
        p.seekTo(t);
    }

    /** The player handed to the on-screen controls (time bar), so its seeks are guarded too. */
    public static Player wrap(ExoPlayer p) {
        return new ForwardingPlayer(p) {
            @Override
            public void seekTo(long positionMs) {
                long t = clamp(getWrappedPlayer(), positionMs);
                if (active() && t == getWrappedPlayer().getCurrentPosition()) return;
                super.seekTo(t);
            }

            @Override
            public void seekTo(int mediaItemIndex, long positionMs) {
                long t = clamp(getWrappedPlayer(), positionMs);
                if (active() && t == getWrappedPlayer().getCurrentPosition()) return;
                super.seekTo(mediaItemIndex, t);
            }
        };
    }

    // ------------------------------------------------------------------ extractor side

    /** Wraps the extractors of a linear link so the file counts as seekable (inside the buffer). */
    public static ExtractorsFactory factory(final ExtractorsFactory base) {
        return new ExtractorsFactory() {
            @Override
            public Extractor[] createExtractors() {
                return wrapAll(base.createExtractors());
            }

            @Override
            public Extractor[] createExtractors(Uri uri, Map<String, List<String>> responseHeaders) {
                return wrapAll(base.createExtractors(uri, responseHeaders));
            }

            @Override
            public ExtractorsFactory experimentalSetTextTrackTranscodingEnabled(boolean enabled) {
                base.experimentalSetTextTrackTranscodingEnabled(enabled);
                return this;
            }

            @Override
            public ExtractorsFactory setSubtitleParserFactory(SubtitleParser.Factory f) {
                base.setSubtitleParserFactory(f);
                return this;
            }

            @Override
            public ExtractorsFactory experimentalSetCodecsToParseWithinGopSampleDependencies(int codecFlags) {
                base.experimentalSetCodecsToParseWithinGopSampleDependencies(codecFlags);
                return this;
            }

            @Override
            public ExtractorsFactory setParseHagcMetadata(boolean parse) {
                base.setParseHagcMetadata(parse);
                return this;
            }
        };
    }

    private static Extractor[] wrapAll(Extractor[] in) {
        Extractor[] out = new Extractor[in.length];
        for (int i = 0; i < in.length; i++) out[i] = new Wrapped(in[i]);
        return out;
    }

    private static final class Wrapped implements Extractor {
        private final Extractor e;

        Wrapped(Extractor e) { this.e = e; }

        @Override public boolean sniff(ExtractorInput input) throws IOException { return e.sniff(input); }
        @Override public List<SniffFailure> getSniffFailureDetails() { return e.getSniffFailureDetails(); }
        @Override public int read(ExtractorInput input, PositionHolder seekPosition) throws IOException { return e.read(input, seekPosition); }
        @Override public void seek(long position, long timeUs) { e.seek(position, timeUs); }
        @Override public void release() { e.release(); }
        @Override public Extractor getUnderlyingImplementation() { return e.getUnderlyingImplementation(); }

        @Override
        public void init(final ExtractorOutput output) {
            e.init(new ExtractorOutput() {
                @Override public TrackOutput track(int id, int type) { return output.track(id, type); }
                @Override public void endTracks() { output.endTracks(); }

                @Override
                public void seekMap(final SeekMap map) {
                    if (map.isSeekable()) {
                        output.seekMap(map);
                        return;
                    }
                    output.seekMap(new SeekMap() {
                        @Override public boolean isSeekable() { return true; }
                        @Override public long getDurationUs() { return map.getDurationUs(); }
                        @Override public boolean isEstimated() { return false; }

                        @Override
                        public SeekPoints getSeekPoints(long timeUs) {
                            // only used for jumps inside the buffer; never moves the requested time
                            return new SeekPoints(new SeekPoint(timeUs, 0));
                        }
                    });
                }
            });
        }
    }

    static long unset() { return C.TIME_UNSET; }
}
