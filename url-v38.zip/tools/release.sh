#!/usr/bin/env bash
# Publishes this build for the in-app "Check for updates" button.
# Tag prefix "justplayer-url-b" keeps it apart from other apps built in this repository,
# and it is never marked as the repository's "latest" release.
set -eu
TAG="justplayer-url-b${GITHUB_RUN_NUMBER}"
VER=$(grep -o 'url-v[0-9]*' app/build.gradle | head -1)
gh release create "$TAG" out/JustPlayer-URL-Tablet.apk out/JustPlayer-URL-TV.apk \
  --repo "$GITHUB_REPOSITORY" --target "$GITHUB_SHA" --latest=false \
  --title "Just Player URL $VER (build $GITHUB_RUN_NUMBER)" \
  --notes "Just Player URL $VER, build $GITHUB_RUN_NUMBER. Installed from the app: Settings > Check for updates."
# keep only the 3 newest Just Player URL releases
OLD=$(gh release list --repo "$GITHUB_REPOSITORY" --limit 200 --json tagName --jq '.[].tagName' \
      | grep '^justplayer-url-b[0-9]*$' | sed 's/^justplayer-url-b//' | sort -n | head -n -3 || true)
for n in $OLD; do
  gh release delete "justplayer-url-b$n" --repo "$GITHUB_REPOSITORY" --cleanup-tag -y || true
done
