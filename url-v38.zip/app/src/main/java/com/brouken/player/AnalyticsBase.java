package com.brouken.player;

/** AnalyticsListener with all-default methods; subclasses override what they need. */
public class AnalyticsBase implements androidx.media3.exoplayer.analytics.AnalyticsListener {
}
