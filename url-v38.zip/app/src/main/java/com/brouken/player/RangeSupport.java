package com.brouken.player;

import android.net.Uri;

import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Servers that ignore "Range" (answer 200 with the whole file instead of 206 with the requested part).
 *
 * ExoPlayer normally jumps to an MKV's index (Cues, at the end of the file) before playing. On such a
 * server that jump turns into "download the whole file from the start", so the video never begins even
 * though data keeps arriving. mpv/FFmpeg instead notice the server can't seek and simply play from the
 * start. Here: the first time a jump is refused we mark the link "linear" and reopen it with the index
 * lookup turned off, so it plays straight away like in mpv (seeking stays limited, as in mpv).
 */
public final class RangeSupport {

    private RangeSupport() {}

    private static final Set<String> LINEAR = Collections.synchronizedSet(new HashSet<String>());

    static String key(Uri uri) {
        return uri == null ? "" : uri.toString();
    }

    public static boolean isLinear(Uri uri) {
        return uri != null && LINEAR.contains(key(uri));
    }

    static void markLinear(Uri uri) {
        if (uri != null && LINEAR.add(key(uri))) {
            Diag.log("Server ignores Range (no seeking) → playing from the start, like mpv");
        }
    }

    /** The server answered a jump with the whole file. */
    public static final class RangeIgnoredException extends IOException {
        public final boolean firstTime;

        RangeIgnoredException(String message, boolean firstTime) {
            super(message);
            this.firstTime = firstTime;
        }
    }

    static RangeIgnoredException find(Throwable t) {
        for (int i = 0; t != null && i < 10; i++, t = t.getCause()) {
            if (t instanceof RangeIgnoredException) return (RangeIgnoredException) t;
        }
        return null;
    }
}
