package com.brouken.player;

/** Shows volume and brightness as 0-100 instead of raw device steps (e.g. 0-30). */
public final class Pct {
    static int volMax = 15;

    private Pct() {}

    public static void setVolMax(int max) {
        if (max > 0) volMax = max;
    }

    public static int vol(int value) {
        return Math.round(value * 100f / volMax);
    }

    /** Boost display: raw value is max + boostLevel (0-10) → 100% + 10% per level. */
    public static int volBoost(int raw) {
        return 100 + Math.max(0, raw - volMax) * 10;
    }
}
