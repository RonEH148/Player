package com.brouken.player;

import android.content.Context;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.net.Uri;
import android.os.Build;
import android.view.Display;

import androidx.media3.common.Format;

import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Behaviour for weak TV hardware (Philips 43PQT8100: 4× Cortex-A53/A55-class CPU, Mali-G52 MC1,
 * 2 GB RAM, hardware 4K60 HEVC/VP9/AV1/H.264 + Dolby Vision decoders, USB 2.0).
 *
 *  - software (FFmpeg) decoding only up to 1080p: 4K in software would just stutter and heat the TV
 *  - when a hardware decode fails, first retry without tunneling (MediaTek TVs are picky with it),
 *    only then try software
 *  - a device report in the overlay showing what this TV really has
 */
public final class TvTune {
    private TvTune() {}

    private static final Set<String> NO_TUNNEL = Collections.synchronizedSet(new HashSet<String>());

    public static boolean weak(Context c) {
        return Utils.isTvBox(c) || Perf.lowEnd();
    }

    /** Can this CPU decode the video in software at full speed? */
    static boolean softwareOk(Context c, Format f) {
        if (f == null || !weak(c)) return true;
        int h = Math.min(f.width, f.height) > 0 ? Math.min(f.width, f.height) : f.height;
        float fps = f.frameRate > 0 ? f.frameRate : 24f;
        return h <= 1088 && fps <= 31f;
    }

    public static boolean tunnelingAllowed(Uri uri) {
        return uri == null || !NO_TUNNEL.contains(uri.toString());
    }

    /** Hardware failed: if tunneling was on, try again without it before giving up on hardware. */
    static boolean retryWithoutTunneling(PlayerActivity a) {
        try {
            if (a.mPrefs == null || !a.mPrefs.tunneling || a.mPrefs.mediaUri == null) return false;
            if (!NO_TUNNEL.add(a.mPrefs.mediaUri.toString())) return false;   // already tried
        } catch (Throwable t) {
            return false;
        }
        Diag.log("Hardware stuck with tunneling → retrying without tunneling");
        Lifecycle.refresh(a);
        return true;
    }

    // ------------------------------------------------------------------ device report

    private static volatile String report;

    /** A few lines about this device for the overlay (computed once, in the background). */
    static String report(final Context c) {
        if (report != null) return report;
        report = "Device: checking…";
        new Thread(new Runnable() {
            @Override
            public void run() {
                report = build(c.getApplicationContext());
            }
        }, "device-report").start();
        return report;
    }

    private static String build(Context c) {
        StringBuilder sb = new StringBuilder();
        sb.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL);
        if (Build.VERSION.SDK_INT >= 31) sb.append(" · ").append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL);
        else sb.append(" · ").append(Build.HARDWARE);
        sb.append(" · Android ").append(Build.VERSION.RELEASE).append('\n');
        sb.append("     ").append(Runtime.getRuntime().availableProcessors()).append(" cores · ")
                .append(Build.SUPPORTED_64_BIT_ABIS.length > 0 ? "64-bit" : "32-bit").append(" · ")
                .append(Perf.describe()).append('\n');
        try {
            Display d = ((android.hardware.display.DisplayManager) c.getSystemService(Context.DISPLAY_SERVICE)).getDisplay(Display.DEFAULT_DISPLAY);
            if (Build.VERSION.SDK_INT >= 23 && d != null) {
                Set<String> rates = new java.util.TreeSet<>();
                Display.Mode cur = d.getMode();
                for (Display.Mode m : d.getSupportedModes()) {
                    if (m.getPhysicalWidth() == cur.getPhysicalWidth())
                        rates.add(String.format(Locale.US, "%.3f", m.getRefreshRate()).replaceAll("\\.?0+$", ""));
                }
                sb.append("     screen ").append(cur.getPhysicalWidth()).append('x').append(cur.getPhysicalHeight())
                        .append(" · modes ").append(rates).append(" Hz");
                Display.HdrCapabilities hc = d.getHdrCapabilities();
                if (hc != null) {
                    sb.append(" · HDR");
                    for (int t : hc.getSupportedHdrTypes()) {
                        sb.append(' ').append(t == 1 ? "DV" : t == 2 ? "HDR10" : t == 3 ? "HLG" : t == 4 ? "HDR10+" : String.valueOf(t));
                    }
                }
                sb.append('\n');
            }
        } catch (Throwable ignored) { }
        try {
            String[][] kinds = {{"video/hevc", "HEVC"}, {"video/dolby-vision", "DV"}, {"video/av01", "AV1"},
                    {"video/x-vnd.on2.vp9", "VP9"}, {"video/avc", "AVC"}, {"video/wvc1", "VC-1"}, {"video/mpeg2", "MPEG-2"}};
            sb.append("     HW decoders:");
            MediaCodecInfo[] all = new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos();
            for (String[] k : kinds) {
                boolean hw = false;
                for (MediaCodecInfo ci : all) {
                    if (ci.isEncoder()) continue;
                    String n = ci.getName().toLowerCase(Locale.US);
                    boolean sw = n.startsWith("omx.google.") || n.startsWith("c2.android.") || n.contains(".sw.");
                    if (Build.VERSION.SDK_INT >= 29) sw = ci.isSoftwareOnly();
                    if (sw) continue;
                    for (String t : ci.getSupportedTypes()) if (t.equalsIgnoreCase(k[0])) hw = true;
                }
                sb.append(' ').append(k[1]).append(hw ? "✓" : "✗");
            }
        } catch (Throwable ignored) { }
        return sb.toString();
    }
}
