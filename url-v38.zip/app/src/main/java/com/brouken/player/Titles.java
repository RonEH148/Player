package com.brouken.player;

import android.net.Uri;

import java.net.URLDecoder;
import java.util.Locale;

/** File name helpers for the link check. (The player no longer sets video titles itself.) */
public final class Titles {

    private Titles() {}

    public static String fromContentDisposition(String cd) {
        if (cd == null) return null;
        try {
            String lower = cd.toLowerCase(Locale.US);
            int i = lower.indexOf("filename*=");
            if (i >= 0) {
                String v = cd.substring(i + 10).split(";")[0].trim();
                int q = v.indexOf("''");
                if (q >= 0) v = v.substring(q + 2);
                return URLDecoder.decode(strip(v), "UTF-8");
            }
            i = lower.indexOf("filename=");
            if (i >= 0) return strip(cd.substring(i + 9).split(";")[0].trim());
        } catch (Exception ignored) { }
        return null;
    }

    static String fromUrl(Uri uri) {
        String last = uri.getLastPathSegment();
        if (last == null) return null;
        int dot = last.lastIndexOf('.');
        if (dot <= 0 || last.length() - dot > 5) return null;
        return last;
    }

    private static String strip(String v) {
        if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
        return v;
    }
}
