package com.brouken.player;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * HTTP headers handed over by the app that opened the link (e.g. the Lumen browser's video grabber).
 *
 * Anime/streaming sites check where a request comes from: without the page's Referer/Origin, cookies
 * and a browser User-Agent their .m3u8/.mpd and segment URLs answer "403 Forbidden". The browser
 * passes them along and they are sent with every request for that video (playlist, keys, segments).
 *
 * Accepted intent extras (all optional, use any):
 *   "headers"                       String[] {"Referer", "https://site/", "Cookie", "a=b", …}  (MX Player style)
 *   "com.android.browser.headers"   Bundle of name → value  (Android Browser.EXTRA_HEADERS)
 *   "User-Agent", "Referer", "Origin", "Cookie"   single String extras
 */
public final class StreamHeaders {

    private StreamHeaders() {}

    private static String forUri;
    private static final Map<String, String> HEADERS = new HashMap<>();

    public static synchronized void fromIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Map<String, String> h = new HashMap<>();
        Bundle b = intent.getExtras();
        if (b != null) {
            try {
                String[] arr = b.getStringArray("headers");
                if (arr != null) for (int i = 0; i + 1 < arr.length; i += 2) put(h, arr[i], arr[i + 1]);
            } catch (Throwable ignored) { }
            try {
                Bundle hb = b.getBundle("com.android.browser.headers");
                if (hb != null) for (String k : hb.keySet()) put(h, k, String.valueOf(hb.get(k)));
            } catch (Throwable ignored) { }
            for (String k : new String[]{"User-Agent", "user-agent", "Referer", "referer", "Origin", "origin", "Cookie", "cookie"}) {
                String v = b.getString(k);
                if (v != null) put(h, k, v);
            }
        }
        forUri = intent.getData().toString();
        HEADERS.clear();
        HEADERS.putAll(h);
        if (!h.isEmpty()) Diag.log("Headers from the browser: " + h.keySet());
    }

    private static void put(Map<String, String> h, String k, String v) {
        if (k == null || v == null || k.trim().isEmpty()) return;
        String key = k.trim();
        // normalise the common ones
        String l = key.toLowerCase(Locale.US);
        if (l.equals("user-agent")) key = "User-Agent";
        else if (l.equals("referer") || l.equals("referrer")) key = "Referer";
        else if (l.equals("origin")) key = "Origin";
        else if (l.equals("cookie")) key = "Cookie";
        h.put(key, v.trim());
    }

    /** Headers for this video (empty for any other link). */
    public static synchronized Map<String, String> forMedia(Uri uri) {
        if (uri == null || forUri == null || !forUri.equals(uri.toString())) return new HashMap<>();
        return new HashMap<>(HEADERS);
    }

    public static synchronized void clear() {
        forUri = null;
        HEADERS.clear();
    }

    /** HLS / DASH: the player streams small segments itself, so no read-ahead cache. */
    public static boolean isAdaptive(Uri uri, String mimeType) {
        String m = mimeType == null ? "" : mimeType.toLowerCase(Locale.US);
        if (m.contains("mpegurl") || m.contains("dash")) return true;
        String p = uri == null || uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.US);
        return p.endsWith(".m3u8") || p.endsWith(".m3u") || p.endsWith(".mpd");
    }
}
