package com.brouken.player;

/** Player.Listener with all-default methods; subclasses override what they need. */
public class ListenerBase implements androidx.media3.common.Player.Listener {
}
