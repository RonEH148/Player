package com.brouken.player;

/** A short message in the middle of the picture (aspect ratio names, telecine status). */
final class CenterText {

    private CenterText() {}

    static void show(PlayerActivity a, String text) {
        show(a, text, 2000);
    }

    static void show(PlayerActivity a, String text, long ms) {
        try {
            if (a != null && a.playerView != null) Utils.showText(a.playerView, text, ms);
        } catch (Throwable ignored) { }
    }
}
