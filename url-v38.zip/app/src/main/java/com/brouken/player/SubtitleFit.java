package com.brouken.player;

import android.view.View;
import android.view.ViewGroup;

import androidx.media3.ui.SubtitleView;

/**
 * The subtitle layer sits inside the video frame, so subtitles are placed and sized relative to
 * the picture exactly as authored. When the picture is bigger than the screen (Crop), the layer
 * is limited to the visible part so nothing ends up off screen.
 */
final class SubtitleFit {

    private SubtitleFit() {}

    private static PlayerActivity activity;
    private static SubtitleView view;

    private static final View.OnLayoutChangeListener LAYOUT = new View.OnLayoutChangeListener() {
        @Override
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            if (l != ol || t != ot || r != or || b != ob) v.post(SubtitleFit::update);
        }
    };

    static void attach(PlayerActivity a) {
        try {
            if (a.playerView == null) return;
            SubtitleView sv = a.playerView.getSubtitleView();
            if (sv == null) return;
            if (sv == view && activity == a) { update(); return; }
            activity = a;
            view = sv;
            ((View) sv.getParent()).addOnLayoutChangeListener(LAYOUT);
            a.playerView.addOnLayoutChangeListener(LAYOUT);
            update();
        } catch (Throwable t) {
            Diag.log("Subtitles: " + t);
        }
    }

    static void update() {
        SubtitleView sv = view;
        PlayerActivity a = activity;
        if (sv == null || a == null || a.playerView == null) return;
        try {
            View frame = (View) sv.getParent();
            int[] f = new int[2];
            int[] p = new int[2];
            frame.getLocationInWindow(f);
            a.playerView.getLocationInWindow(p);
            int left = Math.max(0, p[0] - f[0]);
            int top = Math.max(0, p[1] - f[1]);
            int right = Math.max(0, (f[0] + frame.getWidth()) - (p[0] + a.playerView.getWidth()));
            int bottom = Math.max(0, (f[1] + frame.getHeight()) - (p[1] + a.playerView.getHeight()));
            ViewGroup.LayoutParams lp = sv.getLayoutParams();
            if (lp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
                if (m.leftMargin != left || m.topMargin != top || m.rightMargin != right || m.bottomMargin != bottom) {
                    m.setMargins(left, top, right, bottom);
                    sv.setLayoutParams(m);
                }
            }
        } catch (Throwable ignored) { }
    }
}
