package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.PlaybackException;
import androidx.media3.datasource.BaseDataSource;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HTTP access the way mpv/FFmpeg do it:
 *  - every redirect is followed, including http <-> https (up to 20)
 *  - no compression, one plain connection per read position
 *  - checks the answer to a jump: if the server ignores Range (200 instead of 206) it does NOT
 *    silently download everything up to that point (ExoPlayer's behaviour, which looks like
 *    "endless loading"); the link is switched to linear playback instead (see RangeSupport).
 */
public final class MpvHttpDataSource extends BaseDataSource {

    /** In linear mode a jump is done by reading forward, but only this far (mpv-like stream skip). */
    private static final long MAX_SKIP = 512L * 1024 * 1024;

    public static final class Factory implements DataSource.Factory {
        private final String userAgent;
        private final Map<String, String> headers;
        private final int timeoutMs;
        private final TransferListener listener;

        public Factory(String userAgent, Map<String, String> headers, int timeoutMs, TransferListener listener) {
            this.userAgent = userAgent;
            this.headers = headers;
            this.timeoutMs = timeoutMs;
            this.listener = listener;
        }

        @Override
        public DataSource createDataSource() {
            MpvHttpDataSource ds = new MpvHttpDataSource(userAgent, headers, timeoutMs);
            if (listener != null) ds.addTransferListener(listener);
            return ds;
        }
    }

    private final String userAgent;
    private final Map<String, String> headers;
    private final int timeoutMs;

    private DataSpec dataSpec;
    private HttpURLConnection connection;
    private InputStream input;
    private Uri finalUri;
    private long bytesRemaining;
    private boolean opened;
    private int responseCode;

    MpvHttpDataSource(String userAgent, Map<String, String> headers, int timeoutMs) {
        super(/* isNetwork= */ true);
        this.userAgent = userAgent;
        this.headers = headers;
        this.timeoutMs = timeoutMs;
    }

    @Override
    public long open(DataSpec spec) throws IOException {
        dataSpec = spec;
        transferInitializing(spec);
        HttpURLConnection conn = connect(spec);
        connection = conn;
        responseCode = conn.getResponseCode();

        if (responseCode < 200 || responseCode > 299) {
            Map<String, List<String>> fields = conn.getHeaderFields();
            String msg = conn.getResponseMessage();
            closeConnection();
            throw new HttpDataSource.InvalidResponseCodeException(responseCode, msg, null, fields, spec, new byte[0]);
        }

        long skip = 0;
        if (responseCode == 200 && spec.position > 0 && spec.length != C.LENGTH_UNSET) {
            // a bounded request (HLS/DASH byte range): just read forward to the wanted part
            if (spec.position > MAX_SKIP) {
                closeConnection();
                throw new IOException("Server ignored the byte range");
            }
            skip = spec.position;
        } else if (responseCode == 200 && spec.position > 0) {
            // The server ignored our Range header and sends the file from byte 0.
            if (!RangeSupport.isLinear(spec.uri)) {
                RangeSupport.markLinear(spec.uri);
                closeConnection();
                throw new RangeSupport.RangeIgnoredException("Server ignores Range requests", true);
            }
            if (spec.position > MAX_SKIP) {
                closeConnection();
                throw new RangeSupport.RangeIgnoredException("Server can't jump to " + (spec.position >> 20) + " MB", false);
            }
            skip = spec.position;   // linear mode, short distance: read forward like mpv does
        }

        long contentLength = parseLength(conn);
        if (spec.length != C.LENGTH_UNSET) {
            bytesRemaining = spec.length;
        } else if (contentLength != C.LENGTH_UNSET) {
            bytesRemaining = responseCode == 200 ? contentLength - spec.position : contentLength;
        } else {
            bytesRemaining = C.LENGTH_UNSET;
        }

        try {
            input = conn.getInputStream();
            if (skip > 0) skipFully(skip);
        } catch (IOException e) {
            closeConnection();
            throw new HttpDataSource.HttpDataSourceException(e, spec,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, HttpDataSource.HttpDataSourceException.TYPE_OPEN);
        }
        opened = true;
        transferStarted(spec);
        return bytesRemaining;
    }

    private HttpURLConnection connect(DataSpec spec) throws IOException {
        URL url = new URL(spec.uri.toString());
        for (int redirects = 0; redirects <= 20; redirects++) {
            HttpURLConnection c;
            try {
                c = (HttpURLConnection) url.openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs);
                c.setReadTimeout(timeoutMs);
                c.setRequestProperty("User-Agent", userAgent);
                c.setRequestProperty("Accept-Encoding", "identity");
                c.setRequestProperty("Accept", "*/*");
                for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
                for (Map.Entry<String, String> h : spec.httpRequestHeaders.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
                if (spec.position != 0 || spec.length != C.LENGTH_UNSET) {
                    String range = "bytes=" + spec.position + "-";
                    if (spec.length != C.LENGTH_UNSET) range += (spec.position + spec.length - 1);
                    c.setRequestProperty("Range", range);
                }
                c.connect();
                int code = c.getResponseCode();
                if (code == 300 || code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) throw new IOException("Redirect without Location");
                    url = new URL(url, loc);
                    String p = url.getProtocol();
                    if (!"http".equals(p) && !"https".equals(p)) throw new IOException("Unsupported redirect to " + p);
                    continue;
                }
                finalUri = Uri.parse(url.toString());
                return c;
            } catch (IOException e) {
                if (e instanceof InterruptedIOException) throw e;
                throw new HttpDataSource.HttpDataSourceException(e, spec,
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, HttpDataSource.HttpDataSourceException.TYPE_OPEN);
            }
        }
        throw new HttpDataSource.HttpDataSourceException("Too many redirects", spec,
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, HttpDataSource.HttpDataSourceException.TYPE_OPEN);
    }

    private static long parseLength(HttpURLConnection c) {
        String cr = c.getHeaderField("Content-Range");   // bytes 100-199/1000
        if (cr != null) {
            try {
                int dash = cr.indexOf('-'), slash = cr.indexOf('/');
                int sp = cr.indexOf(' ');
                if (dash > 0 && slash > dash) {
                    long first = Long.parseLong(cr.substring(sp + 1, dash).trim());
                    long last = Long.parseLong(cr.substring(dash + 1, slash).trim());
                    return last - first + 1;
                }
            } catch (Exception ignored) { }
        }
        String cl = c.getHeaderField("Content-Length");
        if (cl != null) {
            try { return Long.parseLong(cl.trim()); } catch (Exception ignored) { }
        }
        return C.LENGTH_UNSET;
    }

    private void skipFully(long n) throws IOException {
        byte[] buf = new byte[64 * 1024];
        long done = 0;
        long nextLog = 32L << 20;
        while (done < n) {
            int r = input.read(buf, 0, (int) Math.min(buf.length, n - done));
            if (r < 0) throw new IOException("End of stream while skipping");
            done += r;
            if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException();
            if (done >= nextLog) {
                Diag.log("Linear stream: reading forward " + (done >> 20) + "/" + (n >> 20) + " MB");
                nextLog += 32L << 20;
            }
        }
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (bytesRemaining == 0) return C.RESULT_END_OF_INPUT;
        int want = bytesRemaining == C.LENGTH_UNSET ? length : (int) Math.min(length, bytesRemaining);
        int n;
        try {
            n = input.read(buffer, offset, want);
        } catch (IOException e) {
            throw new HttpDataSource.HttpDataSourceException(e, dataSpec,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, HttpDataSource.HttpDataSourceException.TYPE_READ);
        }
        if (n == -1) {
            if (bytesRemaining != C.LENGTH_UNSET && bytesRemaining > 0) {
                // connection ended early: let ExoPlayer reconnect from here (mpv's reconnect)
                throw new HttpDataSource.HttpDataSourceException(new IOException("Connection closed early"), dataSpec,
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, HttpDataSource.HttpDataSourceException.TYPE_READ);
            }
            return C.RESULT_END_OF_INPUT;
        }
        if (bytesRemaining != C.LENGTH_UNSET) bytesRemaining -= n;
        bytesTransferred(n);
        return n;
    }

    @Override
    public Uri getUri() {
        return finalUri != null ? finalUri : (dataSpec != null ? dataSpec.uri : null);
    }

    @Override
    public Map<String, List<String>> getResponseHeaders() {
        HttpURLConnection c = connection;
        if (c == null) return Collections.emptyMap();
        Map<String, List<String>> out = new HashMap<>();
        for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
            if (e.getKey() != null) out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    public int getResponseCode() {
        return responseCode;
    }

    @Override
    public void close() throws IOException {
        try {
            closeConnection();
        } finally {
            if (opened) {
                opened = false;
                transferEnded();
            }
            dataSpec = null;
        }
    }

    private void closeConnection() {
        // disconnect first: closing an unfinished stream would otherwise try to read the rest of the file
        if (connection != null) {
            try { connection.disconnect(); } catch (Throwable ignored) { }
            connection = null;
        }
        try { if (input != null) input.close(); } catch (Throwable ignored) { }
        input = null;
    }
}
