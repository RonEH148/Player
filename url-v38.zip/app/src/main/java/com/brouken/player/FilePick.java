package com.brouken.player;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

/**
 * Picking local files when there is no system "Files" app (Android TV / Google TV):
 * hand the request to an installed file manager such as AnExplorer, which can browse USB drives.
 */
public final class FilePick {

    private FilePick() {}

    private static Intent getContent(String type, String[] mimeTypes) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type != null ? type : "*/*");
        if (mimeTypes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        return i;
    }

    public static boolean hasFileManager(Context c) {
        return !c.getPackageManager().queryIntentActivities(getContent("video/*", null), 0).isEmpty();
    }

    public static void pickVideo(Activity a, int requestCode) {
        Intent i = getContent("video/*", null);
        a.startActivityForResult(Intent.createChooser(i, "Open video with"), requestCode);
    }

    /** The system picker is missing: try the same request with a file manager. */
    public static boolean fallback(Activity a, Intent original, int requestCode) {
        if (!Intent.ACTION_OPEN_DOCUMENT.equals(original.getAction())) return false;
        Intent i = getContent(original.getType(), original.getStringArrayExtra(Intent.EXTRA_MIME_TYPES));
        if (a.getPackageManager().queryIntentActivities(i, 0).isEmpty()) {
            i = getContent("*/*", null);   // some file managers only answer "any file"
            if (a.getPackageManager().queryIntentActivities(i, 0).isEmpty()) return false;
        }
        a.startActivityForResult(Intent.createChooser(i, "Open with"), requestCode);
        return true;
    }
}
