package com.brouken.player;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;

/**
 * When a video starts: its HDR format (Dolby Vision, HDR10+, HDR10, HLG) appears for a few
 * seconds in the top right corner, the way it is really played (Dolby Vision that plays as its
 * HDR10 base layer shows HDR10). Nothing for SDR.
 */
final class FormatBadge {

    private FormatBadge() {}

    private static TextView view;
    private static String shownFor;
    private static volatile boolean decoderHdr10Plus;

    /** From the video renderer: the decoder reports HDR10+ metadata in the stream. */
    static void onOutputFormat(MediaFormat mf) {
        try {
            if (mf != null && mf.containsKey("hdr10-plus-info")) decoderHdr10Plus = true;
        } catch (Throwable ignored) { }
    }

    /** Player (re)built: the decoder reports HDR10+ again. */
    static void newMedia() {
        decoderHdr10Plus = false;
    }

    /** Video closed: the next one (even the same link again) shows its badge. */
    static void reset() {
        shownFor = null;
        decoderHdr10Plus = false;
        if (view != null) {
            view.animate().cancel();
            view.setVisibility(View.GONE);
        }
    }

    /** First frame on screen. */
    static void show(Activity a) {
        if (!(a instanceof PlayerActivity) || PlayerActivity.player == null) return;
        PlayerActivity pa = (PlayerActivity) a;
        String uri = pa.mPrefs != null && pa.mPrefs.mediaUri != null ? pa.mPrefs.mediaUri.toString() : null;
        if (uri == null || uri.equals(shownFor)) return;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 24 && a.isInPictureInPictureMode()) return;
        } catch (Throwable ignored) { }
        String label = label(PlayerActivity.player.getVideoFormat(), Diag.videoDecoderName());
        shownFor = uri;
        if (label == null) return;
        try {
            TextView v = view(a);
            v.setText(label);
            v.animate().cancel();
            v.setAlpha(0f);
            v.setVisibility(View.VISIBLE);
            v.animate().alpha(1f).setDuration(250).withEndAction(() ->
                    v.animate().alpha(0f).setStartDelay(3000).setDuration(450)
                            .withEndAction(() -> v.setVisibility(View.GONE)).start()).start();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    static String label(Format f, String decoder) {
        if (f == null) return null;
        String d = decoder == null ? "" : decoder.toLowerCase(java.util.Locale.US);
        boolean dvDecoder = d.contains("dolby") || d.contains("dvhe") || d.contains("dvav") || d.contains(".dv.");
        int transfer = f.colorInfo != null ? f.colorInfo.colorTransfer : Format.NO_VALUE;
        if (MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType)) {
            if (dvDecoder) return "DOLBY VISION";
            if (transfer == C.COLOR_TRANSFER_HLG) return "HLG";
            if (transfer == C.COLOR_TRANSFER_SDR) return null;
            return decoderHdr10Plus ? "HDR10+" : "HDR10";   // Dolby Vision without a DV decoder: its HDR10 base
        }
        if (transfer == C.COLOR_TRANSFER_ST2084) return decoderHdr10Plus ? "HDR10+" : "HDR10";
        if (transfer == C.COLOR_TRANSFER_HLG) return "HLG";
        return null;
    }

    private static TextView view(Activity a) {
        if (view != null && view.getContext() == a) return view;
        float dp = a.getResources().getDisplayMetrics().density;
        TextView t = new TextView(a);
        t.setTextColor(0xFFFFFFFF);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setLetterSpacing(0.12f);
        t.setIncludeFontPadding(false);
        t.setShadowLayer(4 * dp, 0, 0, 0x80000000);
        int ph = (int) (12 * dp), pv = (int) (7 * dp);
        t.setPadding(ph, pv, ph, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x8C000000);
        bg.setCornerRadius(6 * dp);
        bg.setStroke(Math.max(1, (int) (1.5f * dp)), 0xCCFFFFFF);
        t.setBackground(bg);
        t.setVisibility(View.GONE);
        t.setClickable(false);
        t.setFocusable(false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        lp.topMargin = (int) (24 * dp);
        lp.rightMargin = (int) (28 * dp);
        a.addContentView(t, lp);
        view = t;
        return t;
    }
}
