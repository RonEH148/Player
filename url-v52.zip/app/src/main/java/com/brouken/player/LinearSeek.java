package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.ForwardingPlayer;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorInput;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ExtractorsFactory;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekPoint;
import androidx.media3.extractor.SniffFailure;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.extractor.text.SubtitleParser;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Seeking on servers that can't seek ("linear" links, see RangeSupport), like mpv does it:
 * jumps are allowed only inside what is already downloaded, in 5-second steps, at most half of the
 * buffer ahead (30 s buffered → up to 15 s forward) and a few seconds back. Nothing is reloaded and
 * audio stays in sync because the player just moves within its own buffer.
 *
 * ExoPlayer normally refuses any seek on such a file and restarts it from 0:00; the wrapped
 * extractor reports the file as seekable so in-buffer jumps work, and SeekGuard keeps every jump
 * inside the buffer so a reload from the start never happens.
 */
public final class LinearSeek {

    private LinearSeek() {}

    static final int STEP_MS = 5_000;

    static int backBufferMs() {
        return Perf.lowEnd() ? 5_000 : 15_000;
    }

    static boolean active() {
        try {
            ExoPlayer p = PlayerActivity.player;
            if (p == null || p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return false;
            return RangeSupport.isLinear(p.getCurrentMediaItem().localConfiguration.uri);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Seek step for remote / D-pad: 5 s on linear links, Just Player's 10 s otherwise. */
    public static long step() {
        return active() ? STEP_MS : 10_000;
    }

    /** Where a seek to {@code target} may go. Normal links: anywhere. */
    public static long clamp(Player p, long target) {
        if (p == null || !active()) return target;
        long cur = p.getCurrentPosition();
        long buffered = p.getBufferedPosition();
        long maxForward = cur + Math.max(0, (buffered - cur) / 2);
        long minBack = Math.max(0, cur - backBufferMs() + 500);
        long delta = target - cur;
        long steps = Math.round(delta / (double) STEP_MS);
        long t = cur + steps * STEP_MS;
        if (t > maxForward) t = cur + ((maxForward - cur) / STEP_MS) * STEP_MS;
        if (t < minBack) t = cur - ((cur - minBack) / STEP_MS) * STEP_MS;
        if (t != target) Diag.log("Linear seek: " + (target - cur) / 1000 + " s → " + (t - cur) / 1000 + " s (inside buffer)");
        return Math.max(0, t);
    }

    /** All seeks from Just Player's own gestures and keys go through here. */
    public static void seekTo(ExoPlayer p, long target) {
        if (p == null) return;
        long t = clamp(p, target);
        if (active() && t == p.getCurrentPosition()) return;   // nothing buffered that far
        p.seekTo(t);
    }

    /** The player handed to the on-screen controls (time bar), so its seeks are guarded too. */
    public static Player wrap(ExoPlayer p) {
        return new ForwardingPlayer(p) {
            @Override
            public void seekTo(long positionMs) {
                long t = clamp(getWrappedPlayer(), positionMs);
                if (active() && t == getWrappedPlayer().getCurrentPosition()) return;
                super.seekTo(t);
            }

            @Override
            public void seekTo(int mediaItemIndex, long positionMs) {
                long t = clamp(getWrappedPlayer(), positionMs);
                if (active() && t == getWrappedPlayer().getCurrentPosition()) return;
                super.seekTo(mediaItemIndex, t);
            }
        };
    }

    // ------------------------------------------------------------------ extractor side

    /** Wraps the extractors of a linear link so the file counts as seekable (inside the buffer). */
    public static ExtractorsFactory factory(final ExtractorsFactory base) {
        return factory(base, true, false);
    }

    /**
     * @param linear  server can't seek: report the file as seekable for in-buffer jumps
     * @param dv7     "Dolby Vision profile 7 fallback": present DV profile 7/4 video as plain HEVC
     *                (its HDR10 base layer), so it goes to the normal HEVC hardware decoder
     */
    public static ExtractorsFactory factory(final ExtractorsFactory base, final boolean linear, final boolean dv7) {
        final Object[] ass = AssSubs.current();   // this player's libass handler (not a later player's)
        return new ExtractorsFactory() {
            @Override
            public Extractor[] createExtractors() {
                return wrapAll(AssSubs.extractors(base.createExtractors(), linear, ass), linear, dv7);
            }

            @Override
            public Extractor[] createExtractors(Uri uri, Map<String, List<String>> responseHeaders) {
                return wrapAll(AssSubs.extractors(base.createExtractors(uri, responseHeaders), linear, ass), linear, dv7);
            }

            @Override
            public ExtractorsFactory experimentalSetTextTrackTranscodingEnabled(boolean enabled) {
                base.experimentalSetTextTrackTranscodingEnabled(enabled);
                return this;
            }

            @Override
            public ExtractorsFactory setSubtitleParserFactory(SubtitleParser.Factory f) {
                base.setSubtitleParserFactory(f);
                return this;
            }

            @Override
            public ExtractorsFactory experimentalSetCodecsToParseWithinGopSampleDependencies(int codecFlags) {
                base.experimentalSetCodecsToParseWithinGopSampleDependencies(codecFlags);
                return this;
            }

            @Override
            public ExtractorsFactory setParseHagcMetadata(boolean parse) {
                base.setParseHagcMetadata(parse);
                return this;
            }
        };
    }

    private static Extractor[] wrapAll(Extractor[] in, boolean linear, boolean dv7) {
        if (!linear && !dv7 && !Dovi78.enabled) return in;
        Extractor[] out = new Extractor[in.length];
        for (int i = 0; i < in.length; i++) out[i] = new Wrapped(in[i], linear, dv7);
        return out;
    }

    /** DV profile 7 (UHD Blu-ray dual layer) or 4: the base layer is ordinary HDR10 HEVC. */
    static boolean isDvBaseLayerHevc(androidx.media3.common.Format f) {
        if (f == null || !androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType) || f.codecs == null) return false;
        String c = f.codecs.toLowerCase(java.util.Locale.US);
        return c.startsWith("dvhe.07") || c.startsWith("dvh1.07") || c.startsWith("dvhe.04") || c.startsWith("dvh1.04");
    }

    private static final class Dv7Track implements TrackOutput {
        private final TrackOutput t;
        private final boolean mapDv7;
        /** "Dolby Vision profile 7 → profile 8": samples are collected and rewritten. */
        private boolean convert;
        private byte[] buf = new byte[1 << 20];
        private int bufLen;

        Dv7Track(TrackOutput t, boolean mapDv7) { this.t = t; this.mapDv7 = mapDv7; }

        @Override
        public void format(androidx.media3.common.Format format) {
            if (Dovi78.enabled && Dovi78.isProfile7(format.codecs)) {
                convert = true;
                Dovi78.resetCounters();
                String to = Dovi78.profile8Codecs(format.codecs);
                Diag.log("Dolby Vision " + format.codecs + " → " + to + " (profile 7 converted to profile 8.1)");
                format = format.buildUpon().setCodecs(to).build();
            } else if (mapDv7 && isDvBaseLayerHevc(format)) {
                convert = false;
                Diag.log("Dolby Vision " + format.codecs + " → HDR10 base layer (HEVC Main 10)");
                // the enhancement layer and RPU NAL units are simply ignored by the HEVC decoder
                format = format.buildUpon()
                        .setSampleMimeType(androidx.media3.common.MimeTypes.VIDEO_H265)
                        .setCodecs("hvc1.2.4.L153.B0")
                        .build();
            }
            t.format(format);
        }

        private void ensure(int more) {
            if (bufLen + more > buf.length) buf = java.util.Arrays.copyOf(buf, Math.max(buf.length * 2, bufLen + more));
        }

        /** Something other than plain sample data (e.g. supplemental data): stop converting, keep the order. */
        private void giveUp() {
            if (bufLen > 0) t.sampleData(new androidx.media3.common.util.ParsableByteArray(java.util.Arrays.copyOf(buf, bufLen)), bufLen);
            bufLen = 0;
            convert = false;
            Diag.log("DV7 → DV8: unusual stream layout, conversion stopped");
        }

        @Override public void durationUs(long durationUs) { t.durationUs(durationUs); }

        void clear() { bufLen = 0; }

        @Override
        public int sampleData(androidx.media3.common.DataReader input, int length, boolean allowEndOfInput) throws IOException {
            return sampleData(input, length, allowEndOfInput, SAMPLE_DATA_PART_MAIN);
        }

        @Override
        public int sampleData(androidx.media3.common.DataReader input, int length, boolean allowEndOfInput, int sampleDataPart) throws IOException {
            if (convert && sampleDataPart != SAMPLE_DATA_PART_MAIN) giveUp();
            if (!convert) return t.sampleData(input, length, allowEndOfInput, sampleDataPart);
            ensure(length);
            int r = input.read(buf, bufLen, length);
            if (r == C.RESULT_END_OF_INPUT) {
                if (allowEndOfInput) return C.RESULT_END_OF_INPUT;
                throw new java.io.EOFException();
            }
            bufLen += r;
            return r;
        }

        @Override
        public void sampleData(androidx.media3.common.util.ParsableByteArray data, int length) {
            sampleData(data, length, SAMPLE_DATA_PART_MAIN);
        }

        @Override
        public void sampleData(androidx.media3.common.util.ParsableByteArray data, int length, int sampleDataPart) {
            if (convert && sampleDataPart != SAMPLE_DATA_PART_MAIN) giveUp();
            if (!convert) {
                t.sampleData(data, length, sampleDataPart);
                return;
            }
            ensure(length);
            data.readBytes(buf, bufLen, length);
            bufLen += length;
        }

        @Override
        public void sampleMetadata(long timeUs, int flags, int size, int offset, CryptoData cryptoData) {
            if (!convert) {
                t.sampleMetadata(timeUs, flags, size, offset, cryptoData);
                return;
            }
            int end = bufLen - offset;
            int start = end - size;
            byte[] out = null;
            if (start >= 0 && cryptoData == null) {
                try {
                    out = Dovi78.convertAccessUnit(buf, start, size);
                } catch (Throwable e) {
                    out = null;
                }
            }
            if (out == null) out = java.util.Arrays.copyOfRange(buf, Math.max(0, start), end);
            t.sampleData(new androidx.media3.common.util.ParsableByteArray(out), out.length);
            t.sampleMetadata(timeUs, flags, out.length, 0, cryptoData);
            // bytes that already belong to the next sample stay
            System.arraycopy(buf, end, buf, 0, offset);
            bufLen = offset;
        }
    }

    private static final class Wrapped implements Extractor {
        private final Extractor e;
        private final boolean linear, dv7;

        Wrapped(Extractor e, boolean linear, boolean dv7) { this.e = e; this.linear = linear; this.dv7 = dv7; }

        @Override public boolean sniff(ExtractorInput input) throws IOException { return e.sniff(input); }
        @Override public List<SniffFailure> getSniffFailureDetails() { return e.getSniffFailureDetails(); }
        @Override public int read(ExtractorInput input, PositionHolder seekPosition) throws IOException { return e.read(input, seekPosition); }
        private final java.util.List<Dv7Track> dvTracks = new java.util.ArrayList<>();

        @Override public void seek(long position, long timeUs) {
            for (Dv7Track d : dvTracks) d.clear();   // half-collected samples belong to the old position
            e.seek(position, timeUs);
        }
        @Override public void release() { e.release(); }
        @Override public Extractor getUnderlyingImplementation() { return e.getUnderlyingImplementation(); }

        @Override
        public void init(final ExtractorOutput output) {
            e.init(new ExtractorOutput() {
                @Override public TrackOutput track(int id, int type) {
                    TrackOutput t = output.track(id, type);
                    if ((dv7 || Dovi78.enabled) && type == C.TRACK_TYPE_VIDEO) {
                        Dv7Track d = new Dv7Track(t, dv7);
                        dvTracks.add(d);
                        return d;
                    }
                    return t;
                }
                @Override public void endTracks() { output.endTracks(); }

                @Override
                public void seekMap(final SeekMap map) {
                    if (!linear || map.isSeekable()) {
                        output.seekMap(map);
                        return;
                    }
                    output.seekMap(new SeekMap() {
                        @Override public boolean isSeekable() { return true; }
                        @Override public long getDurationUs() { return map.getDurationUs(); }
                        @Override public boolean isEstimated() { return false; }

                        @Override
                        public SeekPoints getSeekPoints(long timeUs) {
                            // only used for jumps inside the buffer; never moves the requested time
                            return new SeekPoints(new SeekPoint(timeUs, 0));
                        }
                    });
                }
            });
        }
    }

    static long unset() { return C.TIME_UNSET; }
}
