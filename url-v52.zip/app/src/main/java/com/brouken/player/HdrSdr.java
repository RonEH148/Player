package com.brouken.player;

import android.content.Context;
import android.media.MediaFormat;
import android.os.Build;
import android.preference.PreferenceManager;

import androidx.media3.common.C;
import androidx.media3.common.Format;

/**
 * "Play HDR as SDR": for TVs whose HDR picture path adds motion smoothing/ghosting that can't be
 * switched off. The hardware decoder is asked to convert HDR10/HLG to SDR itself (Android 13+),
 * so the TV never enters its HDR mode. Only HDR10/HLG (and Dolby Vision profile 7, which plays
 * as HDR10 here); Dolby Vision profile 5/8 play as Dolby Vision, untouched.
 */
final class HdrSdr {

    private HdrSdr() {}

    static final String KEY = "hdrToSdr";

    /** Read at every player start. */
    static volatile boolean active;

    static void refresh(Context c) {
        try {
            active = Build.VERSION.SDK_INT >= 33
                    && PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY, false);
        } catch (Throwable t) {
            active = false;
        }
    }

    /** HDR10 / HLG only: Dolby Vision (profile 5/8) plays fine on the TV and is never touched. */
    static boolean isHdr(Format f) {
        return f != null && !androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType)
                && f.colorInfo != null && (f.colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084
                || f.colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG);
    }

    /** Added to the decoder's configuration. */
    static void request(MediaFormat mf, Format f) {
        if (!active || mf == null || !isHdr(f)) return;
        mf.setInteger("color-transfer-request", 3);   // MediaFormat.COLOR_TRANSFER_SDR_VIDEO
        Diag.log("HDR → SDR requested from the hardware decoder");
    }

    /** What the decoder actually delivers. */
    static void check(Format in, MediaFormat out) {
        if (!active || out == null || !isHdr(in)) return;
        int t = out.containsKey("color-transfer") ? out.getInteger("color-transfer") : -1;
        if (t == 3 || t == 1) {
            Diag.log("HDR → SDR: the decoder converts it, the TV gets SDR");
        } else {
            Diag.log("HDR → SDR: this decoder can't convert (output transfer " + t + "), still HDR"
                    + " – if \"Tunneled playback\" is on, try it off");
        }
    }
}
