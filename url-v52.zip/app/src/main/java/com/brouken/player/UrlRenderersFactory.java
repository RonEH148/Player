package com.brouken.player;

import android.content.Context;
import android.os.Handler;

import androidx.media3.common.Format;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil;
import androidx.media3.exoplayer.video.MediaCodecVideoRenderer;
import androidx.media3.exoplayer.video.VideoRendererEventListener;

import java.util.ArrayList;
import java.util.List;

import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegLibrary;
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegVideoRenderer;

/**
 * Video renderers for Just Player URL.
 *
 *  - Dolby Vision profile 7 (UHD Blu-ray) with "Dolby Vision profile 7 fallback" on: the TV's Dolby
 *    Vision decoder is never used (it can't do profile 7 and fails with "can't decode Dolby Vision");
 *    the HDR10 base layer goes straight to the HEVC hardware decoder. Profiles 5 and 8 keep real DV.
 *  - SW mode: FFmpeg software decoder first (VC-1, 10-bit AVC …).
 */
public final class UrlRenderersFactory extends DefaultRenderersFactory {

    private final int mode;
    private final boolean mapDV7;

    public UrlRenderersFactory(Context context, int mode, boolean mapDV7) {
        super(context);
        this.mode = mode;
        this.mapDV7 = mapDV7;
    }

    @Override
    protected void buildVideoRenderers(Context context, int extensionRendererMode,
                                       MediaCodecSelector mediaCodecSelector, boolean enableDecoderFallback,
                                       Handler eventHandler, VideoRendererEventListener eventListener,
                                       long allowedVideoJoiningTimeMs, ArrayList<Renderer> out) {
        super.buildVideoRenderers(context, extensionRendererMode, mediaCodecSelector, enableDecoderFallback,
                eventHandler, eventListener, allowedVideoJoiningTimeMs, out);

        // replace the standard MediaCodec video renderer with one that handles DV profile 7 properly
        for (int i = 0; i < out.size(); i++) {
            if (out.get(i).getClass() == MediaCodecVideoRenderer.class) {
                try {
                    MediaCodecVideoRenderer.Builder b = new MediaCodecVideoRenderer.Builder(context)
                            .setMediaCodecSelector(mediaCodecSelector)
                            .setAllowedJoiningTimeMs(allowedVideoJoiningTimeMs)
                            .setEnableDecoderFallback(enableDecoderFallback)
                            .setEventHandler(eventHandler)
                            .setEventListener(eventListener)
                            .setMaxDroppedFramesToNotify(MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY)
                            .setMapDV7ToHevc(mapDV7);
                    out.set(i, new Dv7SafeRenderer(b, mapDV7));
                } catch (Throwable t) {
                    Diag.log("Video renderer setup: " + t);
                }
                break;
            }
        }

        // Only in SW mode: hardware decoders often under-report what they can do (e.g. 4K HEVC),
        // so in HW+/HW FFmpeg would win and software-decode 4K.
        if (mode != Decoder.SW) return;
        try {
            Diag.log("FFmpeg video: " + (FfmpegLibrary.isAvailable()
                    ? "loaded " + FfmpegLibrary.getVersion()
                      + " (VC-1 " + yn(FfmpegLibrary.supportsFormat("video/wvc1"))
                      + ", AVC " + yn(FfmpegLibrary.supportsFormat("video/avc"))
                      + ", HEVC " + yn(FfmpegLibrary.supportsFormat("video/hevc")) + ")"
                    : "NOT loaded"));
            Renderer ffmpeg = new FfmpegVideoRenderer(allowedVideoJoiningTimeMs, eventHandler, eventListener,
                    MAX_DROPPED_VIDEO_FRAME_COUNT_TO_NOTIFY);
            out.add(0, ffmpeg);
        } catch (Throwable t) {
            Diag.log("FFmpeg video decoder unavailable: " + t);
        }
    }

    private static String yn(boolean b) { return b ? "yes" : "no"; }

    static boolean isDvProfile7(Format f) {
        if (f == null || f.codecs == null) return false;
        String c = f.codecs.toLowerCase(java.util.Locale.US);
        return c.startsWith("dvhe.07") || c.startsWith("dvh1.07") || c.startsWith("dvhe.04") || c.startsWith("dvh1.04");
    }

    static final class Dv7SafeRenderer extends MediaCodecVideoRenderer {
        private final boolean mapDV7;

        Dv7SafeRenderer(MediaCodecVideoRenderer.Builder b, boolean mapDV7) {
            super(b);
            this.mapDV7 = mapDV7;
        }

        @Override
        protected List<MediaCodecInfo> getDecoderInfos(MediaCodecSelector selector, Format format, boolean requiresSecureDecoder)
                throws MediaCodecUtil.DecoderQueryException {
            List<MediaCodecInfo> all = super.getDecoderInfos(selector, format, requiresSecureDecoder);
            if (!mapDV7 || !isDvProfile7(format)) return all;
            List<MediaCodecInfo> hevc = new ArrayList<>();
            for (MediaCodecInfo i : all) {
                if (!"video/dolby-vision".equals(i.mimeType)) hevc.add(i);
            }
            if (hevc.isEmpty()) return all;
            Diag.log("Dolby Vision profile 7 → HDR10 on " + hevc.get(0).name + " (TV's DV decoder can't do profile 7)");
            return hevc;
        }

        @Override
        protected android.media.MediaFormat getMediaFormat(Format format, String codecMimeType, CodecMaxValues codecMaxValues,
                                                           float codecOperatingRate, boolean deviceNeedsNoPostProcessWorkaround,
                                                           int tunnelingAudioSessionId) {
            android.media.MediaFormat mf = super.getMediaFormat(format, codecMimeType, codecMaxValues, codecOperatingRate,
                    deviceNeedsNoPostProcessWorkaround, tunnelingAudioSessionId);
            HdrSdr.request(mf, format);   // "Play HDR as SDR"
            return mf;
        }

        @Override
        protected void onOutputFormatChanged(Format format, @androidx.annotation.Nullable android.media.MediaFormat mediaFormat) {
            super.onOutputFormatChanged(format, mediaFormat);
            HdrSdr.check(format, mediaFormat);
        }
    }
}
