package com.brouken.player;

import android.content.Context;
import android.preference.PreferenceManager;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Dolby Vision profile 7 → profile 8.1, while playing (like dovi_tool convert -m 2 --discard).
 *
 * Profile 7 (UHD Blu-ray) = HDR10 base layer + enhancement layer + Dolby Vision RPU metadata.
 * Profile 8.1 = the same HDR10 base layer + RPU. So per frame:
 *  - the enhancement layer NAL units (HEVC type 63) are dropped,
 *  - the RPU (HEVC type 62) is rewritten as profile 8.1: residual off, no NLQ, P8.1 colour
 *    coefficients; for FEL discs the mapping curves become identity,
 *  - everything else (base layer video, dynamic metadata L1/L2/L5/L6/…) is kept bit-exact.
 * The base video isn't touched, so quality = the HDR10 picture + Dolby Vision tone mapping.
 */
final class Dovi78 {

    private Dovi78() {}

    static final String KEY = "dv7ToDv8";

    /** Read at every player start. */
    static volatile boolean enabled;
    /** Conversion failed on this video: play its HDR10 base layer. */
    static volatile boolean fallbackHdr10;

    static void refresh(Context c) {
        active = false;
        try {
            enabled = PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY, false);
            if (enabled && c instanceof PlayerActivity && !allowedFor((PlayerActivity) c)) {
                enabled = false;   // failed on this video before: HDR10 base layer instead (below)
                fallbackHdr10 = true;
            } else {
                fallbackHdr10 = false;
            }
        } catch (Throwable t) {
            enabled = false;
        }
    }

    static boolean isProfile7(String codecs) {
        if (codecs == null) return false;
        String c = codecs.toLowerCase(java.util.Locale.US);
        return c.startsWith("dvhe.07") || c.startsWith("dvh1.07");
    }

    /** "dvhe.07.06" → "dvhe.08.06". */
    static String profile8Codecs(String codecs) {
        return codecs.substring(0, 5) + "08" + codecs.substring(7);
    }

    // ------------------------------------------------------------------ access unit (Annex-B)

    static int converted, kept, failed, droppedEl;

    /**
     * One access unit with 00 00 01 / 00 00 00 01 start codes. Returns the converted unit
     * (enhancement layer removed, RPU converted).
     */
    static byte[] convertAccessUnit(byte[] d, int off, int len) {
        int end = off + len;
        List<int[]> nals = new ArrayList<>();   // {startCodeStart, payloadStart}
        int i = off;
        while (i + 3 <= end) {
            if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) {
                int sc = i > off && d[i - 1] == 0 ? i - 1 : i;
                nals.add(new int[] {sc, i + 3});
                i += 3;
            } else {
                i++;
            }
        }
        if (nals.isEmpty()) return null;   // not Annex-B: leave unchanged
        ByteArrayOutputStream out = new ByteArrayOutputStream(len + 64);
        if (nals.get(0)[0] > off) out.write(d, off, nals.get(0)[0] - off);
        for (int n = 0; n < nals.size(); n++) {
            int sc = nals.get(n)[0];
            int p = nals.get(n)[1];
            int stop = n + 1 < nals.size() ? nals.get(n + 1)[0] : end;
            if (p >= stop) continue;
            int type = (d[p] >> 1) & 0x3F;
            if (type == 63) {             // enhancement layer
                droppedEl++;
                continue;
            }
            if (type == 62 && stop - p > 3) {
                byte[] rpu = convertRpuNal(d, p, stop - p);
                if (rpu != null) {
                    out.write(0); out.write(0); out.write(0); out.write(1);
                    out.write(rpu, 0, rpu.length);
                    converted++;
                    continue;
                }
                failed++;
            }
            out.write(d, sc, stop - sc);
        }
        return out.toByteArray();
    }

    // ------------------------------------------------------------------ RPU

    /** NAL (starting with the 0x7C 0x01 header). Returns the new NAL or null. */
    static byte[] convertRpuNal(byte[] d, int off, int len) {
        return convertRpuNal(d, off, len, true);
    }

    static byte[] convertRpuNal(byte[] d, int off, int len, boolean removeFelMapping) {
        try {
            // remove emulation prevention bytes from the payload (after the 2 header bytes)
            byte[] raw = new byte[len];
            int n = 0;
            int p0 = off + 2;   // payload start (0x19)
            for (int i = p0; i < off + len; i++) {
                // as dovi_tool: checks the escaped input bytes
                if (i - p0 >= 2 && d[i - 2] == 0 && d[i - 1] == 0 && d[i] == 3) continue;
                raw[n++] = d[i];
            }
            if (n < 7 || (raw[0] & 0xFF) != 0x19) return null;
            byte[] payload = convertRpu(raw, n, removeFelMapping);
            if (payload == null) return null;
            // add emulation prevention (as dovi_tool: from the 4th byte on)
            ByteArrayOutputStream o = new ByteArrayOutputStream(payload.length + 16);
            o.write(0x7C);
            o.write(0x01);
            int zeros = 0;
            for (int i = 0; i < payload.length; i++) {
                int b = payload[i] & 0xFF;
                if (i > 2 && zeros >= 2 && b <= 3) {
                    o.write(3);
                    zeros = 0;
                }
                o.write(b);
                zeros = b == 0 ? zeros + 1 : 0;
            }
            return o.toByteArray();
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static final class R {
        final byte[] d;
        final long endBit;
        long pos;
        R(byte[] d, int len) { this.d = d; this.endBit = (long) len * 8; }
        long u(int n) {
            long v = 0;
            for (int i = 0; i < n; i++) {
                if (pos >= endBit) throw new IndexOutOfBoundsException();
                v = (v << 1) | ((d[(int) (pos >> 3)] >> (7 - (int) (pos & 7))) & 1);
                pos++;
            }
            return v;
        }
        boolean bit() { return u(1) == 1; }
        long ue() {
            int z = 0;
            while (u(1) == 0) { if (++z > 40) throw new IllegalStateException("ue"); }
            return z == 0 ? 0 : ((1L << z) - 1 + u(z));
        }
        long se() {
            long k = ue();
            return (k & 1) == 1 ? (k + 1) / 2 : -(k / 2);
        }
        boolean aligned() { return (pos & 7) == 0; }
        long available() { return endBit - pos; }
    }

    private static final class W {
        byte[] b = new byte[512];
        long pos;
        void u(int n, long v) {
            for (int i = n - 1; i >= 0; i--) bit(((v >> i) & 1) == 1);
        }
        void bit(boolean one) {
            int byteIdx = (int) (pos >> 3);
            if (byteIdx >= b.length) b = java.util.Arrays.copyOf(b, b.length * 2);
            if (one) b[byteIdx] |= (byte) (0x80 >> (pos & 7));
            pos++;
        }
        void ue(long v) {
            long x = v + 1;
            int bits = 64 - Long.numberOfLeadingZeros(x);
            u(bits - 1, 0);
            u(bits, x);
        }
        void se(long v) {
            ue(v > 0 ? 2 * v - 1 : -2 * v);
        }
        void align() { while ((pos & 7) != 0) bit(false); }
        int bytes() { return (int) (pos >> 3); }
    }

    private static final class Piece {
        long idc, order;
        boolean interp;
        long[] cInt = new long[0], c = new long[0];       // polynomial
        long mmrOrder, mmrConstInt, mmrConst;              // MMR
        long[][] mmrInt, mmr;
    }

    /** dovi_tool ConversionMode::To81 for a profile 7 RPU. Input/output start with 0x19, end with CRC + 0x80. */
    static byte[] convertRpu(byte[] data, int len) {
        return convertRpu(data, len, true);
    }

    /** removeFelMapping=false: dovi_tool mode 4 (mapping kept) – only used to test against its samples. */
    static byte[] convertRpu(byte[] data, int len, boolean removeFelMapping) {
        int end = len;
        while (end > 0 && data[end - 1] == 0) end--;      // trailing zero bytes
        if (end < 7 || (data[end - 1] & 0xFF) != 0x80) return null;
        R r = new R(data, end);
        W w = new W();
        w.u(8, r.u(8));                                    // 0x19

        // ---- rpu_data_header
        long rpuType = r.u(6);
        if (rpuType != 2) return null;
        long rpuFormat = r.u(11);
        long vdrRpuProfile = r.u(4);
        long vdrRpuLevel = r.u(4);
        boolean seqInfo = r.bit();
        w.u(6, rpuType); w.u(11, rpuFormat); w.u(4, vdrRpuProfile); w.u(4, vdrRpuLevel); w.bit(seqInfo);
        long coefType = 0, log2Denom = 0;
        int coefLen = 0;
        long blDepthMinus8 = 2, elDepthRaw = 2, vdrDepthMinus8 = 4, reserved3 = 0;
        boolean elSpatial = false, disableResidual = true;
        if (seqInfo) {
            w.bit(r.bit());                                // chroma_resampling_explicit_filter_flag
            coefType = r.u(2);
            w.u(2, coefType);
            if (coefType == 0) { log2Denom = r.ue(); w.ue(log2Denom); }
            w.u(2, r.u(2));                                // vdr_rpu_normalized_idc
            w.bit(r.bit());                                // bl_video_full_range_flag
            if ((rpuFormat & 0x700) == 0) {
                blDepthMinus8 = r.ue(); w.ue(blDepthMinus8);
                elDepthRaw = r.ue(); w.ue(elDepthRaw);
                vdrDepthMinus8 = r.ue(); w.ue(vdrDepthMinus8);
                w.bit(r.bit());                            // spatial_resampling_filter_flag
                reserved3 = r.u(3); w.u(3, reserved3);
                elSpatial = r.bit();
                disableResidual = r.bit();
                w.bit(false);                              // → el_spatial_resampling_filter_flag = 0
                w.bit(true);                               // → disable_residual_flag = 1
            }
            if (coefType == 0) coefLen = (int) log2Denom;
            else if (coefType == 1) coefLen = 32;
            else return null;
        }
        // profile 7 only (vdr_rpu_profile 1, residual on, 12-bit VDR)
        if (!(vdrRpuProfile == 1 && elSpatial && !disableResidual && vdrDepthMinus8 == 4)) return null;
        boolean dmPresent = r.bit();
        boolean usePrev = r.bit();
        w.bit(dmPresent); w.bit(usePrev);
        if (usePrev) w.ue(r.ue());

        // ---- rpu_data_mapping
        if (!usePrev) {
            w.ue(r.ue()); w.ue(r.ue()); w.ue(r.ue());       // vdr_rpu_id, mapping_color_space, chroma_format_idc
            int blDepth = (int) blDepthMinus8 + 8;
            long[][] pivots = new long[3][];
            for (int cmp = 0; cmp < 3; cmp++) {
                long npm2 = r.ue();
                pivots[cmp] = new long[(int) npm2 + 2];
                for (int i = 0; i < pivots[cmp].length; i++) pivots[cmp][i] = r.u(blDepth);
            }
            boolean nlq = (rpuFormat & 0x700) == 0 && !disableResidual;
            if (nlq) {
                if (r.u(3) != 0) return null;              // nlq_method_idc: linear deadzone
                r.u(blDepth); r.u(blDepth);                // nlq_pred_pivot_value[2]
            }
            r.ue(); r.ue();                                // num_x/y_partitions_minus1 → written as 0
            List<List<Piece>> curves = new ArrayList<>();
            for (int cmp = 0; cmp < 3; cmp++) {
                List<Piece> pieces = new ArrayList<>();
                int numPieces = pivots[cmp].length - 1;
                for (int i = 0; i < numPieces; i++) {
                    Piece pc = new Piece();
                    pc.idc = r.ue();
                    if (pc.idc == 0) {
                        pc.order = r.ue();
                        if (pc.order > 1) return null;
                        if (pc.order == 0) pc.interp = r.bit();
                        if (pc.interp) return null;        // not supported (dovi_tool neither)
                        int cnt = (int) pc.order + 2;
                        pc.cInt = new long[cnt];
                        pc.c = new long[cnt];
                        for (int j = 0; j < cnt; j++) {
                            if (coefType == 0) pc.cInt[j] = r.se();
                            pc.c[j] = r.u(coefLen);
                        }
                    } else if (pc.idc == 1) {
                        pc.mmrOrder = r.u(2);
                        if (pc.mmrOrder > 2) return null;
                        if (coefType == 0) pc.mmrConstInt = r.se();
                        pc.mmrConst = r.u(coefLen);
                        int orders = (int) pc.mmrOrder + 1;
                        pc.mmrInt = new long[orders][7];
                        pc.mmr = new long[orders][7];
                        for (int j = 0; j < orders; j++) {
                            for (int k = 0; k < 7; k++) {
                                if (coefType == 0) pc.mmrInt[j][k] = r.se();
                                pc.mmr[j][k] = r.u(coefLen);
                            }
                        }
                    } else {
                        return null;
                    }
                    pieces.add(pc);
                }
                curves.add(pieces);
            }
            boolean fel = false;
            if (nlq) {
                int elDepth = (int) (elDepthRaw & 0xFF) + 8;
                for (int cmp = 0; cmp < 3; cmp++) {
                    long nlqOffset = r.u(elDepth);
                    long inMaxInt = coefType == 0 ? r.ue() : 0;
                    long inMax = r.u(coefLen);
                    long slopeInt = coefType == 0 ? r.ue() : 0;
                    long slope = r.u(coefLen);
                    long thrInt = coefType == 0 ? r.ue() : 0;
                    long thr = r.u(coefLen);
                    boolean mel = nlqOffset == 0 && inMaxInt == 1 && inMax == 0 && slopeInt == 0 && slope == 0
                            && thrInt == 0 && thr == 0;
                    if (!mel && removeFelMapping) fel = true;
                }
            }
            // write the mapping as profile 8.1
            for (int cmp = 0; cmp < 3; cmp++) {
                long[] pv = fel ? new long[] {0, (1L << blDepth) - 1} : pivots[cmp];
                w.ue(pv.length - 2);
                for (long p : pv) w.u(blDepth, p);
            }
            w.ue(0); w.ue(0);                              // num_x/y_partitions_minus1
            for (int cmp = 0; cmp < 3; cmp++) {
                if (fel) {                                 // identity: y = x
                    w.ue(0); w.ue(0); w.bit(false);
                    if (coefType == 0) w.se(0);
                    w.u(coefLen, 0);
                    if (coefType == 0) w.se(1);
                    w.u(coefLen, 0);
                    continue;
                }
                for (Piece pc : curves.get(cmp)) {
                    w.ue(pc.idc);
                    if (pc.idc == 0) {
                        w.ue(pc.order);
                        if (pc.order == 0) w.bit(pc.interp);
                        for (int j = 0; j < pc.c.length; j++) {
                            if (coefType == 0) w.se(pc.cInt[j]);
                            w.u(coefLen, pc.c[j]);
                        }
                    } else {
                        w.u(2, pc.mmrOrder);
                        if (coefType == 0) w.se(pc.mmrConstInt);
                        w.u(coefLen, pc.mmrConst);
                        for (int j = 0; j < pc.mmr.length; j++) {
                            for (int k = 0; k < 7; k++) {
                                if (coefType == 0) w.se(pc.mmrInt[j][k]);
                                w.u(coefLen, pc.mmr[j][k]);
                            }
                        }
                    }
                }
            }
        }

        // ---- vdr_dm_data
        if (dmPresent) {
            boolean compressed = reserved3 == 1;
            w.ue(r.ue()); w.ue(r.ue()); w.ue(r.ue());       // affected/current dm id, scene_refresh_flag
            if (!compressed) {
                for (int i = 0; i < 9; i++) r.u(16);       // ycc_to_rgb_coef
                for (int i = 0; i < 3; i++) r.u(32);       // ycc_to_rgb_offset
                for (int i = 0; i < 9; i++) r.u(16);       // rgb_to_lms_coef
                for (long v : YCC_TO_RGB) w.u(16, v & 0xFFFF);
                for (long v : YCC_OFFSETS) w.u(32, v);
                for (long v : RGB_TO_LMS) w.u(16, v & 0xFFFF);
                w.u(16, r.u(16)); w.u(16, r.u(16)); w.u(16, r.u(16)); w.u(32, r.u(32));   // signal_eotf + params
                w.u(5, r.u(5));                            // signal_bit_depth
                r.u(2); w.u(2, 0);                         // signal_color_space → 0
                w.u(2, r.u(2)); w.u(2, r.u(2));            // chroma format, full range
                w.u(12, r.u(12)); w.u(12, r.u(12)); w.u(10, r.u(10));   // source min/max pq, diagonal
            }
            copyExtBlocks(r, w);                           // CM v2.9 (L1, L2, L4, L5, L6 …)
            if (r.available() >= 56) copyExtBlocks(r, w);  // CM v4.0 (L3, L8, L9, L10, L11 …)
        }

        // rpu_alignment_zero_bit, then anything left before the CRC
        while (!r.aligned()) r.u(1);
        while (r.available() > 40) w.bit(r.bit());
        if (r.available() != 40) return null;
        w.align();
        int bodyLen = w.bytes();
        long crc = crc32Mpeg2(w.b, 1, bodyLen - 1);
        w.u(32, crc);
        w.u(8, 0x80);
        byte[] out = java.util.Arrays.copyOf(w.b, w.bytes() + (len - end));   // keep the trailing zeros
        return out;
    }

    private static void copyExtBlocks(R r, W w) {
        long n = r.ue();
        w.ue(n);
        while (!r.aligned()) r.u(1);
        w.align();
        for (long i = 0; i < n; i++) {
            long length = r.ue();
            w.ue(length);
            w.u(8, r.u(8));                                // level
            for (long b = 0; b < length * 8; b++) w.bit(r.bit());
        }
    }

    private static final long[] YCC_TO_RGB = {9574, 0, 13802, 9574, -1540, -5348, 9574, 17610, 0};
    private static final long[] YCC_OFFSETS = {16777216L, 134217728L, 134217728L};
    private static final long[] RGB_TO_LMS = {7222, 8771, 390, 2654, 12430, 1300, 0, 422, 15962};

    /** CRC-32/MPEG-2: poly 0x04C11DB7, init 0xFFFFFFFF, no reflection, no final xor. */
    static long crc32Mpeg2(byte[] b, int off, int len) {
        int crc = 0xFFFFFFFF;
        for (int i = off; i < off + len; i++) {
            crc ^= (b[i] & 0xFF) << 24;
            for (int k = 0; k < 8; k++) crc = (crc & 0x80000000) != 0 ? (crc << 1) ^ 0x04C11DB7 : crc << 1;
        }
        return crc & 0xFFFFFFFFL;
    }

    private static String blockedUri;
    static volatile boolean active;   // a converted stream is playing

    static boolean converting() {
        return active && (converted > 0 || droppedEl > 0);
    }

    static void blockCurrent(PlayerActivity a) {
        blockedUri = a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
        active = false;
    }

    /** Conversion allowed for the video being opened? (not after it failed on this video) */
    static boolean allowedFor(PlayerActivity a) {
        String u = a != null && a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
        return enabled && (u == null || !u.equals(blockedUri));
    }

    /** For the overlay. */
    static String status() {
        if (converted == 0 && failed == 0) return null;
        return "DV7 → DV8: " + converted + " frames converted" + (failed > 0 ? ", " + failed + " kept as they were" : "")
                + (droppedEl > 0 ? " · enhancement layer removed" : "");
    }

    static void resetCounters() {
        converted = kept = failed = droppedEl = 0;
    }
}
