package com.brouken.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * Light / dark / grey look for the menus (start screen, Settings, Saved links, dialogs).
 * "System" (the default) follows the tablet's / TV's own setting; "Grey" is Android's original
 * dark grey (like the first versions). The video screen stays dark.
 */
final class ThemeMode {

    private ThemeMode() {}

    static final String KEY = "appTheme";

    static String get(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getString(KEY, "system");
    }

    /** For Settings (AppCompat). */
    static int nightMode(Context c) {
        return nightMode(get(c));
    }

    static int nightMode(String mode) {
        switch (mode) {
            case "light": return AppCompatDelegate.MODE_NIGHT_NO;
            case "dark":
            case "grey": return AppCompatDelegate.MODE_NIGHT_YES;
            default: return AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        }
    }

    /**
     * For the other screens: call in attachBaseContext, right after super. Only the light/dark
     * part of the configuration is replaced, so rotation and everything else still update.
     */
    /** The choice the player window was opened with (it's rebuilt when you change it, if no video plays). */
    static String playerApplied;

    static void override(Activity a, Context base) {
        String m = get(base);
        if (a instanceof PlayerActivity) playerApplied = m;
        if (!"light".equals(m) && !"dark".equals(m) && !"grey".equals(m)) return;
        Configuration o = new Configuration();
        o.uiMode = "light".equals(m) ? Configuration.UI_MODE_NIGHT_NO : Configuration.UI_MODE_NIGHT_YES;
        try {
            a.applyOverrideConfiguration(o);
        } catch (Throwable ignored) { }
    }

    static boolean isDark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    static boolean isGrey(Context c) {
        return "grey".equals(get(c));
    }

    /** Colours for screens built in code. */
    static final class Pal {
        final boolean dark, grey;
        final int bg, panel, card, cardFocus, cardPressed, text, sub, hint, chipText, chipOnText, accent, icon, line;
        Pal(boolean dark) { this(dark, false); }
        Pal(boolean dark, boolean grey) {
            this.dark = dark || grey;
            this.grey = grey;
            if (grey) {
                bg = 0xFF303030; panel = 0xFF424242; card = 0xFF505050; cardFocus = 0xFF666666; cardPressed = 0xFF707070;
            } else if (dark) {
                bg = 0xFF000000; panel = 0xFF1F1F1F; card = 0xFF2A2A2A; cardFocus = 0xFF444444; cardPressed = 0xFF4A4A4A;
            } else {
                bg = 0xFFF2F2F2; panel = 0xFFFFFFFF; card = 0xFFF1F1F1; cardFocus = 0xFFE0E0E0; cardPressed = 0xFFD6D6D6;
            }
            boolean d = this.dark;
            text = d ? 0xFFFFFFFF : 0xDE000000;
            sub = grey ? 0xFFBDBDBD : d ? 0xFF9E9E9E : 0x8A000000;
            hint = d ? 0xFF757575 : 0x61000000;
            chipText = d ? 0xFFE0E0E0 : 0xDE000000;
            chipOnText = d ? 0xFF000000 : 0xFFFFFFFF;
            accent = d ? 0xFF80CBC4 : 0xFF009688;
            icon = d ? 0xFFBDBDBD : 0x8A000000;
            line = d ? 0x1FFFFFFF : 0x1F000000;
        }

        /** A panel (start screen, Saved links). */
        android.graphics.drawable.Drawable panelBg(Context c) {
            float d = c.getResources().getDisplayMetrics().density;
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(8 * d);
            g.setColor(panel);
            if (!dark) g.setStroke(Math.max(1, Math.round(d)), 0x1F000000);
            return g;
        }

        /** A card you can select (Continue watching). */
        android.graphics.drawable.Drawable cardBg(Context c) {
            float d = c.getResources().getDisplayMetrics().density;
            android.graphics.drawable.StateListDrawable s = new android.graphics.drawable.StateListDrawable();
            s.addState(new int[]{android.R.attr.state_pressed}, round(cardPressed, 0, 0, d));
            s.addState(new int[]{android.R.attr.state_focused}, round(cardFocus, Math.max(1, Math.round(d)), dark ? 0x99FFFFFF : 0x8A000000, d));
            s.addState(new int[]{}, round(card, 0, 0, d));
            return s;
        }

        private static android.graphics.drawable.GradientDrawable round(int color, int stroke, int strokeColor, float d) {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(6 * d);
            g.setColor(color);
            if (stroke > 0) g.setStroke(stroke, strokeColor);
            return g;
        }
    }

    static Pal pal(Context c) {
        return new Pal(isDark(c), isGrey(c));
    }
}
