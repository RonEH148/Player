package com.brouken.player;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * What the player shows when no video is open: a panel with Open link / Open file / Saved links / Settings, and "Continue
 * watching" with the videos you stopped in the middle of.
 *
 * Only exists while nothing plays: opening a video removes it, so playback uses exactly the
 * same resources as before.
 */
final class StartScreen {

    private StartScreen() {}

    private static FrameLayout shown;
    private static Runnable openFile, openSettings;

    static void setup(PlayerActivity a, Runnable openFile, Runnable openSettings) {
        StartScreen.openFile = openFile;
        StartScreen.openSettings = openSettings;
    }

    static boolean isShown() {
        return shown != null && shown.getParent() != null;
    }

    /** After the player was (re)created: shown without a video, gone with one. */
    static void sync(PlayerActivity a) {
        try {
            if (PlayerActivity.haveMedia) hide(a);
            else show(a);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    static void hide(PlayerActivity a) {
        if (shown != null) {
            ViewGroup p = (ViewGroup) shown.getParent();
            if (p != null) p.removeView(shown);
            shown = null;
            if (a.playerView != null) a.playerView.setUseController(true);
            // a video opens: its own rotation rule again (Settings → video orientation)
            try { Utils.setOrientation(a, a.mPrefs.orientation); } catch (Throwable ignored) { }
        }
    }

    static void show(final PlayerActivity a) {
        if (ThemeMode.playerApplied != null && !ThemeMode.playerApplied.equals(ThemeMode.get(a))) {
            // Settings → Theme was changed: reopen the (empty) player window in the new look
            ThemeMode.playerApplied = null;
            a.recreate();
            return;
        }
        ViewGroup content = a.findViewById(android.R.id.content);
        if (content == null) return;
        if (shown != null && shown.getParent() != null) ((ViewGroup) shown.getParent()).removeView(shown);
        if (a.playerView != null) {
            a.playerView.hideController();
            a.playerView.setUseController(false);
        }
        // no video: turn freely with the tablet (any direction, like the home screen)
        a.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
        shown = build(a);
        content.addView(shown, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final View first = shown.findViewWithTag("first");
        if (first != null) first.post(first::requestFocus);
    }

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** Light or dark colours (Settings → Theme). */
    private static ThemeMode.Pal P = new ThemeMode.Pal(true);

    private static FrameLayout build(final PlayerActivity a) {
        P = ThemeMode.pal(a);
        FrameLayout root = new FrameLayout(a);
        root.setBackgroundColor(P.bg);
        root.setClickable(true);   // touches don't reach the empty player underneath

        boolean wide = a.getResources().getDisplayMetrics().widthPixels >= a.getResources().getDisplayMetrics().heightPixels;
        // side by side (landscape) with the tops lined up and the same height; stacked (portrait).
        // The whole block is centred on the screen.
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        row.setGravity(wide ? Gravity.TOP : Gravity.CENTER_HORIZONTAL);
        row.setBaselineAligned(false);
        row.setPadding(dp(a, 40), dp(a, 28), dp(a, 40), dp(a, 28));
        android.widget.ScrollView scroll = new android.widget.ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        FrameLayout centre = new FrameLayout(a);
        centre.addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
        scroll.addView(centre, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- the main panel
        LinearLayout hero = panel(a);
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(a);
        icon.setImageResource(R.drawable.gamma_icon);
        top.addView(icon, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
        LinearLayout names = new LinearLayout(a);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(a, a.getString(R.string.app_name), 30, P.text);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        names.addView(title);
        names.addView(text(a, "Paste or pick a link to start watching", 14, P.sub));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.leftMargin = dp(a, 16);
        top.addView(names, nlp);
        hero.addView(top);

        int saved = SavedLinksActivity.load(a).size();
        View open = action(a, R.drawable.ic_g_link, "Open link", "", true, () -> {
            Intent i = new Intent();
            i.setClassName(a, "com.brouken.player.PasteUrlActivity");
            i.putExtra("dialog", true);
            a.startActivity(i);
        });
        open.setTag("first");
        addAction(a, hero, open, 22);
        addAction(a, hero, action(a, R.drawable.ic_g_bookmark, "Saved links", saved > 0 ? String.valueOf(saved) : "", false,
                () -> a.startActivity(new Intent(a, SavedLinksActivity.class))), 10);
        addAction(a, hero, action(a, R.drawable.ic_g_folder, "Open file", "", false, () -> { if (openFile != null) openFile.run(); }), 10);
        addAction(a, hero, action(a, R.drawable.ic_g_gear, "Settings", "", false, () -> { if (openSettings != null) openSettings.run(); }), 10);

        List<ResumePoints.Entry> recent = continueList(a);
        LinearLayout.LayoutParams hlp = wide
                ? new LinearLayout.LayoutParams(dp(a, 400), ViewGroup.LayoutParams.WRAP_CONTENT)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        row.addView(hero, hlp);

        // ---- continue watching
        {   // always shown – with a note when nothing is unfinished yet
            View gap = new View(a);
            row.addView(gap, wide ? new LinearLayout.LayoutParams(0, 1, 1) : new LinearLayout.LayoutParams(1, dp(a, 20)));
            LinearLayout cw = panel(a);
            TextView h = text(a, "CONTINUE WATCHING", 13, P.sub);
            h.setLetterSpacing(0.14f);
            cw.addView(h);
            java.util.Map<String, String> names2 = savedNames(a);
            if (recent.isEmpty()) {
                LinearLayout none = new LinearLayout(a);
                none.setOrientation(LinearLayout.VERTICAL);
                none.setGravity(Gravity.CENTER);
                none.setPadding(dp(a, 16), dp(a, 24), dp(a, 16), dp(a, 24));
                none.setBackground(P.cardBg(a));
                ImageView play = new ImageView(a);
                play.setImageResource(R.drawable.ic_g_play);
                play.setBackgroundResource(R.drawable.glass_circle);
                play.setScaleType(ImageView.ScaleType.CENTER);
                play.setColorFilter(P.icon);
                none.addView(play, new LinearLayout.LayoutParams(dp(a, 44), dp(a, 44)));
                TextView t1 = text(a, "Nothing to continue yet", 15, P.text);
                t1.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                l1.topMargin = dp(a, 12);
                none.addView(t1, l1);
                TextView t2 = text(a, "Videos you stop partway through show up here, so you can pick up where you left off.", 12, P.sub);
                t2.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                l2.topMargin = dp(a, 4);
                none.addView(t2, l2);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = dp(a, 14);
                cw.addView(none, lp);
            }
            for (int i = 0; i < recent.size(); i++) {
                final ResumePoints.Entry e = recent.get(i);
                View card = card(a, e, displayName(a, e.uri, names2));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = dp(a, i == 0 ? 14 : 8);
                cw.addView(card, lp);
            }
            row.addView(cw, wide ? new LinearLayout.LayoutParams(dp(a, 440), ViewGroup.LayoutParams.WRAP_CONTENT)
                    : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (wide) {
                // side by side: the shorter panel grows to the taller one's height (tops already lined up)
                final LinearLayout h1 = hero, h2 = cw;
                row.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                    @Override
                    public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                        int h = Math.max(h1.getMeasuredHeight(), h2.getMeasuredHeight());
                        if (h > 0 && (h1.getMinimumHeight() != h || h2.getMinimumHeight() != h)) {
                            v.removeOnLayoutChangeListener(this);
                            v.post(() -> {
                                h1.setMinimumHeight(h);
                                h2.setMinimumHeight(h);
                            });
                        }
                    }
                });
            }
        }
        return root;
    }

    private static LinearLayout panel(Context c) {
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(c, 24), dp(c, 22), dp(c, 24), dp(c, 22));
        p.setBackground(P.panelBg(c));
        return p;
    }

    private static void addAction(Context c, LinearLayout box, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 52));
        lp.topMargin = dp(c, topDp);
        box.addView(v, lp);
    }

    private static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private static View action(Context c, int icon, String label, String hint, boolean primary, final Runnable run) {
        LinearLayout b = new LinearLayout(c);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(c, 16), 0, dp(c, 18), 0);
        b.setBackgroundResource(R.drawable.glass_row);
        b.setFocusable(true);
        b.setClickable(true);
        ImageView i = new ImageView(c);
        i.setImageResource(icon);
        i.setColorFilter(P.icon);
        b.addView(i, new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22)));
        TextView t = text(c, label, 17, P.text);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tl.leftMargin = dp(c, 14);
        b.addView(t, tl);
        if (!hint.isEmpty()) b.addView(text(c, hint, 13, P.sub));
        b.setOnClickListener(v -> run.run());
        return b;
    }

    /** Unfinished videos from links (the newest three). */
    static List<ResumePoints.Entry> continueList(Context c) {
        List<ResumePoints.Entry> out = new java.util.ArrayList<>();
        for (ResumePoints.Entry e : ResumePoints.all(c)) {
            if (!PasteUrlActivity.isValid(e.uri)) continue;
            out.add(e);
            if (out.size() == 3) break;
        }
        return out;
    }

    private static java.util.Map<String, String> savedNames(Context c) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        for (SavedLinksActivity.Link l : SavedLinksActivity.load(c)) m.put(SavedLinksActivity.key(l.url), l.name);
        return m;
    }

    /** Your name for it, else the saved link's name, else the file name in the link, else the site. */
    private static String displayName(Context c, String uri, java.util.Map<String, String> saved) {
        String n = ResumePoints.name(c, uri);
        if (n == null || n.trim().isEmpty()) n = saved.get(SavedLinksActivity.key(uri));
        if (n == null || n.trim().isEmpty()) {
            try { n = Titles.fromUrl(Uri.parse(uri)); } catch (Throwable ignored) { }
        }
        if (n == null || n.trim().isEmpty()) n = SavedLinksActivity.defaultName(uri);
        return n;
    }

    private static View card(final PlayerActivity a, final ResumePoints.Entry e, final String name) {
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(a, 16), dp(a, 12), dp(a, 16), dp(a, 14));
        card.setBackground(P.cardBg(a));
        card.setFocusable(true);
        card.setClickable(true);
        TextView n = text(a, name, 15, P.text);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(n);
        String d = ResumePoints.time(e.pos) + (e.dur > 0 ? " of " + ResumePoints.time(e.dur) : "");
        card.addView(text(a, d, 12, P.sub));
        if (e.dur > 0) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 6));
            lp.topMargin = dp(a, 8);
            card.addView(ResumePoints.glassBar(a, e.pos, e.dur), lp);
        }
        card.setOnClickListener(v -> options(a, e, name));
        card.setOnLongClickListener(v -> { options(a, e, name); return true; });
        return card;
    }

    /** Play / Rename / Remove from Continue watching. */
    private static void options(final PlayerActivity a, final ResumePoints.Entry e, final String name) {
        new android.app.AlertDialog.Builder(a)
                .setTitle(name)
                .setItems(new String[]{"Play", "Rename", "Remove from Continue watching"}, (d, w) -> {
                    if (w == 0) play(a, e.uri);
                    else if (w == 1) rename(a, e, name);
                    else confirmRemove(a, e, name);
                })
                .show();
    }

    private static void play(Context c, String uri) {
        Intent i = new Intent(c, PasteUrlActivity.class);
        i.putExtra(PasteUrlActivity.EXTRA_URL, uri);   // the usual link check, then it asks Resume / Start over
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    private static void rename(final PlayerActivity a, final ResumePoints.Entry e, String name) {
        final android.widget.EditText input = new android.widget.EditText(a);
        input.setSingleLine(true);
        input.setText(name);
        input.setSelection(name.length());
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout box = new LinearLayout(a);
        box.setPadding(dp(a, 20), dp(a, 8), dp(a, 20), 0);
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final android.app.AlertDialog d = new android.app.AlertDialog.Builder(a)
                .setTitle("Rename")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        d.setOnShowListener(x -> d.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = input.getText().toString().trim();
            if (n.isEmpty()) {
                input.setError("Enter a name");
                return;
            }
            if (n.length() > SavedLinksActivity.MAX_NAME) n = n.substring(0, SavedLinksActivity.MAX_NAME);
            ResumePoints.setName(a, e.uri, n);
            SavedLinksActivity.renameByUrl(a, e.uri, n);   // a saved link of the same video gets the name too
            d.dismiss();
            if (isShown()) show(a);
        }));
        d.show();
        input.requestFocus();
    }

    private static void confirmRemove(final PlayerActivity a, final ResumePoints.Entry e, String name) {
        new android.app.AlertDialog.Builder(a)
                .setTitle("Remove from Continue watching?")
                .setMessage(name + "\n\nThe saved link and any download on the USB drive stay.")
                .setPositiveButton("Remove", (d, w) -> {
                    ResumePoints.remove(a, e.uri);
                    if (isShown()) show(a);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
