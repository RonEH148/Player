package com.phlox.tvwebbrowser.webengine

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import com.phlox.tvwebbrowser.model.Download
import com.phlox.tvwebbrowser.model.HomePageLink
import com.phlox.tvwebbrowser.widgets.cursor.CursorDrawerDelegate
import java.io.InputStream

interface WebEngineWindowProviderCallback {
    fun getActivity(): Activity
    fun onOpenInNewTabRequested(url: String, navigateImmediately: Boolean): WebEngine?
    fun onDownloadRequested(url: String)
    fun onDownloadRequested(url: String, referer: String, originalDownloadFileName: String?, userAgent: String?, mimeType: String?,
                            operationAfterDownload: Download.OperationAfterDownload = Download.OperationAfterDownload.NOP,
                            base64BlobData: String? = null, stream: InputStream? = null, size: Long = 0L, contentDisposition: String? = null)
    fun onDownloadRequested(url: String, userAgent: String?, contentDisposition: String, mimetype: String?, contentLength: Long)
    fun onProgressChanged(newProgress: Int)
    fun onReceivedTitle(title: String)
    fun requestPermissions(array: Array<String>): Int
    fun onShowFileChooser(intent: Intent): Boolean
    fun onReceivedIcon(icon: Bitmap)
    fun shouldOverrideUrlLoading(url: String): Boolean
    fun onPageStarted(url: String?)
    fun onPageFinished(url: String?)
    fun onPageCertificateError(url: String?)
    fun isAd(url: Uri, acceptHeader: String?, baseUri: Uri): Boolean?
    fun isAdBlockingEnabled(): Boolean
    fun isDialogsBlockingEnabled(): Boolean
    fun shouldBlockNewWindow(dialog: Boolean, userGesture: Boolean): Boolean
    fun onBlockedAd(uri: String)
    fun onBlockedDialog(newTab: Boolean)
    fun onCreateWindow(dialog: Boolean, userGesture: Boolean): View?
    fun closeWindow(internalRepresentation: Any)
    fun onScaleChanged(oldScale: Float, newScale: Float)
    fun onCopyTextToClipboardRequested(url: String)
    fun onShareUrlRequested(url: String)
    fun onOpenInExternalAppRequested(url: String)
    fun initiateVoiceSearch()
    fun onEditHomePageBookmarkSelected(index: Int)
    fun getHomePageLinks(): List<HomePageLink>
    fun onPrepareForFullscreen()
    fun onExitFullscreen()
    fun onVisited(url: String)
    fun suggestActionsForLink(baseUri: String?, linkUri: String?, srcUri: String?,
                              title: String?, altText: String?, textContent: String?,
                              x: Int, y: Int)
    fun markBookmarkRecommendationAsUseful(bookmarkOrder: Int)
    /** Lumen: the page scrolled to [y] by [dy] (px); used to auto-hide the top bar. */
    fun onPageScrolled(y: Int, dy: Int) {}
    /** Wisp: the page is pulled down past its top by [distance] px (finger still down unless [released]). */
    fun onPullToRefresh(distance: Float, released: Boolean) {}
    /** Lumen: the page's process died; the engine has dropped its view, [url] was showing. */
    fun onRenderProcessGone(url: String?) {}
    /** Lumen: the page's address changed, also without loading a new page (history.pushState). */
    fun onUrlChanged(url: String) {}
    /** Lumen: something shown on the toolbar for this page changed (e.g. deband switched on by itself). */
    fun onPageStateChanged() {}
    /** Lumen: a video started playing somewhere in the page (also inside player frames). */
    fun onVideoStarted() {}
    /**
     * Lumen: OK held on the page. [result] is the page script's answer (JSON: kind = edit / text /
     * link / none). Return true when handled (no old cursor menu).
     */
    fun onPageLongPress(engine: WebEngine, result: String, x: Int, y: Int): Boolean = false

    /** Wisp: the page script found an image / link / video under a long press (JSON). */
    fun onWispLongPress(json: String) {}
    fun onContextMenu(
        cursorDrawer: CursorDrawerDelegate, baseUri: String?, linkUri: String?, srcUri: String?,
        title: String?, altText: String?,
        textContent: String?, x: Int, y: Int
    )
}