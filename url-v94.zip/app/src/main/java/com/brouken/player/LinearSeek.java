package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.ForwardingPlayer;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.extractor.Extractor;
import androidx.media3.extractor.ExtractorInput;
import androidx.media3.extractor.ExtractorOutput;
import androidx.media3.extractor.ExtractorsFactory;
import androidx.media3.extractor.PositionHolder;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekPoint;
import androidx.media3.extractor.SniffFailure;
import androidx.media3.extractor.TrackOutput;
import androidx.media3.extractor.text.SubtitleParser;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Seeking on servers that can't seek ("linear" links, see RangeSupport), like mpv does it:
 * jumps are allowed only inside what is already downloaded, in 5-second steps, at most half of the
 * buffer ahead (30 s buffered → up to 15 s forward) and a few seconds back. Nothing is reloaded and
 * audio stays in sync because the player just moves within its own buffer.
 *
 * ExoPlayer normally refuses any seek on such a file and restarts it from 0:00; the wrapped
 * extractor reports the file as seekable so in-buffer jumps work, and SeekGuard keeps every jump
 * inside the buffer so a reload from the start never happens.
 */
public final class LinearSeek {

    private LinearSeek() {}

    public static final int STEP_MS = 5_000;

    /** Seeks on the current video are kept inside the buffer. */
    public static boolean limited() {
        return active();
    }

    static int backBufferMs() {
        return Perf.lowEnd() ? 5_000 : 15_000;
    }

    /**
     * The file has no index (no Cues in the MKV …): ExoPlayer can't jump to a position it hasn't
     * downloaded and would restart from 0:00, so seeks stay inside the buffer here too.
     */
    static volatile boolean noIndex;

    static boolean active() {
        try {
            ExoPlayer p = PlayerActivity.player;
            if (p == null || p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return false;
            return noIndex || linearNow();
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean linearNow() {
        try {
            ExoPlayer p = PlayerActivity.player;
            return RangeSupport.isLinear(p.getCurrentMediaItem().localConfiguration.uri);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Seek step for remote / D-pad: 5 s on linear links, Just Player's 10 s otherwise. */
    public static long step() {
        return active() ? STEP_MS : 10_000;
    }

    /** Where a seek to {@code target} may go. Normal links: anywhere. */
    public static long clamp(Player p, long target) {
        if (p == null || !active()) return target;
        long cur = p.getCurrentPosition();
        // Still loading: a seek can't make the data come faster, and on these links a seek the
        // player can't do inside its buffer means downloading the whole file again from 0:00.
        if (p.getPlaybackState() == Player.STATE_BUFFERING && target != cur) {
            Diag.log("Seek blocked while loading");
            blockedNotice();
            return cur;
        }
        long buffered = p.getBufferedPosition();
        // forward: up to 1 s before the end of what's downloaded (5 s downloaded → up to 4 s)
        long maxForward = Math.max(cur, buffered - 1_000);
        // back: only what's kept behind the playhead (linear links keep a few seconds)
        // (half of what's kept, so the target is surely still there)
        long minBack = linearNow() ? Math.max(0, cur - backBufferMs() / 2) : cur;
        // USB drive buffer: everything already on the drive can be jumped to
        try {
            long[] drive = UsbBuffer.seekableMs(p.getCurrentMediaItem().localConfiguration.uri);
            if (drive != null) {
                maxForward = Math.max(maxForward, drive[1] - 1_000);
                minBack = Math.min(minBack, drive[0]);
            }
        } catch (Throwable ignored) { }
        // 5-second steps; the last step before the limit is whatever is left (19 s → 5+5+5+4)
        long t = cur + Math.round((target - cur) / (double) STEP_MS) * STEP_MS;
        if (target > cur && t <= cur) t = cur + STEP_MS;
        if (t > maxForward) t = maxForward;   // stop at the limit instead of refusing the seek
        if (t < minBack) t = minBack;
        if (Math.abs(t - cur) < 300) t = cur;   // nothing left to gain
        if (t != target) Diag.log("Seek: " + (target - cur) / 1000 + " s → " + (t - cur) / 1000 + " s (inside the buffer)");
        return Math.max(0, t);
    }

    private static long lastNotice;

    private static void blockedNotice() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastNotice < 3000) return;
        lastNotice = now;
        HANDLER.post(() -> {
            try {
                android.app.Activity a = PlayerActivity.playerOwner;
                if (a instanceof PlayerActivity) CenterText.show((PlayerActivity) a, "Loading… seeking resumes when it plays", 1500);
            } catch (Throwable ignored) { }
        });
    }

    /** All seeks from Just Player's own gestures and keys go through here. */
    public static void seekTo(ExoPlayer p, long target) {
        if (p == null) return;
        long t = clamp(p, target);
        if (active() && t == p.getCurrentPosition()) return;   // nothing buffered that far
        issue(p, t);
    }

    // ------------------------------------------------------------------ fast repeated seeks

    /**
     * Seeking very fast (holding a key, quick swipes): every seek restarts the video decoder from
     * a keyframe. Back to back, the picture can't keep up and freezes while the sound already
     * plays on. So seeks are sent at most every 300 ms; presses in between only move the target,
     * and the last one is sent when the previous seek has been done.
     */
    private static final long GAP_MS = 300;
    private static final android.os.Handler HANDLER = new android.os.Handler(android.os.Looper.getMainLooper());
    private static long lastIssued;
    private static long pending = -1;
    private static Player pendingPlayer;

    private static final Runnable SEND = new Runnable() {
        @Override
        public void run() {
            Player p = pendingPlayer;
            long t = pending;
            pending = -1;
            pendingPlayer = null;
            if (p == null || t < 0) return;
            Player base = p instanceof ForwardingPlayer ? ((ForwardingPlayer) p).getWrappedPlayer() : p;
            if (base != PlayerActivity.player) return;   // player closed / rebuilt meanwhile
            long c = clamp(p, t);   // the buffer may have changed meanwhile
            if (active() && c == p.getCurrentPosition()) return;
            send(p, c);
        }
    };

    private static void issue(Player p, long t) {
        long now = android.os.SystemClock.uptimeMillis();
        if (pending < 0 && now - lastIssued >= GAP_MS) {
            send(p, t);
            return;
        }
        pending = t;
        pendingPlayer = p;
        HANDLER.removeCallbacks(SEND);
        HANDLER.postAtTime(SEND, Math.max(now, lastIssued + GAP_MS));
    }

    private static void send(Player p, long t) {
        lastIssued = android.os.SystemClock.uptimeMillis();
        Player base = p instanceof ForwardingPlayer ? ((ForwardingPlayer) p).getWrappedPlayer() : p;
        if (active() && base instanceof ExoPlayer) {
            // land on a keyframe: the picture is there at once (files without an index get
            // the keyframes from what's downloaded, see Keyframes)
            // only if one is within 1 s, so the 5-second steps stay 5 seconds
            ((ExoPlayer) base).setSeekParameters(new androidx.media3.exoplayer.SeekParameters(1_000_000, 1_000_000));
        }
        base.seekTo(t);
    }

    /** Where the video is going: a seek waiting to be sent, or the current position. */
    public static long position(Player p) {
        return pending >= 0 ? pending : p.getCurrentPosition();
    }

    /** The player handed to the on-screen controls (time bar), so its seeks are guarded too. */
    public static Player wrap(ExoPlayer p) {
        return new ForwardingPlayer(p) {
            @Override
            public void seekTo(long positionMs) {
                long t = clamp(getWrappedPlayer(), positionMs);
                if (active() && t == getWrappedPlayer().getCurrentPosition()) return;
                issue(getWrappedPlayer(), t);
            }

            @Override
            public void seekTo(int mediaItemIndex, long positionMs) {
                if (mediaItemIndex != getWrappedPlayer().getCurrentMediaItemIndex()) {
                    super.seekTo(mediaItemIndex, positionMs);
                    return;
                }
                seekTo(positionMs);
            }

            // the gray part of the time bar: with the USB drive buffer, everything ready on the drive
            @Override
            public long getBufferedPosition() {
                long b = super.getBufferedPosition();
                try {
                    long d = UsbBuffer.readyUntilMs(getWrappedPlayer().getCurrentMediaItem().localConfiguration.uri, getDuration());
                    if (d > b) b = Math.min(d, getDuration());
                } catch (Throwable ignored) { }
                return b;
            }

            @Override
            public long getCurrentPosition() {
                return position(getWrappedPlayer());   // the time bar shows where it's going
            }

            // Fast-forward / rewind buttons, media keys and the media session (15 s / 5 s steps)
            @Override
            public void seekForward() {
                if (!active()) { super.seekForward(); return; }
                seekTo(position(getWrappedPlayer()) + step());
            }

            @Override
            public void seekBack() {
                if (!active()) { super.seekBack(); return; }
                seekTo(Math.max(0, position(getWrappedPlayer()) - step()));
            }

            // "Previous" would jump to 0:00: not possible without reloading
            @Override
            public void seekToPrevious() {
                if (!active()) super.seekToPrevious();
            }

            @Override
            public void seekToPreviousMediaItem() {
                if (!active()) super.seekToPreviousMediaItem();
            }

            @Override
            public void seekToDefaultPosition() {
                if (!active()) super.seekToDefaultPosition();
            }
        };
    }

    // ------------------------------------------------------------------ extractor side

    /** Wraps the extractors of a linear link so the file counts as seekable (inside the buffer). */
    public static ExtractorsFactory factory(final ExtractorsFactory base) {
        return factory(base, true, false);
    }

    /**
     * @param linear  server can't seek: report the file as seekable for in-buffer jumps
     * @param dv7     "Dolby Vision profile 7 fallback": present DV profile 7/4 video as plain HEVC
     *                (its HDR10 base layer), so it goes to the normal HEVC hardware decoder
     */
    public static ExtractorsFactory factory(final ExtractorsFactory base, final boolean linear, final boolean dv7) {
        final Object[] ass = AssSubs.current();   // this player's libass handler (not a later player's)
        return new ExtractorsFactory() {
            @Override
            public Extractor[] createExtractors() {
                return wrapAll(AssSubs.extractors(base.createExtractors(), linear, ass), linear, dv7);
            }

            @Override
            public Extractor[] createExtractors(Uri uri, Map<String, List<String>> responseHeaders) {
                return wrapAll(AssSubs.extractors(base.createExtractors(uri, responseHeaders), linear, ass), linear, dv7);
            }

            @Override
            public ExtractorsFactory experimentalSetTextTrackTranscodingEnabled(boolean enabled) {
                base.experimentalSetTextTrackTranscodingEnabled(enabled);
                return this;
            }

            @Override
            public ExtractorsFactory setSubtitleParserFactory(SubtitleParser.Factory f) {
                base.setSubtitleParserFactory(f);
                return this;
            }

            @Override
            public ExtractorsFactory experimentalSetCodecsToParseWithinGopSampleDependencies(int codecFlags) {
                base.experimentalSetCodecsToParseWithinGopSampleDependencies(codecFlags);
                return this;
            }

            @Override
            public ExtractorsFactory setParseHagcMetadata(boolean parse) {
                base.setParseHagcMetadata(parse);
                return this;
            }
        };
    }

    private static Extractor[] wrapAll(Extractor[] in, boolean linear, boolean dv7) {
        Extractor[] out = new Extractor[in.length];
        for (int i = 0; i < in.length; i++) out[i] = new Wrapped(in[i], linear, dv7);
        return out;
    }

    /** DV profile 7 (UHD Blu-ray dual layer) or 4: the base layer is ordinary HDR10 HEVC. */
    static boolean isDvBaseLayerHevc(androidx.media3.common.Format f) {
        if (f == null || !androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType) || f.codecs == null) return false;
        String c = f.codecs.toLowerCase(java.util.Locale.US);
        return c.startsWith("dvhe.07") || c.startsWith("dvh1.07") || c.startsWith("dvhe.04") || c.startsWith("dvh1.04");
    }

    private static final class Dv7Track implements TrackOutput {
        private final TrackOutput t;
        private final boolean mapDv7;
        /** "Dolby Vision profile 7 → profile 8": samples are collected and rewritten. */
        private boolean convert;
        /** Profile 7 → HDR10 base layer: the enhancement layer units are removed. */
        private boolean stripEl;
        private byte[] buf = new byte[1 << 20];
        private int bufLen;

        Dv7Track(TrackOutput t, boolean mapDv7) { this.t = t; this.mapDv7 = mapDv7; }

        @Override
        public void format(androidx.media3.common.Format format) {
            convert = false;
            stripEl = false;
            // No Dolby Vision decoder on this device (tablet): profile 7 can only play as its HDR10
            // base layer, whatever the settings say (otherwise no decoder is found: black screen).
            final boolean noDv = !Dovi78.deviceHasDvDecoder();
            if (Dovi78.enabled && Dovi78.isProfile7(format.codecs) && !noDv) {
                convert = true;
                Dovi78.active = true;
                Dovi78.resetCounters();
                String to = Dovi78.profile8Codecs(format.codecs);
                Diag.log("Dolby Vision " + format.codecs + " → " + to + " (profile 7 converted to profile 8.1)");
                format = format.buildUpon().setCodecs(to).build();
            } else if ((mapDv7 || Dovi78.fallbackHdr10 || noDv) && isDvBaseLayerHevc(format)) {
                Diag.log("Dolby Vision " + format.codecs + " → HDR10 base layer (HEVC Main 10)");
                // the enhancement layer is removed (some HEVC decoders choke on it); the RPU
                // units are ignored by the HEVC decoder
                stripEl = true;
                format = format.buildUpon()
                        .setSampleMimeType(androidx.media3.common.MimeTypes.VIDEO_H265)
                        .setCodecs("hvc1.2.4.L153.B0")
                        .build();
            }
            t.format(format);
        }

        private void ensure(int more) {
            if (bufLen + more > buf.length) buf = java.util.Arrays.copyOf(buf, Math.max(buf.length * 2, bufLen + more));
        }

        /** Pieces of the current sample in order: {part, start, length} (main data, supplemental data …). */
        private final java.util.ArrayList<int[]> segs = new java.util.ArrayList<>();

        private void added(int part, int start, int len) {
            int[] last = segs.isEmpty() ? null : segs.get(segs.size() - 1);
            if (last != null && last[0] == part && last[1] + last[2] == start) last[2] += len;
            else segs.add(new int[] {part, start, len});
        }

        @Override public void durationUs(long durationUs) { t.durationUs(durationUs); }

        void clear() { bufLen = 0; segs.clear(); }

        @Override
        public int sampleData(androidx.media3.common.DataReader input, int length, boolean allowEndOfInput) throws IOException {
            return sampleData(input, length, allowEndOfInput, SAMPLE_DATA_PART_MAIN);
        }

        @Override
        public int sampleData(androidx.media3.common.DataReader input, int length, boolean allowEndOfInput, int sampleDataPart) throws IOException {
            if (!convert && !stripEl) return t.sampleData(input, length, allowEndOfInput, sampleDataPart);
            ensure(length);
            int r = input.read(buf, bufLen, length);
            if (r == C.RESULT_END_OF_INPUT) {
                if (allowEndOfInput) return C.RESULT_END_OF_INPUT;
                throw new java.io.EOFException();
            }
            added(sampleDataPart, bufLen, r);
            bufLen += r;
            return r;
        }

        @Override
        public void sampleData(androidx.media3.common.util.ParsableByteArray data, int length) {
            sampleData(data, length, SAMPLE_DATA_PART_MAIN);
        }

        @Override
        public void sampleData(androidx.media3.common.util.ParsableByteArray data, int length, int sampleDataPart) {
            if (!convert && !stripEl) {
                t.sampleData(data, length, sampleDataPart);
                return;
            }
            ensure(length);
            data.readBytes(buf, bufLen, length);
            added(sampleDataPart, bufLen, length);
            bufLen += length;
        }

        private void writeRaw(int from, int to) {
            // pieces as they came (parts kept)
            for (int[] sg : segs) {
                int st = Math.max(sg[1], from), en = Math.min(sg[1] + sg[2], to);
                if (en > st) t.sampleData(new androidx.media3.common.util.ParsableByteArray(java.util.Arrays.copyOfRange(buf, st, en)), en - st, sg[0]);
            }
        }

        @Override
        public void sampleMetadata(long timeUs, int flags, int size, int offset, CryptoData cryptoData) {
            if (!convert && !stripEl) {
                t.sampleMetadata(timeUs, flags, size, offset, cryptoData);
                return;
            }
            int end = bufLen - offset;
            int start = end - size;
            boolean simple = offset == 0 && start == 0 && cryptoData == null;
            int mainCount = 0;
            for (int[] sg : segs) if (sg[0] == SAMPLE_DATA_PART_MAIN) mainCount++;
            byte[] conv = null;
            int[] main = null;
            if (simple && mainCount == 1) {
                for (int[] sg : segs) if (sg[0] == SAMPLE_DATA_PART_MAIN) main = sg;
                try {
                    conv = convert ? Dovi78.convertAccessUnit(buf, main[1], main[2])
                            : Dovi78.stripEnhancementLayer(buf, main[1], main[2]);
                } catch (Throwable e) {
                    conv = null;
                }
            }
            if (conv == null) {
                writeRaw(Math.max(0, start), end);
                t.sampleMetadata(timeUs, flags, size, offset, cryptoData);
            } else {
                // Matroska with BlockAdditions: [main size, 4 bytes, supplemental] [main] [supplemental]
                boolean sizePrefix = (flags & C.BUFFER_FLAG_HAS_SUPPLEMENTAL_DATA) != 0;
                int newSize = 0;
                for (int[] sg : segs) {
                    if (sg == main) {
                        t.sampleData(new androidx.media3.common.util.ParsableByteArray(conv), conv.length, SAMPLE_DATA_PART_MAIN);
                        newSize += conv.length;
                        continue;
                    }
                    byte[] piece = java.util.Arrays.copyOfRange(buf, sg[1], sg[1] + sg[2]);
                    if (sizePrefix && sg[0] == SAMPLE_DATA_PART_SUPPLEMENTAL && sg[2] == 4 && segs.indexOf(sg) < segs.indexOf(main)) {
                        int n = conv.length;
                        piece = new byte[] {(byte) (n >>> 24), (byte) (n >>> 16), (byte) (n >>> 8), (byte) n};
                    }
                    t.sampleData(new androidx.media3.common.util.ParsableByteArray(piece), piece.length, sg[0]);
                    newSize += piece.length;
                }
                t.sampleMetadata(timeUs, flags, newSize, 0, cryptoData);
            }
            System.arraycopy(buf, end, buf, 0, offset);
            bufLen = offset;
            segs.clear();
            if (offset > 0) segs.add(new int[] {SAMPLE_DATA_PART_MAIN, 0, offset});
        }
    }

    /**
     * Keyframe times seen in the downloaded video, for the seek map of files without an index.
     * A keyframe after the target is offered only if audio and video are both downloaded past it.
     */
    private static final class Keyframes {
        private long[] times = new long[4096];
        private int count;
        private long videoEnd = Long.MIN_VALUE, audioEnd = Long.MIN_VALUE;
        private boolean hasAudio;

        synchronized void clear() {
            count = 0;
            videoEnd = audioEnd = Long.MIN_VALUE;
        }

        synchronized void add(long t, boolean key, boolean video) {
            if (video) {
                videoEnd = Math.max(videoEnd, t);
                if (!key) return;
                if (count > 0 && t <= times[count - 1]) return;   // keep it sorted
                if (count == times.length) {
                    System.arraycopy(times, times.length / 2, times, 0, times.length - times.length / 2);
                    count = times.length - times.length / 2;
                }
                times[count++] = t;
            } else {
                hasAudio = true;
                audioEnd = Math.max(audioEnd, t);
            }
        }

        synchronized SeekMap.SeekPoints around(long timeUs) {
            int lo = 0, hi = count - 1, before = -1;
            while (lo <= hi) {
                int mid = (lo + hi) >>> 1;
                if (times[mid] <= timeUs) { before = mid; lo = mid + 1; } else hi = mid - 1;
            }
            if (before < 0) return new SeekMap.SeekPoints(new SeekPoint(timeUs, 0));
            long first = times[before];
            long limit = (hasAudio ? Math.min(videoEnd, audioEnd) : videoEnd) - 500_000;
            long second = before + 1 < count && times[before + 1] <= limit ? times[before + 1] : timeUs;
            if (first == timeUs || second == first) return new SeekMap.SeekPoints(new SeekPoint(first, 0));
            return new SeekMap.SeekPoints(new SeekPoint(first, 0), new SeekPoint(second, 0));
        }

        TrackOutput track(final TrackOutput t, final boolean video) {
            return new TrackOutput() {
                @Override public void format(androidx.media3.common.Format f) { t.format(f); }
                @Override public void durationUs(long d) { t.durationUs(d); }
                @Override public int sampleData(androidx.media3.common.DataReader in, int len, boolean eoi) throws IOException {
                    return t.sampleData(in, len, eoi);
                }
                @Override public int sampleData(androidx.media3.common.DataReader in, int len, boolean eoi, int part) throws IOException {
                    return t.sampleData(in, len, eoi, part);
                }
                @Override public void sampleData(androidx.media3.common.util.ParsableByteArray d, int len) { t.sampleData(d, len); }
                @Override public void sampleData(androidx.media3.common.util.ParsableByteArray d, int len, int part) { t.sampleData(d, len, part); }
                @Override
                public void sampleMetadata(long timeUs, int flags, int size, int offset, CryptoData crypto) {
                    t.sampleMetadata(timeUs, flags, size, offset, crypto);
                    add(timeUs, (flags & C.BUFFER_FLAG_KEY_FRAME) != 0, video);
                }
            };
        }
    }

    private static final class Wrapped implements Extractor {
        private final Extractor e;
        private final boolean linear, dv7;

        Wrapped(Extractor e, boolean linear, boolean dv7) { this.e = e; this.linear = linear; this.dv7 = dv7; }

        @Override public boolean sniff(ExtractorInput input) throws IOException { return e.sniff(input); }
        @Override public List<SniffFailure> getSniffFailureDetails() { return e.getSniffFailureDetails(); }
        @Override public int read(ExtractorInput input, PositionHolder seekPosition) throws IOException { return e.read(input, seekPosition); }
        private final java.util.List<Dv7Track> dvTracks = new java.util.ArrayList<>();
        /** Keyframes of the video track (stream time, µs) and how far each A/V track got. */
        private final Keyframes keys = new Keyframes();

        @Override public void seek(long position, long timeUs) {
            for (Dv7Track d : dvTracks) d.clear();   // half-collected samples belong to the old position
            keys.clear();
            e.seek(position, timeUs);
        }
        @Override public void release() { e.release(); }
        @Override public Extractor getUnderlyingImplementation() { return e.getUnderlyingImplementation(); }

        @Override
        public void init(final ExtractorOutput output) {
            noIndex = false;
            e.init(new ExtractorOutput() {
                @Override public TrackOutput track(int id, int type) {
                    TrackOutput t = output.track(id, type);
                    if ((dv7 || Dovi78.enabled || Dovi78.fallbackHdr10 || !Dovi78.deviceHasDvDecoder()) && type == C.TRACK_TYPE_VIDEO) {
                        Dv7Track d = new Dv7Track(t, dv7);
                        dvTracks.add(d);
                        t = d;
                    }
                    if (type == C.TRACK_TYPE_VIDEO || type == C.TRACK_TYPE_AUDIO) t = keys.track(t, type == C.TRACK_TYPE_VIDEO);
                    return t;
                }
                @Override public void endTracks() { output.endTracks(); }

                @Override
                public void seekMap(final SeekMap map) {
                    if (map.isSeekable()) {
                        noIndex = false;
                        output.seekMap(map);
                        return;
                    }
                    // no index: ExoPlayer would restart every seek from 0:00; report it seekable so
                    // jumps inside the buffer work (all seeks are kept inside, see clamp)
                    noIndex = !linear;
                    if (noIndex) Diag.log("No index in the file: seeking only inside the buffer");
                    output.seekMap(new SeekMap() {
                        @Override public boolean isSeekable() { return true; }
                        @Override public long getDurationUs() { return map.getDurationUs(); }
                        @Override public boolean isEstimated() { return false; }

                        @Override
                        public SeekPoints getSeekPoints(long timeUs) {
                            // Only used for jumps inside the buffer. The keyframes around the
                            // target let the player land on one (the picture appears at once,
                            // instead of the decoder catching up while the sound already plays).
                            // on the USB drive buffer: the MKV clusters already downloaded
                            SeekPoints drive = linear ? UsbBuffer.seekPoints(timeUs) : null;
                            return drive != null ? drive : keys.around(timeUs);
                        }
                    });
                }
            });
        }
    }

    static long unset() { return C.TIME_UNSET; }
}
