package com.brouken.player;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * What the player shows when no video is open (instead of a black screen): the background
 * picture, a glass panel with Open link / Open file / Saved links / Settings, and "Continue
 * watching" with the videos you stopped in the middle of.
 *
 * Only exists while nothing plays: opening a video removes it and frees the picture's memory,
 * so playback uses exactly the same resources as before.
 */
final class StartScreen {

    private StartScreen() {}

    private static FrameLayout shown;
    private static Runnable openFile, openSettings;

    static void setup(PlayerActivity a, Runnable openFile, Runnable openSettings) {
        StartScreen.openFile = openFile;
        StartScreen.openSettings = openSettings;
    }

    static boolean isShown() {
        return shown != null && shown.getParent() != null;
    }

    /** After the player was (re)created: shown without a video, gone with one. */
    static void sync(PlayerActivity a) {
        try {
            if (PlayerActivity.haveMedia) hide(a);
            else show(a);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    static void hide(PlayerActivity a) {
        if (shown != null) {
            ViewGroup p = (ViewGroup) shown.getParent();
            if (p != null) p.removeView(shown);
            shown = null;
            if (a.playerView != null) a.playerView.setUseController(true);
        }
        Backdrop.releaseSharp();
    }

    static void show(final PlayerActivity a) {
        ViewGroup content = a.findViewById(android.R.id.content);
        if (content == null) return;
        if (shown != null && shown.getParent() != null) ((ViewGroup) shown.getParent()).removeView(shown);
        Backdrop.init(a);
        if (a.playerView != null) {
            a.playerView.hideController();
            a.playerView.setUseController(false);
        }
        shown = build(a);
        content.addView(shown, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final View first = shown.findViewWithTag("first");
        if (first != null) first.post(first::requestFocus);
    }

    private static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    private static FrameLayout build(final PlayerActivity a) {
        FrameLayout root = new FrameLayout(a);
        root.setBackground(new BackdropDrawable(root));
        root.setClickable(true);   // touches don't reach the empty player underneath

        boolean wide = a.getResources().getDisplayMetrics().widthPixels >= a.getResources().getDisplayMetrics().heightPixels;
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(a, 40), dp(a, 28), dp(a, 40), dp(a, 28));
        root.addView(row, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- the main panel
        LinearLayout hero = panel(a);
        LinearLayout top = new LinearLayout(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(a);
        icon.setImageResource(R.drawable.gamma_icon);
        top.addView(icon, new LinearLayout.LayoutParams(dp(a, 60), dp(a, 60)));
        LinearLayout names = new LinearLayout(a);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(a, a.getString(R.string.app_name), 30, 0xFFEAFFF6);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        names.addView(title);
        names.addView(text(a, "Paste or pick a link to start watching", 14, 0xFFC8E6DB));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.leftMargin = dp(a, 16);
        top.addView(names, nlp);
        hero.addView(top);

        int saved = SavedLinksActivity.load(a).size();
        View open = action(a, R.drawable.ic_g_link, "Open link", "", true, () -> {
            Intent i = new Intent();
            i.setClassName(a, "com.brouken.player.PasteUrlActivity");
            i.putExtra("dialog", true);
            a.startActivity(i);
        });
        open.setTag("first");
        addAction(a, hero, open, 22);
        addAction(a, hero, action(a, R.drawable.ic_g_bookmark, "Saved links", saved > 0 ? String.valueOf(saved) : "", false,
                () -> a.startActivity(new Intent(a, SavedLinksActivity.class))), 10);
        addAction(a, hero, action(a, R.drawable.ic_g_folder, "Open file", "", false, () -> { if (openFile != null) openFile.run(); }), 10);
        addAction(a, hero, action(a, R.drawable.ic_g_gear, "Settings", "", false, () -> { if (openSettings != null) openSettings.run(); }), 10);

        LinearLayout.LayoutParams hlp = wide
                ? new LinearLayout.LayoutParams(dp(a, 400), ViewGroup.LayoutParams.WRAP_CONTENT)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        row.addView(hero, hlp);

        // ---- continue watching
        List<ResumePoints.Entry> recent = continueList(a);
        if (!recent.isEmpty()) {
            View gap = new View(a);
            row.addView(gap, wide ? new LinearLayout.LayoutParams(0, 1, 1) : new LinearLayout.LayoutParams(1, dp(a, 20)));
            LinearLayout cw = panel(a);
            TextView h = text(a, "CONTINUE WATCHING", 13, 0xFFBFFFE2);
            h.setLetterSpacing(0.14f);
            cw.addView(h);
            java.util.Map<String, String> names2 = savedNames(a);
            for (int i = 0; i < recent.size(); i++) {
                final ResumePoints.Entry e = recent.get(i);
                View card = card(a, e, names2.get(SavedLinksActivity.key(e.uri)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = dp(a, i == 0 ? 14 : 8);
                cw.addView(card, lp);
            }
            row.addView(cw, wide ? new LinearLayout.LayoutParams(dp(a, 420), ViewGroup.LayoutParams.WRAP_CONTENT)
                    : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return root;
    }

    private static LinearLayout panel(Context c) {
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(c, 24), dp(c, 22), dp(c, 24), dp(c, 22));
        p.setBackground(new GlassDrawable(p, 24));
        p.setElevation(dp(c, 14));
        p.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        return p;
    }

    private static void addAction(Context c, LinearLayout box, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 52));
        lp.topMargin = dp(c, topDp);
        box.addView(v, lp);
    }

    private static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setShadowLayer(dp(c, 2), 0, dp(c, 1) / 2f, 0x80000000);
        return t;
    }

    private static View action(Context c, int icon, String label, String hint, boolean primary, final Runnable run) {
        LinearLayout b = new LinearLayout(c);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(c, 16), 0, dp(c, 18), 0);
        b.setBackgroundResource(primary ? R.drawable.glass_button_primary : R.drawable.glass_row);
        b.setFocusable(true);
        b.setClickable(true);
        ImageView i = new ImageView(c);
        i.setImageResource(icon);
        b.addView(i, new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22)));
        TextView t = text(c, label, 17, primary ? 0xFFD6FFEC : 0xFFEAFFF6);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tl.leftMargin = dp(c, 14);
        b.addView(t, tl);
        if (!hint.isEmpty()) b.addView(text(c, hint, 13, 0xFFA9CCBF));
        b.setOnClickListener(v -> run.run());
        return b;
    }

    /** Unfinished videos from links (the newest three). */
    private static List<ResumePoints.Entry> continueList(Context c) {
        List<ResumePoints.Entry> out = new java.util.ArrayList<>();
        for (ResumePoints.Entry e : ResumePoints.all(c)) {
            if (!PasteUrlActivity.isValid(e.uri)) continue;
            out.add(e);
            if (out.size() == 3) break;
        }
        return out;
    }

    private static java.util.Map<String, String> savedNames(Context c) {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        for (SavedLinksActivity.Link l : SavedLinksActivity.load(c)) m.put(SavedLinksActivity.key(l.url), l.name);
        return m;
    }

    private static View card(final Context c, final ResumePoints.Entry e, String savedName) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 14));
        card.setBackgroundResource(R.drawable.glass_row);
        card.setFocusable(true);
        card.setClickable(true);
        String name = savedName;
        if (name == null || name.trim().isEmpty()) {
            try { name = Titles.fromUrl(Uri.parse(e.uri)); } catch (Throwable ignored) { }
        }
        if (name == null || name.trim().isEmpty()) name = SavedLinksActivity.defaultName(e.uri);
        TextView n = text(c, name, 15, 0xFFEAFFF6);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(n);
        String d = ResumePoints.time(e.pos) + (e.dur > 0 ? " of " + ResumePoints.time(e.dur) : "");
        TextView dt = text(c, d, 12, 0xFFA9CCBF);
        card.addView(dt);
        if (e.dur > 0) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 6));
            lp.topMargin = dp(c, 8);
            card.addView(ResumePoints.glassBar(c, e.pos, e.dur), lp);
        }
        card.setOnClickListener(v -> {
            Intent i = new Intent(c, PasteUrlActivity.class);
            i.putExtra(PasteUrlActivity.EXTRA_URL, e.uri);   // the usual link check, then it asks Resume / Start over
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        });
        return card;
    }
}
