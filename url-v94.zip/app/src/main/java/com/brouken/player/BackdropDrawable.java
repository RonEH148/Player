package com.brouken.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * The background picture, filling the screen (window background of Settings and Saved links,
 * and the start screen). Drawn in screen coordinates, exactly like the glass maps it.
 */
public class BackdropDrawable extends Drawable {

    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();
    private final Rect src = new Rect();
    private final int[] loc = new int[2];
    private View host;

    public BackdropDrawable() { }

    BackdropDrawable(View host) {
        this.host = host;
    }

    private View view() {
        if (host != null) return host;
        Callback cb = getCallback();
        while (cb instanceof Drawable) cb = ((Drawable) cb).getCallback();
        return cb instanceof View ? (View) cb : null;
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        View v = view();
        Context ctx = v != null ? v.getContext() : null;
        Bitmap bm = ctx != null ? Backdrop.sharp(ctx) : null;
        if (bm == null) {
            c.drawColor(0xFF020605);
            return;
        }
        int[] scr = Backdrop.realScreen(ctx);
        v.getLocationOnScreen(loc);
        src.set(0, 0, bm.getWidth(), bm.getHeight());
        Backdrop.cover(dst, bm.getWidth(), bm.getHeight(), scr[0], scr[1], -loc[0], -loc[1]);
        c.drawColor(0xFF020605);
        c.drawBitmap(bm, src, dst, paint);
    }

    @Override public void setAlpha(int a) { paint.setAlpha(a); }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
