package com.brouken.player;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.SparseArray;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.preference.PreferenceCategory;
import androidx.preference.PreferenceGroupAdapter;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Settings: each section's rows sit on one raised glass card (drawn behind the rows), with thin
 * lines between the rows.
 */
final class GlassCards extends RecyclerView.ItemDecoration {

    private final RecyclerView list;
    private final float d;
    private final Paint line = new Paint();
    private final SparseArray<GlassDrawable> cards = new SparseArray<>();
    private final SparseArray<Rect> bounds = new SparseArray<>();
    private final SparseArray<boolean[]> ends = new SparseArray<>();

    GlassCards(RecyclerView list) {
        this.list = list;
        d = list.getResources().getDisplayMetrics().density;
        line.setColor(0x17FFFFFF);
        line.setStrokeWidth(Math.max(1f, d * 0.75f));
    }

    private Object item(int pos) {
        RecyclerView.Adapter<?> a = list.getAdapter();
        if (!(a instanceof PreferenceGroupAdapter) || pos < 0 || pos >= a.getItemCount()) return null;
        return ((PreferenceGroupAdapter) a).getItem(pos);
    }

    private boolean isCategory(int pos) {
        return item(pos) instanceof PreferenceCategory;
    }

    /** Position of the section heading this row belongs to (-1: before any heading). */
    private int group(int pos) {
        for (int p = pos; p >= 0; p--) if (isCategory(p)) return p;
        return -1;
    }

    @Override
    public void getItemOffsets(@NonNull Rect out, @NonNull View child, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        int pos = parent.getChildAdapterPosition(child);
        if (pos == RecyclerView.NO_POSITION || isCategory(pos)) return;
        int pad = Math.round(8 * d);
        out.left = pad;
        out.right = pad;
        if (pos == 0 || isCategory(pos - 1)) out.top = pad;
        RecyclerView.Adapter<?> a = parent.getAdapter();
        if (a != null && (pos + 1 >= a.getItemCount() || isCategory(pos + 1))) out.bottom = pad;
    }

    @Override
    public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        bounds.clear();
        ends.clear();
        int pad = Math.round(8 * d);
        RecyclerView.Adapter<?> a = parent.getAdapter();
        int count = a == null ? 0 : a.getItemCount();
        for (int i = 0; i < parent.getChildCount(); i++) {
            View v = parent.getChildAt(i);
            int pos = parent.getChildAdapterPosition(v);
            if (pos == RecyclerView.NO_POSITION || isCategory(pos)) continue;
            int g = group(pos);
            boolean first = pos == 0 || isCategory(pos - 1);
            boolean last = pos + 1 >= count || isCategory(pos + 1);
            int top = Math.round(v.getTop() + v.getTranslationY()) - (first ? pad : 0);
            int bottom = Math.round(v.getBottom() + v.getTranslationY()) + (last ? pad : 0);
            if (!first) top -= 1;
            Rect r = bounds.get(g);
            if (r == null) {
                r = new Rect(v.getLeft() - pad, first ? top : Math.min(top, -Math.round(40 * d)), v.getRight() + pad, bottom);
                bounds.put(g, r);
                ends.put(g, new boolean[]{first, last});
            } else {
                r.top = Math.min(r.top, top);
                r.bottom = Math.max(r.bottom, bottom);
                ends.get(g)[1] |= last;
            }
        }
        for (int k = 0; k < bounds.size(); k++) {
            int g = bounds.keyAt(k);
            Rect r = bounds.valueAt(k);
            if (!ends.get(g)[1]) r.bottom = Math.max(r.bottom, parent.getHeight() + Math.round(40 * d));
            GlassDrawable card = cards.get(g);
            if (card == null) {
                card = new GlassDrawable(parent, 20);
                cards.put(g, card);
            }
            if (!card.getBounds().equals(r)) card.setBounds(r);
            card.draw(c);
        }
        // lines go on top of the cards: draw them again
        for (int i = 0; i < parent.getChildCount(); i++) {
            View v = parent.getChildAt(i);
            int pos = parent.getChildAdapterPosition(v);
            if (pos <= 0 || pos == RecyclerView.NO_POSITION || isCategory(pos) || isCategory(pos - 1)) continue;
            float y = v.getTop() + v.getTranslationY();
            c.drawLine(v.getLeft() + 72 * d, y, v.getRight() - 16 * d, y, line);
        }
    }
}
