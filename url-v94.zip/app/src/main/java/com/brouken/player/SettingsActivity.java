package com.brouken.player;

import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;

public class SettingsActivity extends AppCompatActivity {

    static RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Gamma Player: light text on the background picture, so the status bar stays light-on-dark
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            );
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
        }
        Backdrop.init(this);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        View back = findViewById(R.id.settings_back);
        if (back != null) back.setOnClickListener(v -> finish());
        android.widget.TextView app = findViewById(R.id.settings_app);
        if (app != null) app.setText(getString(R.string.app_name) + " · " + BuildConfig.VERSION_NAME);

        if (Build.VERSION.SDK_INT >= 29) {
            LinearLayout layout = findViewById(R.id.settings_layout);
            layout.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                view.setPadding(windowInsets.getSystemWindowInsetLeft(),
                        windowInsets.getSystemWindowInsetTop(),
                        windowInsets.getSystemWindowInsetRight(),
                        0);
                if (recyclerView != null) {
                    recyclerView.setPadding(recyclerView.getPaddingLeft(), 0, recyclerView.getPaddingRight(), windowInsets.getSystemWindowInsetBottom() + Math.round(32 * getResources().getDisplayMetrics().density));
                }
                windowInsets.consumeSystemWindowInsets();
                return windowInsets;
            });
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        static final int REQUEST_BACKGROUND = 4713;

        @Override
        public void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQUEST_BACKGROUND) {
                if (resultCode == android.app.Activity.RESULT_OK && data != null && data.getData() != null && getActivity() != null) {
                    final android.app.Activity a = getActivity();
                    android.widget.Toast.makeText(a, "Preparing the background…", android.widget.Toast.LENGTH_SHORT).show();
                    Backdrop.setPicture(a, data.getData(), ok -> {
                        android.widget.Toast.makeText(a, ok ? "Background changed" : "Couldn't open that picture", android.widget.Toast.LENGTH_SHORT).show();
                        refreshLook();
                    });
                }
                return;
            }
            if (requestCode == UsbBuffer.REQUEST_PICK && resultCode == android.app.Activity.RESULT_OK && data != null && getActivity() != null) {
                final Preference usbTest = findPreference(UsbBuffer.KEY_TEST);
                final Preference usbSaved = findPreference("usbSaved");
                final UsbBuffer.Done then = UsbBuffer.afterPick;
                UsbBuffer.afterPick = null;
                UsbBuffer.onPicked(getActivity(), data.getData(), ok -> {
                    if (usbTest != null) usbTest.setSummary(UsbBuffer.testSummary(getContext()));
                    if (usbSaved != null) usbSaved.setSummary(UsbBuffer.savedSummary(getContext()));
                    if (then != null) then.done(ok);
                });
            }
        }

        @Override
        public void onDestroy() {
            UsbBuffer.pickHook = null;
            super.onDestroy();
        }

        /** Gamma Player look: glass rows, section headings, the glass slider. */
        private static void glassLayouts(androidx.preference.PreferenceGroup g) {
            for (int i = 0; i < g.getPreferenceCount(); i++) {
                Preference p = g.getPreference(i);
                if (p instanceof androidx.preference.PreferenceCategory) {
                    p.setLayoutResource(R.layout.glass_pref_category);
                    glassLayouts((androidx.preference.PreferenceGroup) p);
                } else if (p instanceof androidx.preference.SeekBarPreference) {
                    p.setLayoutResource(R.layout.glass_pref_seekbar);
                } else {
                    p.setLayoutResource(R.layout.glass_pref);
                    if (p instanceof androidx.preference.PreferenceGroup) glassLayouts((androidx.preference.PreferenceGroup) p);
                }
                p.setIconSpaceReserved(true);
            }
        }

        /** The picture or the glass opacity changed: redraw this screen. */
        private void refreshLook() {
            android.app.Activity a = getActivity();
            if (a == null) return;
            a.getWindow().getDecorView().invalidate();
            RecyclerView l = getListView();
            if (l != null) l.invalidate();
            Preference bg = findPreference("backgroundImage");
            if (bg != null) bg.setSummary(Backdrop.summary(a));
        }

        private void pickBackground() {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            android.content.pm.PackageManager pm = requireContext().getPackageManager();
            if (pm.queryIntentActivities(i, 0).isEmpty()) {
                // TV without the system picker: a file manager / gallery
                i = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
                i.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                i = android.content.Intent.createChooser(i, "Choose a picture");
            }
            try {
                startActivityForResult(i, REQUEST_BACKGROUND);
            } catch (Exception e) {
                android.widget.Toast.makeText(getContext(), "No app to choose a picture with. Install a file manager or gallery.", android.widget.Toast.LENGTH_LONG).show();
            }
        }

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            glassLayouts(getPreferenceScreen());

            // Gamma Player: background picture and glass opacity
            final Preference bgPref = findPreference("backgroundImage");
            if (bgPref != null) {
                bgPref.setSummary(Backdrop.summary(requireContext()));
                bgPref.setOnPreferenceClickListener(p -> {
                    if (getActivity() == null) return true;
                    if (!Backdrop.hasOwnPicture(getActivity())) {
                        pickBackground();
                        return true;
                    }
                    new android.app.AlertDialog.Builder(getActivity())
                            .setTitle("Background image")
                            .setItems(new String[]{"Choose another picture", "Use the built-in background"}, (d, w) -> {
                                if (w == 0) pickBackground();
                                else {
                                    Backdrop.useDefault(getActivity());
                                    refreshLook();
                                }
                            })
                            .show();
                    return true;
                });
            }
            Preference opacityPref = findPreference(Backdrop.KEY_OPACITY);
            if (opacityPref != null) {
                opacityPref.setOnPreferenceChangeListener((p, v) -> {
                    if (v instanceof Integer) Backdrop.setOpacity((Integer) v);
                    refreshLook();
                    return true;
                });
            }

            Preference preferenceUpdate = findPreference("urlUpdate");
            if (preferenceUpdate != null) {
                preferenceUpdate.setSummary(BuildConfig.VERSION_NAME
                        + (BuildConfig.URL_BUILD > 0 ? " · build " + BuildConfig.URL_BUILD : "")
                        + "\nFrom github.com/" + BuildConfig.UPDATE_REPO);
                preferenceUpdate.setOnPreferenceClickListener(p -> {
                    if (getActivity() != null) Updater.check(getActivity(), true);
                    return true;
                });
            }

            // URL build: USB drive as buffer
            UsbBuffer.pickHook = () -> UsbBuffer.pick(this);
            final Preference usbTest = findPreference(UsbBuffer.KEY_TEST);
            final androidx.preference.SwitchPreferenceCompat usbSwitch = findPreference(UsbBuffer.KEY);
            if (usbTest != null) {
                usbTest.setSummary(UsbBuffer.testSummary(getContext()));
                usbTest.setOnPreferenceClickListener(p -> {
                    if (getActivity() != null) UsbBuffer.test(getActivity(), ok -> usbTest.setSummary(UsbBuffer.testSummary(getContext())));
                    return true;
                });
            }
            final Preference usbSaved = findPreference("usbSaved");
            if (usbSaved != null) {
                usbSaved.setSummary(UsbBuffer.savedSummary(getContext()));
                usbSaved.setOnPreferenceClickListener(p -> {
                    if (getActivity() != null) UsbBuffer.manageSaved(getActivity(), () -> usbSaved.setSummary(UsbBuffer.savedSummary(getContext())));
                    return true;
                });
            }
            if (usbSwitch != null) {
                usbSwitch.setOnPreferenceChangeListener((p, value) -> getActivity() == null || UsbBuffer.onSwitch(getActivity(),
                        Boolean.TRUE.equals(value),
                        () -> usbSwitch.setChecked(true),
                        () -> { if (usbTest != null) usbTest.setSummary(UsbBuffer.testSummary(getContext())); }));
            }

            Preference preferenceIvtc = findPreference(Ivtc.KEY_CONFIG);
            if (preferenceIvtc != null) {
                IvtcSettings.summary(preferenceIvtc);
                preferenceIvtc.setOnPreferenceClickListener(p -> {
                    if (getActivity() != null) IvtcSettings.edit(getActivity(), preferenceIvtc);
                    return true;
                });
            }

            Preference preferenceAutoPiP = findPreference("autoPiP");
            if (preferenceAutoPiP != null) {
                preferenceAutoPiP.setEnabled(Utils.isPiPSupported(this.getContext()));
            }
            Preference preferenceFrameRateMatching = findPreference("frameRateMatching");
            if (preferenceFrameRateMatching != null) {
                preferenceFrameRateMatching.setEnabled(Build.VERSION.SDK_INT >= 23);
            }
            ListPreference listPreferenceFileAccess = findPreference("fileAccess");
            if (listPreferenceFileAccess != null) {
                List<String> entries = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.file_access_entries)));
                List<String> values = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.file_access_values)));
                if (Build.VERSION.SDK_INT < 30) {
                    int index = values.indexOf("mediastore");
                    entries.remove(index);
                    values.remove(index);
                }
                if (!Utils.hasSAFChooser(getContext().getPackageManager())) {
                    int index = values.indexOf("saf");
                    entries.remove(index);
                    values.remove(index);
                }
                listPreferenceFileAccess.setEntries(entries.toArray(new String[0]));
                listPreferenceFileAccess.setEntryValues(values.toArray(new String[0]));
            }

            ListPreference listPreferenceLanguageAudio = findPreference("languageAudio");
            if (listPreferenceLanguageAudio != null) {
                LinkedHashMap<String, String> entries = new LinkedHashMap<>();
                entries.put(Prefs.TRACK_DEFAULT, getString(R.string.pref_language_track_default));
                entries.put(Prefs.TRACK_DEVICE, getString(R.string.pref_language_track_device));
                entries.putAll(getLanguages());
                listPreferenceLanguageAudio.setEntries(entries.values().toArray(new String[0]));
                listPreferenceLanguageAudio.setEntryValues(entries.keySet().toArray(new String[0]));
            }
        }

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);
            // Gamma Player: sections on glass cards, centred, not too wide on the TV
            setDivider(null);
            setDividerHeight(0);
            final RecyclerView l = getListView();
            if (l != null) {
                l.setBackground(null);
                l.setClipToPadding(false);
                l.addItemDecoration(new GlassCards(l));
                final float d = getResources().getDisplayMetrics().density;
                l.addOnLayoutChangeListener((v, a, b, c, e, oa, ob, oc, oe) -> {
                    int w = v.getWidth();
                    int side = Math.max(Math.round(28 * d), (w - Math.round(860 * d)) / 2);
                    if (v.getPaddingLeft() != side) v.setPadding(side, v.getPaddingTop(), side, Math.max(v.getPaddingBottom(), Math.round(32 * d)));
                });
            }
            if (Build.VERSION.SDK_INT >= 29) {
                recyclerView = getListView();
            }
        }

        LinkedHashMap<String, String> getLanguages() {
            LinkedHashMap<String, String> languages = new LinkedHashMap<>();
            for (Locale locale : Locale.getAvailableLocales()) {
                try {
                    // MissingResourceException: Couldn't find 3-letter language code for zz
                    String key = locale.getISO3Language();
                    String language = locale.getDisplayLanguage();
                    int length = language.offsetByCodePoints(0, 1);
                    if (!language.isEmpty()) {
                        language = language.substring(0, length).toUpperCase(locale) + language.substring(length);
                    }
                    String value = language + " [" + key + "]";
                    languages.put(key, value);
                } catch (MissingResourceException e) {
                    e.printStackTrace();
                }
            }
            Collator collator = Collator.getInstance();
            collator.setStrength(Collator.PRIMARY);
            Utils.orderByValue(languages, collator::compare);
            return languages;
        }
    }
}