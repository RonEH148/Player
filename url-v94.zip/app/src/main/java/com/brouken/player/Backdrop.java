package com.brouken.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Gamma Player's background picture (yours, or the built-in one) behind the start screen,
 * Settings, Saved links and the dialogs.
 *
 * Kept light for the TV: the picture is shrunk to the screen size once, and a tiny blurred copy
 * (1/12 of the screen) is made once and saved. The glass panels just show the matching part of
 * that copy, stretched smoothly – it looks like live frosted glass but costs almost nothing.
 * The full picture is only in memory while a menu is open; a playing video releases it.
 */
final class Backdrop {

    private Backdrop() {}

    static final String KEY_OPACITY = "glassOpacity";
    static final String KEY_PICKED = "backgroundPicked";
    static final int DEFAULT_OPACITY = 35;
    private static final int BLUR_DIV = 12;

    private static Context app;
    private static Bitmap sharp, blur;
    private static int screenW, screenH;
    /** Darkness of the glass, 0..255 (from the "Glass opacity" slider). */
    static int tintAlpha = -1;
    /** Bumped when the picture changes, so open screens redraw. */
    static int version;

    static void init(Context c) {
        if (app == null) app = c.getApplicationContext();
        if (screenW == 0) {
            try {
                DisplayMetrics dm = new DisplayMetrics();
                WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
                wm.getDefaultDisplay().getRealMetrics(dm);
                screenW = Math.max(dm.widthPixels, dm.heightPixels);
                screenH = Math.min(dm.widthPixels, dm.heightPixels);
            } catch (Throwable t) {
                screenW = 1920;
                screenH = 1080;
            }
            // the picture never needs more than 1080p: the TV draws its menus at that size anyway
            if (screenW > 1920) {
                screenH = screenH * 1920 / screenW;
                screenW = 1920;
            }
        }
        if (tintAlpha < 0) setOpacity(opacity(app));
    }

    static int screenW() { return screenW; }
    static int screenH() { return screenH; }

    /** Real screen size (for mapping a panel's position onto the picture). */
    private static int[] real;
    private static int realOrientation;

    static int[] realScreen(Context c) {
        int o = c.getResources().getConfiguration().orientation;
        if (real != null && o == realOrientation) return real;
        realOrientation = o;
        real = measureScreen(c);
        return real;
    }

    /**
     * Where a picture of size bw×bh goes so it covers the screen (center-cropped), with the
     * screen's top-left at (ox, oy). The same for the picture and its blurred copy, so the glass
     * always shows what's really behind it.
     */
    static void cover(android.graphics.RectF out, int bw, int bh, int sw, int sh, float ox, float oy) {
        float scale = Math.max(sw / (float) bw, sh / (float) bh);
        float w = bw * scale, h = bh * scale;
        float l = ox + (sw - w) / 2f, t = oy + (sh - h) / 2f;
        out.set(l, t, l + w, t + h);
    }

    /** Rotation (tablet): measured again. */
    static void screenChanged() {
        real = null;
    }

    private static int[] measureScreen(Context c) {
        DisplayMetrics dm = new DisplayMetrics();
        try {
            ((WindowManager) c.getApplicationContext().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
            return new int[]{dm.widthPixels, dm.heightPixels};
        } catch (Throwable t) {
            DisplayMetrics d = c.getResources().getDisplayMetrics();
            return new int[]{d.widthPixels, d.heightPixels};
        }
    }

    static int opacity(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getInt(KEY_OPACITY, DEFAULT_OPACITY);
    }

    static void setOpacity(int percent) {
        int p = Math.max(0, Math.min(100, percent));
        tintAlpha = Math.round(p * 2.55f);
    }

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "theme");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    static boolean hasOwnPicture(Context c) {
        return new File(dir(c), "bg.jpg").exists();
    }

    /** The full picture, screen-sized (menus only). */
    static synchronized Bitmap sharp(Context c) {
        init(c);
        if (sharp == null) loadSharp(c);
        return sharp;
    }

    /** The tiny blurred copy the glass shows. */
    static synchronized Bitmap blur(Context c) {
        init(c);
        if (blur == null) loadBlur(c);
        return blur;
    }

    /** A video is playing: the full picture isn't needed until the next menu. */
    static synchronized void releaseSharp() {
        sharp = null;
    }

    private static void loadSharp(Context c) {
        File own = new File(dir(c), "bg.jpg");
        try {
            if (own.exists()) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inPreferredConfig = Bitmap.Config.ARGB_8888;
                sharp = BitmapFactory.decodeFile(own.getPath(), o);
            }
        } catch (Throwable t) {
            sharp = null;
        }
        if (sharp == null) sharp = fit(decodeDefault(c));
    }

    private static void loadBlur(Context c) {
        File ownBlur = new File(dir(c), "blur.png");
        File defBlur = new File(dir(c), "default_blur.png");
        File f = hasOwnPicture(c) ? ownBlur : defBlur;
        try {
            if (f.exists()) blur = BitmapFactory.decodeFile(f.getPath());
        } catch (Throwable t) {
            blur = null;
        }
        if (blur != null) return;
        Bitmap src = sharp != null ? sharp : (hasOwnPicture(c) ? null : fit(decodeDefault(c)));
        if (src == null) {
            try { src = BitmapFactory.decodeFile(new File(dir(c), "bg.jpg").getPath()); } catch (Throwable ignored) { }
        }
        if (src == null) return;
        blur = makeBlur(src);
        save(blur, f, Bitmap.CompressFormat.PNG);
    }

    private static Bitmap decodeDefault(Context c) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            return BitmapFactory.decodeResource(c.getResources(), R.drawable.gamma_bg, o);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Center-cropped to the screen's shape and size. */
    private static Bitmap fit(Bitmap src) {
        if (src == null) return null;
        int w = screenW > 0 ? screenW : 1920, h = screenH > 0 ? screenH : 1080;
        float scale = Math.max(w / (float) src.getWidth(), h / (float) src.getHeight());
        int cw = Math.round(w / scale), ch = Math.round(h / scale);
        int cx = (src.getWidth() - cw) / 2, cy = (src.getHeight() - ch) / 2;
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(out);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        cv.drawBitmap(src, new Rect(cx, cy, cx + cw, cy + ch), new Rect(0, 0, w, h), p);
        if (out != src) src.recycle();
        return out;
    }

    /** Frosted copy: small, blurred three times, a little more colourful (light through glass). */
    static Bitmap makeBlur(Bitmap src) {
        int w = Math.max(16, src.getWidth() / BLUR_DIV), h = Math.max(9, src.getHeight() / BLUR_DIV);
        Bitmap small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(small);
        Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(1.5f);
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        cv.drawBitmap(src, new Rect(0, 0, src.getWidth(), src.getHeight()), new Rect(0, 0, w, h), p);
        int[] px = new int[w * h];
        small.getPixels(px, 0, w, 0, 0, w, h);
        for (int i = 0; i < 3; i++) {
            boxBlur(px, w, h, 3, true);
            boxBlur(px, w, h, 3, false);
        }
        small.setPixels(px, 0, w, 0, 0, w, h);
        return small;
    }

    private static void boxBlur(int[] px, int w, int h, int r, boolean horizontal) {
        int[] out = new int[px.length];
        int lines = horizontal ? h : w, len = horizontal ? w : h;
        for (int l = 0; l < lines; l++) {
            for (int i = 0; i < len; i++) {
                int a = 0, rr = 0, g = 0, b = 0, n = 0;
                for (int k = -r; k <= r; k++) {
                    int j = Math.max(0, Math.min(len - 1, i + k));
                    int c = horizontal ? px[l * w + j] : px[j * w + l];
                    a += c >>> 24; rr += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; n++;
                }
                int idx = horizontal ? l * w + i : i * w + l;
                out[idx] = ((a / n) << 24) | ((rr / n) << 16) | ((g / n) << 8) | (b / n);
            }
        }
        System.arraycopy(out, 0, px, 0, px.length);
    }

    private static void save(Bitmap b, File f, Bitmap.CompressFormat fmt) {
        if (b == null) return;
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            b.compress(fmt, fmt == Bitmap.CompressFormat.JPEG ? 90 : 100, o);
        } catch (Throwable t) {
            tmp.delete();
            return;
        }
        tmp.renameTo(f);
    }

    interface Done { void done(boolean ok); }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Your picture: shrunk and blurred once, in the background (a second or two), then used everywhere. */
    static void setPicture(final Context ctx, final Uri uri, final Done done) {
        final Context c = ctx.getApplicationContext();
        init(c);
        new Thread(() -> {
            boolean ok = false;
            try {
                BitmapFactory.Options b = new BitmapFactory.Options();
                b.inJustDecodeBounds = true;
                try (InputStream in = c.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, b); }
                int sample = 1;
                while (b.outWidth / (sample * 2) >= screenW && b.outHeight / (sample * 2) >= screenH) sample *= 2;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = sample;
                Bitmap src;
                try (InputStream in = c.getContentResolver().openInputStream(uri)) { src = BitmapFactory.decodeStream(in, null, o); }
                if (src != null) {
                    Bitmap full = fit(src);
                    Bitmap bl = makeBlur(full);
                    save(full, new File(dir(c), "bg.jpg"), Bitmap.CompressFormat.JPEG);
                    save(bl, new File(dir(c), "blur.png"), Bitmap.CompressFormat.PNG);
                    synchronized (Backdrop.class) {
                        sharp = full;
                        blur = bl;
                        version++;
                    }
                    PreferenceManager.getDefaultSharedPreferences(c).edit().putLong(KEY_PICKED, System.currentTimeMillis()).apply();
                    ok = true;
                }
            } catch (Throwable t) {
                ok = false;
            }
            final boolean result = ok;
            MAIN.post(() -> done.done(result));
        }, "backdrop").start();
    }

    /** Back to the built-in picture. */
    static synchronized void useDefault(Context c) {
        new File(dir(c), "bg.jpg").delete();
        new File(dir(c), "blur.png").delete();
        PreferenceManager.getDefaultSharedPreferences(c).edit().remove(KEY_PICKED).apply();
        sharp = null;
        blur = null;
        version++;
    }

    static String summary(Context c) {
        if (!hasOwnPicture(c)) return "Built-in emerald background";
        long t = PreferenceManager.getDefaultSharedPreferences(c).getLong(KEY_PICKED, 0);
        return "Your picture" + (t > 0 ? " · picked " + new java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(new java.util.Date(t)) : "");
    }
}
