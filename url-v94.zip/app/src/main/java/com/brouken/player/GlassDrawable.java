package com.brouken.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Frosted glass: shows the blurred background picture behind it (the part that's really behind it
 * on screen), darkened by the "Glass opacity" setting, with light on it – a bright rim where the
 * light hits the top edge, a glint in the top-left corner and two soft reflections across.
 * Everything is a precomputed gradient: drawing it is cheap, even on the TV.
 *
 * Used as the background of every dialog (from the theme), of the Settings cards, the Saved links
 * panel and the start screen panels.
 */
public class GlassDrawable extends Drawable {

    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topFade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rimTop = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final RectF rect = new RectF();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private final int[] loc = new int[2];

    private float radius;
    private float density = 2f;
    private View host;
    private int alpha = 255;
    /** Extra darkness for panels that hold a lot of text. */
    private int extraTint;
    /** Corners: false = square top/bottom (a card cut off at the screen edge). */
    private boolean roundTop = true, roundBottom = true;

    public GlassDrawable() {
        this(null, 22);
    }

    public GlassDrawable(View host, float radiusDp) {
        this.host = host;
        if (host != null) density = host.getResources().getDisplayMetrics().density;
        else if (Backdrop.screenW() > 0) density = android.content.res.Resources.getSystem().getDisplayMetrics().density;
        radius = radiusDp * density;
        rim.setStyle(Paint.Style.STROKE);
        rimTop.setStyle(Paint.Style.STROKE);
    }

    void setHost(View v) {
        host = v;
        if (v != null) {
            density = v.getResources().getDisplayMetrics().density;
        }
    }

    void setRadiusDp(float dp) {
        radius = dp * density;
        onBoundsChange(getBounds());
    }

    void setExtraTint(int a) {
        extraTint = a;
    }

    void setRoundEnds(boolean top, boolean bottom) {
        if (roundTop == top && roundBottom == bottom) return;
        roundTop = top;
        roundBottom = bottom;
        buildPath(getBounds());
    }

    /** The view this drawable is drawn in (directly, or through a wrapping drawable). */
    private View view() {
        if (host != null) return host;
        Callback cb = getCallback();
        while (cb instanceof Drawable) cb = ((Drawable) cb).getCallback();
        return cb instanceof View ? (View) cb : null;
    }

    @Override
    protected void onBoundsChange(Rect b) {
        super.onBoundsChange(b);
        if (b.isEmpty()) return;
        View v = view();
        if (v != null) density = v.getResources().getDisplayMetrics().density;
        float w = b.width(), h = b.height();
        float l = b.left, t = b.top;
        rect.set(b);
        buildPath(b);

        // faint milky body: lighter top-left, clearer middle
        base.setShader(new LinearGradient(l, t, l + w, t + h,
                new int[]{0x1FFFFFFF, 0x05FFFFFF, 0x0CFFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        // two diagonal reflections
        float dx = (float) Math.cos(Math.toRadians(22)) * (w + h), dy = (float) Math.sin(Math.toRadians(22)) * (w + h);
        sheen.setShader(new LinearGradient(l, t, l + dx, t + dy,
                new int[]{0x33FFFFFF, 0x12FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x12FFFFFF, 0x05FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.14f, 0.24f, 0.58f, 0.63f, 0.68f, 0.72f}, Shader.TileMode.CLAMP));
        // light falling on the top edge
        topFade.setShader(new LinearGradient(0, t, 0, t + Math.min(h, 120 * density),
                new int[]{0x1CFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        // glint in the top-left corner (an ellipse)
        float gr = Math.min(w * 0.35f, 160 * density);
        RadialGradient rg = new RadialGradient(0, 0, 1f, new int[]{0x73FFFFFF, 0x1AFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        Matrix m = new Matrix();
        m.setScale(gr, gr * 0.42f);
        m.postTranslate(l + w * 0.08f, t);
        rg.setLocalMatrix(m);
        glint.setShader(rg);
        // rim: bright where the light hits (top-left), faint on the sides, a little green at the bottom
        rim.setStrokeWidth(Math.max(1f, 1.2f * density));
        rim.setShader(new LinearGradient(l, t, l + w, t + h,
                new int[]{0x99FFFFFF, 0x26FFFFFF, 0x0DFFFFFF, 0x47C8FFE6}, new float[]{0f, 0.3f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        rimTop.setStrokeWidth(Math.max(1f, 1.5f * density));
        rimTop.setShader(new LinearGradient(0, t, 0, t + Math.max(8 * density, radius),
                new int[]{0x8CFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
    }

    private void buildPath(Rect b) {
        clip.reset();
        if (b.isEmpty()) return;
        float r = Math.min(radius, Math.min(b.width(), b.height()) / 2f);
        float rt = roundTop ? r : 0, rb = roundBottom ? r : 0;
        clip.addRoundRect(new RectF(b), new float[]{rt, rt, rt, rt, rb, rb, rb, rb}, Path.Direction.CW);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        View v = view();
        Context ctx = v != null ? v.getContext() : null;
        int save = c.save();
        c.clipPath(clip);

        // what's behind the glass, frosted
        Bitmap bl = ctx != null ? Backdrop.blur(ctx) : null;
        if (bl != null) {
            int[] scr = Backdrop.realScreen(ctx);
            v.getLocationOnScreen(loc);
            // screen (0,0) in this drawable's coordinates
            float ox = -loc[0], oy = -loc[1];
            src.set(0, 0, bl.getWidth(), bl.getHeight());
            Backdrop.cover(dst, bl.getWidth(), bl.getHeight(), scr[0], scr[1], ox, oy);
            bitmapPaint.setAlpha(alpha);
            c.drawBitmap(bl, src, dst, bitmapPaint);
        } else {
            fill.setShader(null);
            fill.setColor(0xFF0B1A15);
            c.drawRect(b, fill);
        }

        // how solid the glass is (the slider)
        int tint = Math.min(255, Math.max(0, Backdrop.tintAlpha < 0 ? 90 : Backdrop.tintAlpha) + extraTint);
        fill.setShader(null);
        fill.setColor((tint << 24) | 0x04100C);
        c.drawRect(b, fill);

        c.drawRect(b, base);
        c.drawRect(b, topFade);
        c.drawRect(b, sheen);
        c.drawRect(b, glint);
        c.restoreToCount(save);

        // edges catching the light
        float in = rim.getStrokeWidth() / 2f;
        float r = Math.min(radius, Math.min(b.width(), b.height()) / 2f);
        RectF e = new RectF(b.left + in, b.top + in, b.right - in, b.bottom - in);
        if (roundTop && roundBottom) {
            c.drawRoundRect(e, r, r, rim);
            int s2 = c.save();
            c.clipRect(b.left, b.top, b.right, b.top + Math.max(r, 10 * density));
            c.drawRoundRect(e, r, r, rimTop);
            c.restoreToCount(s2);
        } else {
            Path p = new Path();
            float rt = roundTop ? r : 0, rb = roundBottom ? r : 0;
            p.addRoundRect(e, new float[]{rt, rt, rt, rt, rb, rb, rb, rb}, Path.Direction.CW);
            c.drawPath(p, rim);
        }
    }

    @Override
    public void getOutline(Outline outline) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        outline.setRoundRect(b, Math.min(radius, Math.min(b.width(), b.height()) / 2f));
        outline.setAlpha(0.6f);
    }

    @Override
    public boolean getPadding(Rect padding) {
        padding.set(0, 0, 0, 0);
        return false;
    }

    @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
