package com.brouken.player;

import android.view.SurfaceView;
import android.view.View;

/**
 * HDR video in the mini player (picture-in-picture): the screen switches to HDR for it and dims
 * everything else (the home screen, other apps) to make room for the bright highlights, so the
 * whole screen looks washed out. In the mini player the video is tone-mapped to normal brightness
 * instead (Android 15+), and full HDR comes back when it's full screen again.
 */
final class HdrPip {

    private HdrPip() {}

    static void apply(View surfaceView, boolean inPip) {
        if (android.os.Build.VERSION.SDK_INT < 35 || !(surfaceView instanceof SurfaceView)) return;
        try {
            Object sc = SurfaceView.class.getMethod("getSurfaceControl").invoke(surfaceView);
            if (sc == null) return;
            Class<?> scClass = Class.forName("android.view.SurfaceControl");
            Class<?> tClass = Class.forName("android.view.SurfaceControl$Transaction");
            Object t = tClass.getConstructor().newInstance();
            // 1.0 = no headroom above normal white: shown as SDR; 0 = no limit (full HDR)
            tClass.getMethod("setDesiredHdrHeadroom", scClass, float.class).invoke(t, sc, inPip ? 1.0f : 0f);
            tClass.getMethod("apply").invoke(t);
            Diag.log(inPip ? "Mini player: HDR shown at normal brightness (the rest of the screen keeps its colours)"
                    : "Full screen: HDR again");
        } catch (Throwable t) {
            Diag.log("Mini player HDR limit not available: " + t.getClass().getSimpleName());
        }
    }
}
