package com.brouken.player;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.preference.PreferenceManager;

import androidx.media3.common.C;
import androidx.media3.common.Format;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegLibrary;
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.VideoFilter;

/**
 * Player config (mpv.conf style) and automatic inverse telecine / deinterlacing – the same
 * method as mpv URL+'s ivtc.lua, for ANY codec or container:
 *  1. Candidates: SDR, up to 1088 lines, frame rate in the "fps" list. When the file doesn't
 *     say its frame rate, it is measured during the first seconds.
 *  2. For ~12 s the video is decoded by FFmpeg and its "idet" filter counts combed vs. clean frames.
 *  3. Hardly any combing → back to hardware decoding, no filter.
 *     Some combing at 29.97/30/59.94 fps → telecine: fieldmatch + bwdif + decimate.
 *     Combing nearly everywhere → bwdif deinterlace.
 * The result is remembered per video. "hwdec" and "vf" work like in mpv.
 */
final class Ivtc {

    private Ivtc() {}

    static final String KEY_CONFIG = "ivtcConfig";
    private static final String DETECT = "idet";

    static final String DEFAULT_CONFIG =
            "# Player config, like mpv.conf. Lines starting with # are comments.\n"
            + "# Reset restores these defaults. Unknown options are reported and ignored.\n"
            + "\n"
            + "# ---- mpv options ----\n"
            + "# hwdec=auto       hardware decoding, software when needed (HW+)\n"
            + "# hwdec=no         always software (FFmpeg)\n"
            + "# hwdec=mediacodec hardware only\n"
            + "#hwdec=auto\n"
            + "\n"
            + "# Your own FFmpeg video filter, always on (software decoding), e.g.\n"
            + "#   vf=pullup        vf=lavfi=[fieldmatch,yadif=deint=interlaced,decimate]\n"
            + "#   vf=bwdif         vf=yadif         vf=detelecine\n"
            + "# Available: idet fieldmatch decimate pullup detelecine bwdif yadif w3fdif\n"
            + "#            estdif kerndeint deband gradfun format null\n"
            + "#vf=\n"
            + "\n"
            + "# deinterlace=yes  always deinterlace (bwdif)\n"
            + "#deinterlace=no\n"
            + "\n"
            + "# ---- automatic inverse telecine (ivtc.lua) ----\n"
            + "ivtc-enabled=yes\n"
            + "# auto = measure, then decide | ivtc | mixed | deint | off\n"
            + "ivtc-mode=auto\n"
            + "# seconds of playback measured (software decoding meanwhile)\n"
            + "ivtc-detect_seconds=12\n"
            + "# at least this many measured frames, else measure again (max 3 more rounds)\n"
            + "ivtc-min_frames=150\n"
            + "# combed share below this = progressive (no filter, hardware decoding)\n"
            + "ivtc-progressive_below=0.10\n"
            + "# 29.97/30/59.94 fps with combing up to this share = telecine → IVTC (pullup),\n"
            + "# more = deinterlace (bwdif). 1.0 = NTSC is always IVTC'd, like vf=pullup in mpv.\n"
            + "ivtc-telecine_below=1.0\n"
            + "# only videos up to this height and with these frame rates are checked\n"
            + "ivtc-max_height=1088\n"
            + "ivtc-fps=23.976,24,25,29.97,30,50,59.94\n"
            + "# stream flagged interlaced (480i/576i/1080i BD/DVD, PAFF/MBAFF): decide after\n"
            + "# ~6 s of moving picture instead of ~10 s\n"
            + "ivtc-trust_flags=yes\n"
            + "# remember the result per video\n"
            + "ivtc-remember=yes\n"
            + "# FFmpeg filter chains\n"
            + "# hard telecine (steady 3:2 pattern)\n"
            + "ivtc-ivtc_filter=pullup\n"
            + "# telecine with interlaced parts (credits, video-shot scenes)\n"
            + "ivtc-mixed_filter=fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate\n"
            + "# really interlaced\n"
            + "ivtc-deint_filter=bwdif=mode=send_frame:deint=all\n";

    // ------------------------------------------------------------------ configuration

    static final class Config {
        Integer hwdec;               // null = not set
        String vf = "";              // FFmpeg chain, "" = none
        boolean enabled = true;
        String mode = "auto";
        double detectSeconds = 12;
        int minFrames = 150;
        double progressiveBelow = 0.10;
        double telecineBelow = 1.0;
        int maxHeight = 1088;
        List<Double> fps = new ArrayList<>();
        boolean remember = true;
        boolean trustFlags = true;
        String ivtcFilter = "pullup";
        String deintFilter = "bwdif=mode=send_frame:deint=all";
        String mixedFilter = "fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate";
        final List<String> warnings = new ArrayList<>();
    }

    static String configText(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getString(KEY_CONFIG, DEFAULT_CONFIG);
    }

    private static String cachedText;
    private static Config cached;

    static Config load(Context c) {
        String text = configText(c);
        // v39: the old default telecine settings → pullup (what works for you in mpv)
        String migrated = text
                .replace("ivtc-telecine_below=0.80", "ivtc-telecine_below=1.0")
                .replace("ivtc-ivtc_filter=fieldmatch=order=auto,bwdif=mode=send_frame:deint=interlaced,decimate", "ivtc-ivtc_filter=pullup");
        if (!migrated.equals(text) && PreferenceManager.getDefaultSharedPreferences(c).contains(KEY_CONFIG)) {
            PreferenceManager.getDefaultSharedPreferences(c).edit().putString(KEY_CONFIG, migrated).apply();
            text = migrated;
        }
        if (cached != null && text.equals(cachedText)) return cached;
        Config cfg;
        try {
            cfg = parse(text);
        } catch (IllegalArgumentException e) {
            Diag.log("Config error (" + e.getMessage() + ") → defaults used");
            cfg = parse(DEFAULT_CONFIG);
        }
        cachedText = text;
        cached = cfg;
        return cfg;
    }

    /** hwdec from the config: Decoder mode, or null when not set. */
    static Integer configHwdec(Context c) {
        try {
            return load(c).hwdec;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Errors (stop saving) as an exception message; returns the warnings otherwise. */
    static List<String> check(String text) {
        return parse(text).warnings;
    }

    static Config parse(String text) {
        Config cfg = new Config();
        boolean fpsSet = false;
        String section = null;
        int n = 0;
        for (String raw : text.split("\n")) {
            n++;
            String line = raw.trim();
            int hash = line.indexOf('#');
            if (hash == 0) continue;
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                section = line.substring(1, line.length() - 1).trim();
                if (!section.equals("default")) {
                    cfg.warnings.add("line " + n + ": profile [" + section + "] is ignored (profiles/conditions aren't supported – put the options at the top)");
                } else {
                    section = null;
                }
                continue;
            }
            if (section != null) continue;
            String key, value;
            int eq = line.indexOf('=');
            if (eq < 0) {
                key = line;
                value = "yes";              // mpv: "option" alone = yes
            } else {
                key = line.substring(0, eq).trim();
                value = line.substring(eq + 1).trim();
            }
            if (key.startsWith("--")) key = key.substring(2);
            key = key.toLowerCase(Locale.US);
            if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1);
            if (key.equals("script-opts") || key.equals("script-opts-append") || key.equals("script-opts-add")) {
                for (String part : value.split(",")) {
                    int e2 = part.indexOf('=');
                    if (e2 > 0) option(cfg, part.substring(0, e2).trim().toLowerCase(Locale.US), part.substring(e2 + 1).trim(), n);
                }
                continue;
            }
            if (key.equals("ivtc-fps")) fpsSet = true;
            option(cfg, key, value, n);
        }
        if (!fpsSet) {
            for (double f : new double[] {23.976, 24, 25, 29.97, 30, 50, 59.94}) cfg.fps.add(f);
        }
        return cfg;
    }

    private static void option(Config cfg, String key, String value, int n) {
        String k = key.startsWith("ivtc-") ? key.substring(5) : key;
        try {
            switch (key.startsWith("ivtc-") ? "ivtc" : key) {
                case "hwdec": {
                    String v = value.toLowerCase(Locale.US);
                    if (v.equals("no")) cfg.hwdec = Decoder.SW;
                    else if (v.equals("mediacodec") || v.equals("mediacodec-copy")) cfg.hwdec = Decoder.HW;
                    else if (v.equals("auto") || v.equals("yes") || v.equals("auto-safe") || v.equals("auto-copy")
                            || v.equals("auto-copy-safe")) cfg.hwdec = Decoder.HW_PLUS;
                    else throw new IllegalArgumentException("line " + n + ": hwdec must be auto, no or mediacodec");
                    return;
                }
                case "vf":
                case "vf-add":
                case "vf-append":
                case "vf-pre": {
                    String chain = mpvFilters(value, n);
                    if (key.equals("vf") || cfg.vf.isEmpty()) cfg.vf = chain;
                    else if (!chain.isEmpty()) cfg.vf = key.equals("vf-pre") ? chain + "," + cfg.vf : cfg.vf + "," + chain;
                    return;
                }
                case "deinterlace": {
                    String v = value.toLowerCase(Locale.US);
                    if (v.equals("yes")) {
                        if (cfg.vf.isEmpty()) cfg.vf = "bwdif=mode=send_frame:deint=all";
                    } else if (!v.equals("no") && !v.equals("auto")) {
                        throw new IllegalArgumentException("line " + n + ": deinterlace must be yes, no or auto");
                    }
                    return;
                }
                case "ivtc":
                    break;
                default:
                    cfg.warnings.add("line " + n + ": '" + key + "' isn't supported in Just Player (ignored)");
                    return;
            }
            switch (k) {
                case "enabled": cfg.enabled = bool(value, n); break;
                case "mode": {
                    String v = value.toLowerCase(Locale.US);
                    if (!v.equals("auto") && !v.equals("ivtc") && !v.equals("deint") && !v.equals("mixed") && !v.equals("off")) {
                        throw new IllegalArgumentException("line " + n + ": ivtc-mode must be auto, ivtc, mixed, deint or off");
                    }
                    cfg.mode = v;
                    break;
                }
                case "detect_seconds": cfg.detectSeconds = range(Double.parseDouble(value), 2, 120, n); break;
                case "min_frames": cfg.minFrames = (int) range(Integer.parseInt(value), 10, 10000, n); break;
                case "progressive_below": cfg.progressiveBelow = range(Double.parseDouble(value), 0, 1, n); break;
                case "telecine_below": cfg.telecineBelow = range(Double.parseDouble(value), 0, 1, n); break;
                case "max_height": cfg.maxHeight = (int) range(Integer.parseInt(value), 144, 4320, n); break;
                case "fps":
                    cfg.fps.clear();
                    for (String f : value.split(",")) {
                        if (!f.trim().isEmpty()) cfg.fps.add(range(Double.parseDouble(f.trim()), 1, 300, n));
                    }
                    break;
                case "remember": cfg.remember = bool(value, n); break;
                case "trust_flags": cfg.trustFlags = bool(value, n); break;
                case "ivtc_filter": cfg.ivtcFilter = mpvFilters(value, n); break;
                case "deint_filter": cfg.deintFilter = mpvFilters(value, n); break;
                case "mixed_filter": cfg.mixedFilter = mpvFilters(value, n); break;
                default: cfg.warnings.add("line " + n + ": '" + key + "' isn't an ivtc option (ignored)");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("line " + n + ": '" + value + "' is not a number");
        }
    }

    /** mpv vf syntax → FFmpeg chain: "@label:lavfi=[a,b],c" → "a,b,c". */
    static String mpvFilters(String v, int n) {
        StringBuilder out = new StringBuilder();
        int depth = 0;
        StringBuilder cur = new StringBuilder();
        List<String> parts = new ArrayList<>();
        for (char ch : v.toCharArray()) {
            if (ch == '[') depth++;
            if (ch == ']') depth--;
            if (ch == ',' && depth == 0) { parts.add(cur.toString()); cur.setLength(0); }
            else cur.append(ch);
        }
        parts.add(cur.toString());
        for (String p : parts) {
            p = p.trim();
            if (p.isEmpty()) continue;
            if (p.startsWith("@")) {
                int colon = p.indexOf(':');
                if (colon < 0) continue;
                p = p.substring(colon + 1).trim();
            }
            if (p.startsWith("lavfi=")) {
                p = p.substring(6).trim();
                if (p.startsWith("[") && p.endsWith("]")) p = p.substring(1, p.length() - 1);
                if (p.startsWith("\"") && p.endsWith("\"")) p = p.substring(1, p.length() - 1);
            } else if (p.startsWith("lavfi-")) {
                p = p.substring(6);
            }
            if (p.contains(";") || p.contains("[")) {
                throw new IllegalArgumentException("line " + n + ": only simple filter chains (a,b,c) are supported");
            }
            if (out.length() > 0) out.append(',');
            out.append(p);
        }
        return out.toString();
    }

    private static boolean bool(String v, int n) {
        v = v.toLowerCase(Locale.US);
        if (v.equals("yes") || v.equals("true") || v.equals("on") || v.equals("1")) return true;
        if (v.equals("no") || v.equals("false") || v.equals("off") || v.equals("0")) return false;
        throw new IllegalArgumentException("line " + n + ": use yes or no");
    }

    private static double range(double v, double min, double max, int n) {
        if (v < min || v > max) throw new IllegalArgumentException("line " + n + ": " + v + " is outside " + min + "…" + max);
        return v;
    }

    // ------------------------------------------------------------------ state

    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    private static String uri;
    // idle | measuring | detecting | ivtc | deint | custom | off | skip
    private static String state = "idle";
    private static String reason = "";
    private static String filter = "";
    private static boolean weSwitched;
    private static boolean hadOverride;
    private static int previousMode;
    private static long playedMs;
    private static long lastTick;
    private static int extraRounds;
    private static float fps;
    private static float measuredFps;
    private static long measureFrames0 = -1;
    private static long measureMs;
    private static Format lastFormat;
    private static Config cfg;
    private static PlayerActivity activity;

    static final String KEY_AUTO = "ivtcAuto";

    /** Settings → "Automatic deinterlacing" (the master switch for the AUTO mode). */
    static boolean autoEnabled(Context c) {
        try {
            return PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY_AUTO, true);
        } catch (Throwable t) {
            return true;
        }
    }

    /** New video opened (or exit): forget everything. */
    static void newSession() {
        manual = null;
        HANDLER.removeCallbacks(TICK);
        HANDLER.removeCallbacks(MEASURE);
        uri = null;
        state = "idle";
        reason = "";
        filter = "";
        weSwitched = false;
        measuredFps = 0;
        VideoFilter.spec = "";
        VideoFilter.fpsHint = 0;
        VideoFilter.clearStats();
    }

    /**
     * Decoder button pressed: HW+/HW → no filter (hardware can't filter); SW → the filter that was
     * found for this video is used again (or the check runs again).
     */
    static void decoderChanged(int mode) {
        HANDLER.removeCallbacks(TICK);
        HANDLER.removeCallbacks(CHECK_RUNNING);
        state = "idle";
        reason = "";
        filter = "";
        weSwitched = false;
        VideoFilter.spec = "";
        VideoFilter.clearStats();
    }

    /** Before every player build (also after a decoder switch). */
    static void onPlayerBuild(PlayerActivity a) {
        updateButton();
        activity = a;
        String u = a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
        if (u == null || !u.equals(uri)) {
            newSession();
            uri = u;
        }
        switch (state) {
            case "detecting": VideoFilter.spec = DETECT; break;
            case "ivtc":
            case "deint":
            case "mixed":
            case "custom": VideoFilter.spec = filter; break;
            default: VideoFilter.spec = "";
        }
    }

    private static boolean needsSoftware() {
        return "detecting".equals(state) || "ivtc".equals(state) || "deint".equals(state) || "mixed".equals(state) || "custom".equals(state);
    }

    /** Software decoding is on only because of this (don't save it as "the decoder for this video"). */
    static boolean usesSoftware() {
        return needsSoftware();
    }

    static boolean holdsSoftware() {
        return weSwitched && needsSoftware();
    }

    static String status() {
        switch (state) {
            case "measuring": return "measuring the frame rate…";
            case "detecting": {
                long[] s = VideoFilter.stats(DETECT);
                return String.format(Locale.US, "checking… %d/%d s · %d combed / %d clean · coded interlaced %d/%d · repeat flags %d · %s%s",
                        playedMs / 1000, (int) (cfg != null ? cfg.detectSeconds : 12), s[0] + s[1], s[2], s[7], s[8], s[10],
                        cadence(VideoFilter.pattern(DETECT)),
                        s[4] == 0 && playedMs > 3000 ? " (no frames from FFmpeg yet)" : "");
            }
            case "ivtc": return "inverse telecine on (" + reason + ")" + filterInfo();
            case "deint": return "deinterlacing on (" + reason + ")" + filterInfo();
            case "mixed": return "telecine + interlaced parts: field matching + deinterlacing (" + reason + ")" + filterInfo();
            case "custom": return "vf=" + filter + filterInfo();
            case "off": return "progressive, no filter (" + reason + ")";
            case "skip": return reason.isEmpty() ? null : "not used – " + reason;
            default: return null;
        }
    }

    /** "· 1200 frames in → 960 out" or the FFmpeg error, so you can see the filter really runs. */
    private static String filterInfo() {
        long[] s = VideoFilter.stats(filter);
        if (s[5] < 0) return "\n      ✗ FFmpeg: " + VideoFilter.error();
        if (s[5] == 0) return "\n      waiting for frames from the FFmpeg decoder…";
        return String.format(Locale.US, "\n      FFmpeg filter running · %d frames in → %d out", s[4], s[6]);
    }

    /**
     * Tracks known (every player build). Returns true when a decoder switch was started, so the
     * normal decoder choice is skipped for this build.
     */
    static boolean onTracks(PlayerActivity a, Format f) {
        activity = a;
        if (f == null) return false;
        lastFormat = f;
        if (!"idle".equals(state)) {
            if (needsSoftware() && Decoder.get(a) != Decoder.SW) {
                // e.g. software was too slow and the decoder fell back to hardware
                HANDLER.removeCallbacks(TICK);
                VideoFilter.spec = "";
                skip(Decoder.userChosen(a) ? "you chose " + Decoder.name(Decoder.get(a)) + " with the decoder button"
                        : "the software decoder isn't in use any more (too slow?)");
            }
            return false;
        }
        cfg = load(a);
        lastFormat = f;
        manual = manualFor(a);
        if (manual != null) return manualApply(a, f);
        if (!cfg.vf.isEmpty()) return custom(a, f);
        if (!autoEnabled(a)) {
            // Settings → "Automatic deinterlacing" off: stay on the hardware decoder; the
            // deinterlace button still works for the video that's open
            skip("automatic deinterlacing is off in settings");
            return false;
        }
        if (!cfg.enabled || "off".equals(cfg.mode)) {
            skip("off in the player config");
            return false;
        }
        // Frame rate not in the file (Media3 doesn't read it from MKV): it's measured during the
        // check itself, no separate measuring step / extra reload.
        return evaluate(a, f);
    }

    private static boolean evaluate(PlayerActivity a, Format f) {
        fps = f.frameRate > 0 ? f.frameRate : measuredFps;
        VideoFilter.fpsHint = fps;
        Format withFps = fps > 0 && f.frameRate <= 0 ? f.buildUpon().setFrameRate(fps).build() : f;
        String why = notCandidate(a, withFps);
        if (why != null) {
            skip(why);
            return false;
        }
        String saved = cfg.remember ? memory(a).getString(uri, null) : null;
        if ("off".equals(saved)) {
            state = "off";
            reason = "checked before";
            Diag.log("IVTC: progressive (checked before)");
            return false;
        }
        if ("ivtc".equals(saved) || "deint".equals(saved) || "mixed".equals(saved)) {
            if (fps <= 0) {
                fps = memory(a).getFloat(uri + "|fps", 0f);   // the file doesn't state it: use the measured one
                VideoFilter.fpsHint = fps;
            }
            if (fps <= 0 && filterFor(saved).contains("decimate")) return startDetect(a);   // measure it again
            return apply(a, saved, "checked before");
        }
        if ("ivtc".equals(cfg.mode) || "deint".equals(cfg.mode) || "mixed".equals(cfg.mode)) return apply(a, cfg.mode, "set in config");
        return startDetect(a);
    }

    // ------------------------------------------------------------------ IVTC button

    /** Your choice with the IVTC button for this video: null = automatic, "ivtc", "deint" or "off". */
    private static String manual;
    static android.widget.TextView button;

    private static SharedPreferences manualPrefs(Context c) {
        return c.getSharedPreferences("ivtc_manual", Context.MODE_PRIVATE);
    }

    /** The button's choice holds for the video that's open; a new video starts on Auto. */
    private static String manualFor(PlayerActivity a) {
        try {
            if (manualPrefs(a).getAll().size() > 0) manualPrefs(a).edit().clear().apply();   // old saved choices
        } catch (Throwable ignored) { }
        return manual;
    }

    static String label() {
        if (manual == null) return "AUTO";
        switch (manual) {
            case "ivtc": return "IVTC";
            case "deint": return "DEINT";
            default: return "OFF";
        }
    }

    private static void updateButton() {
        if (button != null) button.post(() -> { if (button != null) button.setText(label()); });
    }

    /** Applies your choice at once, without measuring. */
    private static boolean manualApply(PlayerActivity a, Format f) {
        updateButton();
        fps = f.frameRate > 0 ? f.frameRate : measuredFps;
        VideoFilter.fpsHint = fps;
        if ("off".equals(manual)) {
            state = "off";
            reason = "turned off with the deinterlace button";
            filter = "";
            VideoFilter.spec = "";
            return false;
        }
        if (Decoder.userChosen(a) && Decoder.get(a) != Decoder.SW) {
            skip("you chose " + Decoder.name(Decoder.get(a)) + " with the decoder button");
            return false;
        }
        if (f.sampleMimeType == null || !FfmpegLibrary.isAvailable() || !FfmpegLibrary.supportsFormat(f.sampleMimeType)) {
            skip("FFmpeg can't decode " + f.sampleMimeType);
            return false;
        }
        return applyQuiet(a, manual, "chosen with the deinterlace button");
    }

    private static boolean applyQuiet(PlayerActivity a, String mode, String why) {
        HANDLER.removeCallbacks(TICK);
        state = mode;
        reason = why;
        filter = "ivtc".equals(mode) ? cfg.ivtcFilter : cfg.deintFilter;
        VideoFilter.spec = filter;
        Diag.log("IVTC: " + mode + " (" + why + ")");
        HANDLER.postDelayed(CHECK_RUNNING, 4000);
        return ensureSoftware(a, "ivtc".equals(mode) ? "inverse telecine" : "deinterlacing");
    }

    /** IVTC button: Auto → Inverse telecine → Deinterlace → Off → Auto. Applied instantly. */
    static void cycle(PlayerActivity a) {
        if (a == null || a.mPrefs == null || a.mPrefs.mediaUri == null) return;
        activity = a;
        if (uri == null) uri = a.mPrefs.mediaUri.toString();
        cfg = load(a);
        String next = manual == null ? "ivtc" : "ivtc".equals(manual) ? "deint" : "deint".equals(manual) ? "off" : null;
        manual = next;
        HANDLER.removeCallbacks(TICK);
        HANDLER.removeCallbacks(CHECK_RUNNING);
        String text;
        if (next == null) {
            text = "Automatic";
            memory(a).edit().remove(uri).apply();   // check this video again
            state = "idle";
            filter = "";
            VideoFilter.spec = "";
            VideoFilter.clearStats();
            if (lastFormat != null) onTracks(a, lastFormat);
        } else if ("off".equals(next)) {
            text = "Off";
            state = "off";
            reason = "turned off with the deinterlace button";
            filter = "";
            VideoFilter.spec = "";
            restoreDecoder(a);
        } else {
            text = "ivtc".equals(next) ? "Inverse telecine" : "Deinterlacing";
            if (lastFormat != null) manualApply(a, lastFormat);
        }
        updateButton();
        CenterText.show(a, text, 1500);
    }

    private static void skip(String why) {
        state = "skip";
        reason = why;
        Diag.log("IVTC: not used (" + why + ")");
    }

    private static String notCandidate(PlayerActivity a, Format f) {
        if (f.height <= 0) return "video size unknown";
        if (f.height > cfg.maxHeight) return f.height + " lines (ivtc-max_height=" + cfg.maxHeight + ")";
        if (f.colorInfo != null && (f.colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084
                || f.colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG)) return "HDR video";
        if (f.frameRate > 0 && !fpsListed(f.frameRate)) return String.format(Locale.US, "%.3f fps isn't in ivtc-fps", f.frameRate);
        return softwareProblem(a, f);
    }

    private static boolean fpsListed(double r) {
        for (double v : cfg.fps) {
            if (Math.abs(r - v) < (v > 40 ? 0.3 : 0.15)) return true;
        }
        return false;
    }

    private static String softwareProblem(PlayerActivity a, Format f) {
        if (f.sampleMimeType == null || !FfmpegLibrary.isAvailable() || !FfmpegLibrary.supportsFormat(f.sampleMimeType)) {
            return "FFmpeg can't decode " + f.sampleMimeType;
        }
        if (!TvTune.softwareOk(a, f)) return String.format(Locale.US, "%dp %.0f fps is too heavy for software decoding on this TV", f.height, f.frameRate);
        int mode = Decoder.get(a);
        if (mode != Decoder.SW && Decoder.userChosen(a)) return "you chose " + Decoder.name(mode) + " with the decoder button";
        if (mode != Decoder.SW && RangeSupport.isLinear(a.mPrefs.mediaUri)) {
            return "this server can't seek, a decoder switch would restart the video";
        }
        return null;
    }

    private static boolean custom(PlayerActivity a, Format f) {
        fps = f.frameRate > 0 ? f.frameRate : measuredFps;
        VideoFilter.fpsHint = fps;
        String why = softwareProblem(a, f);
        if (why != null && !why.contains("too heavy")) {   // your own vf: tried even if it may be heavy
            skip("vf=" + cfg.vf + ": " + why);
            return false;
        }
        state = "custom";
        filter = cfg.vf;
        reason = "player config";
        VideoFilter.spec = filter;
        Diag.log("Video filter from config: " + filter);
        HANDLER.postDelayed(CHECK_RUNNING, 4000);
        return ensureSoftware(a, "vf from config");
    }

    private static boolean ensureSoftware(PlayerActivity a, String why) {
        if (Decoder.get(a) == Decoder.SW) return false;
        hadOverride = Decoder.hasOverride(a);
        previousMode = Decoder.get(a);
        weSwitched = true;
        Decoder.switchTo(a, Decoder.SW, why);
        return true;
    }

    private static boolean startDetect(PlayerActivity a) {
        state = "detecting";
        filter = "";
        playedMs = 0;
        lastTick = 0;
        extraRounds = 0;
        VideoFilter.clearStats();
        VideoFilter.spec = DETECT;
        countBase = -1;
        lastPos = -1;
        countNow = 0;
        countNowMs = 0;
        Diag.log(fps > 0
                ? String.format(Locale.US, "IVTC: checking for telecine/interlacing (%.0f s, %.3f fps)", cfg.detectSeconds, fps)
                : String.format(Locale.US, "IVTC: checking for telecine/interlacing (%.0f s, frame rate measured meanwhile)", cfg.detectSeconds));
        HANDLER.removeCallbacks(TICK);
        HANDLER.postDelayed(TICK, 1000);
        return ensureSoftware(a, "checking for telecine");
    }

    private static boolean apply(PlayerActivity a, String mode, String why) {
        HANDLER.removeCallbacks(TICK);
        state = mode;
        reason = why;
        filter = filterFor(mode);
        VideoFilter.spec = filter;
        remember(a, mode);
        String text = ("ivtc".equals(mode) ? "Inverse telecine on" : "mixed".equals(mode) ? "Inverse telecine + deinterlacing on"
                : "Deinterlacing on") + " (" + why + ")";
        Diag.log("IVTC: " + text);
        CenterText.show(a, "ivtc".equals(mode) ? "Inverse telecine" : "mixed".equals(mode) ? "Inverse telecine + deinterlacing" : "Deinterlacing", 2000);
        HANDLER.postDelayed(CHECK_RUNNING, 4000);
        return ensureSoftware(a, "ivtc".equals(mode) ? "inverse telecine" : "deinterlacing");
    }

    private static String filterFor(String mode) {
        return "ivtc".equals(mode) ? cfg.ivtcFilter : "mixed".equals(mode) ? cfg.mixedFilter : cfg.deintFilter;
    }

    private static void progressive(PlayerActivity a, String why) {
        HANDLER.removeCallbacks(TICK);
        state = "off";
        reason = why;
        filter = "";
        VideoFilter.spec = "";
        remember(a, "off");
        Diag.log("IVTC: progressive (" + why + ") → no filter");
        restoreDecoder(a);
    }

    private static void stop(PlayerActivity a, String why) {
        HANDLER.removeCallbacks(TICK);
        filter = "";
        VideoFilter.spec = "";
        skip(why);
        restoreDecoder(a);
    }

    private static void restoreDecoder(PlayerActivity a) {
        if (!weSwitched) return;
        weSwitched = false;
        if (Decoder.get(a) != Decoder.SW) return;
        if (hadOverride) Decoder.setOverride(a, previousMode);
        else Decoder.clearOverride(a);
        Decoder.reopen(a, "back to " + Decoder.name(previousMode) + ", no filter needed");
    }

    private static void remember(Context c, String mode) {
        if (cfg == null || !cfg.remember || uri == null) return;
        SharedPreferences m = memory(c);
        if (m.getAll().size() > 600) m.edit().clear().apply();
        SharedPreferences.Editor e = m.edit().putString(uri, mode);
        if (fps > 0) e.putFloat(uri + "|fps", fps);
        e.apply();
    }

    private static SharedPreferences memory(Context c) {
        return c.getSharedPreferences("ivtc_memory_v46", Context.MODE_PRIVATE);
    }

    /** Settings: config saved – forget remembered results and decide again when the player returns. */
    static void forgetAll(Context c) {
        memory(c).edit().clear().apply();
        cached = null;
        if (weSwitched && !hadOverride) Decoder.clearOverride(c);
        newSession();
    }

    private static boolean near(double a, double b, double tol) {
        return Math.abs(a - b) < tol;
    }

    /** Result of the 3:2 cadence analysis over blocks of 30 frames (6 pulldown cycles). */
    static final class Cadence {
        int telecine, interlaced, unclear, still;
        int motion() { return telecine + interlaced + unclear; }
        @Override public String toString() {
            return String.format(Locale.US, "3:2 cadence in %d, interlaced in %d, unclear %d of %d moving parts",
                    telecine, interlaced, unclear, motion());
        }
    }

    /**
     * Hard telecine (3:2 pulldown) combs exactly 2 of every 5 frames, always at the same two
     * positions in the 5-frame cycle (frames AB and BC of AA AB BC CC DD). Really interlaced video
     * combs whenever something moves, at every position. So per block of 30 frames: where in the
     * cycle do the combed frames fall?
     */
    static Cadence cadence(byte[] p) {
        Cadence c = new Cadence();
        for (int start = 0; start + 30 <= p.length; start += 30) {
            int[] phase = new int[5];
            int combed = 0, judged = 0;
            for (int i = start; i < start + 30; i++) {
                int t = (p[i] >> 2) & 3;
                if (t == 1 || t == 2) { combed++; phase[(i - start) % 5]++; }
                if (t != 0) judged++;
            }
            if (judged < 15 || combed < 3) { c.still++; continue; }   // no motion: says nothing
            int[] sorted = phase.clone();
            java.util.Arrays.sort(sorted);
            int top2 = sorted[4] + sorted[3];
            if (top2 >= combed * 0.8 && combed <= 15) c.telecine++;
            else if (combed >= judged * 0.6 && top2 < combed * 0.6) c.interlaced++;
            else c.unclear++;
        }
        return c;
    }

    private static boolean ntsc(double r) {
        return near(r, 29.97, 0.15) || near(r, 30, 0.15) || near(r, 59.94, 0.3);
    }

    private static void decide(PlayerActivity a) {
        decide(a, true);
    }

    /** final = the measuring time is over (decide now with what there is). */
    private static void decide(PlayerActivity a, boolean isFinal) {
        long[] s = VideoFilter.stats(DETECT);
        if (s[5] < 0) {
            stop(a, "FFmpeg couldn't run the idet filter: " + VideoFilter.error());
            return;
        }
        if (s[4] == 0) {
            if (isFinal) stop(a, "the FFmpeg decoder isn't decoding this video");
            return;
        }
        if (fps <= 0) {
            float measured = measuredNow();
            if (measured <= 0) return;   // not yet
            fps = measured;
            VideoFilter.fpsHint = fps;
            if (!fpsListed(fps)) {
                // not remembered: a wrong measurement must not switch the check off for good
                HANDLER.removeCallbacks(TICK);
                VideoFilter.spec = "";
                skip(String.format(Locale.US, "%.3f fps isn't in ivtc-fps", fps));
                restoreDecoder(a);
                return;
            }
        }
        long codedTotal = s[8];
        boolean codedInterlaced = codedTotal >= 60 && s[7] >= codedTotal * 0.95;
        boolean softTelecine = codedTotal >= 60 && s[10] >= codedTotal * 0.15;
        Cadence cad = cadence(VideoFilter.pattern(DETECT));
        long combed = s[0] + s[1];
        long clean = s[2];
        long total = combed + clean;
        double ratio = total > 0 ? (double) combed / total : 0;

        // 1. Soft telecine: film frames + "repeat this field" flags. Shown as film, nothing to fix.
        if (softTelecine && ratio < 0.25) {
            progressive(a, String.format(Locale.US, "soft telecine (repeat-field flags on %d%% of frames) – shown as film",
                    s[10] * 100 / codedTotal));
            return;
        }
        // Enough moving picture to judge? (fast when the stream is flagged interlaced)
        int needMotion = codedInterlaced && cfg.trustFlags ? 6 : 10;
        if (!isFinal && cad.motion() < needMotion) return;
        if (isFinal && cad.motion() < 3 && total < cfg.minFrames && extraRounds < 3) {
            extraRounds++;          // still pictures / black so far: measure longer
            playedMs = 0;
            return;
        }
        String coded = codedInterlaced ? (s[9] >= codedTotal / 2 ? "coded interlaced TFF" : "coded interlaced BFF") : "coded progressive";
        String why = String.format(Locale.US, "%s, %.0f%% combed, %s, %.3f fps", coded, ratio * 100, cad, fps);
        Diag.log("IVTC: " + why);

        // 2. No combing at all (progressive, or PAL 2:2 that weaves cleanly)
        if (ratio < cfg.progressiveBelow && cad.telecine == 0 && cad.interlaced == 0) {
            progressive(a, why);
            return;
        }
        int m = Math.max(1, cad.motion());
        double tele = (double) cad.telecine / m;
        double inter = (double) cad.interlaced / m;
        if (ntsc(fps)) {
            if (tele >= 0.4 && inter <= 0.2) apply(a, "ivtc", "hard telecine – " + why);          // pullup
            else if (tele >= 0.25 && inter > 0.2) apply(a, "mixed", "telecine + interlaced parts – " + why);   // fieldmatch+bwdif+decimate
            else if (tele >= 0.25) apply(a, "ivtc", "telecine – " + why);
            else if (inter >= 0.5) apply(a, "deint", "really interlaced – " + why);                // bwdif
            else if (ratio <= cfg.telecineBelow) apply(a, "ivtc", "probably telecine – " + why);   // like vf=pullup in mpv
            else apply(a, "deint", why);
        } else {
            apply(a, "deint", "interlaced – " + why);
        }
    }

    private static boolean playing() {
        try {
            return PlayerActivity.player != null && PlayerActivity.player.isPlaying();
        } catch (Throwable t) {
            return false;
        }
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = activity;
            if (a == null || a.isFinishing() || !"detecting".equals(state)) return;
            long now = SystemClock.elapsedRealtime();
            if (playing() && lastTick > 0) playedMs += Math.min(2000, now - lastTick);
            lastTick = now;
            countFrames();
            long[] st = VideoFilter.stats(DETECT);
            // decide as soon as there is enough moving picture (≈ 6-10 s), at the latest after detect_seconds
            if (playedMs >= cfg.detectSeconds * 1000) decide(a, true);
            else if (playedMs >= 4000 && st[4] > 0) decide(a, false);
            if ("detecting".equals(state)) HANDLER.postDelayed(this, 1000);
        }
    };

    private static final double[] STANDARD_FPS = {23.976, 24, 25, 29.97, 30, 50, 59.94, 60};

    private static long countBase = -1;
    private static long lastPos = -1;
    private static long lastWall;
    private static long countBaseMs;
    private static long countNow;
    private static long countNowMs;

    /** Frames shown/dropped by the video renderer while playing → frame rate. */
    private static void countFrames() {
        try {
            androidx.media3.exoplayer.DecoderCounters dc = PlayerActivity.player.getVideoDecoderCounters();
            if (dc == null) return;
            dc.ensureUpdated();
            // shown + dropped frames only (seeking skips frames, which would count double)
            long frames = dc.renderedOutputBufferCount + dc.droppedBufferCount;
            long pos = PlayerActivity.player.getCurrentPosition();
            long wall = SystemClock.elapsedRealtime();
            boolean jumped = lastPos >= 0 && Math.abs((pos - lastPos) - (wall - lastWall)) > 400;
            lastPos = pos;
            lastWall = wall;
            if (!playing() || jumped) { countBase = -1; return; }   // paused, seek or stall: start over
            if (countBase < 0) { countBase = frames; countBaseMs = playedMs; return; }
            countNow = frames - countBase;
            countNowMs = playedMs - countBaseMs;
        } catch (Throwable ignored) { }
    }

    private static float measuredNow() {
        double f;
        long[] st = VideoFilter.stats(DETECT);
        if (st[11] > 0) {
            f = 1_000_000.0 / st[11];        // from the frame timestamps: exact, seeking doesn't matter
        } else {
            if (countNowMs < 3000 || countNow <= 0) return 0;
            f = countNow * 1000.0 / countNowMs;
        }
        double best = f;
        for (double s : STANDARD_FPS) if (Math.abs(f - s) / s < 0.05) best = s;
        measuredFps = (float) best;
        Diag.log(String.format(Locale.US, "IVTC: measured %.2f fps → %.3f", f, best));
        return measuredFps;
    }

    /** Frame rate not in the file: count decoded frames over 4 s of playback. */
    private static final Runnable MEASURE = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = activity;
            if (a == null || a.isFinishing() || !"measuring".equals(state)) return;
            long frames = -1;
            try {
                androidx.media3.exoplayer.DecoderCounters dc = PlayerActivity.player.getVideoDecoderCounters();
                if (dc != null) {
                    dc.ensureUpdated();
                    frames = dc.renderedOutputBufferCount + dc.droppedBufferCount + dc.skippedOutputBufferCount;
                }
            } catch (Throwable ignored) { }
            long now = SystemClock.elapsedRealtime();
            if (!playing() || frames < 0) {
                measureFrames0 = -1;           // paused / buffering: start counting again
            } else if (measureFrames0 < 0) {
                measureFrames0 = frames;
                measureMs = now;
            } else if (now - measureMs >= 4000) {
                double f = (frames - measureFrames0) * 1000.0 / (now - measureMs);
                double best = f;
                for (double s : STANDARD_FPS) if (Math.abs(f - s) / s < 0.04) best = s;
                measuredFps = (float) best;
                state = "idle";
                Diag.log(String.format(Locale.US, "IVTC: measured %.2f fps → %.3f", f, best));
                if (lastFormat != null) evaluate(a, lastFormat);
                return;
            }
            HANDLER.postDelayed(this, 500);
        }
    };

    /** A filter that can't be built is switched off by the decoder; go back to hardware then. */
    private static final Runnable CHECK_RUNNING = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = activity;
            if (a == null || a.isFinishing()) return;
            if (!"ivtc".equals(state) && !"deint".equals(state) && !"mixed".equals(state) && !"custom".equals(state)) return;
            long[] s = VideoFilter.stats(filter);
            if (s[5] < 0) {
                String err = VideoFilter.error();
                if ("mixed".equals(state)) {
                    Diag.log("IVTC: field matching failed (" + err + ") → pullup");
                    apply(a, "ivtc", "field matching failed, pullup instead");
                } else if ("ivtc".equals(state) && !"deint".equals(reason)) {
                    Diag.log("IVTC: pullup failed (" + err + ") → bwdif");
                    apply(a, "deint", "pullup failed, deinterlacing instead");
                } else {
                    stop(a, "FFmpeg couldn't run " + filter + ": " + err);
                    android.widget.Toast.makeText(a, "Video filter failed – check the player config in Settings", android.widget.Toast.LENGTH_LONG).show();
                }
            } else if (s[5] == 0) {
                HANDLER.postDelayed(this, 4000);   // not reported yet (paused, buffering)
            }
        }
    };
}
