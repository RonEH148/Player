package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Paste a link, check it, then hand it to PlayerActivity. */
public class PasteUrlActivity extends Activity {

    /** A link to check and play right away (from Saved links). */
    static final String EXTRA_URL = "url";

    private boolean handled;
    private boolean finished;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || handled) return;
        handled = true;
        // Saved links → Play: straight to the link check
        String given = getIntent() != null ? getIntent().getStringExtra(EXTRA_URL) : null;
        if (given != null && isValid(given)) {
            check(given);
            return;
        }
        // URL build: the box always starts empty (no clipboard / last link filled in or played)
        showInput(null);
    }

    // ------------------------------------------------------------ input box

    private void showInput(String prefill) {
        final EditText input = new EditText(this);
        input.setHint("Paste a link (http, https or rtsp)");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        if (prefill != null) {
            input.setText(prefill);
            input.setSelection(prefill.length());   // whole link, cursor at the end, nothing highlighted
        }
        FrameLayout box = new FrameLayout(this);
        int pad = dp(20);
        box.setPadding(pad, dp(8), pad, 0);
        box.addView(input);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Open link")
                .setView(box)
                .setPositiveButton("Play", null)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { done(); }
                })
                .setNeutralButton("Saved links", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Intent i = new Intent(PasteUrlActivity.this, SavedLinksActivity.class);
                        startActivity(i);
                        done();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) { done(); }
                })
                .create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String url = input.getText().toString().trim();
                        if (isValid(url)) {
                            dialog.setOnCancelListener(null);
                            dialog.dismiss();
                            check(url);
                        } else {
                            input.setError("That isn't a valid http, https or rtsp link");
                        }
                    }
                });
            }
        });
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        dialog.show();
        input.requestFocus();
    }

    private static final String KEY_LAST = "lastPastedUrl";

    private String lastUrl() {
        return android.preference.PreferenceManager.getDefaultSharedPreferences(this).getString(KEY_LAST, null);
    }

    // ------------------------------------------------------------ link check

    private void check(String raw) {
        final String url = normalize(raw);
        if (!url.toLowerCase(Locale.US).startsWith("http")) {
            play(url, null);   // rtsp: nothing to probe
            return;
        }

        final List<String> lines = new ArrayList<>();
        final TextView log = new TextView(this);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        log.setTextIsSelectable(true);
        int pad = dp(20);
        log.setPadding(pad, dp(8), pad, dp(8));
        log.setText("Checking link…");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(log);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Checking link…")
                .setView(scroll)
                .setPositiveButton("Play anyway", null)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { done(); }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) { done(); }
                })
                .create();
        final Probe.Result[] holder = new Probe.Result[1];
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Probe.Result r = holder[0];
                        Diag.setProbe(url, probeLines(r, lines));
                        dialog.setOnCancelListener(null);
                        dialog.dismiss();
                        play(url, r != null ? r.mimeType : null);
                    }
                });
            }
        });
        dialog.show();

        Probe.start(url, new Probe.Callback() {
            @Override
            public void onLog(final String line) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        lines.add(line);
                        log.setText(join(lines));
                    }
                });
            }

            @Override
            public void onDone(final Probe.Result r) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        holder[0] = r;
                        Decoder.rememberSize(PasteUrlActivity.this, url, r.size);
                        // the link check found the server can't seek: start in linear mode right
                        // away (5-second seeks inside the buffer), not after the first failed jump
                        if (r.ok && !r.seekable && r.code == 200) RangeSupport.markLinear(android.net.Uri.parse(url));
                        if (finished) return;
                        if (r.ok) {
                            lines.add("✓ Looks playable, starting…");
                            log.setText(join(lines));
                            Diag.setProbe(url, probeLines(r, lines));
                            log.postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (finished) return;
                                    dialog.setOnCancelListener(null);
                                    dialog.dismiss();
                                    play(url, r.mimeType);
                                }
                            }, 700);
                        } else {
                            dialog.setTitle("Problem with this link");
                            Button b = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                            if (b != null) b.setText("Play anyway");
                        }
                    }
                });
            }
        });
    }

    private static List<String> probeLines(Probe.Result r, List<String> lines) {
        List<String> out = new ArrayList<>();
        if (r != null && r.summary != null && !r.summary.isEmpty()) {
            out.add(r.summary);
        } else if (!lines.isEmpty()) {
            out.add("Probe: " + lines.get(lines.size() - 1));
        }
        return out;
    }

    private void play(String url, String mimeType) {
        android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit().putString(KEY_LAST, url).apply();
        Lifecycle.clear(this);
        Decoder.clearOverride(this);
        Lifecycle.markFreshStart(this, url);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if (mimeType != null) {
            intent.setDataAndType(Uri.parse(url), mimeType);
        } else {
            intent.setData(Uri.parse(url));
        }
        intent.setClassName(this, "com.brouken.player.PlayerActivity");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        done();
    }

    private void done() {
        finished = true;
        finish();
    }

    // ------------------------------------------------------------ helpers

    private String readClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return null;
            CharSequence t = clip.getItemAt(0).coerceToText(this);
            if (t == null) return null;
            String s = t.toString().trim();
            return isValid(s) ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isValid(String s) {
        if (s == null || s.isEmpty() || s.indexOf(' ') >= 0 || s.indexOf('\n') >= 0) return false;
        String l = s.toLowerCase(Locale.US);
        return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("rtsp://");
    }

    /** Official Pixeldrain share pages (/u/ID) → direct file links (/api/file/ID), always https. */
    public static String normalize(String s) {
        try {
            Uri u = Uri.parse(s);
            String host = u.getHost();
            if (host == null) return s;
            host = host.toLowerCase(Locale.US);
            if (!(host.equals("pixeldrain.com") || host.equals("www.pixeldrain.com") || host.equals("pixeldra.in"))) {
                return s;
            }
            List<String> seg = u.getPathSegments();
            if (seg.size() >= 2 && "u".equals(seg.get(0))) {
                return "https://pixeldrain.com/api/file/" + seg.get(1);
            }
            if (s.startsWith("http://")) {
                return "https://" + s.substring(7);
            }
        } catch (Exception ignored) { }
        return s;
    }

    private static String join(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(l);
        }
        return sb.toString();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
