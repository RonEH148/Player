package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Saved links: your own list of video links with names. Play (with the usual link check), copy,
 * rename, share and delete them. Opened from the ★ button in the player and from "Open link".
 */
public class SavedLinksActivity extends Activity {

    /** The link of the video that's open in the player (offered as "Save current video"). */
    static final String EXTRA_CURRENT = "current";
    static final String EXTRA_CURRENT_NAME = "currentName";

    // ------------------------------------------------------------------ storage

    static final class Link {
        String name;
        String url;
        long added;

        Link(String name, String url, long added) {
            this.name = name;
            this.url = url;
            this.added = added;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("saved_links", Context.MODE_PRIVATE);
    }

    static List<Link> load(Context c) {
        List<Link> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Link(o.optString("n"), o.optString("u"), o.optLong("t")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    static void save(Context c, List<Link> links) {
        try {
            JSONArray a = new JSONArray();
            for (Link l : links) {
                JSONObject o = new JSONObject();
                o.put("n", l.name);
                o.put("u", l.url);
                o.put("t", l.added);
                a.put(o);
            }
            prefs(c).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** A name to start with: the file name in the link, else the site. */
    static String defaultName(String url) {
        try {
            String t = Titles.fromUrl(Uri.parse(url));
            if (t != null && !t.trim().isEmpty()) return t.trim();
            String host = Uri.parse(url).getHost();
            if (host != null) return host;
        } catch (Throwable ignored) { }
        return url;
    }

    // ------------------------------------------------------------------ screen

    private List<Link> links;
    private AlertDialog list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showList();
    }

    private void showList() {
        links = load(this);
        final String current = getIntent().getStringExtra(EXTRA_CURRENT);
        final boolean canSaveCurrent = current != null && PasteUrlActivity.isValid(current) && indexOf(current) < 0;

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(links.isEmpty() ? "Saved links" : "Saved links (" + links.size() + ")")
                .setPositiveButton("Add link", (d, w) -> addDialog(null, null))
                .setNegativeButton("Close", (d, w) -> close())
                .setOnCancelListener(d -> close());
        if (canSaveCurrent) {
            b.setNeutralButton("Save this video", (d, w) ->
                    addDialog(current, getIntent().getStringExtra(EXTRA_CURRENT_NAME)));
        }
        if (links.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No saved links yet.\n\nAdd one with “Add link”"
                    + (canSaveCurrent ? ", or save the video that's playing." : "."));
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            empty.setPadding(dp(24), dp(16), dp(24), dp(8));
            b.setView(empty);
        } else {
            b.setAdapter(new Adapter(), (d, which) -> itemOptions(which));
        }
        list = b.create();
        list.show();
    }

    private void refresh() {
        if (list != null) {
            list.setOnCancelListener(null);
            list.dismiss();
        }
        showList();
    }

    private int indexOf(String url) {
        for (int i = 0; i < links.size(); i++) if (links.get(i).url.equals(url)) return i;
        return -1;
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return links.size(); }
        @Override public Object getItem(int i) { return links.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            LinearLayout row;
            TextView name, url;
            if (v instanceof LinearLayout) {
                row = (LinearLayout) v;
                name = (TextView) row.getChildAt(0);
                url = (TextView) row.getChildAt(1);
            } else {
                row = new LinearLayout(SavedLinksActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(24), dp(10), dp(24), dp(10));
                row.setMinimumHeight(dp(56));
                row.setGravity(Gravity.CENTER_VERTICAL);
                name = new TextView(SavedLinksActivity.this);
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                name.setTextColor(0xFFFFFFFF);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.END);
                url = new TextView(SavedLinksActivity.this);
                url.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                url.setTextColor(0xFF9E9E9E);
                url.setSingleLine(true);
                url.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                row.addView(name);
                row.addView(url);
            }
            Link l = links.get(i);
            name.setText(l.name);
            url.setText(l.url);
            return row;
        }
    }

    // ------------------------------------------------------------------ actions

    private void itemOptions(final int index) {
        if (index < 0 || index >= links.size()) return;
        final Link l = links.get(index);
        final String[] actions = {"Play", "Copy link", "Rename", "Share", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(actions, (d, which) -> {
                    switch (which) {
                        case 0: play(l); break;
                        case 1: copy(l); refresh(); break;
                        case 2: rename(index); break;
                        case 3: share(l); break;
                        default: confirmDelete(index);
                    }
                })
                .setOnCancelListener(d -> refresh())
                .show();
    }

    private void play(Link l) {
        Intent i = new Intent(this, PasteUrlActivity.class);
        i.putExtra(PasteUrlActivity.EXTRA_URL, l.url);   // the usual link check, then play
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        close();
    }

    private void copy(Link l) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(l.name, l.url));
            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't copy the link", Toast.LENGTH_SHORT).show();
        }
    }

    private void share(Link l) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, l.name);
        send.putExtra(Intent.EXTRA_TEXT, l.name + "\n" + l.url);
        try {
            startActivity(Intent.createChooser(send, "Share link"));
        } catch (Exception e) {
            Toast.makeText(this, "No app to share with", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    private void rename(final int index) {
        final Link l = links.get(index);
        final EditText input = field(l.name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(wrap(input))
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) {
                input.setError("Enter a name");
                return;
            }
            l.name = name;
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        input.requestFocus();
    }

    private void confirmDelete(final int index) {
        final Link l = links.get(index);
        new AlertDialog.Builder(this)
                .setTitle("Delete this link?")
                .setMessage(l.name)
                .setPositiveButton("Delete", (d, w) -> {
                    links.remove(index);
                    save(this, links);
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNegativeButton("Cancel", (d, w) -> refresh())
                .setOnCancelListener(d -> refresh())
                .show();
    }

    /** Add a link: name + link (the link is filled in from the clipboard when it holds one). */
    private void addDialog(String presetUrl, String presetName) {
        String url = presetUrl != null ? presetUrl : clipboardLink();
        final EditText urlField = field(url, "Link (http, https or rtsp)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        String name = presetName != null && !presetName.trim().isEmpty() ? presetName.trim()
                : url != null ? defaultName(url) : null;
        final EditText nameField = field(name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(nameField);
        box.addView(urlField);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(presetUrl != null ? "Save this video" : "Add link")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = urlField.getText().toString().trim();
            if (!PasteUrlActivity.isValid(u)) {
                urlField.setError("That isn't a valid http, https or rtsp link");
                return;
            }
            String n = nameField.getText().toString().trim();
            if (n.isEmpty()) n = defaultName(u);
            int existing = indexOf(u);
            if (existing >= 0) {
                links.get(existing).name = n;   // already saved: just rename it
                Toast.makeText(this, "Already saved – renamed", Toast.LENGTH_SHORT).show();
            } else {
                links.add(0, new Link(n, u, System.currentTimeMillis()));
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            }
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        (url == null ? urlField : nameField).requestFocus();
    }

    private String clipboardLink() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null) return null;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            String s = t == null ? null : t.toString().trim();
            return PasteUrlActivity.isValid(s) ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    private EditText field(String text, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(type);
        if (text != null) {
            e.setText(text);
            e.setSelection(text.length());
        }
        return e;
    }

    private View wrap(View v) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void close() {
        if (list != null) list.setOnCancelListener(null);
        finish();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
