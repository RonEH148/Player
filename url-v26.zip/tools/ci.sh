#!/usr/bin/env bash
# Full build, called by .github/workflows/build-url.yml after the newest url-vNN.zip was unpacked.
# Lives in the zip so later changes to the build need no workflow edits.
# Output: out/JustPlayer-URL-Tablet.apk (64-bit ARM) and out/JustPlayer-URL-TV.apk (32- and 64-bit ARM).
set -euo pipefail

sudo apt-get update -qq
sudo apt-get install -y -qq meson ninja-build nasm pkg-config
# "yes" ends with a broken pipe once sdkmanager is done; that is normal, so ignore its exit code
(yes || true) | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --install "ndk;25.2.9519653" "cmake;3.22.1" > /dev/null

# FFmpeg video decoder (NextLib) for both ARM ABIs – many Android TVs run 32-bit
git clone -q https://github.com/anilbeesetti/nextlib.git nextlib
git -C nextlib checkout -q 2dc77cd
NEXTLIB_ABIS="armeabi-v7a arm64-v8a" python3 tools/patch_nextlib.py nextlib
(cd nextlib && chmod +x gradlew ffmpeg/setup.sh && ./gradlew :media3ext:assembleRelease --stacktrace)
cp nextlib/media3ext/build/outputs/aar/*release*.aar app/libs/lib-nextlib-media3ext.aar

chmod +x gradlew
mkdir -p out
APKDIR=app/build/outputs/apk/latestUniversal/release

./gradlew assembleLatestUniversalRelease -PabiFilter=arm64-v8a --stacktrace
cp "$APKDIR"/*.apk out/JustPlayer-URL-Tablet.apk

rm -rf app/build/outputs/apk
./gradlew assembleLatestUniversalRelease --stacktrace          # all ABIs: runs on 32- and 64-bit TVs
cp "$APKDIR"/*.apk out/JustPlayer-URL-TV.apk
ls -la out
