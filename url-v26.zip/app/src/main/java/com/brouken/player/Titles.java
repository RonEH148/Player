package com.brouken.player;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import java.net.URLDecoder;
import java.util.Locale;

/**
 * Video names for links. Taken from the server's Content-Disposition header
 * (e.g. Pixeldrain's /api/file sends the original file name), otherwise from the
 * URL itself when it ends in a file name.
 */
public final class Titles {

    private Titles() {}

    private static SharedPreferences store(Context c) {
        return c.getSharedPreferences("titles", Context.MODE_PRIVATE);
    }

    public static void save(Context c, String url, String fileName) {
        if (url == null || fileName == null || fileName.trim().isEmpty()) return;
        SharedPreferences s = store(c);
        if (s.getAll().size() > 300) s.edit().clear().apply();
        s.edit().putString(url, fileName.trim()).apply();
    }

    /** Pretty title for display, or null if unknown. */
    public static String get(Context c, Uri uri) {
        if (uri == null) return null;
        String f = store(c).getString(uri.toString(), null);
        if (f == null) f = fromUrl(uri);
        return f == null ? null : pretty(f);
    }

    /** Raw file name from a Content-Disposition header. */
    public static String fromContentDisposition(String cd) {
        if (cd == null) return null;
        try {
            String lower = cd.toLowerCase(Locale.US);
            int i = lower.indexOf("filename*=");
            if (i >= 0) {                                   // RFC 5987: filename*=UTF-8''name%20here.mkv
                String v = cd.substring(i + 10).split(";")[0].trim();
                int q = v.indexOf("''");
                if (q >= 0) v = v.substring(q + 2);
                return URLDecoder.decode(strip(v), "UTF-8");
            }
            i = lower.indexOf("filename=");
            if (i >= 0) return strip(cd.substring(i + 9).split(";")[0].trim());
        } catch (Exception ignored) { }
        return null;
    }

    /** File name at the end of the URL, only if it looks like one (has an extension). */
    static String fromUrl(Uri uri) {
        String last = uri.getLastPathSegment();
        if (last == null) return null;
        int dot = last.lastIndexOf('.');
        if (dot <= 0 || last.length() - dot > 5) return null;
        return last;
    }

    private static String strip(String v) {
        if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
        return v;
    }

    /** "Movie.Name.2019.2160p.UHD.BluRay.REMUX.mkv" → "Movie Name 2019 2160p UHD BluRay REMUX" */
    static String pretty(String f) {
        String s = f;
        int dot = s.lastIndexOf('.');
        if (dot > 0 && s.length() - dot <= 5) s = s.substring(0, dot);
        if (!s.contains(" ")) s = s.replace('.', ' ');
        s = s.replace('_', ' ').replaceAll("\\s+", " ").trim();
        return s.isEmpty() ? f : s;
    }

    /** Before the player starts: show the name as the video title. */
    static void apply(PlayerActivity a) {
        try {
            if (a.mPrefs == null || a.mPrefs.mediaUri == null || a.apiTitle != null) return;
            if (!NetCompat.isHttp(a.mPrefs.mediaUri)) return;
            String t = get(a, a.mPrefs.mediaUri);
            if (t != null) a.apiTitle = t;
        } catch (Throwable ignored) { }
    }
}
