package com.brouken.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;

/**
 * Leaving the player stops all network activity. Coming back to a stream asks
 * whether to resume it or stop and go to the player's main screen.
 */
public final class Lifecycle {

    private static final String KEY_ASK = "askResumeUrl";
    private static AlertDialog dialog;

    private Lifecycle() {}

    /** Hooked in PlayerActivity.onStop(), after the player was released. */
    public static void onStop(PlayerActivity a) {
        ReadAheadDataSource.stopAll();
        sessionUri = null;   // playback session over: next start is from the beginning unless Resume is chosen
        try {
            Uri uri = a.mPrefs != null ? a.mPrefs.mediaUri : null;
            if (NetCompat.isHttp(uri)) {
                prefs(a).edit().putString(KEY_ASK, uri.toString()).apply();
            }
        } catch (Throwable ignored) { }
    }

    /** Replaces the initializePlayer() call in PlayerActivity.onStart(). */
    public static void onStart(final PlayerActivity a) {
        Uri uri = a.mPrefs != null ? a.mPrefs.mediaUri : null;
        String pending = prefs(a).getString(KEY_ASK, null);
        if (uri == null || pending == null || !pending.equals(uri.toString())) {
            clear(a);
            a.initializePlayer();
            return;
        }
        if (dialog != null && dialog.isShowing()) return;

        String name = Titles.get(a, uri);
        if (name == null) name = uri.getLastPathSegment() != null ? uri.getLastPathSegment() : uri.getHost();
        dialog = new AlertDialog.Builder(a)
                .setTitle("Continue streaming?")
                .setMessage(name)
                .setCancelable(false)
                .setPositiveButton("Resume", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        clear(a);
                        resumeAllowed = true;
                        a.initializePlayer();
                    }
                })
                .setNeutralButton("Refresh", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        clear(a);
                        resumeAllowed = true;
                        refresh(a);
                    }
                })
                .setNegativeButton("Stop", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        clear(a);
                        try { a.mPrefs.updatePosition(0L); } catch (Throwable ignored) { }   // next time start from the beginning
                        forgetMedia(a);
                        Decoder.clearOverride(a);
                        Decoder.systemBrightness(a);
                        a.initializePlayer();
                    }
                })
                .create();
        dialog.show();
    }

    private static final String KEY_FRESH = "freshStartUrl";

    /** A link pasted again starts from the beginning instead of the last position. */
    public static void markFreshStart(Context c, String url) {
        prefs(c).edit().putString(KEY_FRESH, url).apply();
    }

    /**
     * Refresh: drop every connection and the decoder, then reopen the video at the
     * current position, like closing and reopening it. For a frozen or unresponsive video.
     */
    public static void refresh(final PlayerActivity a) {
        try {
            if (PlayerActivity.player != null) a.releasePlayer();   // saves the current position
        } catch (Throwable ignored) { }
        ReadAheadDataSource.stopAll();
        Diag.log("Refresh: reopening at the same position");
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!a.isFinishing() && !a.isDestroyed()) a.initializePlayer();
            }
        }, 300);
    }

    private static String sessionUri;
    private static boolean resumeAllowed;

    /**
     * Called before every player start. A new playback session always starts at 0:00;
     * the only exception is "Resume" on the continue-streaming prompt. Reloads inside the
     * same session (decoder switch etc.) keep the current position.
     */
    static void beginSession(PlayerActivity a) {
        try {
            if (a.mPrefs == null || a.mPrefs.mediaUri == null) return;
            String uri = a.mPrefs.mediaUri.toString();
            boolean fresh = uri.equals(prefs(a).getString(KEY_FRESH, null));
            if (fresh) prefs(a).edit().remove(KEY_FRESH).apply();
            if (fresh || !uri.equals(sessionUri)) {
                if (resumeAllowed && !fresh) {
                    Diag.log("Resuming where you left off");
                } else {
                    a.mPrefs.updatePosition(0L);
                }
                sessionUri = uri;
            }
            resumeAllowed = false;
        } catch (Throwable ignored) { }
    }

    static void applyFreshStart(PlayerActivity a) {
        try {
            String fresh = prefs(a).getString(KEY_FRESH, null);
            if (fresh == null || a.mPrefs == null || a.mPrefs.mediaUri == null) return;
            if (fresh.equals(a.mPrefs.mediaUri.toString())) {
                a.mPrefs.updatePosition(0L);
                prefs(a).edit().remove(KEY_FRESH).apply();
            }
        } catch (Throwable ignored) { }
    }

    /** A new link was chosen explicitly: no need to ask. */
    public static void clear(Context c) {
        prefs(c).edit().remove(KEY_ASK).apply();
    }

    private static void forgetMedia(PlayerActivity a) {
        try {
            a.mPrefs.mediaUri = null;
            a.mPrefs.mediaType = null;
            prefs(a).edit().remove("mediaUri").remove("mediaType").apply();
        } catch (Throwable ignored) { }
    }

    private static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }
}
