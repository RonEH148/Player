package com.brouken.player;

import android.app.Activity;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.ExoPlayer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Live network/playback diagnostics shown as a small overlay on top of the player. */
public final class Diag {

    private static final int MAX_LOG = 8;
    private static final List<String> LOG = new ArrayList<>();
    private static final List<String> PROBE = new ArrayList<>();
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private static final AtomicLong bytes = new AtomicLong();
    private static volatile int opens;
    private static volatile int lastCode;
    private static volatile String lastHost = "";
    private static volatile String lastType = "";
    private static volatile long totalSize = -1;
    private static volatile boolean rangesOk;
    private static volatile String state = "idle";
    private static volatile Uri media;

    private static long lastTickBytes;
    private static long lastTickTime;
    private static double speedMbps;

    private static TextView view;
    private static Activity activity;
    private static boolean hiddenByUser;
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    private Diag() {}

    // ---------------------------------------------------------------- logging

    public static void log(String line) {
        synchronized (LOG) {
            LOG.add(TIME.format(new Date()) + " " + line);
            while (LOG.size() > MAX_LOG) LOG.remove(0);
        }
    }

    private static volatile String probedUrl;

    public static void setProbe(String url, List<String> lines) {
        probedUrl = url;
        synchronized (PROBE) {
            PROBE.clear();
            PROBE.addAll(lines);
        }
    }

    static String describe(Throwable t) {
        if (t == null) return "unknown";
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        for (Throwable c = t; c != null && depth < 4; c = c.getCause(), depth++) {
            if (depth > 0) sb.append(" <- ");
            sb.append(c.getClass().getSimpleName());
            if (c instanceof HttpDataSource.InvalidResponseCodeException) {
                sb.append(" HTTP ").append(((HttpDataSource.InvalidResponseCodeException) c).responseCode);
            }
            if (c.getMessage() != null) {
                String m = c.getMessage();
                sb.append(": ").append(m.length() > 90 ? m.substring(0, 90) + "…" : m);
            }
        }
        return sb.toString();
    }

    static void onNewMedia(Uri uri) {
        media = uri;
        videoDecoder = "";
        audioDecoder = "";
        TrackPrefs.reset();
        Decoder.onNewMedia();
        tracksLogged = false;
        lastFpsTime = 0;
        shownFps = 0;
        bytes.set(0);
        opens = 0;
        lastCode = 0;
        lastType = "";
        totalSize = -1;
        rangesOk = false;
        speedMbps = 0;
        lastTickBytes = 0;
        lastTickTime = SystemClock.elapsedRealtime();
        state = "preparing";
        synchronized (LOG) { LOG.clear(); }
        if (uri == null || probedUrl == null || !probedUrl.equals(uri.toString())) {
            synchronized (PROBE) { PROBE.clear(); }
        }
        if (uri != null && NetCompat.isHttp(uri)) {
            log("Open " + shorten(uri.toString()));
        }
    }

    // ---------------------------------------------------------------- network events

    public static final TransferListener TRANSFER_LISTENER = new TransferListener() {
        @Override
        public void onTransferInitializing(DataSource source, DataSpec dataSpec, boolean isNetwork) { }

        @Override
        public void onTransferStart(DataSource source, DataSpec dataSpec, boolean isNetwork) {
            if (!isNetwork) return;
            opens++;
            int code = 0;
            if (source instanceof HttpDataSource) {
                try { code = ((HttpDataSource) source).getResponseCode(); } catch (Throwable ignored) { }
            }
            lastCode = code;
            Uri finalUri = null;
            try { finalUri = source.getUri(); } catch (Throwable ignored) { }
            if (finalUri != null && finalUri.getHost() != null) lastHost = finalUri.getHost();
            try {
                Map<String, List<String>> headers = source.getResponseHeaders();
                String ct = header(headers, "Content-Type");
                if (ct != null) lastType = ct;
                String cr = header(headers, "Content-Range");
                if (cr != null && cr.contains("/")) {
                    try { totalSize = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim()); } catch (NumberFormatException ignored) { }
                    rangesOk = true;
                } else if (dataSpec.position == 0) {
                    String cl = header(headers, "Content-Length");
                    if (cl != null) try { totalSize = Long.parseLong(cl.trim()); } catch (NumberFormatException ignored) { }
                }
            } catch (Throwable ignored) { }
            if (opens <= 3 || code < 200 || code >= 300) {
                String redirected = (finalUri != null && media != null && finalUri.getHost() != null
                        && !finalUri.getHost().equals(media.getHost())) ? " via " + finalUri.getHost() : "";
                log("Conn #" + opens + ": HTTP " + code + " at " + mb(dataSpec.position) + redirected);
            }
        }

        @Override
        public void onBytesTransferred(DataSource source, DataSpec dataSpec, boolean isNetwork, int bytesTransferred) {
            if (isNetwork) bytes.addAndGet(bytesTransferred);
        }

        @Override
        public void onTransferEnd(DataSource source, DataSpec dataSpec, boolean isNetwork) { }
    };

    private static String header(Map<String, List<String>> headers, String name) {
        if (headers == null) return null;
        for (Map.Entry<String, List<String>> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name) && e.getValue() != null && !e.getValue().isEmpty()) {
                return e.getValue().get(0);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- player events

    /** Called from PlayerActivity right after the player is created. */
    public static void onPlayerCreated() {
        ExoPlayer p = PlayerActivity.player;
        if (p != null) {
            p.addListener(PLAYER_LISTENER);
            p.addAnalyticsListener(ANALYTICS);
            TrackPrefs.applyParams(p);
            if (activity instanceof PlayerActivity) Decoder.onPlayerCreated((PlayerActivity) activity, p);
            if (activity instanceof PlayerActivity) SubtitleBars.attach((PlayerActivity) activity);
            if (isNetworkMedia()) {
                try { p.setWakeMode(C.WAKE_MODE_NETWORK); } catch (Throwable ignored) { }   // Wi-Fi high-perf lock while playing
            }
        }
    }

    private static volatile String videoDecoder = "";
    private static volatile String audioDecoder = "";

    static long currentSize() {
        return totalSize;
    }

    static String videoDecoderName() {
        String v = videoDecoder;
        int i = v.indexOf(" (");
        return i > 0 ? v.substring(0, i) : v;
    }

    static String decoderKind(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.contains("ffmpeg") || n.contains("dav1d") || n.contains("libgav1") || n.startsWith("lib")) return "SW app";
        if (n.startsWith("c2.android.") || n.startsWith("omx.google.") || n.contains(".sw.")) return "SW";
        return "HW";
    }

    private static final AnalyticsBase ANALYTICS = new AnalyticsBase() {
        @Override
        public void onVideoDecoderInitialized(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime t, String name, long a, long b) {
            videoDecoder = name + " (" + decoderKind(name) + ")";
            log("Video decoder: " + videoDecoder);
        }

        @Override
        public void onAudioDecoderInitialized(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime t, String name, long a, long b) {
            audioDecoder = name;
        }
    };

    private static final ListenerBase PLAYER_LISTENER = new ListenerBase() {
        @Override
        public void onPlaybackStateChanged(int s) {
            switch (s) {
                case Player.STATE_BUFFERING: state = "buffering"; break;
                case Player.STATE_READY: state = "ready"; break;
                case Player.STATE_ENDED: state = "ended"; break;
                default: state = "idle";
            }
            if (isNetworkMedia()) log("State: " + state);
        }

        @Override
        public void onTracksChanged(androidx.media3.common.Tracks tracks) {
            logTracks(tracks);
            if (activity instanceof PlayerActivity) Decoder.onTracks(tracks, (PlayerActivity) activity);
            TrackPrefs.onTracks(tracks);
        }

        @Override
        public void onCues(androidx.media3.common.text.CueGroup cueGroup) {
            SubtitleBars.onCues(cueGroup);
        }

        @Override
        public void onVideoSizeChanged(androidx.media3.common.VideoSize size) {
            HANDLER.post(new Runnable() { @Override public void run() { SubtitleBars.update(); } });
        }

        @Override
        public void onRenderedFirstFrame() {
            Decoder.onRenderedFirstFrame(activity instanceof PlayerActivity ? (PlayerActivity) activity : null);
        }

        @Override
        public void onPositionDiscontinuity(Player.PositionInfo oldPos, Player.PositionInfo newPos, int reason) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK && isNetworkMedia()) {
                long s = newPos.positionMs / 1000;
                log(String.format(Locale.US, "Seek → %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60));
            }
        }

        @Override
        public void onIsPlayingChanged(boolean playing) {
            if (activity instanceof PlayerActivity) Decoder.onIsPlayingChanged(playing, (PlayerActivity) activity);
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (activity instanceof PlayerActivity) Decoder.onError(error, (PlayerActivity) activity);
            state = "error";
            log("ERROR " + error.getErrorCodeName());
            log(describe(error.getCause() != null ? error.getCause() : error));
            hiddenByUser = false;
        }
    };

    private static boolean tracksLogged;

    private static void logTracks(androidx.media3.common.Tracks tracks) {
        if (tracksLogged || tracks == null || tracks.isEmpty()) return;
        tracksLogged = true;
        StringBuilder sb = new StringBuilder("Tracks:");
        for (androidx.media3.common.Tracks.Group g : tracks.getGroups()) {
            for (int i = 0; i < g.length; i++) {
                Format f = g.getTrackFormat(i);
                String m = f.sampleMimeType == null ? "?" : f.sampleMimeType.substring(f.sampleMimeType.indexOf('/') + 1);
                sb.append(' ').append(m);
                if (!g.isTrackSupported(i)) sb.append("(✗)");
            }
        }
        log(sb.toString());
    }

    // ---------------------------------------------------------------- overlay

    /** Called once from PlayerActivity.onCreate (via UrlButton.add). */
    public static void attach(Activity a) {
        try {
            activity = a;
            TextView tv = new TextView(a);
            tv.setTypeface(Typeface.MONOSPACE);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            tv.setTextColor(0xFFFFFFFF);
            tv.setBackgroundColor(0xB0000000);
            int pad = dp(a, 8);
            tv.setPadding(pad, pad / 2, pad, pad / 2);
            tv.setVisibility(View.GONE);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    hiddenByUser = true;
                    v.setVisibility(View.GONE);
                }
            });
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
            lp.topMargin = dp(a, 56);
            lp.leftMargin = dp(a, 12);
            lp.rightMargin = dp(a, 12);
            a.addContentView(tv, lp);
            view = tv;
            HANDLER.removeCallbacks(TICK);
            HANDLER.post(TICK);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /** Long-press on the link button toggles the overlay. */
    public static void toggle() {
        hiddenByUser = !hiddenByUser;
        HANDLER.post(TICK);
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            if (activity == null || activity.isDestroyed()) return;
            if (activity instanceof PlayerActivity) {
                try { Decoder.checkStall((PlayerActivity) activity); } catch (Throwable ignored) { }
            }
            update();
            HANDLER.postDelayed(this, 500);
        }
    };

    private static boolean isNetworkMedia() {
        try {
            if (activity instanceof PlayerActivity) {
                PlayerActivity pa = (PlayerActivity) activity;
                return pa.mPrefs != null && NetCompat.isHttp(pa.mPrefs.mediaUri);
            }
        } catch (Throwable ignored) { }
        return NetCompat.isHttp(media);
    }

    private static void update() {
        if (view == null) return;
        if (hiddenByUser || !isNetworkMedia()) {
            view.setVisibility(View.GONE);
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long b = bytes.get();
        long dt = now - lastTickTime;
        if (dt >= 1000) {
            double inst = (b - lastTickBytes) * 8.0 / 1_000_000.0 / (dt / 1000.0);
            speedMbps = speedMbps == 0 ? inst : speedMbps * 0.6 + inst * 0.4;
            lastTickBytes = b;
            lastTickTime = now;
        }

        StringBuilder sb = new StringBuilder();
        synchronized (PROBE) {
            for (String p : PROBE) sb.append(p).append('\n');
        }

        sb.append("Net: ");
        sb.append(lastCode == 0 ? "connecting…" : "HTTP " + lastCode);
        if (!lastHost.isEmpty()) sb.append(" · ").append(lastHost);
        sb.append('\n');
        sb.append("     ").append(opens).append(" conn · ").append(mb(b)).append(" recv · ")
                .append(String.format(Locale.US, "%.1f Mbit/s", speedMbps));
        if (totalSize > 0) sb.append(" · size ").append(mb(totalSize));
        sb.append(rangesOk ? " · seek ok" : "").append('\n');
        if (!lastType.isEmpty()) sb.append("     type ").append(lastType).append('\n');

        ExoPlayer p = PlayerActivity.player;
        if (p != null) {
            Format v = null;
            try { v = p.getVideoFormat(); } catch (Throwable ignored) { }
            if (v != null) {
                sb.append("Video: ").append(v.codecs != null ? v.codecs : v.sampleMimeType)
                        .append(' ').append(v.width).append('x').append(v.height)
                        .append(' ').append(hdr(v.colorInfo));
                int br = v.peakBitrate > 0 ? v.peakBitrate : v.bitrate > 0 ? v.bitrate : v.averageBitrate;
                if (br > 0) {
                    sb.append(String.format(Locale.US, " · needs ~%.0f Mbit/s", br / 1_000_000.0));
                }
                sb.append('\n');
                // Frame rate of the file vs. frames actually shown, and the screen's refresh rate.
                sb.append("FPS: ").append(v.frameRate > 0 ? String.format(Locale.US, "%.3f", v.frameRate) : "?").append(" file");
                try {
                    androidx.media3.exoplayer.DecoderCounters dc = p.getVideoDecoderCounters();
                    if (dc != null) {
                        dc.ensureUpdated();
                        long nowF = SystemClock.elapsedRealtime();
                        if (nowF - lastFpsTime >= 1000) {
                            int rendered = dc.renderedOutputBufferCount;
                            if (lastFpsTime > 0 && rendered >= lastRendered) {
                                shownFps = (rendered - lastRendered) * 1000.0 / (nowF - lastFpsTime);
                            }
                            lastRendered = rendered;
                            lastFpsTime = nowF;
                        }
                        sb.append(String.format(Locale.US, " · %.1f shown · %d dropped", shownFps, dc.droppedBufferCount));
                    }
                } catch (Throwable ignored) { }
                sb.append('\n');
            }
            sb.append("Display: ").append(displayInfo()).append('\n');
            long buffered = 0;
            try { buffered = p.getTotalBufferedDuration(); } catch (Throwable ignored) { }
            if (!videoDecoder.isEmpty()) sb.append("Decoder: ").append(videoDecoder).append('\n');
            long pos = 0;
            try { pos = p.getCurrentPosition() / 1000; } catch (Throwable ignored) { }
            sb.append("Player: ").append(state)
                    .append(String.format(Locale.US, " · at %d:%02d:%02d", pos / 3600, (pos / 60) % 60, pos % 60))
                    .append(" · buffer ").append(buffered / 1000).append(" s\n");
        }

        synchronized (LOG) {
            for (String l : LOG) sb.append(l).append('\n');
        }
        sb.append("(tap to hide · long-press 🔗 to show)");
        view.setText(sb.toString());
        view.setVisibility(View.VISIBLE);
    }

    private static long lastFpsTime;
    private static int lastRendered;
    private static double shownFps;

    /** Current screen refresh rate (what frame-rate matching switched to) and the panel's maximum. */
    private static String displayInfo() {
        try {
            android.view.Display d = android.os.Build.VERSION.SDK_INT >= 30
                    ? activity.getDisplay()
                    : activity.getWindowManager().getDefaultDisplay();
            if (d == null) return "?";
            float now = d.getRefreshRate();
            float max = now;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                for (android.view.Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
            }
            return String.format(Locale.US, "%.0f Hz now (max %.0f Hz)", now, max);
        } catch (Throwable t) {
            return "?";
        }
    }

    private static String hdr(ColorInfo c) {
        if (c == null) return "SDR";
        switch (c.colorTransfer) {
            case C.COLOR_TRANSFER_ST2084: return "HDR10/PQ";
            case C.COLOR_TRANSFER_HLG: return "HLG";
            default: return "SDR";
        }
    }

    static String mb(long b) {
        if (b < 0) return "?";
        if (b >= 1_000_000_000L) return String.format(Locale.US, "%.2f GB", b / 1e9);
        return String.format(Locale.US, "%.1f MB", b / 1e6);
    }

    static String shorten(String s) {
        return s.length() > 70 ? s.substring(0, 67) + "…" : s;
    }

    private static int dp(Activity a, int dp) {
        return (int) (dp * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
