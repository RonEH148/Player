package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * mpv/VLC-style stream cache: a background thread keeps reading the HTTP stream into a
 * large ring buffer at full network speed, independent of how fast the extractor pulls.
 * Seeks inside the cached window are served instantly; seeks outside restart the reader.
 */
public final class ReadAheadDataSource implements DataSource {

    // Tab S9 (largeHeap ≈ 512 MB): 64 MB read-ahead; smaller devices keep 48 MB or less.
    static final int CAPACITY = Perf.readAheadBytes();
    static final int KEEP_BACK = 6 * 1024 * 1024;
    static final int CHUNK = 1024 * 1024;
    static final int REUSE_AHEAD = 8 * 1024 * 1024;

    public static final class Factory implements DataSource.Factory {
        private final DataSource.Factory upstream;

        public Factory(DataSource.Factory upstream) {
            this.upstream = upstream;
        }

        @Override
        public DataSource createDataSource() {
            return new ReadAheadDataSource(upstream);
        }
    }

    private static final List<Reader> LIVE = new ArrayList<>();

    /** Stop every background download right away (player left / stopped). */
    public static void stopAll() {
        final List<Reader> copy;
        synchronized (LIVE) {
            copy = new ArrayList<>(LIVE);
            LIVE.clear();
        }
        for (final Reader r : copy) {
            r.shutdown();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try { r.upstream.close(); } catch (Throwable ignored) { }  // aborts a blocked read
                }
            }, "read-ahead-close").start();
        }
        if (!copy.isEmpty()) Diag.log("Stopped " + copy.size() + " background download(s)");
    }

    private final DataSource.Factory upstreamFactory;
    private final List<TransferListener> listeners = new ArrayList<>();
    private byte[] ring;
    private Reader reader;
    private DataSource direct;
    private Uri uri;

    ReadAheadDataSource(DataSource.Factory upstreamFactory) {
        this.upstreamFactory = upstreamFactory;
    }

    @Override
    public void addTransferListener(TransferListener listener) {
        listeners.add(listener);
    }

    private DataSource newUpstream() {
        DataSource ds = upstreamFactory.createDataSource();
        for (TransferListener l : listeners) ds.addTransferListener(l);
        return ds;
    }

    @Override
    public long open(DataSpec spec) throws IOException {
        uri = spec.uri;
        // Bounded requests (manifests, segments) don't need a cache.
        if (spec.length != C.LENGTH_UNSET) {
            stopReader();
            direct = newUpstream();
            return direct.open(spec);
        }
        direct = null;

        Reader r = reader;
        if (r != null && r.canServe(spec.uri, spec.position)) {
            r.reuseAt(spec.position);
            return r.end == C.LENGTH_UNSET ? C.LENGTH_UNSET : r.end - spec.position;
        }

        stopReader();
        DataSource up = newUpstream();
        long length = up.open(spec);   // errors (HTTP 4xx etc.) surface right here
        if (ring == null) ring = new byte[CAPACITY];
        reader = new Reader(up, spec.uri, spec.position,
                length == C.LENGTH_UNSET ? C.LENGTH_UNSET : spec.position + length, ring);
        reader.start();
        return length;
    }

    @Override
    public int read(byte[] buffer, int offset, int length) throws IOException {
        if (length == 0) return 0;
        if (direct != null) return direct.read(buffer, offset, length);
        Reader r = reader;
        if (r == null) throw new IOException("Not opened");
        return r.read(buffer, offset, length);
    }

    @Override
    public Uri getUri() {
        try {
            if (direct != null) return direct.getUri();
            Reader r = reader;
            if (r != null && r.upstream.getUri() != null) return r.upstream.getUri();
        } catch (Throwable ignored) { }
        return uri;
    }

    @Override
    public Map<String, List<String>> getResponseHeaders() {
        try {
            if (direct != null) return direct.getResponseHeaders();
            Reader r = reader;
            if (r != null) return r.upstream.getResponseHeaders();
        } catch (Throwable ignored) { }
        return Collections.emptyMap();
    }

    @Override
    public void close() throws IOException {
        if (direct != null) {
            DataSource d = direct;
            direct = null;
            d.close();
            return;
        }
        Reader r = reader;
        if (r != null) r.markClosed();   // keep downloading briefly so a quick re-open (seek) can reuse it
    }

    private void stopReader() {
        Reader r = reader;
        reader = null;
        if (r != null) r.shutdown();
    }

    // ------------------------------------------------------------------ reader thread

    private static final class Reader extends Thread {
        final DataSource upstream;
        final Uri uri;
        final long end;           // absolute end of stream, or LENGTH_UNSET
        private final byte[] ring;

        private long base;        // oldest byte still in the ring
        private long writePos;    // next byte the network will write
        private long readPos;     // next byte the player will read
        private boolean eof;
        private boolean stopped;
        private boolean closed;
        private long closedAt;
        private IOException error;

        Reader(DataSource upstream, Uri uri, long start, long end, byte[] ring) {
            super("read-ahead");
            this.upstream = upstream;
            this.uri = uri;
            this.end = end;
            this.ring = ring;
            this.base = start;
            this.writePos = start;
            this.readPos = start;
            setDaemon(true);
            setPriority(Thread.MAX_PRIORITY);
            synchronized (LIVE) { LIVE.add(this); }
        }

        synchronized boolean canServe(Uri u, long pos) {
            if (stopped || error != null || u == null || !u.equals(uri)) return false;
            if (pos < base) return false;
            if (pos <= writePos) return true;
            return !eof && pos - writePos <= REUSE_AHEAD;
        }

        synchronized void reuseAt(long pos) {
            readPos = pos;
            closed = false;
            notifyAll();
        }

        synchronized void markClosed() {
            closed = true;
            closedAt = System.currentTimeMillis();
            notifyAll();
        }

        synchronized void shutdown() {
            stopped = true;
            notifyAll();
        }

        private long space() {
            long low = Math.max(base, readPos - KEEP_BACK);
            if (low > writePos) low = writePos;
            base = low;
            return CAPACITY - (writePos - base);
        }

        @Override
        public void run() {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_FOREGROUND); } catch (Throwable ignored) { }
            byte[] tmp = new byte[CHUNK];
            try {
                while (true) {
                    int want;
                    synchronized (this) {
                        while (!stopped && space() <= 0) {
                            if (closed && System.currentTimeMillis() - closedAt > 3_000) stopped = true;
                            else wait(500);
                        }
                        if (closed && System.currentTimeMillis() - closedAt > 3_000) stopped = true;
                        if (stopped) break;
                        want = (int) Math.min(CHUNK, space());
                    }
                    int n = upstream.read(tmp, 0, want);
                    synchronized (this) {
                        if (stopped) break;
                        if (n == C.RESULT_END_OF_INPUT) {
                            eof = true;
                            notifyAll();
                            break;
                        }
                        int idx = (int) (writePos % CAPACITY);
                        int first = Math.min(n, CAPACITY - idx);
                        System.arraycopy(tmp, 0, ring, idx, first);
                        if (first < n) System.arraycopy(tmp, first, ring, 0, n - first);
                        writePos += n;
                        notifyAll();
                    }
                }
            } catch (InterruptedException e) {
                synchronized (this) { stopped = true; notifyAll(); }
            } catch (IOException e) {
                synchronized (this) { error = e; notifyAll(); }
                Diag.log("Read-ahead: " + Diag.describe(e));
            } finally {
                synchronized (LIVE) { LIVE.remove(this); }
                try { upstream.close(); } catch (Throwable ignored) { }
            }
        }

        int read(byte[] buf, int off, int len) throws IOException {
            synchronized (this) {
                while (readPos >= writePos) {
                    if (error != null) throw error;
                    if (eof) return C.RESULT_END_OF_INPUT;
                    if (stopped) throw new IOException("Read-ahead stopped");
                    try {
                        wait(1000);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new InterruptedIOException();
                    }
                }
                int n = (int) Math.min(len, writePos - readPos);
                int idx = (int) (readPos % CAPACITY);
                int first = Math.min(n, CAPACITY - idx);
                System.arraycopy(ring, idx, buf, off, first);
                if (first < n) System.arraycopy(ring, 0, buf, off + first, n - first);
                readPos += n;
                notifyAll();
                return n;
            }
        }
    }
}
