package com.brouken.player;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Video decoder mode, like MX Player:
 *  HW+ : default; hardware decoder, automatically switches to software (or back) when checks fail
 *  HW  : hardware decoders only
 *  SW  : software decoders first (FFmpeg, the app's own decoders, then Android's software codecs)
 */
public final class Decoder {

    public static final int HW_PLUS = 0;
    public static final int HW = 1;
    public static final int SW = 2;
    private static final String[] NAMES = {"HW+", "HW", "SW"};

    private Decoder() {}

    private static final String KEY_URI = "decoderOverrideUri";
    private static final String KEY_MODE = "decoderOverrideMode";
    static android.widget.TextView button;

    private static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }

    private static String currentUri(PlayerActivity a) {
        return a.mPrefs != null && a.mPrefs.mediaUri != null ? a.mPrefs.mediaUri.toString() : null;
    }

    private static SharedPreferences memory(Context c) {
        return c.getSharedPreferences("decoder_memory", Context.MODE_PRIVATE);
    }

    /** Mode for the current video: session override, else what worked for this file before, else HW+. */
    public static int get(Context c) {
        try {
            if (c instanceof PlayerActivity) {
                String uri = currentUri((PlayerActivity) c);
                if (uri != null && uri.equals(prefs(c).getString(KEY_URI, null))) {
                    return prefs(c).getInt(KEY_MODE, HW_PLUS);
                }
                if (uri != null) {
                    SharedPreferences m = memory(c);
                    if (m.contains(uri)) return m.getInt(uri, HW_PLUS);
                    String id = fileId(c, uri);
                    if (id != null && m.contains(id)) return m.getInt(id, HW_PLUS);
                }
            }
        } catch (Throwable ignored) { }
        return HW_PLUS;
    }

    static boolean learned(PlayerActivity a) {
        String uri = currentUri(a);
        if (uri == null) return false;
        String id = fileId(a, uri);
        return memory(a).contains(uri) || (id != null && memory(a).contains(id));
    }

    // Same video under another link: identified by its exact file size (e.g. 54,700,000,123 bytes),
    // which the link check measures before playback.
    private static final String SIZE_PREFIX = "size|";

    public static void rememberSize(Context c, String url, long size) {
        if (url == null || size <= 0) return;
        memory(c).edit().putLong(SIZE_PREFIX + url, size).apply();
    }

    private static String fileId(Context c, String uri) {
        long size = memory(c).getLong(SIZE_PREFIX + uri, -1);
        if (size <= 0) size = Diag.currentSize();
        return size > 0 ? "file|" + size : null;
    }

    /** Long-press on the decoder button: forget the saved decoder for this video. */
    public static void forget(PlayerActivity a) {
        String uri = currentUri(a);
        if (uri == null) return;
        SharedPreferences.Editor e = memory(a).edit().remove(uri);
        String id = fileId(a, uri);
        if (id != null) e.remove(id);
        e.apply();
        clearOverride(a);
        Diag.log("Saved decoder for this video cleared → HW+");
    }

    /** First picture shown: remember the decoder that worked for this file. */
    private static void learn(PlayerActivity a) {
        String uri = currentUri(a);
        if (uri == null) return;
        int mode = get(a);
        if (mode == HW_PLUS && !hasOverride(a) && !learned(a)) {
            return;   // default worked, nothing to remember
        }
        SharedPreferences m = memory(a);
        if (m.getAll().size() > 600) m.edit().clear().apply();
        SharedPreferences.Editor e = m.edit().putInt(uri, mode);
        String id = fileId(a, uri);
        if (id != null) e.putInt(id, mode);
        e.apply();
        Diag.log("Saved decoder " + name(mode) + " for this video (10 s smooth)");
    }

    /** After the player is built: SW seeks jump to the nearest keyframe so they don't stall decoding. */
    static void onPlayerCreated(PlayerActivity a, androidx.media3.exoplayer.ExoPlayer p) {
        if (a != null && p != null && get(a) == SW) {
            p.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC);
        }
    }

    static boolean hasOverride(PlayerActivity a) {
        String uri = currentUri(a);
        return uri != null && uri.equals(prefs(a).getString(KEY_URI, null));
    }

    static void setOverride(PlayerActivity a, int mode) {
        String uri = currentUri(a);
        if (uri == null) return;
        prefs(a).edit().putString(KEY_URI, uri).putInt(KEY_MODE, mode).apply();
    }

    /** Back to HW+ (video stopped). */
    public static void clearOverride(Context c) {
        prefs(c).edit().remove(KEY_URI).remove(KEY_MODE).apply();
    }

    public static String name(int mode) {
        return NAMES[Math.max(0, Math.min(2, mode))];
    }

    /** Decoder button: cycles the mode for this video only. */
    public static int cycle(Context c) {
        int next = (get(c) + 1) % 3;
        if (c instanceof PlayerActivity) setOverride((PlayerActivity) c, next);
        return next;
    }

    // ------------------------------------------------------------------ automatic choice
    //
    // Same idea as mpv-android's hwdec handling: look at the actual video codec/profile,
    // use hardware only when a hardware decoder really supports it, otherwise software.
    // If hardware still fails at runtime (decoder error, or no picture while audio plays),
    // switch this video to SW, and remember that codec/profile so next time SW is picked
    // straight away.

    private static final String KEY_BAD = "decoderHwBad";
    private static final android.os.Handler HANDLER = new android.os.Handler(android.os.Looper.getMainLooper());
    private static String currentSig;
    private static boolean firstFrame;
    private static boolean checkedThisLoad;
    private static boolean fellBack;

    static void onNewMedia() {
        currentSig = null;
        firstFrame = false;
        checkedThisLoad = false;
        fellBack = false;
        stallSince = 0;
        smoothSince = 0;
        savedThisLoad = false;
        HANDLER.removeCallbacks(WATCHDOG);
    }

    static String signature(androidx.media3.common.Format f) {
        String mime = f.sampleMimeType == null ? "?" : f.sampleMimeType;
        String profile = "";
        try {
            android.util.Pair<Integer, Integer> pl = MediaCodecUtil.getCodecProfileAndLevel(f);
            if (pl != null) profile = "p" + pl.first;
        } catch (Throwable ignored) { }
        if (profile.isEmpty() && f.codecs != null) {
            String c = f.codecs;
            profile = c.length() > 7 ? c.substring(0, 7) : c;   // e.g. avc1.6E (profile byte)
        }
        return mime + "|" + profile;
    }

    static String describe(androidx.media3.common.Format f) {
        String mime = f.sampleMimeType == null ? "?" : f.sampleMimeType.replace("video/", "");
        String extra = "";
        try {
            android.util.Pair<Integer, Integer> pl = MediaCodecUtil.getCodecProfileAndLevel(f);
            if (pl != null && "video/avc".equals(f.sampleMimeType)) {
                if (pl.first == 0x10) extra = " High 10";
                else if (pl.first == 0x20) extra = " High 4:2:2";
                else if (pl.first == 0x40) extra = " High 4:4:4";
            }
        } catch (Throwable ignored) { }
        return mime + extra + (f.codecs != null ? " (" + f.codecs + ")" : "");
    }

    private static boolean isBad(Context c, String sig) {
        return prefs(c).getStringSet(KEY_BAD, new java.util.HashSet<String>()).contains(sig);
    }

    private static void markBad(Context c, String sig) {
        java.util.Set<String> set = new java.util.HashSet<>(prefs(c).getStringSet(KEY_BAD, new java.util.HashSet<String>()));
        set.add(sig);
        prefs(c).edit().putStringSet(KEY_BAD, set).apply();
    }

    private static androidx.media3.common.Format videoFormat(androidx.media3.common.Tracks tracks) {
        androidx.media3.common.Format any = null;
        for (androidx.media3.common.Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != androidx.media3.common.C.TRACK_TYPE_VIDEO) continue;
            for (int i = 0; i < g.length; i++) {
                if (g.isTrackSelected(i)) return g.getTrackFormat(i);
                if (any == null) any = g.getTrackFormat(i);
            }
        }
        return any;
    }

    /** Does the device have any hardware decoder for this codec at all? (Profile limits are often under-reported.) */
    private static boolean hasHardware(androidx.media3.common.Format f) {
        try {
            for (MediaCodecInfo i : MediaCodecUtil.getDecoderInfos(f.sampleMimeType, false, false)) {
                if (i.hardwareAccelerated && !i.softwareOnly) return true;
            }
            // Dolby Vision is decoded by the HEVC/AVC hardware decoder on most devices.
            if ("video/dolby-vision".equals(f.sampleMimeType)) return true;
        } catch (Throwable ignored) { }
        return false;
    }

    /** Tracks known, before the first frame: choose the starting decoder for this file. */
    static void onTracks(androidx.media3.common.Tracks tracks, final PlayerActivity a) {
        if (a == null || tracks == null || tracks.isEmpty()) return;
        androidx.media3.common.Format f = videoFormat(tracks);
        if (f == null) return;
        currentSig = signature(f);
        rememberTried(a, get(a));
        if (checkedThisLoad) return;
        checkedThisLoad = true;
        if (hasOverride(a) || learned(a) || get(a) == SW) {
            Diag.log("Video: " + describe(f) + " · decoder " + name(get(a)) + (learned(a) && !hasOverride(a) ? " (worked before)" : ""));
            return;
        }

        String mime = f.sampleMimeType == null ? "" : f.sampleMimeType.toLowerCase();
        String reason = null;
        if (mime.contains("vc1") || mime.contains("wmv")) reason = "VC-1";
        else if (isBad(a, currentSig)) reason = "hardware failed on this codec before";
        else if (!hasHardware(f)) reason = "no hardware decoder for this codec";

        if (reason == null) {
            Diag.log("Video: " + describe(f) + " · trying hardware (HW+)");
            return;
        }
        switchTo(a, SW, describe(f) + ": " + reason);
    }

    // ------------------------------------------------------------------ runtime checks

    private static String triedUri;
    private static final java.util.Set<Integer> TRIED = new java.util.HashSet<>();

    private static void rememberTried(PlayerActivity a, int mode) {
        String uri = currentUri(a);
        if (uri == null) return;
        if (!uri.equals(triedUri)) {
            triedUri = uri;
            TRIED.clear();
        }
        TRIED.add(mode);
    }

    /** Was the decoder actually running on hardware (per the decoder name)? */
    private static boolean runningOnHardware(PlayerActivity a) {
        String d = Diag.videoDecoderName();
        if (d == null || d.isEmpty()) return get(a) != SW;
        return Diag.decoderKind(d).equals("HW");
    }

    /** Something failed with the current decoder: try the other kind, then give up. */
    private static void fallback(PlayerActivity a, String why) {
        int current = get(a);
        rememberTried(a, current);
        int next;
        if (runningOnHardware(a)) {
            next = SW;                                   // hardware failed → software
            if (currentSig != null && current != HW) markBad(a, currentSig);
        } else {
            next = HW;                                   // software failed/too slow → hardware only
        }
        if (TRIED.contains(next)) {
            int other = next == SW ? HW : SW;
            if (TRIED.contains(other)) {
                unsupported(a);
                return;
            }
            next = other;
        }
        switchTo(a, next, why);
    }

    private static void switchTo(final PlayerActivity a, int mode, String why) {
        setOverride(a, mode);
        rememberTried(a, mode);
        fellBack = true;
        Diag.log("→ " + name(mode) + " decoder (" + why + ")");
        HANDLER.post(new Runnable() {
            @Override
            public void run() {
                if (PlayerActivity.player != null) {
                    a.releasePlayer();
                    a.initializePlayer();
                }
            }
        });
    }

    /** Video decoder error: try the other decoder type. */
    static void onError(androidx.media3.common.PlaybackException e, PlayerActivity a) {
        if (a == null) return;
        int code = e.errorCode;
        boolean decoding = code >= 4000 && code < 5000;
        boolean video = !(e instanceof androidx.media3.exoplayer.ExoPlaybackException)
                || ((androidx.media3.exoplayer.ExoPlaybackException) e).rendererFormat == null
                || isVideo(((androidx.media3.exoplayer.ExoPlaybackException) e).rendererFormat);
        if (!decoding || !video) return;
        fallback(a, "decoder error " + e.getErrorCodeName());
    }

    private static boolean isVideo(androidx.media3.common.Format f) {
        return f.sampleMimeType != null && f.sampleMimeType.startsWith("video/");
    }

    static void onRenderedFirstFrame(PlayerActivity a) {
        firstFrame = true;
        stallSince = 0;
        HANDLER.removeCallbacks(WATCHDOG);
        smoothSince = 0;   // saving happens after 10 s of smooth playback (see checkStall)
        if (a != null) applySavedBrightness(a);
    }

    /** The brightness you set by swiping is applied only once a video is on screen, not when the app opens. */
    static void applySavedBrightness(PlayerActivity a) {
        if (Utils.isTvBox(a)) return;   // TV: picture settings handle brightness
        try {
            BrightnessControl bc = a.mBrightnessControl;
            if (bc != null && a.mPrefs != null && a.mPrefs.brightness >= 0) {
                bc.setScreenBrightness(bc.levelToBrightness(bc.currentBrightnessLevel));
            }
        } catch (Throwable ignored) { }
    }

    /** Back to the system brightness (no video playing). */
    static void systemBrightness(PlayerActivity a) {
        if (Utils.isTvBox(a)) return;
        try {
            if (a.mBrightnessControl != null) a.mBrightnessControl.setScreenBrightness(-1f);
        } catch (Throwable ignored) { }
    }

    /** Playing but no picture after a few seconds = silent decoder failure (black screen). */
    static void onIsPlayingChanged(boolean playing, PlayerActivity a) {
        HANDLER.removeCallbacks(WATCHDOG);
        watchdogActivity = a;
        if (playing && !firstFrame && currentSig != null) HANDLER.postDelayed(WATCHDOG, 5000);
    }

    private static PlayerActivity watchdogActivity;
    private static final Runnable WATCHDOG = new Runnable() {
        @Override
        public void run() {
            PlayerActivity a = watchdogActivity;
            if (a == null || firstFrame || PlayerActivity.player == null || !PlayerActivity.player.isPlaying()) return;
            fallback(a, "no picture");
        }
    };

    private static long stallSince;
    private static long smoothSince;
    private static int droppedAtSmoothStart;
    private static boolean savedThisLoad;

    /**
     * Called twice a second. "Loading" while the buffer is already full means the data is
     * there but the decoder isn't producing frames (e.g. a software decoder too slow for 4K,
     * or a decoder that silently stalled) – switch decoder.
     */
    static void checkStall(PlayerActivity a) {
        androidx.media3.exoplayer.ExoPlayer p = PlayerActivity.player;
        if (a == null || p == null || currentSig == null) { stallSince = 0; smoothSince = 0; return; }
        checkSmooth(a, p);
        boolean buffering = p.getPlaybackState() == androidx.media3.common.Player.STATE_BUFFERING && p.getPlayWhenReady();
        long buffered = p.getTotalBufferedDuration();
        if (!buffering || buffered < 8_000) { stallSince = 0; return; }
        long now = android.os.SystemClock.elapsedRealtime();
        if (stallSince == 0) { stallSince = now; return; }
        if (now - stallSince > 6_000) {
            stallSince = 0;
            fallback(a, "stuck loading with " + buffered / 1000 + " s buffered");
        }
    }

    /**
     * Save the decoder for this video only after 10 s of smooth playback: picture on screen,
     * playing without any loading pause, and at most a few dropped frames.
     */
    private static void checkSmooth(PlayerActivity a, androidx.media3.exoplayer.ExoPlayer p) {
        if (savedThisLoad || !firstFrame) return;
        boolean playingOk = p.isPlaying() && p.getPlaybackState() == androidx.media3.common.Player.STATE_READY;
        int dropped = 0;
        try {
            androidx.media3.exoplayer.DecoderCounters dc = p.getVideoDecoderCounters();
            if (dc != null) { dc.ensureUpdated(); dropped = dc.droppedBufferCount; }
        } catch (Throwable ignored) { }
        long now = android.os.SystemClock.elapsedRealtime();
        if (!playingOk) { smoothSince = 0; return; }
        if (smoothSince == 0) { smoothSince = now; droppedAtSmoothStart = dropped; return; }
        if (dropped - droppedAtSmoothStart > 6) {           // stutter: start the 10 s over
            smoothSince = now;
            droppedAtSmoothStart = dropped;
            return;
        }
        if (now - smoothSince >= 10_000) {
            savedThisLoad = true;
            learn(a);
        }
    }

    private static void unsupported(PlayerActivity a) {
        Diag.log("✗ No decoder on this device can play this video (HW and SW both failed)");
        android.widget.Toast.makeText(a, "This video's codec isn't supported on this device. Try mpv or VLC.", android.widget.Toast.LENGTH_LONG).show();
    }

    /** Called from NetCompat.apply() before the player is built. */
    static void apply(ExoPlayer.Builder builder, PlayerActivity activity) {
        final int mode = get(activity);
        boolean mapDV7 = activity.mPrefs != null && activity.mPrefs.mapDV7ToHevc;
        DefaultRenderersFactory factory = new UrlRenderersFactory(activity, mode)
                .setExtensionRendererMode(mode == SW
                        ? DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                        : DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(mode != HW)
                .setMediaCodecSelector(new Selector(mode));
        factory.setMapDV7ToHevc(mapDV7);
        builder.setRenderersFactory(factory);
        if (button != null) button.setText(name(mode));
        Diag.log("Decoder mode: " + name(mode) + (hasOverride(activity) ? " (this video)" : learned(activity) ? " (worked before)" : ""));
    }

    private static final class Selector implements MediaCodecSelector {
        private final int mode;

        Selector(int mode) {
            this.mode = mode;
        }

        @Override
        public List<MediaCodecInfo> getDecoderInfos(String mimeType, boolean secure, boolean tunneling)
                throws MediaCodecUtil.DecoderQueryException {
            List<MediaCodecInfo> all = MediaCodecSelector.DEFAULT.getDecoderInfos(mimeType, secure, tunneling);
            if (mimeType == null || !mimeType.startsWith("video/")) return all;   // audio unchanged
            List<MediaCodecInfo> hw = new ArrayList<>();
            List<MediaCodecInfo> sw = new ArrayList<>();
            for (MediaCodecInfo i : all) {
                if (i.hardwareAccelerated && !i.softwareOnly) hw.add(i);
                else sw.add(i);
            }
            List<MediaCodecInfo> out = new ArrayList<>();
            if (mode == HW) {
                out.addAll(hw);
            } else if (mode == SW) {
                out.addAll(sw);
                out.addAll(hw);
            } else {
                // HW+: never let a software decoder "win" just because hardware under-reports its
                // limits (e.g. 4K HEVC); software is only used when no hardware decoder exists.
                // Real hardware failures are caught at runtime and switch this video to SW.
                out.addAll(hw.isEmpty() ? sw : hw);
            }
            return out;
        }
    }
}
