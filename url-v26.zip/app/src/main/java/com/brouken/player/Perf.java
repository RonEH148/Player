package com.brouken.player;

/** Memory budget for buffering, scaled to what this device gives the app (Tab S9: ~512 MB). */
public final class Perf {
    private Perf() {}

    private static long heap() {
        return Runtime.getRuntime().maxMemory();
    }

    /** Background download cache. */
    public static int readAheadBytes() {
        long h = heap();
        if (h >= 400L * 1024 * 1024) return 64 * 1024 * 1024;
        if (h >= 256L * 1024 * 1024) return 40 * 1024 * 1024;
        return 24 * 1024 * 1024;   // 2 GB TVs (e.g. Philips 8100: ~192 MB heap)
    }

    /** Demuxed video/audio waiting to be decoded (the "buffer s" in the overlay). */
    public static int sampleBufferBytes() {
        long h = heap();
        if (h >= 400L * 1024 * 1024) return 200 * 1024 * 1024;   // ~25 s of an 65 Mbit/s 4K remux
        if (h >= 256L * 1024 * 1024) return 100 * 1024 * 1024;
        return 64 * 1024 * 1024;   // ~6 s of a 4K remux at 80 Mbit/s, plus 24 MB read-ahead
    }
}
