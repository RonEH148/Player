package com.brouken.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.Locale;

/**
 * "Continue watching": the last position of every video (by link), saved while playing and when
 * it's closed. Opening it again asks Resume / Start from the beginning, when resuming really
 * works there (links that can seek, files, and links that can't seek when the USB drive holds
 * the video up to that point).
 */
final class ResumePoints {

    private ResumePoints() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("resume_points", Context.MODE_PRIVATE);
    }

    /** Saved position (ms), or 0. */
    static long get(Context c, Uri uri) {
        if (uri == null) return 0;
        String v = prefs(c).getString(uri.toString(), null);
        if (v == null) return 0;
        try { return Long.parseLong(v.split("\\|")[0]); } catch (Exception e) { return 0; }
    }

    static void put(Context c, Uri uri, long pos, long dur) {
        if (uri == null) return;
        SharedPreferences p = prefs(c);
        boolean finished = dur > 0 && dur != C.TIME_UNSET && pos > dur - 120_000;   // last 2 minutes: watched
        if (finished) markWatched(c, uri.toString());
        if (pos < 30_000 || finished) {
            if (p.contains(uri.toString())) p.edit().remove(uri.toString()).apply();
        } else {
            if (p.getAll().size() > 500) p.edit().clear().apply();
            p.edit().putString(uri.toString(), pos + "|" + dur + "|" + System.currentTimeMillis()).apply();
        }
        UsbBuffer.notePosition(uri, pos, dur);
    }

    // ------------------------------------------------------------------ for Saved links / start screen

    /** One unfinished video: link, position, length, when it was last watched. */
    static final class Entry {
        final String uri;
        final long pos, dur, time;
        Entry(String uri, long pos, long dur, long time) {
            this.uri = uri; this.pos = pos; this.dur = dur; this.time = time;
        }
    }

    /** All unfinished videos, most recently watched first. */
    static java.util.List<Entry> all(Context c) {
        java.util.List<Entry> out = new java.util.ArrayList<>();
        for (java.util.Map.Entry<String, ?> e : prefs(c).getAll().entrySet()) {
            if (!(e.getValue() instanceof String)) continue;
            String[] f = ((String) e.getValue()).split("\\|");
            try {
                long pos = Long.parseLong(f[0]);
                long dur = f.length > 1 ? Long.parseLong(f[1]) : 0;
                long t = f.length > 2 ? Long.parseLong(f[2]) : 0;
                out.add(new Entry(e.getKey(), pos, dur, t));
            } catch (Exception ignored) { }
        }
        java.util.Collections.sort(out, (a, b) -> Long.compare(b.time, a.time));
        return out;
    }

    private static SharedPreferences names(Context c) {
        return c.getSharedPreferences("resume_names", Context.MODE_PRIVATE);
    }

    /** Your own name for a video in Continue watching, or null. */
    static String name(Context c, String uri) {
        return names(c).getString(uri, null);
    }

    static void setName(Context c, String uri, String name) {
        names(c).edit().putString(uri, name).apply();
    }

    /** Removed from Continue watching (the saved link and the USB download stay). */
    static void remove(Context c, String uri) {
        prefs(c).edit().remove(uri).apply();
        names(c).edit().remove(uri).apply();
    }

    private static SharedPreferences watched(Context c) {
        return c.getSharedPreferences("watched", Context.MODE_PRIVATE);
    }

    private static void markWatched(Context c, String uri) {
        SharedPreferences w = watched(c);
        if (w.getAll().size() > 1000) w.edit().clear().apply();
        w.edit().putLong(uri, System.currentTimeMillis()).apply();
    }

    /** Watched to the end: link → when. */
    static java.util.Map<String, Long> watchedAll(Context c) {
        java.util.Map<String, Long> out = new java.util.HashMap<>();
        for (java.util.Map.Entry<String, ?> e : watched(c).getAll().entrySet()) {
            if (e.getValue() instanceof Long) out.put(e.getKey(), (Long) e.getValue());
        }
        return out;
    }

    /** Saves the player's position now (pause, close). */
    static void save(Context c) {
        try {
            ExoPlayer p = PlayerActivity.player;
            if (p == null || p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return;
            if (p.getPlaybackState() == Player.STATE_IDLE) return;
            Uri u = p.getCurrentMediaItem().localConfiguration.uri;
            if (p.getPlaybackState() == Player.STATE_ENDED) { put(c, u, Long.MAX_VALUE / 4, p.getDuration()); return; }
            put(c, u, p.getCurrentPosition(), p.getDuration());
        } catch (Throwable ignored) { }
    }

    private static long lastTick;

    /** Twice a second from the overlay timer: saved every 10 s while playing. */
    static void tick(Context c) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastTick < 10_000) return;
        ExoPlayer p = PlayerActivity.player;
        if (p == null || !p.isPlaying()) return;
        lastTick = now;
        save(c);
    }

    // ------------------------------------------------------------------ opening a video

    private static long pending;
    private static String pendingUri;

    /** A new video is opened: start where it was left, if that works here. Returns the position or 0. */
    static long startAt(PlayerActivity a, Uri uri) {
        pending = 0;
        pendingUri = null;
        long pos = get(a, uri);
        if (pos <= 0) return 0;
        boolean ok = !NetCompat.isHttp(uri) || !RangeSupport.isLinear(uri)
                || UsbBuffer.storedUntilMs(a, uri) >= pos + 5_000;
        if (!ok) {
            Diag.log("Continue watching: not possible here (server can't seek, not on the USB drive) – from the start");
            return 0;
        }
        pending = pos;
        pendingUri = uri.toString();
        return pos;
    }

    /** First picture of the video: ask once. */
    static void onFirstFrame(final PlayerActivity a) {
        if (a == null || pending <= 0 || PlayerActivity.player == null) return;
        final ExoPlayer p = PlayerActivity.player;
        try {
            if (p.getCurrentMediaItem() == null || !p.getCurrentMediaItem().localConfiguration.uri.toString().equals(pendingUri)) return;
        } catch (Throwable t) { return; }
        final long pos = pending;
        pending = 0;
        p.pause();
        long dur = p.getDuration();
        String msg = "You stopped at " + time(pos) + (dur > 0 && dur != C.TIME_UNSET ? " of " + time(dur) + "." : ".");
        AlertDialog.Builder b = new AlertDialog.Builder(a)
                .setTitle("Continue watching?")
                .setPositiveButton("Resume", (x, w) -> p.play())
                .setNegativeButton("Start from the beginning", (x, w) -> {
                    p.seekTo(0);   // straight to the player: a jump back to 0:00 is always allowed
                    p.play();
                })
                .setOnCancelListener(x -> p.play());
        if (dur > 0 && dur != C.TIME_UNSET) b.setView(progressView(a, msg, pos, dur));
        else b.setMessage(msg);
        AlertDialog d = b.create();
        d.show();
    }

    /** "You stopped at …" with a glass progress bar under it (0:00 … length). */
    static android.view.View progressView(Context c, String msg, long pos, long dur) {
        float d = c.getResources().getDisplayMetrics().density;
        android.widget.LinearLayout box = new android.widget.LinearLayout(c);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(Math.round(24 * d), Math.round(6 * d), Math.round(24 * d), Math.round(4 * d));
        android.widget.TextView t = new android.widget.TextView(c);
        t.setText(msg);
        t.setTextColor(0xFFD8EFE6);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16);
        box.addView(t);
        android.widget.ProgressBar bar = glassBar(c, pos, dur);
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, Math.round(8 * d));
        lp.topMargin = Math.round(16 * d);
        box.addView(bar, lp);
        android.widget.LinearLayout ends = new android.widget.LinearLayout(c);
        android.widget.TextView a = new android.widget.TextView(c);
        a.setText("0:00");
        android.widget.TextView z = new android.widget.TextView(c);
        z.setText(time(dur));
        z.setGravity(android.view.Gravity.END);
        for (android.widget.TextView x : new android.widget.TextView[]{a, z}) {
            x.setTextColor(0xFF9DBDB1);
            x.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
            ends.addView(x, new android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }
        android.widget.LinearLayout.LayoutParams lp2 = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = Math.round(6 * d);
        box.addView(ends, lp2);
        return box;
    }

    /** Glass progress bar (lit glass up to the position, bright edge where you stopped). */
    static android.widget.ProgressBar glassBar(Context c, long pos, long dur) {
        android.widget.ProgressBar bar = new android.widget.ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(false);
        bar.setMax(1000);
        bar.setProgress(dur > 0 ? (int) Math.max(0, Math.min(1000, pos * 1000 / dur)) : 0);
        bar.setProgressDrawable(c.getResources().getDrawable(R.drawable.glass_progress, c.getTheme()));
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            bar.setProgressTintList(null);
            bar.setProgressBackgroundTintList(null);
        }
        bar.setFocusable(false);
        return bar;
    }

    static String time(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                : String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }
}
