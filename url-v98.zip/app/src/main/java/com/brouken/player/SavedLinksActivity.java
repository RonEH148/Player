package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Saved links: your own list of video links with names. Play (with the usual link check), copy,
 * rename, share and delete them. Opened from the ★ button in the player and from "Open link".
 */
public class SavedLinksActivity extends Activity {

    /** The link of the video that's open in the player (offered as "Save current video"). */
    static final String EXTRA_CURRENT = "current";
    static final String EXTRA_CURRENT_NAME = "currentName";

    // ------------------------------------------------------------------ storage

    static final class Link {
        String name;
        String url;
        long added;

        Link(String name, String url, long added) {
            this.name = name;
            this.url = url;
            this.added = added;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("saved_links", Context.MODE_PRIVATE);
    }

    static List<Link> load(Context c) {
        List<Link> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Link(o.optString("n"), o.optString("u"), o.optLong("t")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    static void save(Context c, List<Link> links) {
        try {
            JSONArray a = new JSONArray();
            for (Link l : links) {
                JSONObject o = new JSONObject();
                o.put("n", l.name);
                o.put("u", l.url);
                o.put("t", l.added);
                a.put(o);
            }
            prefs(c).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Renamed somewhere else (Continue watching): the saved link with this URL gets the name too. */
    static void renameByUrl(Context c, String url, String name) {
        List<Link> all = load(c);
        String k = key(url);
        Link target = null;
        for (Link l : all) if (key(l.url).equals(k)) target = l;
        if (target == null) return;
        String n = name;
        for (int i = 2; ; i++) {
            boolean taken = false;
            for (Link l : all) if (l != target && l.name.trim().equalsIgnoreCase(n.trim())) taken = true;
            if (!taken) break;
            n = name + " (" + i + ")";
        }
        target.name = n;
        save(c, all);
    }

    /** A name to start with: the file name in the link, else the site. */
    static String defaultName(String url) {
        try {
            String t = Titles.fromUrl(Uri.parse(url));
            if (t != null && !t.trim().isEmpty()) return t.trim();
            String host = Uri.parse(url).getHost();
            if (host != null) return host;
        } catch (Throwable ignored) { }
        return url;
    }

    // ------------------------------------------------------------------ rules

    static final int MAX_NAME = 120;

    /** Same link, written differently (spaces, pixeldrain /u/ vs /api/file/): compared like this. */
    static String key(String url) {
        String u = PasteUrlActivity.normalize(url.trim());
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    private Link byUrl(String url, Link except) {
        String k = key(url);
        for (Link l : links) if (l != except && key(l.url).equals(k)) return l;
        return null;
    }

    private Link byName(String name, Link except) {
        for (Link l : links) if (l != except && l.name.trim().equalsIgnoreCase(name.trim())) return l;
        return null;
    }

    /** A free name based on {@code base}: "Name", "Name (2)", "Name (3)" … */
    private String freeName(String base) {
        String b = base.length() > MAX_NAME ? base.substring(0, MAX_NAME) : base;
        if (byName(b, null) == null) return b;
        for (int i = 2; ; i++) {
            String n = b + " (" + i + ")";
            if (byName(n, null) == null) return n;
        }
    }

    /** Problem with this name, or null if it can be used. */
    private String nameProblem(String name, Link except) {
        if (name.isEmpty()) return "Enter a name";
        if (name.length() > MAX_NAME) return "Keep the name under " + MAX_NAME + " characters";
        Link other = byName(name, except);
        return other != null ? "A link with this name already exists" : null;
    }

    // ------------------------------------------------------------------ screen

    private List<Link> links;
    /** Shown after search, filters and sorting. */
    private final List<Item> shown = new ArrayList<>();
    private final List<Item> items = new ArrayList<>();
    private java.util.Map<String, UsbBuffer.Stored> stored = new java.util.HashMap<>();
    private boolean storedLoaded;

    private static final String[] STATUS = {"All", "On drive", "In progress", "Not started", "Watched"};
    private static final String[] SORTS = {"Last watched", "Recently added", "A–Z", "Size"};
    private static final String[] QUALITY = {"4K", "1080p", "Dolby Vision", "HDR10"};
    private static final String[] SIZES = {"> 20 GB", "< 20 GB"};
    private static final long BIG = 20_000_000_000L;

    private int status, sortMode, quality = -1, sizeFilter = -1;
    private String query = "";

    private ArrayAdapter adapter;
    private android.widget.ListView listView;
    private TextView count, empty;
    private EditText search;
    private final List<TextView> statusChips = new ArrayList<>();
    private final List<TextView> qualityChips = new ArrayList<>();
    private final List<TextView> sizeChips = new ArrayList<>();
    private TextView sortChip;
    private LinearLayout rail;

    /** A saved link with what's known about it. */
    static final class Item {
        Link link;
        UsbBuffer.Stored drive;
        ResumePoints.Entry resume;
        long watchedAt, lastWatched, size;
        boolean is4k, is1080, isDv, isHdr;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Backdrop.init(this);
        SharedPreferences p = prefs(this);
        status = p.getInt("filterStatus", 0);
        sortMode = p.getInt("sort", 0);
        if (status < 0 || status >= STATUS.length) status = 0;
        if (sortMode < 0 || sortMode >= SORTS.length) sortMode = 0;
        links = load(this);
        setContentView(buildScreen());
        reload();
        listView.post(() -> { if (!shown.isEmpty()) listView.requestFocus(); });
        // what's on the USB drive: read in the background (the drive may be slow to answer)
        new Thread(() -> {
            final java.util.Map<String, UsbBuffer.Stored> s = UsbBuffer.storedAll(getApplicationContext());
            runOnUiThread(() -> {
                if (isFinishing()) return;
                stored = new java.util.HashMap<>();
                for (java.util.Map.Entry<String, UsbBuffer.Stored> e : s.entrySet()) stored.put(key(e.getKey()), e.getValue());
                storedLoaded = true;
                reload();
            });
        }, "saved-links-drive").start();
    }

    @Override
    public void onBackPressed() {
        close();
    }

    private static char group(String name) {
        char c = name.isEmpty() ? '#' : Character.toUpperCase(name.trim().isEmpty() ? '#' : name.trim().charAt(0));
        return c >= 'A' && c <= 'Z' ? c : '#';
    }

    private static final java.util.regex.Pattern P4K = java.util.regex.Pattern.compile("(?i)(2160p|\\b4k\\b|\\buhd\\b)");
    private static final java.util.regex.Pattern P1080 = java.util.regex.Pattern.compile("(?i)1080[pi]");
    private static final java.util.regex.Pattern PDV = java.util.regex.Pattern.compile("(?i)(\\bdv\\b|dovi|dolby[ ._-]?vision)");
    private static final java.util.regex.Pattern PHDR = java.util.regex.Pattern.compile("(?i)\\bhdr(10)?(\\+|plus)?\\b");

    /** Links, resume points, watched list and the drive, put together. */
    private void reload() {
        links = load(this);
        java.util.Map<String, ResumePoints.Entry> resume = new java.util.HashMap<>();
        for (ResumePoints.Entry e : ResumePoints.all(this)) resume.put(key(e.uri), e);
        java.util.Map<String, Long> watched = new java.util.HashMap<>();
        for (java.util.Map.Entry<String, Long> e : ResumePoints.watchedAll(this).entrySet()) watched.put(key(e.getKey()), e.getValue());
        items.clear();
        for (Link l : links) {
            Item it = new Item();
            it.link = l;
            String k = key(l.url);
            it.drive = stored.get(k);
            it.resume = resume.get(k);
            Long w = watched.get(k);
            it.watchedAt = w != null ? w : 0;
            it.lastWatched = Math.max(it.watchedAt, it.resume != null ? it.resume.time : 0);
            it.size = it.drive != null && it.drive.size > 0 ? it.drive.size : Decoder.knownSize(this, l.url);
            if (it.size <= 0) it.size = Decoder.knownSize(this, PasteUrlActivity.normalize(l.url));
            String text = l.name + " " + l.url;
            it.is4k = P4K.matcher(text).find();
            it.is1080 = P1080.matcher(text).find();
            it.isDv = PDV.matcher(text).find();
            it.isHdr = PHDR.matcher(text).find() || it.isDv;
            items.add(it);
        }
        applyFilter();
    }

    private boolean statusMatches(Item it, int s) {
        switch (s) {
            case 1: return it.drive != null;
            case 2: return it.resume != null;
            case 3: return it.resume == null && it.watchedAt == 0;
            case 4: return it.resume == null && it.watchedAt > 0;
            default: return true;
        }
    }

    private boolean otherFiltersMatch(Item it) {
        if (!query.isEmpty() && !it.link.name.toLowerCase(java.util.Locale.ROOT).contains(query)
                && !it.link.url.toLowerCase(java.util.Locale.ROOT).contains(query)) return false;
        switch (quality) {
            case 0: if (!it.is4k) return false; break;
            case 1: if (!it.is1080) return false; break;
            case 2: if (!it.isDv) return false; break;
            case 3: if (!it.isHdr) return false; break;
        }
        if (sizeFilter == 0 && !(it.size > BIG)) return false;
        if (sizeFilter == 1 && !(it.size > 0 && it.size <= BIG)) return false;
        return true;
    }

    private void applyFilter() {
        shown.clear();
        int[] counts = new int[STATUS.length];
        for (Item it : items) {
            if (!otherFiltersMatch(it)) continue;
            for (int s = 0; s < STATUS.length; s++) if (statusMatches(it, s)) counts[s]++;
            if (statusMatches(it, status)) shown.add(it);
        }
        java.util.Comparator<Item> byName = (a, b) -> a.link.name.compareToIgnoreCase(b.link.name);
        switch (sortMode) {
            case 0: java.util.Collections.sort(shown, (a, b) -> a.lastWatched != b.lastWatched
                    ? Long.compare(b.lastWatched, a.lastWatched) : Long.compare(b.link.added, a.link.added)); break;
            case 1: java.util.Collections.sort(shown, (a, b) -> Long.compare(b.link.added, a.link.added)); break;
            case 2: java.util.Collections.sort(shown, byName); break;
            default: java.util.Collections.sort(shown, (a, b) -> Long.compare(b.size, a.size));
        }
        for (int s = 0; s < statusChips.size(); s++) {
            TextView t = statusChips.get(s);
            t.setText(STATUS[s] + "  " + counts[s]);
            t.setActivated(s == status);
        }
        for (int q = 0; q < qualityChips.size(); q++) qualityChips.get(q).setActivated(q == quality);
        for (int z = 0; z < sizeChips.size(); z++) sizeChips.get(z).setActivated(z == sizeFilter);
        if (sortChip != null) sortChip.setText("Sort: " + SORTS[sortMode] + "  ▾");
        if (count != null) count.setText(links.size() + (links.size() == 1 ? " link" : " links"));
        if (empty != null) {
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            empty.setText(links.isEmpty()
                    ? "No saved links yet.\nAdd one with “Add link”" + (canSaveCurrent() ? ", or save the video that's playing." : ".")
                    : "Nothing matches.\nTry another filter or search.");
        }
        buildRail();
        if (adapter != null) adapter.notifyDataSetChanged();
        prefs(this).edit().putInt("filterStatus", status).putInt("sort", sortMode).apply();
    }

    private boolean canSaveCurrent() {
        String current = getIntent().getStringExtra(EXTRA_CURRENT);
        return current != null && PasteUrlActivity.isValid(current) && byUrl(current, null) == null;
    }

    /** Called after a change (rename, delete, add): read everything again. */
    private void refresh() {
        reload();
        updateHeaderButtons();
    }

    // ------------------------------------------------------------------ building the screen

    private View saveCurrentButton;

    private View buildScreen() {
        float d = getResources().getDisplayMetrics().density;
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(18), dp(24), dp(16));
        GlassDrawable glass = new GlassDrawable(panel, 24);
        panel.setBackground(glass);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            panel.setElevation(dp(14));
            panel.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        }
        int sw = getResources().getDisplayMetrics().widthPixels, sh = getResources().getDisplayMetrics().heightPixels;
        android.widget.FrameLayout.LayoutParams plp = new android.widget.FrameLayout.LayoutParams(
                Math.min(Math.round(sw * 0.92f), dp(1100)), Math.round(sh * 0.92f), Gravity.CENTER);
        root.addView(panel, plp);

        // header: back, title, count, search, buttons
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageButton back = new android.widget.ImageButton(this);
        back.setImageResource(R.drawable.ic_g_back);
        back.setBackgroundResource(R.drawable.glass_chip);
        back.setContentDescription("Close");
        back.setOnClickListener(v -> close());
        head.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        TextView title = text("Saved links", 24, 0xFFEAFFF6);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.leftMargin = dp(14);
        head.addView(title, tlp);
        count = text("", 13, 0xFFA9CCBF);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        clp.leftMargin = dp(12);
        head.addView(count, clp);

        search = new EditText(this);
        search.setHint("Search");
        search.setSingleLine(true);
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        search.setTextColor(0xFFEAFFF6);
        search.setHintTextColor(0xFF7FA396);
        search.setBackgroundResource(R.drawable.glass_input);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_g_search, 0, 0, 0);
        search.setCompoundDrawablePadding(dp(10));
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                query = s.toString().trim().toLowerCase(java.util.Locale.ROOT);
                applyFilter();
            }
        });
        search.setOnEditorActionListener((v, a, e) -> {
            hideKeyboard(v);
            if (listView != null && !shown.isEmpty()) listView.requestFocus();
            return true;
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(300), dp(46));
        slp.leftMargin = dp(12);
        head.addView(search, slp);

        Button save = button("Save this video", false);
        save.setOnClickListener(v -> addDialog(getIntent().getStringExtra(EXTRA_CURRENT), getIntent().getStringExtra(EXTRA_CURRENT_NAME)));
        saveCurrentButton = save;
        head.addView(save, buttonLp());
        Button add = button("Add link", true);
        add.setOnClickListener(v -> addDialog(null, null));
        head.addView(add, buttonLp());
        panel.addView(head);

        // row 1: status + sort
        android.widget.HorizontalScrollView r1 = new android.widget.HorizontalScrollView(this);
        r1.setHorizontalScrollBarEnabled(false);
        r1.setClipToPadding(false);
        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        for (int s = 0; s < STATUS.length; s++) {
            final int which = s;
            TextView c = chip(STATUS[s]);
            if (s == 1) c.setCompoundDrawablesWithIntrinsicBounds(dot(), null, null, null);
            c.setOnClickListener(v -> { status = which; applyFilter(); });
            statusChips.add(c);
            row1.addView(c);
        }
        View gap = new View(this);
        row1.addView(gap, new LinearLayout.LayoutParams(dp(18), 1));
        sortChip = chip("Sort");
        sortChip.setOnClickListener(v -> chooseSort());
        row1.addView(sortChip);
        r1.addView(row1);
        LinearLayout.LayoutParams r1lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r1lp.topMargin = dp(12);
        panel.addView(r1, r1lp);

        // row 2: quality, size
        android.widget.HorizontalScrollView r2 = new android.widget.HorizontalScrollView(this);
        r2.setHorizontalScrollBarEnabled(false);
        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        row2.addView(label("Quality"));
        for (int q = 0; q < QUALITY.length; q++) {
            final int which = q;
            TextView c = chip(QUALITY[q]);
            c.setOnClickListener(v -> { quality = quality == which ? -1 : which; applyFilter(); });
            qualityChips.add(c);
            row2.addView(c);
        }
        TextView sz = label("Size");
        ((LinearLayout.LayoutParams) sz.getLayoutParams()).leftMargin = dp(16);
        row2.addView(sz);
        for (int z = 0; z < SIZES.length; z++) {
            final int which = z;
            TextView c = chip(SIZES[z]);
            c.setOnClickListener(v -> { sizeFilter = sizeFilter == which ? -1 : which; applyFilter(); });
            sizeChips.add(c);
            row2.addView(c);
        }
        r2.addView(row2);
        LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r2lp.topMargin = dp(4);
        panel.addView(r2, r2lp);

        // body: list + A–Z rail
        LinearLayout body = new LinearLayout(this);
        android.widget.FrameLayout listBox = new android.widget.FrameLayout(this);
        listView = new android.widget.ListView(this);
        listView.setDivider(null);
        listView.setDividerHeight(dp(6));
        listView.setSelector(R.drawable.glass_list_selector);
        listView.setDrawSelectorOnTop(false);
        listView.setClipToPadding(false);
        listView.setPadding(dp(2), dp(4), dp(2), dp(4));
        listView.setVerticalScrollBarEnabled(false);
        listView.setCacheColorHint(0);
        adapter = new ArrayAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos >= 0 && pos < shown.size()) itemOptions(shown.get(pos).link);
        });
        listBox.addView(listView);
        empty = text("", 15, 0xFFA9CCBF);
        empty.setGravity(Gravity.CENTER);
        listBox.addView(empty, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        body.addView(listBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));
        rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);
        rail.setPadding(0, dp(6), 0, dp(6));
        android.graphics.drawable.GradientDrawable rb = new android.graphics.drawable.GradientDrawable();
        rb.setCornerRadius(dp(16));
        rb.setColor(0x0AFFFFFF);
        rb.setStroke(Math.max(1, dp(1)), 0x1AFFFFFF);
        rail.setBackground(rb);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.MATCH_PARENT);
        rlp.leftMargin = dp(10);
        body.addView(rail, rlp);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        blp.topMargin = dp(10);
        panel.addView(body, blp);

        updateHeaderButtons();
        return root;
    }

    private void updateHeaderButtons() {
        if (saveCurrentButton != null) saveCurrentButton.setVisibility(canSaveCurrent() ? View.VISIBLE : View.GONE);
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46));
        lp.leftMargin = dp(10);
        return lp;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTextColor(primary ? 0xFFD6FFEC : 0xFFEAFFF6);
        b.setBackgroundResource(primary ? R.drawable.glass_button_primary : R.drawable.glass_button);
        b.setPadding(dp(20), 0, dp(20), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        if (android.os.Build.VERSION.SDK_INT >= 21) b.setStateListAnimator(null);
        return b;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setShadowLayer(dp(2), 0, dp(1) / 2f, 0x73000000);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, 0xFFA9CCBF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(6);
        lp.leftMargin = dp(2);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView chip(String s) {
        TextView t = text(s, 14, 0xFFE0F5EC);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.glass_chip);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        t.setCompoundDrawablePadding(dp(8));
        t.setFocusable(true);
        t.setClickable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40));
        lp.rightMargin = dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    private android.graphics.drawable.Drawable dot() {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(0xFF19F28A);
        g.setStroke(Math.max(1, dp(1)), 0x6619F28A);
        g.setSize(dp(8), dp(8));
        return g;
    }

    private void chooseSort() {
        new AlertDialog.Builder(this)
                .setTitle("Sort by")
                .setSingleChoiceItems(SORTS, sortMode, (d, w) -> {
                    sortMode = w;
                    applyFilter();
                    d.dismiss();
                })
                .show();
    }

    /** A–Z: the letters that have links. Choosing one sorts A–Z and jumps there. */
    private void buildRail() {
        if (rail == null) return;
        rail.removeAllViews();
        java.util.TreeSet<Character> present = new java.util.TreeSet<>();
        for (Item it : shown) present.add(group(it.link.name));
        if (shown.size() < 8 || present.size() < 2) {
            rail.setVisibility(View.GONE);
            return;
        }
        rail.setVisibility(View.VISIBLE);
        List<Character> letters = new ArrayList<>();
        if (present.contains('#')) letters.add('#');
        for (Character c : present) if (c != '#') letters.add(c);
        for (final Character c : letters) {
            TextView t = text(String.valueOf(c), 11, 0xFFC8E6DB);
            t.setGravity(Gravity.CENTER);
            t.setFocusable(true);
            t.setClickable(true);
            t.setBackgroundResource(R.drawable.glass_chip);
            t.setOnClickListener(v -> jumpTo(c));
            rail.addView(t, new LinearLayout.LayoutParams(dp(28), 0, 1));
        }
    }

    private void jumpTo(char c) {
        if (sortMode != 2) {
            sortMode = 2;
            applyFilter();
        }
        for (int i = 0; i < shown.size(); i++) {
            if (group(shown.get(i).link.name) == c) {
                listView.setSelection(i);
                listView.requestFocus();
                return;
            }
        }
    }

    private void hideKeyboard(View v) {
        try {
            ((android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Throwable ignored) { }
    }

    /** The rows: play circle, name, details, progress, "On drive" badge. */
    private final class ArrayAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Row r;
            if (v != null && v.getTag() instanceof Row) {
                r = (Row) v.getTag();
            } else {
                r = new Row();
                v = r.build();
            }
            r.bind(shown.get(i));
            return v;
        }
    }

    private final class Row {
        TextView name, details, badge;
        android.widget.ProgressBar bar;

        View build() {
            LinearLayout row = new LinearLayout(SavedLinksActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(8), dp(16), dp(8));
            row.setMinimumHeight(dp(62));
            row.setBackgroundResource(R.drawable.glass_row_idle);
            android.widget.ImageView play = new android.widget.ImageView(SavedLinksActivity.this);
            play.setImageResource(R.drawable.ic_play_arrow_24dp);
            play.setBackgroundResource(R.drawable.glass_circle);
            play.setScaleType(android.widget.ImageView.ScaleType.CENTER);
            play.setColorFilter(0xFFEAFFF6);
            row.addView(play, new LinearLayout.LayoutParams(dp(38), dp(38)));
            LinearLayout mid = new LinearLayout(SavedLinksActivity.this);
            mid.setOrientation(LinearLayout.VERTICAL);
            name = text("", 16, 0xFFEAFFF6);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            details = text("", 12, 0xFFA9CCBF);
            details.setSingleLine(true);
            details.setEllipsize(TextUtils.TruncateAt.END);
            mid.addView(name);
            mid.addView(details);
            bar = ResumePoints.glassBar(SavedLinksActivity.this, 0, 1);
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(260), dp(5));
            bl.topMargin = dp(6);
            mid.addView(bar, bl);
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            mlp.leftMargin = dp(14);
            mlp.rightMargin = dp(10);
            row.addView(mid, mlp);
            badge = text("", 12, 0xFF9DFFD2);
            badge.setBackgroundResource(R.drawable.glass_badge);
            badge.setPadding(dp(10), dp(4), dp(10), dp(4));
            row.addView(badge);
            row.setTag(this);
            return row;
        }

        void bind(Item it) {
            name.setText(it.link.name);
            details.setText(details(it));
            if (it.resume != null && it.resume.dur > 0) {
                bar.setVisibility(View.VISIBLE);
                bar.setProgress((int) Math.max(0, Math.min(1000, it.resume.pos * 1000 / it.resume.dur)));
            } else {
                bar.setVisibility(View.GONE);
            }
            if (it.drive != null) {
                badge.setVisibility(View.VISIBLE);
                badge.setText(it.drive.label());
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    /** "pixeldrain.eu.cc · 23 Oct 2026 · stopped at 1:22:15 of 2:00:10" */
    private String details(Item it) {
        Link l = it.link;
        String host = null;
        try { host = Uri.parse(l.url).getHost(); } catch (Throwable ignored) { }
        String date = l.added > 0 ? new java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date(l.added)) : null;
        StringBuilder sb = new StringBuilder(host != null ? host : l.url);
        if (date != null) sb.append(" · ").append(date);
        if (it.resume != null) {
            sb.append(" · stopped at ").append(ResumePoints.time(it.resume.pos));
            if (it.resume.dur > 0) sb.append(" of ").append(ResumePoints.time(it.resume.dur));
        } else if (it.watchedAt > 0) {
            sb.append(" · watched");
        }
        if (it.size > 0) sb.append(String.format(java.util.Locale.US, " · %.1f GB", it.size / 1e9));
        return sb.toString();
    }

    // ------------------------------------------------------------------ actions

    private void itemOptions(final Link l) {
        final String[] actions = {"Play", "Copy link", "Rename", "Share", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(actions, (d, which) -> {
                    switch (which) {
                        case 0: play(l); break;
                        case 1: copy(l); refresh(); break;
                        case 2: rename(l); break;
                        case 3: share(l); break;
                        default: confirmDelete(l);
                    }
                })
                .setOnCancelListener(d -> refresh())
                .show();
    }

    private void play(Link l) {
        Intent i = new Intent(this, PasteUrlActivity.class);
        i.putExtra(PasteUrlActivity.EXTRA_URL, l.url);   // the usual link check, then play
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        close();
    }

    private void copy(Link l) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(l.name, l.url));
            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't copy the link", Toast.LENGTH_SHORT).show();
        }
    }

    private void share(Link l) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, l.name);
        send.putExtra(Intent.EXTRA_TEXT, l.name + "\n" + l.url);
        try {
            startActivity(Intent.createChooser(send, "Share link"));
        } catch (Exception e) {
            Toast.makeText(this, "No app to share with", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    private void rename(final Link l) {
        final EditText input = field(l.name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(wrap(input))
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            String problem = nameProblem(name, l);
            if (problem != null) {
                input.setError(problem);
                return;
            }
            l.name = name;
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        input.requestFocus();
    }

    private void confirmDelete(final Link l) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this link?")
                .setMessage(l.name)
                .setPositiveButton("Delete", (d, w) -> {
                    links.remove(l);
                    save(this, links);
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNegativeButton("Cancel", (d, w) -> refresh())
                .setOnCancelListener(d -> refresh())
                .show();
    }

    /** Add a link: name + link (the link is filled in from the clipboard when it holds one). */
    private void addDialog(String presetUrl, String presetName) {
        String url = presetUrl != null ? presetUrl : clipboardLink();
        final EditText urlField = field(url, "Link (http, https or rtsp)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        String name = presetName != null && !presetName.trim().isEmpty() ? presetName.trim()
                : url != null ? defaultName(url) : null;
        if (name != null) name = freeName(name);   // suggested names never clash
        final EditText nameField = field(name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(nameField);
        box.addView(urlField);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(presetUrl != null ? "Save this video" : "Add link")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = urlField.getText().toString().trim();
            if (!PasteUrlActivity.isValid(u)) {
                urlField.setError("That isn't a valid http, https or rtsp link");
                return;
            }
            Link sameLink = byUrl(u, null);
            if (sameLink != null) {
                urlField.setError("Already saved as “" + sameLink.name + "”");
                return;
            }
            String n = nameField.getText().toString().trim();
            if (n.isEmpty()) n = freeName(defaultName(u));
            String problem = nameProblem(n, null);
            if (problem != null) {
                nameField.setError(problem);
                return;
            }
            links.add(new Link(n, u, System.currentTimeMillis()));
            query = ""; if (search != null) search.setText(""); status = 0;   // show it
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        (url == null ? urlField : nameField).requestFocus();
    }

    private String clipboardLink() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null) return null;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            String s = t == null ? null : t.toString().trim();
            return PasteUrlActivity.isValid(s) ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    private EditText field(String text, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(type);
        if (text != null) {
            e.setText(text);
            e.setSelection(text.length());
        }
        return e;
    }

    private View wrap(View v) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void close() {
        finish();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
