package com.brouken.player;

import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.extractor.SeekMap;
import androidx.media3.extractor.SeekPoint;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * One video downloaded onto the USB drive while it plays ("Use USB drive as buffer").
 *
 * A single download connection runs ahead of playback and writes the file into 64 MB pieces in
 * Just Player's own folder on the drive; the player reads everything from there. Pieces far
 * behind the playhead are deleted when space is needed, and the whole folder is deleted when the
 * video is closed. On links that can seek, a jump outside the downloaded part moves the download
 * there (still one connection). On links that can't seek ("no seek"), the download simply goes
 * on from the start, and an index of the MKV clusters lets the player jump anywhere inside the
 * downloaded part.
 */
final class DriveBuffer {

    static final long CHUNK = 64L << 20;
    /** A read this far ahead of the download waits for it instead of moving the download. */
    static final long REACH = 48L << 20;
    /** Kept behind the playhead for jumping back (when space runs out). */
    static final long BACK_KEEP = 3L << 30;
    /** Always left free on the drive. */
    static final long MARGIN = 2L << 30;

    final DriveDir dir;
    final Uri uri;
    final String key;
    final boolean linear;
    private final DataSource.Factory upstreamFactory;
    private final long cap;

    // ---- what's on the drive (all guarded by this)
    private final TreeMap<Long, Long> ranges = new TreeMap<>();   // start → end (exclusive)
    private long used;
    private long total = C.LENGTH_UNSET;
    private boolean complete;
    private Downloader dl;
    private IOException error;
    private long readPos;
    private boolean closed;
    volatile boolean bypass;

    /** MKV clusters seen in the download (linear links): time µs → file position. */
    private final TreeMap<Long, Long> index = new TreeMap<>();
    private Scanner scanner;

    private Uri finalUri;
    private Map<String, List<String>> headers = Collections.emptyMap();

    // ---- drive speed (for the overlay and the slow-drive fallback)
    private long winStart = System.nanoTime(), winWriteNanos, winBytes;
    private int slowWindows;
    volatile double writeMBps;
    private long downloadedTotal;

    // ---- kept on the drive for next time (meta.json in the video's folder)
    volatile String title;
    volatile long positionMs, durationMs;
    private long lastUsed;
    private long scale = 1_000_000;        // MKV TimecodeScale, for the saved index
    private long scanResume = -1;          // where the index scan continues (a cluster), or -1
    private long lastSave;

    DriveBuffer(DriveDir dir, Uri uri, boolean linear, DataSource.Factory upstreamFactory, long cap) {
        this.dir = dir;
        this.uri = uri;
        this.key = uri.toString();
        this.linear = linear;
        this.upstreamFactory = upstreamFactory;
        this.cap = cap;
        load();
    }

    // ------------------------------------------------------------------ saved state

    private synchronized void load() {
        try {
            byte[] data = dir.read("meta.json");
            if (data == null) return;
            org.json.JSONObject o = new org.json.JSONObject(new String(data, "UTF-8"));
            total = o.optLong("size", C.LENGTH_UNSET);
            title = o.optString("title", null);
            positionMs = o.optLong("pos", 0);
            durationMs = o.optLong("dur", 0);
            scale = o.optLong("scale", 1_000_000);
            org.json.JSONArray r = o.optJSONArray("ranges");
            if (r != null) for (int i = 0; i < r.length(); i++) {
                org.json.JSONArray x = r.getJSONArray(i);
                long st = x.getLong(0), en = valid(x.getLong(0), x.getLong(1));
                if (en > st) addRange(st, en);
            }
            org.json.JSONArray ix = o.optJSONArray("index");
            if (ix != null) for (int i = 0; i < ix.length(); i++) {
                org.json.JSONArray x = ix.getJSONArray(i);
                long t = x.getLong(0), p = x.getLong(1);
                if (coveredEnd(p) > p) index.put(t, p);
            }
            if (!index.isEmpty()) scanResume = index.lastEntry().getValue();
            complete = total != C.LENGTH_UNSET && coveredEnd(0) >= total;
            if (used > 0) Diag.log("USB buffer: " + Diag.mb(used) + " of this video already on the drive");
        } catch (Throwable t) {
            ranges.clear();
            used = 0;
            index.clear();
        }
    }

    /** End of [s, e) that really is in the chunk files (a crash may have left them shorter). */
    private long valid(long s, long e) {
        long p = s;
        while (p < e) {
            long c = p / CHUNK;
            long len = dir.length("c" + c);
            long have = len >= 0 ? c * CHUNK + len : c * CHUNK;
            long chunkEnd = Math.min(e, (c + 1) * CHUNK);
            if (have < chunkEnd) return Math.max(p, Math.min(have, e));
            p = chunkEnd;
        }
        return e;
    }

    /** Writes meta.json (to a temp file first, so a power cut never leaves it broken). */
    synchronized void save() {
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("url", key);
            o.put("size", total);
            if (title != null) o.put("title", title);
            o.put("pos", positionMs);
            o.put("dur", durationMs);
            o.put("used", used);
            o.put("last", System.currentTimeMillis());
            o.put("scale", scale);
            o.put("complete", complete);
            org.json.JSONArray r = new org.json.JSONArray();
            for (Map.Entry<Long, Long> e : ranges.entrySet()) r.put(new org.json.JSONArray().put(e.getKey()).put(e.getValue()));
            o.put("ranges", r);
            org.json.JSONArray ix = new org.json.JSONArray();
            for (Map.Entry<Long, Long> e : index.entrySet()) ix.put(new org.json.JSONArray().put(e.getKey()).put(e.getValue()));
            o.put("index", ix);
            dir.writeAtomic("meta.json", o.toString().getBytes("UTF-8"));
            lastSave = System.currentTimeMillis();
        } catch (Throwable ignored) { }
    }

    private void saveSometimes() {
        if (System.currentTimeMillis() - lastSave > 60_000) save();   // the index can be large: not too often
    }

    /** The player's position, kept for "continue watching". */
    void setPosition(long posMs, long durMs) {
        positionMs = posMs;
        if (durMs > 0) durationMs = durMs;
    }

    // ------------------------------------------------------------------ ranges

    /** End of the downloaded stretch that contains pos, or -1. */
    private long coveredEnd(long pos) {
        Map.Entry<Long, Long> e = ranges.floorEntry(pos);
        return e != null && e.getValue() > pos ? e.getValue() : -1;
    }

    private void addRange(long s, long e) {
        Map.Entry<Long, Long> before = ranges.floorEntry(s);
        if (before != null && before.getValue() >= s) {
            s = before.getKey();
            e = Math.max(e, before.getValue());
            used -= before.getValue() - before.getKey();
            ranges.remove(before.getKey());
        }
        while (true) {
            Map.Entry<Long, Long> next = ranges.ceilingEntry(s);
            if (next == null || next.getKey() > e) break;
            e = Math.max(e, next.getValue());
            used -= next.getValue() - next.getKey();
            ranges.remove(next.getKey());
        }
        ranges.put(s, e);
        used += e - s;
    }

    private void removeRange(long s, long e) {
        Map.Entry<Long, Long> first = ranges.floorEntry(s);
        long from = first != null && first.getValue() > s ? first.getKey() : s;
        for (Map.Entry<Long, Long> r : new TreeMap<>(ranges.subMap(from, true, e, false)).entrySet()) {
            long rs = r.getKey(), re = r.getValue();
            ranges.remove(rs);
            used -= re - rs;
            if (rs < s) { ranges.put(rs, s); used += s - rs; }
            if (re > e) { ranges.put(e, re); used += re - e; }
        }
    }

    /** Frees the oldest piece far enough behind the playhead. */
    private boolean evictOne(long writing) {
        long limit = readPos - BACK_KEEP;
        if (ranges.isEmpty() || limit <= 0) return false;
        long first = ranges.firstKey();
        long c = first / CHUNK;
        long cs = c * CHUNK, ce = cs + CHUNK;
        if (ce > limit || writing / CHUNK == c) return false;
        removeRange(cs, ce);
        dir.delete("c" + c);
        java.util.Iterator<Long> it = index.values().iterator();
        while (it.hasNext()) {
            long p = it.next();
            if (p >= cs && p < ce) it.remove();
        }
        return true;
    }

    // ------------------------------------------------------------------ player side

    static final int OK = 0, DIRECT = 1;

    /**
     * The player opens the file at pos. Returns OK (served from the drive) or DIRECT (not
     * possible from the drive: read straight from the network, as without the buffer).
     */
    int prepare(long pos) throws IOException {
        Downloader start = null, stop = null;
        synchronized (this) {
            if (closed || bypass) return DIRECT;
            readPos = pos;
            notifyAll();
            if (total != C.LENGTH_UNSET && pos >= total) return OK;
            boolean alive = dl != null && dl.isAlive() && !dl.stop;
            long ce = coveredEnd(pos);
            if (ce > pos) {
                // on the drive already (from earlier): keep downloading ahead of it, so the player
                // never catches up. Links that can't seek have to download from the start again.
                if (alive || complete) return OK;
                long resumeFrom = linear ? 0 : ce;
                if (total != C.LENGTH_UNSET && resumeFrom >= total) return OK;
                startQuietly(resumeFrom);
                return OK;
            }
            if (alive && pos >= dl.pos && (pos - dl.pos <= REACH || linear)) return OK;   // the download gets there
            if (linear) {
                if (alive) return DIRECT;                          // before the drive's part: as without the buffer
                Map.Entry<Long, Long> first = ranges.firstEntry();
                if (first != null && first.getKey() > 0 && pos < first.getKey()) return DIRECT;
                stop = dl;
            } else {
                stop = dl;
            }
            dl = null;
            error = null;
        }
        if (stop != null) stop.finish();
        // (re)start the one download: links that can seek start at pos, others from the start
        long from = linear ? 0 : pos;
        DataSource up = upstreamFactory.createDataSource();
        long len = up.open(new DataSpec.Builder().setUri(uri).setPosition(from).build());   // errors surface here
        synchronized (this) {
            if (len != C.LENGTH_UNSET) total = from + len;
            try { finalUri = up.getUri(); headers = up.getResponseHeaders(); } catch (Throwable ignored) { }
            if (closed) { try { up.close(); } catch (Throwable ignored) { } return DIRECT; }
            start = dl = new Downloader(up, from);
        }
        start.start();
        if (linear) startScanner();
        noteTitle();
        Diag.log("USB buffer: downloading from " + Diag.mb(from));
        return OK;
    }

    /** Starts the download in the background (the player reads from the drive meanwhile). */
    private void startQuietly(final long from) {
        if (starting) return;
        starting = true;
        new Thread(() -> {
            try {
                DataSource up = upstreamFactory.createDataSource();
                long len = up.open(new DataSpec.Builder().setUri(uri).setPosition(from).build());
                Downloader d;
                synchronized (DriveBuffer.this) {
                    if (len != C.LENGTH_UNSET) total = from + len;
                    try { finalUri = up.getUri(); headers = up.getResponseHeaders(); } catch (Throwable ignored) { }
                    if (closed || (dl != null && dl.isAlive() && !dl.stop)) { try { up.close(); } catch (Throwable ignored) { } return; }
                    d = dl = new Downloader(up, from);
                }
                d.start();
                if (linear) startScanner();
                noteTitle();
                Diag.log("USB buffer: continuing the download" + (linear && from == 0
                        ? " (this server can't seek: from the start, skipping what's on the drive)" : " from " + Diag.mb(from)));
            } catch (IOException e) {
                Diag.log("USB buffer: couldn't continue the download: " + Diag.describe(e));
            } finally {
                synchronized (DriveBuffer.this) { starting = false; DriveBuffer.this.notifyAll(); }
            }
        }, "usb-buffer-start").start();
    }

    private boolean starting;

    private void noteTitle() {
        if (title != null) return;
        try {
            String cd = null;
            for (Map.Entry<String, List<String>> e : headers.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase("Content-Disposition") && !e.getValue().isEmpty()) cd = e.getValue().get(0);
            }
            String t = Titles.fromContentDisposition(cd);
            if (t == null) t = Titles.fromUrl(uri);
            title = t;
        } catch (Throwable ignored) { }
    }

    long length(long pos) {
        synchronized (this) {
            return total == C.LENGTH_UNSET ? C.LENGTH_UNSET : Math.max(0, total - pos);
        }
    }

    Uri finalUri() { return finalUri; }
    Map<String, List<String>> headers() { return headers; }

    /**
     * Blocks until data at pos is on the drive. Returns how many bytes can be read there, -1 at
     * the end, -2 = read this from the network, -3 = call {@link #prepare} for pos (moves the download).
     */
    long await(long pos) throws IOException {
        return await(pos, true);
    }

    /** @param player false for the index scanner (it doesn't move the playhead). */
    long await(long pos, boolean player) throws IOException {
        synchronized (this) {
            if (player) {
                readPos = pos;
                notifyAll();
            } else if (coveredEnd(pos) <= pos && (dl == null || pos < dl.pos)) {
                return -1;   // behind the download (deleted, or not on the drive): the index stops here
            }
            while (true) {
                if (closed) throw new IOException("USB buffer closed");
                long ce = coveredEnd(pos);
                if (ce > pos) return ce - pos;
                if (total != C.LENGTH_UNSET && pos >= total) return -1;
                if (bypass) return -2;
                boolean alive = dl != null && dl.isAlive() && !dl.stop;
                if (!player) {
                    if (!alive || pos < dl.pos) return -1;
                } else if (!alive && starting) {
                    // the download is being started: wait for it
                } else if (!alive) {
                    IOException e = error;
                    if (e != null && !linear && dl != null && dl.pos == pos) {
                        error = null;
                        throw e;                          // the download failed right here: the player retries
                    }
                    return -3;                            // download finished/stopped elsewhere: start it here
                } else if (pos < dl.pos) {
                    return linear ? -2 : -3;              // a gap behind the download
                } else if (!linear && pos - dl.pos > REACH) {
                    return -3;                            // far ahead: move the download
                }
                try {
                    wait(500);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new InterruptedIOException();
                }
            }
        }
    }

    int readAt(long pos, byte[] buf, int off, int len, DriveDir.Chan[] handle, long[] handleChunk) throws IOException {
        long c = pos / CHUNK;
        if (handle[0] == null || handleChunk[0] != c) {
            if (handle[0] != null) handle[0].close();
            handle[0] = dir.open("c" + c, false);
            handleChunk[0] = c;
        }
        int n = (int) Math.min(len, (c + 1) * CHUNK - pos);
        return handle[0].read(pos - c * CHUNK, buf, off, n);
    }

    // ------------------------------------------------------------------ download

    private final class Downloader extends Thread {
        private DataSource up;
        volatile long pos;
        volatile boolean stop;
        private DriveDir.Chan out;
        private long outChunk = -1;

        Downloader(DataSource up, long from) {
            super("usb-buffer");
            this.up = up;
            this.pos = from;
            setDaemon(true);
        }

        void finish() {
            stop = true;
            interrupt();
            final DataSource u = up;
            new Thread(() -> { try { u.close(); } catch (Throwable ignored) { } }, "usb-buffer-close").start();
        }

        @Override
        public void run() {
            // below the player's own threads: playback always comes first on the TV's 4 small cores
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DEFAULT + 2); } catch (Throwable ignored) { }
            byte[] buf = new byte[1 << 20];
            try {
                while (!stop) {
                    pace();
                    int want = (int) Math.min(buf.length, CHUNK - pos % CHUNK);
                    synchronized (DriveBuffer.this) {
                        // room on the drive: free old pieces behind the playhead, else wait
                        while (!stop && !closed && used + want > cap) {
                            if (!evictOne(pos)) DriveBuffer.this.wait(500);
                        }
                        if (stop || closed) break;
                    }
                    int n = up.read(buf, 0, want);
                    if (n == C.RESULT_END_OF_INPUT) {
                        synchronized (DriveBuffer.this) {
                            if (total == C.LENGTH_UNSET || pos >= total) { total = pos; complete = true; }
                            DriveBuffer.this.notifyAll();
                        }
                        Diag.log("USB buffer: whole file downloaded");
                        break;
                    }
                    boolean have;
                    synchronized (DriveBuffer.this) { have = coveredEnd(pos) >= pos + n; }
                    if (!have) {
                        yieldToPlayer();
                        long t = System.nanoTime();
                        write(pos, buf, n);
                        measure(System.nanoTime() - t, n);
                    }
                    synchronized (DriveBuffer.this) {
                        if (stop) break;
                        addRange(pos, pos + n);
                        pos += n;
                        paceBytes += n;
                        downloadedTotal += n;
                        if (total != C.LENGTH_UNSET && coveredEnd(0) >= total && !complete) {
                            complete = true;
                            Diag.log("USB buffer: the whole video is on the drive");
                        }
                        DriveBuffer.this.notifyAll();
                        saveSometimes();
                    }
                    if (complete) break;
                    if (!linear) skipDownloaded();
                    if (bypass) break;
                }
            } catch (InterruptedException e) {
                // stopped
            } catch (IOException e) {
                if (!stop) {
                    synchronized (DriveBuffer.this) { error = e; DriveBuffer.this.notifyAll(); }
                    Diag.log("USB buffer: " + Diag.describe(e));
                }
            } finally {
                if (out != null) out.close();
                try { up.close(); } catch (Throwable ignored) { }
                synchronized (DriveBuffer.this) { DriveBuffer.this.notifyAll(); }
            }
        }

        private long paceStart, paceBytes;

        /**
         * Far ahead already (20+ minutes on the drive): no need to run the network, the USB port
         * and the CPU flat out. The download continues gently at 1.5× the video's bitrate, so the
         * head start still grows; full speed again as soon as it's below 20 minutes.
         */
        private void pace() throws InterruptedException {
            long bytesPerSec;
            long aheadMs;
            synchronized (DriveBuffer.this) {
                if (total <= 0 || durationMs <= 0 || linearCatchingUp()) { paceStart = 0; return; }
                bytesPerSec = total * 1000 / durationMs;
                long ce = coveredEnd(readPos);
                long aheadBytes = ce > readPos ? ce - readPos : 0;
                aheadMs = bytesPerSec > 0 ? aheadBytes * 1000 / bytesPerSec : 0;
            }
            if (aheadMs < 20 * 60_000L) { paceStart = 0; return; }
            long now = System.nanoTime();
            if (paceStart == 0 || now - paceStart > 10_000_000_000L) { paceStart = now; paceBytes = 0; return; }
            long allowed = (long) ((now - paceStart) / 1e9 * bytesPerSec * 1.5);
            if (paceBytes > allowed) Thread.sleep(Math.min(500, (paceBytes - allowed) * 1000 / Math.max(1, (long) (bytesPerSec * 1.5))));
        }

        /** A link that can't seek is running through data already on the drive: never slowed. */
        private boolean linearCatchingUp() {
            return linear && coveredEnd(pos) > pos;
        }

        /**
         * The playback comes first: a hard disk can't write the download and read the video at
         * full speed at the same time (the head jumps between both places). While the player has
         * little read ahead in memory, the download waits a moment so the drive serves the reads.
         */
        private void yieldToPlayer() throws InterruptedException {
            long want = Math.min(48L << 20, ReadAheadDataSource.capacity() / 3);
            for (int i = 0; i < 10 && !stop && ReadAheadDataSource.driveReading()
                    && ReadAheadDataSource.ahead() < want && driveAhead() > (128L << 20); i++) {
                // only when the drive already holds plenty for the player: if the player is
                // waiting for this download (right after a jump to the edge), never hold it back
                Thread.sleep(20);
            }
        }

        private long driveAhead() {
            synchronized (DriveBuffer.this) {
                long ce = coveredEnd(readPos);
                return ce > readPos ? ce - readPos : 0;
            }
        }

        /** Already on the drive from an earlier jump: continue the download after it. */
        private void skipDownloaded() throws IOException {
            long ce;
            synchronized (DriveBuffer.this) { ce = coveredEnd(pos); }
            if (ce <= pos) return;
            if (total != C.LENGTH_UNSET && ce >= total) {
                synchronized (DriveBuffer.this) { complete = true; DriveBuffer.this.notifyAll(); }
                stop = true;
                return;
            }
            try { up.close(); } catch (Throwable ignored) { }
            up = upstreamFactory.createDataSource();
            up.open(new DataSpec.Builder().setUri(uri).setPosition(ce).build());
            pos = ce;
        }

        private void write(long p, byte[] b, int n) throws IOException {
            long c = p / CHUNK;
            if (out == null || outChunk != c) {
                if (out != null) out.close();
                out = dir.open("c" + c, true);
                outChunk = c;
            }
            out.write(p - c * CHUNK, b, 0, n);
        }
    }

    /** Drive write speed; a drive that can't keep up (links that can seek) → back to the normal buffer. */
    private void measure(long nanos, int bytes) {
        winWriteNanos += nanos;
        winBytes += bytes;
        long now = System.nanoTime();
        long span = now - winStart;
        if (span < 10_000_000_000L) return;
        if (winWriteNanos > 0) writeMBps = winBytes / 1048576.0 / (winWriteNanos / 1e9);
        double busy = winWriteNanos / (double) span;   // share of the time spent waiting for the drive
        slowWindows = busy > 0.85 ? slowWindows + 1 : 0;
        winStart = now;
        winWriteNanos = 0;
        winBytes = 0;
        if (slowWindows >= 3 && !linear && !bypass) {
            bypass = true;
            Diag.log(String.format(java.util.Locale.US,
                    "USB buffer: the drive can't keep up (%.1f MB/s) → normal buffer for this video", writeMBps));
        }
    }

    // ------------------------------------------------------------------ MKV cluster index (linear links)

    private synchronized void startScanner() {
        if (scanner != null && scanner.isAlive()) return;
        scanner = new Scanner();
        scanner.start();
    }

    /** Seek points from the index, inside what's on the drive; null if there's nothing usable. */
    synchronized SeekMap.SeekPoints seekPoints(long timeUs) {
        Map.Entry<Long, Long> a = index.floorEntry(timeUs);
        while (a != null && coveredEnd(a.getValue()) <= a.getValue()) a = index.lowerEntry(a.getKey());
        if (a == null) return null;
        Map.Entry<Long, Long> b = index.higherEntry(timeUs);
        SeekPoint first = new SeekPoint(a.getKey(), a.getValue());
        if (b != null && coveredEnd(b.getValue()) > b.getValue() && a.getKey() != timeUs) {
            return new SeekMap.SeekPoints(first, new SeekPoint(b.getKey(), b.getValue()));
        }
        return new SeekMap.SeekPoints(first);
    }

    /** {first, last} time (ms) the player can jump to inside what's on the drive, or null. */
    synchronized long[] seekableMs() {
        long lo = -1, hi = -1;
        for (Map.Entry<Long, Long> e : index.entrySet()) {
            if (coveredEnd(e.getValue()) > e.getValue()) {
                if (lo < 0) lo = e.getKey();
                hi = e.getKey();
            }
        }
        return lo < 0 ? null : new long[] {lo / 1000, hi / 1000};
    }

    private final class Scanner extends Thread {
        private final byte[] b = new byte[16];
        Scanner() {
            super("usb-buffer-index");
            setDaemon(true);
            setPriority(Thread.MIN_PRIORITY);
        }

        private final DriveDir.Chan[] h = {null};
        private final long[] hc = {-1};

        private boolean fill(long p, int n) throws IOException {
            int got = 0;
            while (got < n) {
                long avail = await(p + got, false);
                if (avail < 0) return false;
                int r = readAt(p + got, b, got, (int) Math.min(n - got, avail), h, hc);
                if (r <= 0) return false;
                got += r;
            }
            return true;
        }

        /** EBML element header at p: {id, size (-1 = unknown), header length} or null. */
        private long[] header(long p) throws IOException {
            if (!fill(p, 1)) return null;
            int first = b[0] & 0xFF;
            int idLen = first >= 0x80 ? 1 : first >= 0x40 ? 2 : first >= 0x20 ? 3 : first >= 0x10 ? 4 : 0;
            if (idLen == 0) return null;
            if (!fill(p, idLen + 1)) return null;
            long id = 0;
            for (int i = 0; i < idLen; i++) id = (id << 8) | (b[i] & 0xFF);
            int s0 = b[idLen] & 0xFF;
            int sLen = 1;
            while (sLen <= 8 && (s0 & (0x80 >> (sLen - 1))) == 0) sLen++;
            if (sLen > 8) return null;
            if (!fill(p, idLen + sLen)) return null;
            long size = s0 & (0xFF >> sLen);
            boolean allOnes = size == (0xFF >> sLen);
            for (int i = 1; i < sLen; i++) {
                int v = b[idLen + i] & 0xFF;
                size = (size << 8) | v;
                if (v != 0xFF) allOnes = false;
            }
            return new long[] {id, allOnes ? -1 : size, idLen + sLen};
        }

        private long uint(long p, int len) throws IOException {
            if (len <= 0 || len > 8 || !fill(p, len)) return -1;
            long v = 0;
            for (int i = 0; i < len; i++) v = (v << 8) | (b[i] & 0xFF);
            return v;
        }

        @Override
        public void run() {
            try {
                long p;
                long resume;
                synchronized (DriveBuffer.this) { resume = scanResume; }
                if (resume > 0) {
                    p = resume;                                              // continue the saved index
                } else {
                    long[] e = header(0);
                    if (e == null || e[0] != 0x1A45DFA3L || e[1] < 0) return;   // not Matroska/WebM
                    p = e[2] + e[1];
                    e = header(p);
                    if (e == null || e[0] != 0x18538067L) return;               // Segment
                    p += e[2];
                }
                while (!isInterrupted()) {
                    synchronized (DriveBuffer.this) { if (closed) return; }
                    long[] e = header(p);
                    if (e == null) return;
                    long id = e[0], size = e[1], data = p + e[2];
                    if (id == 0x1549A966L && size > 0) {                     // Info: TimecodeScale
                        long q = data;
                        while (q < data + size) {
                            long[] c = header(q);
                            if (c == null || c[1] < 0) break;
                            if (c[0] == 0x2AD7B1L) { long v = uint(q + c[2], (int) c[1]); if (v > 0) synchronized (DriveBuffer.this) { scale = v; } }
                            q += c[2] + c[1];
                        }
                    } else if (id == 0x1F43B675L) {                          // Cluster: its Timestamp
                        long q = data;
                        for (int i = 0; i < 4; i++) {
                            long[] c = header(q);
                            if (c == null || c[1] < 0) break;
                            if (c[0] == 0xE7L) {
                                long ts = uint(q + c[2], (int) c[1]);
                                if (ts >= 0) {
                                    synchronized (DriveBuffer.this) {
                                        index.put(ts * scale / 1000, p);
                                        scanResume = p;
                                    }
                                }
                                break;
                            }
                            q += c[2] + c[1];
                        }
                        if (size < 0) return;   // cluster of unknown size: can't skip it
                    }
                    if (size < 0) return;
                    p = data + size;
                }
            } catch (IOException ignored) {
                // closed / stopped
            } finally {
                if (h[0] != null) h[0].close();
            }
        }
    }

    // ------------------------------------------------------------------ status / end

    /** For the overlay: {bytes ready ahead of the player, bytes on the drive}. */
    synchronized long[] stats() {
        long ce = coveredEnd(readPos);
        return new long[] {ce > readPos ? ce - readPos : 0, used};
    }

    synchronized boolean isComplete() { return complete; }

    /** End (file position) of the downloaded stretch the player is in. */
    synchronized long readyEnd() {
        long ce = coveredEnd(readPos);
        return ce > readPos ? ce : readPos;
    }

    /** Refresh: drop the download connection; the next read starts it again (links that can seek). */
    void kick() {
        Downloader d;
        synchronized (this) {
            if (linear || dl == null) return;   // a link that can't seek would start over from 0
            d = dl;
            dl = null;
            error = null;
            notifyAll();
        }
        d.finish();
    }

    /** @param delete false: the download stays on the drive for next time. */
    void close(boolean delete) {
        Downloader d;
        Scanner s;
        synchronized (this) {
            closed = true;
            d = dl;
            dl = null;
            s = scanner;
            notifyAll();
        }
        if (d != null) d.finish();
        if (s != null) s.interrupt();
        final DriveDir folder = dir;
        if (delete) {
            new Thread(folder::deleteTree, "usb-buffer-delete").start();
        } else {
            new Thread(() -> {
                try { if (d != null) d.join(3000); } catch (InterruptedException ignored) { }
                save();
            }, "usb-buffer-save").start();
        }
    }

    synchronized long usedBytes() { return used; }
}
