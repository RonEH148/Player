package com.brouken.player;

import android.preference.PreferenceManager;
import android.view.View;

import androidx.media3.ui.AspectRatioFrameLayout;

/**
 * Aspect ratio button: cycles through the modes and shows the name in the middle of the picture.
 * Fixed ratios (16:9, 4:3 …) override the video's own shape; the choice is kept for the next video.
 */
final class AspectModes {

    private AspectModes() {}

    private static final String KEY = "aspectModeIndex";

    private static final String[] NAMES = {
            "Fit (original)", "Crop (fill screen)", "Stretch", "16:9", "4:3", "21:9", "2.35:1", "1.85:1"};
    private static final int[] RESIZE = {
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FIT};
    private static final float[] RATIO = {0, 0, 0, 16f / 9f, 4f / 3f, 21f / 9f, 2.35f, 1.85f};

    private static int current = -1;

    static void next(PlayerActivity a) {
        int i = (index(a) + 1) % NAMES.length;
        apply(a, i);
        CenterText.show(a, NAMES[i], 1500);
    }

    /** Player (re)started: apply the saved mode. */
    static void restore(PlayerActivity a) {
        int i = index(a);
        // pinch-zoom on the tablet sets Crop with a custom scale: keep that
        if (a.mPrefs != null && a.mPrefs.resizeMode == AspectRatioFrameLayout.RESIZE_MODE_ZOOM && i != 1) i = 1;
        if (i == 1) {
            current = i;
            forced(a, 0);
            return;
        }
        apply(a, i);
    }

    private static int index(PlayerActivity a) {
        if (current < 0) {
            try {
                current = PreferenceManager.getDefaultSharedPreferences(a).getInt(KEY, 0);
            } catch (Throwable t) {
                current = 0;
            }
        }
        if (current < 0 || current >= NAMES.length) current = 0;
        return current;
    }

    private static void apply(PlayerActivity a, int i) {
        current = i;
        try {
            PreferenceManager.getDefaultSharedPreferences(a).edit().putInt(KEY, i).apply();
        } catch (Throwable ignored) { }
        if (a.playerView == null) return;
        a.playerView.setScale(1.f);
        a.playerView.setResizeMode(RESIZE[i]);
        if (a.mPrefs != null) a.mPrefs.resizeMode = RESIZE[i];
        forced(a, RATIO[i]);
    }

    private static float forcedRatio;

    private static void forced(PlayerActivity a, float ratio) {
        forcedRatio = ratio;
        final AspectRatioFrameLayout frame = a.playerView == null ? null
                : a.playerView.findViewById(androidx.media3.ui.R.id.exo_content_frame);
        if (frame == null) return;
        if (frame.getTag(R.id.controls) == null) {
            // The player view sets the video's own ratio whenever the video size is known;
            // put the chosen ratio back right after.
            frame.setTag(R.id.controls, Boolean.TRUE);
            frame.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                @Override
                public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                    if (forcedRatio > 0) frame.setAspectRatio(forcedRatio);
                }
            });
        }
        if (ratio > 0) {
            frame.setAspectRatio(ratio);
        } else if (PlayerActivity.player != null) {
            androidx.media3.common.VideoSize vs = PlayerActivity.player.getVideoSize();
            if (vs.width > 0 && vs.height > 0) frame.setAspectRatio(vs.width * vs.pixelWidthHeightRatio / vs.height);
        }
    }
}
