package com.brouken.player;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * Light / dark look for the menus (start screen, Settings, Saved links, dialogs).
 * "System" (the default) follows the tablet's / TV's own setting. The video screen stays dark.
 */
final class ThemeMode {

    private ThemeMode() {}

    static final String KEY = "appTheme";

    static String get(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c).getString(KEY, "system");
    }

    /** For Settings (AppCompat). */
    static int nightMode(Context c) {
        return nightMode(get(c));
    }

    static int nightMode(String mode) {
        switch (mode) {
            case "light": return AppCompatDelegate.MODE_NIGHT_NO;
            case "dark": return AppCompatDelegate.MODE_NIGHT_YES;
            default: return AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        }
    }

    /**
     * For the other screens: call in attachBaseContext, right after super. Only the light/dark
     * part of the configuration is replaced, so rotation and everything else still update.
     */
    /** The choice the player window was opened with (it's rebuilt when you change it, if no video plays). */
    static String playerApplied;

    static void override(Activity a, Context base) {
        String m = get(base);
        if (a instanceof PlayerActivity) playerApplied = m;
        if (!"light".equals(m) && !"dark".equals(m)) return;
        Configuration o = new Configuration();
        o.uiMode = "dark".equals(m) ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO;
        try {
            a.applyOverrideConfiguration(o);
        } catch (Throwable ignored) { }
    }

    static boolean isDark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Colours for screens built in code. */
    static final class Pal {
        final int bg, text, sub, hint, chipText, chipOnText, accent, icon, line;
        Pal(boolean dark) {
            bg = dark ? 0xFF000000 : 0xFFF2F2F2;
            text = dark ? 0xFFFFFFFF : 0xDE000000;
            sub = dark ? 0xFF9E9E9E : 0x8A000000;
            hint = dark ? 0xFF757575 : 0x61000000;
            chipText = dark ? 0xFFE0E0E0 : 0xDE000000;
            chipOnText = dark ? 0xFF000000 : 0xFFFFFFFF;
            accent = dark ? 0xFF80CBC4 : 0xFF009688;
            icon = dark ? 0xFFBDBDBD : 0x8A000000;
            line = dark ? 0x1FFFFFFF : 0x1F000000;
        }
    }

    static Pal pal(Context c) {
        return new Pal(isDark(c));
    }
}
