package com.brouken.player;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.Locale;

/**
 * Default track choices, applied once per video (manual changes in the player are kept):
 *  - audio: the video's original language (default-flagged track, else the first one),
 *           in AC-3 / E-AC-3 or FLAC when available, otherwise TrueHD / DTS etc.
 *  - subtitles: always English; SRT first, otherwise the next best English track.
 */
public final class TrackPrefs {

    private static boolean applied;

    private TrackPrefs() {}

    static void reset() {
        applied = false;
    }

    /** Before prepare(): drop the device-language audio preference set by Just Player. */
    static void applyParams(ExoPlayer p) {
        try {
            p.setTrackSelectionParameters(p.getTrackSelectionParameters().buildUpon()
                    .setPreferredAudioLanguages()
                    .setPreferredAudioMimeTypes("audio/eac3-joc", "audio/eac3", "audio/ac3", "audio/flac")
                    .setPreferredTextLanguages("en")
                    .build());
        } catch (Throwable t) {
            Diag.log("Track prefs failed: " + t);
        }
    }

    static void onTracks(Tracks tracks, android.content.Context c) {
        ExoPlayer p = PlayerActivity.player;
        if (p == null || tracks == null || tracks.isEmpty()) return;
        if (applied) {
            remember(tracks, c, p);   // your own choices are kept for this link
            return;
        }
        boolean hasAudio = false;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() == C.TRACK_TYPE_AUDIO) { hasAudio = true; break; }
        }
        if (!hasAudio) return;
        applied = true;
        try {
            TrackSelectionParameters.Builder b = p.getTrackSelectionParameters().buildUpon();
            String[] mine = c != null ? stored(c, p) : null;
            boolean changed;
            // the tracks you chose last time for this link, else the usual defaults
            Boolean a = mine != null && mine[0] != null ? pickRemembered(tracks, b, C.TRACK_TYPE_AUDIO, mine[0]) : null;
            changed = a != null ? a : pickAudio(tracks, b);
            Boolean t = mine != null && mine[1] != null ? pickRemembered(tracks, b, C.TRACK_TYPE_TEXT, mine[1]) : null;
            changed |= t != null ? t : pickSubtitle(tracks, b);
            if (changed) p.setTrackSelectionParameters(b.build());
        } catch (Throwable t) {
            Diag.log("Track switch failed: " + t);
        }
    }

    // ------------------------------------------------------------------ per link memory

    private static android.content.SharedPreferences memory(android.content.Context c) {
        return c.getSharedPreferences("track_memory", android.content.Context.MODE_PRIVATE);
    }

    private static String linkKey(ExoPlayer p) {
        try {
            if (p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return null;
            return SavedLinksActivity.key(p.getCurrentMediaItem().localConfiguration.uri.toString());
        } catch (Throwable t) {
            return null;
        }
    }

    /** {audio, subtitles} remembered for this link (null = nothing). */
    private static String[] stored(android.content.Context c, ExoPlayer p) {
        String k = linkKey(p);
        if (k == null) return null;
        String v = memory(c).getString(k, null);
        if (v == null) return null;
        String[] parts = v.split("\n", -1);
        return new String[]{parts.length > 0 && !parts[0].isEmpty() ? parts[0] : null, parts.length > 1 && !parts[1].isEmpty() ? parts[1] : null};
    }

    private static String id(Format f) {
        String l = iso3(f.language);
        return (l != null ? l : "") + "|" + mime(f) + "|" + f.channelCount + "|" + (f.label != null ? f.label : "")
                + "|" + ((f.selectionFlags & C.SELECTION_FLAG_FORCED) != 0 ? "f" : "");
    }

    /** Saves what's selected now (after you changed it in the player). */
    private static void remember(Tracks tracks, android.content.Context c, ExoPlayer p) {
        if (c == null) return;
        String k = linkKey(p);
        if (k == null) return;
        String audio = null, text = null;
        boolean hasText = false;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() == C.TRACK_TYPE_TEXT) hasText = true;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSelected(i)) continue;
                if (g.getType() == C.TRACK_TYPE_AUDIO && audio == null) audio = id(g.getTrackFormat(i));
                if (g.getType() == C.TRACK_TYPE_TEXT && text == null) text = id(g.getTrackFormat(i));
            }
        }
        if (audio == null) return;   // still loading
        if (hasText && text == null) text = "off";
        String v = audio + "\n" + (text != null ? text : "");
        android.content.SharedPreferences m = memory(c);
        if (v.equals(m.getString(k, null))) return;
        if (m.getAll().size() > 2000) m.edit().clear().apply();
        m.edit().putString(k, v).apply();
    }

    /** Selects the remembered track; null when it isn't in this file (then the defaults apply). */
    private static Boolean pickRemembered(Tracks tracks, TrackSelectionParameters.Builder b, int type, String want) {
        if (type == C.TRACK_TYPE_TEXT && "off".equals(want)) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
            Diag.log("Subtitles: off (as last time)");
            return true;
        }
        String[] w = want.split("\\|", -1);
        Tracks.Group best = null;
        int bestIndex = -1, bestScore = 0;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != type) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                String[] h = id(g.getTrackFormat(i)).split("\\|", -1);
                if (w.length < 5 || h.length < 5 || !w[0].equals(h[0])) continue;   // same language at least
                int score = 1 + (w[1].equals(h[1]) ? 4 : 0) + (w[2].equals(h[2]) ? 2 : 0) + (w[3].equals(h[3]) ? 3 : 0) + (w[4].equals(h[4]) ? 2 : 0);
                if (score > bestScore) { bestScore = score; best = g; bestIndex = i; }
            }
        }
        if (best == null) return null;
        if (type == C.TRACK_TYPE_TEXT) b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
        Diag.log((type == C.TRACK_TYPE_AUDIO ? "Audio" : "Subtitles") + " → " + describe(best.getTrackFormat(bestIndex)) + " (as last time)");
        if (best.isTrackSelected(bestIndex)) return false;
        b.setOverrideForType(new TrackSelectionOverride(best.getMediaTrackGroup(), bestIndex));
        return true;
    }

    // ------------------------------------------------------------------ audio

    static int audioRank(String mime) {
        switch (mime) {
            case "audio/eac3-joc": return 0;
            case "audio/eac3": return 1;
            case "audio/ac3": return 2;
            case "audio/flac": return 3;
            case "audio/mp4a-latm": return 4;
            case "audio/opus": return 5;
            case "audio/true-hd": return 10;
            case "audio/vnd.dts.hd": return 11;
            case "audio/vnd.dts": return 12;
            default: return mime.startsWith("audio/vnd.dts") ? 13 : 20;
        }
    }

    private static boolean pickAudio(Tracks tracks, TrackSelectionParameters.Builder b) {
        // Original language: the default-flagged audio track, otherwise the first audio track.
        String original = null;
        String first = null;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < g.length; i++) {
                Format f = g.getTrackFormat(i);
                if ((f.roleFlags & C.ROLE_FLAG_COMMENTARY) != 0) continue;
                if (first == null) first = iso3(f.language);
                if (original == null && (f.selectionFlags & C.SELECTION_FLAG_DEFAULT) != 0) original = iso3(f.language);
            }
        }
        if (original == null) original = first;

        Tracks.Group bestGroup = null;
        int bestIndex = -1;
        int bestRank = Integer.MAX_VALUE;
        int bestChannels = -1;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                Format f = g.getTrackFormat(i);
                if (original != null && !original.equals(iso3(f.language))) continue;
                int rank = audioRank(mime(f));
                if ((f.roleFlags & C.ROLE_FLAG_COMMENTARY) != 0) rank += 100;
                if (rank < bestRank || (rank == bestRank && f.channelCount > bestChannels)) {
                    bestRank = rank;
                    bestChannels = f.channelCount;
                    bestGroup = g;
                    bestIndex = i;
                }
            }
        }
        if (bestGroup == null || bestGroup.isTrackSelected(bestIndex)) {
            if (bestGroup != null) Diag.log("Audio: " + describe(bestGroup.getTrackFormat(bestIndex)) + " (original)");
            return false;
        }
        b.setOverrideForType(new TrackSelectionOverride(bestGroup.getMediaTrackGroup(), bestIndex));
        Diag.log("Audio → " + describe(bestGroup.getTrackFormat(bestIndex)) + " (original language)");
        return true;
    }

    // ------------------------------------------------------------------ subtitles

    static int subtitleScore(String mime) {
        switch (mime) {
            case "application/x-subrip": return 100;
            case "text/x-ssa": return 80;
            case "text/vtt": return 75;
            case "application/ttml+xml": return 70;
            case "application/x-quicktime-tx3g": return 70;
            case "application/pgs": return 40;
            case "application/vobsub": return 35;
            case "application/dvbsubs": return 35;
            default: return 50;
        }
    }

    private static boolean pickSubtitle(Tracks tracks, TrackSelectionParameters.Builder b) {
        Tracks.Group bestGroup = null;
        int bestIndex = -1;
        int bestScore = Integer.MIN_VALUE;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                Format f = g.getTrackFormat(i);
                if (!"eng".equals(iso3(f.language))) continue;
                int score = subtitleScore(mime(f));
                if ((f.selectionFlags & C.SELECTION_FLAG_FORCED) != 0) score -= 60;   // forced = signs/foreign parts only
                if ((f.roleFlags & C.ROLE_FLAG_DESCRIBES_MUSIC_AND_SOUND) != 0) score -= 3; // plain before SDH
                if (score > bestScore) {
                    bestScore = score;
                    bestGroup = g;
                    bestIndex = i;
                }
            }
        }
        if (bestGroup == null) {
            Diag.log("Subtitles: no English track");
            return false;
        }
        b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false);
        if (bestGroup.isTrackSelected(bestIndex)) return false;
        b.setOverrideForType(new TrackSelectionOverride(bestGroup.getMediaTrackGroup(), bestIndex));
        Diag.log("Subtitles → English " + shortMime(mime(bestGroup.getTrackFormat(bestIndex))));
        return true;
    }

    // ------------------------------------------------------------------ helpers

    private static String describe(Format f) {
        String l = iso3(f.language);
        return shortMime(mime(f)) + " " + f.channelCount + "ch" + (l != null ? " " + l : "");
    }

    private static String mime(Format f) {
        return f == null || f.sampleMimeType == null ? "" : f.sampleMimeType.toLowerCase(Locale.US);
    }

    private static String shortMime(String m) {
        int i = m.indexOf('/');
        return i >= 0 ? m.substring(i + 1) : m;
    }

    private static String iso3(String lang) {
        if (lang == null || lang.isEmpty() || lang.equals("und")) return null;
        try {
            return new Locale(lang.split("[-_]")[0]).getISO3Language();
        } catch (Exception e) {
            return lang.toLowerCase(Locale.US);
        }
    }
}
