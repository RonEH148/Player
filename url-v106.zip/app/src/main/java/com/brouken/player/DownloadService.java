package com.brouken.player;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Keeps downloads to the USB drive running when the player is closed or the screen is off:
 * a notification with the progress, and the CPU / Wi-Fi kept awake while it downloads.
 */
public class DownloadService extends Service {

    private static final String CHANNEL = "downloads";
    private static final int ID = 4801;
    private static boolean running;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    static void start(Context c) {
        if (running) return;
        try {
            Intent i = new Intent(c, DownloadService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
            running = true;
        } catch (Throwable t) {
            Diag.log("Downloads: couldn't keep running in the background: " + t);
        }
    }

    static void stop(Context c) {
        if (!running) return;
        running = false;
        try { c.stopService(new Intent(c, DownloadService.class)); } catch (Throwable ignored) { }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(ID, n);
        } catch (Throwable t) {
            Diag.log("Downloads: no background notification: " + t);
        }
        try {
            if (wake == null) {
                wake = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GammaPlayer:download");
                wake.setReferenceCounted(false);
                wake.acquire(12 * 60 * 60 * 1000L);
            }
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (wm != null) {
                    wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "GammaPlayer:download");
                    wifi.setReferenceCounted(false);
                    wifi.acquire();
                }
            }
        } catch (Throwable ignored) { }
        ui.removeCallbacks(update);
        ui.postDelayed(update, 2000);
        return START_NOT_STICKY;
    }

    private final Runnable update = new Runnable() {
        @Override
        public void run() {
            if (!Downloads.hasActive()) {
                stopSelf();
                return;
            }
            try {
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(ID, build());
            } catch (Throwable ignored) { }
            ui.postDelayed(this, 3000);
        }
    };

    private Notification build() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, DownloadsActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(R.drawable.ic_g_download)
                .setContentTitle("Downloading to the USB drive")
                .setContentText(Downloads.summary())
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    // Android 15+: background data transfers have a daily time limit
    public void onTimeout(int startId, int fgsType) {
        Diag.log("Downloads: Android's background time limit reached – open the player to continue");
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        ui.removeCallbacks(update);
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Throwable ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
