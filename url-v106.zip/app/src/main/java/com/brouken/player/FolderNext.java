package com.brouken.player;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;

import java.util.List;

/** A video from a Saved links folder ended: offer the next one in the folder. */
final class FolderNext {

    private FolderNext() {}

    static void onEnded(final PlayerActivity a) {
        try {
            Uri uri = a.mPrefs != null ? a.mPrefs.mediaUri : null;
            if (uri == null || a.isFinishing()) return;
            String k = SavedLinksActivity.key(uri.toString());
            List<SavedLinksActivity.Link> all = SavedLinksActivity.load(a);
            SavedLinksActivity.Link me = null;
            for (SavedLinksActivity.Link l : all) if (l.folder != null && SavedLinksActivity.key(l.url).equals(k)) { me = l; break; }
            if (me == null) return;
            List<SavedLinksActivity.Link> eps = SavedLinksActivity.inFolder(all, me.folder);
            int i = -1;
            for (int j = 0; j < eps.size(); j++) if (eps.get(j) == me) i = j;
            if (i < 0 || i + 1 >= eps.size()) return;
            final SavedLinksActivity.Link next = eps.get(i + 1);
            new AlertDialog.Builder(a)
                    .setTitle("Up next in " + me.folder)
                    .setMessage(next.name)
                    .setPositiveButton("Play next", (d, w) -> {
                        Intent in = new Intent(a, PasteUrlActivity.class);
                        in.putExtra(PasteUrlActivity.EXTRA_URL, next.url);
                        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        a.startActivity(in);
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Throwable t) {
            Diag.log("Up next: " + t);
        }
    }
}
