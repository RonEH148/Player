package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Downloads to the USB drive: size, speed, time left, time taken; pause / resume (links that can
 * seek), delete, play.
 */
public class DownloadsActivity extends Activity {

    private ThemeMode.Pal P = new ThemeMode.Pal(true);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Downloads.Job> shown = new ArrayList<>();
    private Adapter adapter;
    private TextView status, empty;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        ThemeMode.override(this, base);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        P = ThemeMode.pal(this);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(P.bg));
        setContentView(build());
        Downloads.kick(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            ui.postDelayed(this, 1000);
        }
    };

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(true);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        b.setTextColor(P.accent);
        b.setBackgroundResource(R.drawable.glass_row);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(dp(64));
        b.setStateListAnimator(null);
        return b;
    }

    private View build() {
        FrameLayout root = new FrameLayout(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(24), dp(18), dp(24), dp(12));
        panel.setBackground(P.panelBg(this));
        int sw = getResources().getDisplayMetrics().widthPixels, sh = getResources().getDisplayMetrics().heightPixels;
        root.addView(panel, new FrameLayout.LayoutParams(Math.min(Math.round(sw * 0.92f), dp(1000)), Math.round(sh * 0.9f), Gravity.CENTER));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Downloads", 24, P.text);
        head.addView(title);
        status = text("", 13, P.sub);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        slp.leftMargin = dp(14);
        head.addView(status, slp);
        panel.addView(head);

        FrameLayout box = new FrameLayout(this);
        ListView list = new ListView(this);
        list.setDivider(new android.graphics.drawable.ColorDrawable(P.line));
        list.setDividerHeight(Math.max(1, dp(1) / 2 + 1));
        list.setSelector(R.drawable.glass_list_selector);
        list.setVerticalScrollBarEnabled(false);
        adapter = new Adapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> { if (pos < shown.size()) options(shown.get(pos)); });
        box.addView(list);
        empty = text("Nothing downloading.\n\nIn Saved links, choose a link (or a folder) → “Download to USB drive”.", 15, P.sub);
        empty.setGravity(Gravity.CENTER);
        box.addView(empty, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        blp.topMargin = dp(12);
        panel.addView(box, blp);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        Button clear = button("Clear finished");
        clear.setOnClickListener(v -> { Downloads.clearFinished(this); refresh(); });
        Button close = button("Close");
        close.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        b1.leftMargin = dp(6);
        buttons.addView(clear, b1);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        b2.leftMargin = dp(6);
        buttons.addView(close, b2);
        LinearLayout.LayoutParams bb = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bb.topMargin = dp(8);
        panel.addView(buttons, bb);
        list.post(list::requestFocus);
        return root;
    }

    private void refresh() {
        shown.clear();
        shown.addAll(Downloads.list(this));
        int n = 0;
        for (Downloads.Job j : shown) if (j.state == Downloads.ACTIVE || j.state == Downloads.QUEUED) n++;
        String b = Downloads.blocked;
        status.setText(b != null && n > 0 ? b : n == 0 ? "" : n + " to go · one at a time, full speed");
        empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
    }

    // ------------------------------------------------------------------ text

    static String size(long b) {
        if (b <= 0) return "?";
        return b >= 1e9 ? String.format(Locale.US, "%.1f GB", b / 1e9) : String.format(Locale.US, "%.0f MB", b / 1e6);
    }

    static String duration(long ms) {
        long s = Math.max(0, ms / 1000);
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                : String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private String line(Downloads.Job j) {
        String of = j.size > 0 ? size(j.have) + " of " + size(j.size) : size(j.have);
        switch (j.state) {
            case Downloads.ACTIVE: {
                double mbps = Downloads.mbps;
                StringBuilder sb = new StringBuilder(of);
                if (j.size > 0) sb.append(String.format(Locale.US, " · %d%%", Math.min(100, j.have * 100 / j.size)));
                if (mbps > 0) sb.append(String.format(Locale.US, " · %.0f Mbit/s (%.1f MB/s)", mbps, mbps / 8));
                if (mbps > 0 && j.size > j.have) sb.append(" · ").append(duration((long) ((j.size - j.have) * 8 / (mbps * 1e6) * 1000))).append(" left");
                sb.append(" · ").append(duration(j.elapsedMs)).append(" so far");
                if (j.have == 0 && mbps == 0) sb = new StringBuilder("Starting…");
                return sb.toString();
            }
            case Downloads.QUEUED: return "Waiting" + (j.have > 0 ? " · " + of + " on the drive" : "");
            case Downloads.PAUSED: return "Paused · " + of;
            case Downloads.DONE: return "Done · " + size(j.size > 0 ? j.size : j.have) + " · took " + duration(j.elapsedMs);
            default: return "Stopped" + (j.error != null ? ": " + j.error : "");
        }
    }

    // ------------------------------------------------------------------ actions

    private void options(final Downloads.Job j) {
        List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        if (j.state == Downloads.DONE || j.have > 0) {
            labels.add("Play");
            actions.add(() -> play(j));
        }
        if (j.state == Downloads.ACTIVE && !j.linear) {
            labels.add("Pause");
            actions.add(() -> Downloads.pause(this, j.id));
        }
        if (j.state == Downloads.QUEUED) {
            labels.add("Hold (don't start yet)");
            actions.add(() -> Downloads.pause(this, j.id));
        }
        if (j.state == Downloads.PAUSED) {
            labels.add(j.linear ? "Continue (starts again from the beginning, keeps what's on the drive)" : "Resume");
            actions.add(() -> Downloads.resume(this, j.id));
        }
        if (j.state == Downloads.FAILED) {
            labels.add("Try again");
            actions.add(() -> Downloads.resume(this, j.id));
        }
        labels.add("Delete");
        actions.add(() -> confirmDelete(j));
        if (j.state == Downloads.ACTIVE && j.linear) {
            // can't be paused: the choices as buttons, with the reason
            new AlertDialog.Builder(this)
                    .setTitle(j.name)
                    .setMessage("This server can't seek, so the download can't be paused – it would start again from the beginning.")
                    .setPositiveButton("Play", (d, w) -> play(j))
                    .setNeutralButton("Delete", (d, w) -> confirmDelete(j))
                    .setNegativeButton("Close", null)
                    .show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(j.name)
                .setItems(labels.toArray(new String[0]), (d, w) -> { actions.get(w).run(); refresh(); })
                .show();
    }

    private void confirmDelete(final Downloads.Job j) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this download?")
                .setMessage(j.name + "\n\nIt's removed from the list and deleted from the USB drive. The saved link stays.")
                .setPositiveButton("Delete", (d, w) -> { Downloads.delete(this, j.id); refresh(); })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void play(Downloads.Job j) {
        Intent i = new Intent(this, PasteUrlActivity.class);
        i.putExtra(PasteUrlActivity.EXTRA_URL, j.url);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    // ------------------------------------------------------------------ rows

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            Row r;
            if (v != null && v.getTag() instanceof Row) r = (Row) v.getTag();
            else { r = new Row(); v = r.build(); }
            r.bind(shown.get(i));
            return v;
        }
    }

    private final class Row {
        TextView name, folder, detail;
        ProgressBar bar;

        View build() {
            LinearLayout row = new LinearLayout(DownloadsActivity.this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(14), dp(10), dp(14), dp(10));
            LinearLayout top = new LinearLayout(DownloadsActivity.this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            name = text("", 16, P.text);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            top.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            folder = text("", 12, P.accent);
            top.addView(folder);
            row.addView(top);
            detail = text("", 12, P.sub);
            row.addView(detail);
            bar = ResumePoints.glassBar(DownloadsActivity.this, 0, 1);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4));
            lp.topMargin = dp(8);
            row.addView(bar, lp);
            row.setTag(this);
            return row;
        }

        void bind(Downloads.Job j) {
            name.setText(j.name);
            folder.setText(j.folder != null ? j.folder : "");
            detail.setText(line(j) + (j.linear && j.state == Downloads.ACTIVE ? " · can't pause (server can't seek)" : ""));
            if (j.size > 0 && j.state != Downloads.DONE) {
                bar.setVisibility(View.VISIBLE);
                bar.setProgress((int) Math.min(1000, j.have * 1000 / j.size));
            } else {
                bar.setVisibility(View.GONE);
            }
        }
    }
}
