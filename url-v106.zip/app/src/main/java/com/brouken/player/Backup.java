package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Back up / restore Saved links (with folders), Continue watching and the watched list:
 * to the USB drive (easy to move between the tablet and the TV) or to any file.
 * Restoring adds what's missing; nothing you have is overwritten.
 */
final class Backup {

    private Backup() {}

    static final int REQUEST_SAVE = 5101, REQUEST_OPEN = 5102;
    private static final String FILE = "Gamma Player backup.json";

    private static byte[] build(Activity a) throws Exception {
        JSONObject o = new JSONObject();
        o.put("app", "Gamma Player");
        o.put("version", 1);
        o.put("made", System.currentTimeMillis());
        JSONArray links = new JSONArray();
        for (SavedLinksActivity.Link l : SavedLinksActivity.load(a)) {
            JSONObject x = new JSONObject();
            x.put("n", l.name).put("u", l.url).put("t", l.added);
            if (l.folder != null) x.put("f", l.folder);
            links.put(x);
        }
        o.put("links", links);
        o.put("progress", ResumePoints.export(a));
        return o.toString(1).getBytes("UTF-8");
    }

    static void backup(final Activity a) {
        final DriveDir drive = UsbBuffer.drive(a);
        List<String> items = new ArrayList<>();
        if (drive != null) items.add("Save to the USB drive");
        items.add("Save as a file…");
        new AlertDialog.Builder(a)
                .setTitle("Back up saved links")
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    if (drive != null && w == 0) toDrive(a, drive);
                    else toFile(a);
                })
                .show();
    }

    private static void toDrive(Activity a, DriveDir drive) {
        try {
            drive.writeAtomic(FILE, build(a));
            Toast.makeText(a, "Saved on the USB drive (“" + FILE + "”)", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(a, "Couldn't save on the USB drive: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static void toFile(Activity a) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, FILE);
        try {
            a.startActivityForResult(i, REQUEST_SAVE);
        } catch (Exception e) {
            Toast.makeText(a, "No app here can save files – use the USB drive instead", Toast.LENGTH_LONG).show();
        }
    }

    static void restore(final Activity a, final Runnable changed) {
        final DriveDir drive = UsbBuffer.drive(a);
        final byte[] onDrive = drive != null ? drive.read(FILE) : null;
        List<String> items = new ArrayList<>();
        if (onDrive != null) items.add("From the USB drive" + madeOn(onDrive));
        items.add("Open a backup file…");
        new AlertDialog.Builder(a)
                .setTitle("Restore saved links")
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    if (onDrive != null && w == 0) { apply(a, onDrive); changed.run(); }
                    else fromFile(a);
                })
                .show();
    }

    private static String madeOn(byte[] data) {
        try {
            long t = new JSONObject(new String(data, "UTF-8")).optLong("made");
            return t > 0 ? " (" + new java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.getDefault()).format(new java.util.Date(t)) + ")" : "";
        } catch (Exception e) {
            return "";
        }
    }

    private static void fromFile(Activity a) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (a.getPackageManager().queryIntentActivities(i, 0).isEmpty()) {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            i = Intent.createChooser(i, "Open backup");
        }
        try {
            a.startActivityForResult(i, REQUEST_OPEN);
        } catch (Exception e) {
            Toast.makeText(a, "No app here can open files – use the USB drive instead", Toast.LENGTH_LONG).show();
        }
    }

    /** From SavedLinksActivity.onActivityResult. Returns true when it was ours. */
    static boolean onResult(Activity a, int request, int result, Intent data, Runnable changed) {
        if (request != REQUEST_SAVE && request != REQUEST_OPEN) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) return true;
        Uri uri = data.getData();
        if (request == REQUEST_SAVE) {
            try (OutputStream out = a.getContentResolver().openOutputStream(uri, "wt")) {
                out.write(build(a));
                Toast.makeText(a, "Backup saved", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(a, "Couldn't save the backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            try (InputStream in = a.getContentResolver().openInputStream(uri)) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0 && b.size() < 20_000_000) b.write(buf, 0, n);
                apply(a, b.toByteArray());
            } catch (Exception e) {
                Toast.makeText(a, "Couldn't open the backup: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        changed.run();
        return true;
    }

    /** Adds the links that aren't saved yet; a link without a folder here gets the backup's folder. */
    private static void apply(Activity a, byte[] data) {
        try {
            JSONObject o = new JSONObject(new String(data, "UTF-8"));
            JSONArray in = o.optJSONArray("links");
            if (in == null) throw new Exception("not a Gamma Player backup");
            List<SavedLinksActivity.Link> links = SavedLinksActivity.load(a);
            Set<String> have = new HashSet<>();
            Set<String> names = new HashSet<>();
            for (SavedLinksActivity.Link l : links) { have.add(SavedLinksActivity.key(l.url)); names.add(l.name.toLowerCase()); }
            int added = 0;
            for (int i = 0; i < in.length(); i++) {
                JSONObject x = in.getJSONObject(i);
                String url = x.optString("u");
                if (!PasteUrlActivity.isValid(url)) continue;
                String k = SavedLinksActivity.key(url);
                String folder = x.optString("f", "").trim();
                if (have.contains(k)) {
                    if (!folder.isEmpty()) {
                        for (SavedLinksActivity.Link l : links) {
                            if (l.folder == null && SavedLinksActivity.key(l.url).equals(k)) l.folder = folder;
                        }
                    }
                    continue;
                }
                String name = x.optString("n", url);
                String n = name;
                for (int c = 2; names.contains(n.toLowerCase()); c++) n = name + " (" + c + ")";
                SavedLinksActivity.Link l = new SavedLinksActivity.Link(n, url, x.optLong("t", System.currentTimeMillis()));
                l.folder = folder.isEmpty() ? null : folder;
                links.add(l);
                have.add(k);
                names.add(n.toLowerCase());
                added++;
            }
            SavedLinksActivity.save(a, links);
            ResumePoints.merge(a, o.optJSONObject("progress"));
            Toast.makeText(a, added == 0 ? "Restored – nothing new (everything was here already)"
                    : "Restored " + added + (added == 1 ? " link" : " links"), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(a, "That isn't a Gamma Player backup", Toast.LENGTH_LONG).show();
        }
    }
}
