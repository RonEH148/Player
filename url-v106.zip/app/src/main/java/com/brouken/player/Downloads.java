package com.brouken.player;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.media3.common.C;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * "Download to USB drive": links from Saved links are downloaded onto the drive (the same
 * per-video folders the player uses), one after the other, each with one connection at full
 * speed. A finished video plays from the drive with full seeking. Playing a link while it
 * downloads uses the same download.
 *
 * Links that can't seek can't be paused (the server would start again from the beginning).
 */
final class Downloads {

    private Downloads() {}

    static final int QUEUED = 0, ACTIVE = 1, PAUSED = 2, DONE = 3, FAILED = 4;

    static final class Job {
        String id, url, name, folder, error;
        int state;
        long added, size = -1, have, elapsedMs, finishedAt;
        boolean linear, probed;

        JSONObject json() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id).put("u", url).put("n", name).put("s", state).put("a", added)
                    .put("z", size).put("h", have).put("e", elapsedMs).put("d", finishedAt)
                    .put("l", linear).put("p", probed);
            if (folder != null) o.put("f", folder);
            if (error != null) o.put("x", error);
            return o;
        }

        static Job from(JSONObject o) {
            Job j = new Job();
            j.id = o.optString("id");
            j.url = o.optString("u");
            j.name = o.optString("n");
            j.folder = o.has("f") ? o.optString("f") : null;
            j.error = o.has("x") ? o.optString("x") : null;
            j.state = o.optInt("s");
            j.added = o.optLong("a");
            j.size = o.optLong("z", -1);
            j.have = o.optLong("h");
            j.elapsedMs = o.optLong("e");
            j.finishedAt = o.optLong("d");
            j.linear = o.optBoolean("l");
            j.probed = o.optBoolean("p");
            return j;
        }

        Job copy() {
            try { return from(json()); } catch (Exception e) { return this; }
        }
    }

    private static Context app;
    private static List<Job> jobs;
    private static Job active;
    /** Live numbers of the running download. */
    static volatile double mbps;
    /** Why the queue can't start (no drive …), or null. */
    static volatile String blocked;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("downloads", Context.MODE_PRIVATE);
    }

    private static synchronized void load(Context c) {
        if (app == null) app = c.getApplicationContext();
        if (jobs != null) return;
        jobs = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("jobs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                Job j = Job.from(a.getJSONObject(i));
                if (j.state == ACTIVE) j.state = QUEUED;   // the app was closed while it ran: continues
                jobs.add(j);
            }
        } catch (Exception ignored) { }
    }

    private static synchronized void save() {
        if (app == null || jobs == null) return;
        try {
            JSONArray a = new JSONArray();
            for (Job j : jobs) a.put(j.json());
            prefs(app).edit().putString("jobs", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized List<Job> list(Context c) {
        load(c);
        List<Job> out = new ArrayList<>();
        for (Job j : jobs) out.add(j.copy());
        return out;
    }

    private static Job find(String id) {
        if (jobs != null) for (Job j : jobs) if (j.id.equals(id)) return j;
        return null;
    }

    private static Job byUrl(String url) {
        String k = SavedLinksActivity.key(url);
        if (jobs != null) for (Job j : jobs) if (SavedLinksActivity.key(j.url).equals(k)) return j;
        return null;
    }

    /** Is something downloading right now? */
    static synchronized boolean hasActive() {
        return active != null;
    }

    /** Is something downloading or waiting? */
    static synchronized boolean running() {
        if (jobs == null) return false;
        for (Job j : jobs) if (j.state == ACTIVE || j.state == QUEUED) return true;
        return false;
    }

    static synchronized int activeCount(Context c) {
        load(c);
        int n = 0;
        for (Job j : jobs) if (j.state == ACTIVE || j.state == QUEUED) n++;
        return n;
    }

    /** State of a link on the Downloads list, or -1. */
    static synchronized int stateOf(Context c, String url) {
        load(c);
        Job j = byUrl(url);
        return j == null ? -1 : j.state;
    }

    /** Adds a link; returns false when it's on the list already. */
    static synchronized boolean add(Context c, String url, String name, String folder) {
        load(c);
        String u = PasteUrlActivity.normalize(url.trim());
        Job old = byUrl(u);
        if (old != null) {
            if (old.state == FAILED || old.state == PAUSED) {
                old.state = QUEUED;
                old.error = null;
                save();
                pump();
                return true;
            }
            return false;
        }
        Job j = new Job();
        j.id = Long.toString(System.nanoTime(), 36);
        j.url = u;
        j.name = name;
        j.folder = folder;
        j.state = QUEUED;
        j.added = System.currentTimeMillis();
        jobs.add(j);
        save();
        pump();
        return true;
    }

    static synchronized void pause(Context c, String id) {
        load(c);
        Job j = find(id);
        if (j == null) return;
        if (j.state == ACTIVE) {
            if (j.linear) return;   // can't: the server would start again from the beginning
            j.state = PAUSED;
            active = null;
            UsbBuffer.backgroundStop(false);
        } else if (j.state == QUEUED) {
            j.state = PAUSED;
        }
        save();
        pump();
    }

    static synchronized void resume(Context c, String id) {
        load(c);
        Job j = find(id);
        if (j == null || (j.state != PAUSED && j.state != FAILED)) return;
        j.state = QUEUED;
        j.error = null;
        save();
        pump();
    }

    /** Removes it from the list and deletes the download from the drive. */
    static synchronized void delete(Context c, String id) {
        load(c);
        Job j = find(id);
        if (j == null) return;
        jobs.remove(j);
        if (j == active) {
            active = null;
            UsbBuffer.backgroundStop(true);
        } else {
            final String url = j.url;
            final Context a = app;
            new Thread(() -> UsbBuffer.deleteStored(a, url), "download-delete").start();
        }
        save();
        pump();
    }

    /** Finished ones off the list (the videos stay on the drive). */
    static synchronized void clearFinished(Context c) {
        load(c);
        List<Job> keep = new ArrayList<>();
        for (Job j : jobs) if (j.state != DONE) keep.add(j);
        jobs = keep;
        save();
    }

    /** The player deleted this video's download (Paused → Delete & close). */
    static synchronized void removedByPlayer(String url) {
        if (jobs == null) return;
        Job j = byUrl(url);
        if (j == null) return;
        jobs.remove(j);
        if (j == active) active = null;
        save();
        pump();
    }

    /** The drive was connected / switched on: try again. */
    static synchronized void kick(Context c) {
        load(c);
        pump();
    }

    // ------------------------------------------------------------------ the queue

    private static synchronized void pump() {
        if (app == null || jobs == null) return;
        if (active != null) return;
        Job next = null;
        for (Job j : jobs) if (j.state == QUEUED) { next = j; break; }
        if (next == null) {
            blocked = null;
            DownloadService.stop(app);
            return;
        }
        String why = UsbBuffer.notUsedBecause(app);
        if (why != null) {
            blocked = "off".equals(why) ? "Turn on “Use USB drive as buffer” in Settings" : "USB drive: " + why;
            DownloadService.stop(app);   // nothing to keep awake for: continues when you open Downloads again
            return;
        }
        blocked = null;
        active = next;
        next.state = ACTIVE;
        next.error = null;
        save();
        DownloadService.start(app);
        final Job job = next;
        new Thread(() -> run(job), "download").start();
    }

    private static synchronized boolean still(Job j) {
        return active == j && j.state == ACTIVE;
    }

    private static void run(final Job job) {
        DriveBuffer b = null;
        int retries = 0;
        try {
            Uri uri = Uri.parse(job.url);
            // the link check: size, and whether the server can seek
            if (!job.probed) {
                Probe.Result r = probe(job.url);
                if (r == null || !r.ok) {
                    fail(job, r == null ? "The link check didn't answer" : "The link doesn't work: " + r.summary);
                    return;
                }
                synchronized (Downloads.class) {
                    job.size = r.size;
                    job.linear = !r.seekable && r.code == 200;
                    job.probed = true;
                    save();
                }
            }
            if (job.size > 0) Decoder.rememberSize(app, job.url, job.size);
            if (job.linear) RangeSupport.markLinear(uri);
            if (!still(job)) return;
            b = UsbBuffer.backgroundStart(app, uri, job.linear, NetCompat.httpFactory(uri));
            b.fullSpeed = true;
            if (b.title == null) b.title = job.name;
            if (job.size > 0 && job.size - b.usedBytes() > b.capacity() - b.usedBytes()) {
                fail(job, "Not enough room on the USB drive (needs " + DownloadsActivity.size(job.size) + ")");
                return;
            }
            long gap = b.firstGap();
            if (gap < 0) { finish(job, b); return; }
            if (!b.downloading()) b.startQuietly(job.linear ? 0 : gap);
            long last = android.os.SystemClock.elapsedRealtime();
            int idle = 0, ticks = 0;
            while (still(job)) {
                Thread.sleep(1000);
                long now = android.os.SystemClock.elapsedRealtime();
                synchronized (Downloads.class) {
                    if (!still(job)) break;
                    job.elapsedMs += now - last;
                    job.have = b.usedBytes();
                    long t = b.totalSize();
                    if (t != C.LENGTH_UNSET && t > 0) job.size = t;
                    mbps = b.downloadMbps;
                }
                last = now;
                gap = b.firstGap();
                if (gap < 0) { finish(job, b); return; }
                if (b.isClosed()) {
                    // the player closed it (Delete & close) – handled there
                    return;
                }
                if (!b.downloading()) {
                    if (++idle < 3) continue;   // a moment to start
                    idle = 0;
                    IOException e = b.takeError();
                    if (e != null && retries >= 1) {
                        fail(job, "Download stopped: " + Diag.describe(e));
                        return;
                    }
                    if (e != null) retries++;
                    b.startQuietly(job.linear ? 0 : gap);   // one more try after an error
                } else {
                    idle = 0;
                }
                if (++ticks % 30 == 0) synchronized (Downloads.class) { save(); }
            }
        } catch (InterruptedException ignored) {
        } catch (Throwable t) {
            fail(job, Diag.describe(t));
        }
    }

    private static Probe.Result probe(String url) throws InterruptedException {
        final Probe.Result[] out = new Probe.Result[1];
        final CountDownLatch done = new CountDownLatch(1);
        Probe.start(url, new Probe.Callback() {
            @Override public void onLog(String line) { }
            @Override public void onDone(Probe.Result r) { out[0] = r; done.countDown(); }
        });
        done.await(90, TimeUnit.SECONDS);
        return out[0];
    }

    private static void finish(Job job, DriveBuffer b) {
        synchronized (Downloads.class) {
            if (active != job) return;
            job.state = DONE;
            job.finishedAt = System.currentTimeMillis();
            job.have = b.usedBytes();
            if (b.totalSize() > 0) job.size = b.totalSize();
            active = null;
            mbps = 0;
            UsbBuffer.backgroundStop(false);
            save();
            Diag.log("Download finished: " + job.name);
            pump();
        }
    }

    private static void fail(Job job, String why) {
        synchronized (Downloads.class) {
            if (active != job) return;
            job.state = FAILED;
            job.error = why;
            active = null;
            mbps = 0;
            UsbBuffer.backgroundStop(false);
            save();
            pump();
        }
    }

    /** For the notification. */
    static synchronized String summary() {
        Job j = active;
        if (j == null) return blocked != null ? blocked : "Starting…";
        String pct = j.size > 0 ? String.format(java.util.Locale.US, " · %d%%", Math.min(100, j.have * 100 / j.size)) : "";
        return j.name + pct + String.format(java.util.Locale.US, " · %.0f Mbit/s", mbps);
    }

    static void openScreen(Context c) {
        Intent i = new Intent(c, DownloadsActivity.class);
        if (!(c instanceof android.app.Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
}
