package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Saved links: your own list of video links with names. Play (with the usual link check), copy,
 * rename, share and delete them. Opened from the ★ button in the player and from "Open link".
 */
public class SavedLinksActivity extends Activity {

    /** The link of the video that's open in the player (offered as "Save current video"). */
    static final String EXTRA_CURRENT = "current";
    static final String EXTRA_CURRENT_NAME = "currentName";

    // ------------------------------------------------------------------ storage

    static final class Link {
        String name;
        String url;
        long added;

        Link(String name, String url, long added) {
            this.name = name;
            this.url = url;
            this.added = added;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("saved_links", Context.MODE_PRIVATE);
    }

    static List<Link> load(Context c) {
        List<Link> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Link(o.optString("n"), o.optString("u"), o.optLong("t")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    static void save(Context c, List<Link> links) {
        try {
            JSONArray a = new JSONArray();
            for (Link l : links) {
                JSONObject o = new JSONObject();
                o.put("n", l.name);
                o.put("u", l.url);
                o.put("t", l.added);
                a.put(o);
            }
            prefs(c).edit().putString("list", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** A name to start with: the file name in the link, else the site. */
    static String defaultName(String url) {
        try {
            String t = Titles.fromUrl(Uri.parse(url));
            if (t != null && !t.trim().isEmpty()) return t.trim();
            String host = Uri.parse(url).getHost();
            if (host != null) return host;
        } catch (Throwable ignored) { }
        return url;
    }

    // ------------------------------------------------------------------ rules

    static final int MAX_NAME = 120;

    /** Same link, written differently (spaces, pixeldrain /u/ vs /api/file/): compared like this. */
    static String key(String url) {
        String u = PasteUrlActivity.normalize(url.trim());
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    private Link byUrl(String url, Link except) {
        String k = key(url);
        for (Link l : links) if (l != except && key(l.url).equals(k)) return l;
        return null;
    }

    private Link byName(String name, Link except) {
        for (Link l : links) if (l != except && l.name.trim().equalsIgnoreCase(name.trim())) return l;
        return null;
    }

    /** A free name based on {@code base}: "Name", "Name (2)", "Name (3)" … */
    private String freeName(String base) {
        String b = base.length() > MAX_NAME ? base.substring(0, MAX_NAME) : base;
        if (byName(b, null) == null) return b;
        for (int i = 2; ; i++) {
            String n = b + " (" + i + ")";
            if (byName(n, null) == null) return n;
        }
    }

    /** Problem with this name, or null if it can be used. */
    private String nameProblem(String name, Link except) {
        if (name.isEmpty()) return "Enter a name";
        if (name.length() > MAX_NAME) return "Keep the name under " + MAX_NAME + " characters";
        Link other = byName(name, except);
        return other != null ? "A link with this name already exists" : null;
    }

    // ------------------------------------------------------------------ screen

    private List<Link> links;
    private final List<Link> shown = new ArrayList<>();
    private AlertDialog list;
    /** A–Z filter: null = all, '#' = names starting with a digit or symbol. */
    private Character letter;
    private BaseAdapter adapter;
    private LinearLayout letters;
    private TextView count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showList();
    }

    private static char group(String name) {
        char c = name.isEmpty() ? '#' : Character.toUpperCase(name.trim().isEmpty() ? '#' : name.trim().charAt(0));
        return c >= 'A' && c <= 'Z' ? c : '#';
    }

    private void sort() {
        java.util.Collections.sort(links, (a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    private void showList() {
        links = load(this);
        sort();
        final String current = getIntent().getStringExtra(EXTRA_CURRENT);
        final boolean canSaveCurrent = current != null && PasteUrlActivity.isValid(current) && byUrl(current, null) == null;

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Saved links")
                .setPositiveButton("Add link", (d, w) -> addDialog(null, null))
                .setNegativeButton("Close", (d, w) -> close())
                .setOnCancelListener(d -> close());
        if (canSaveCurrent) {
            b.setNeutralButton("Save this video", (d, w) ->
                    addDialog(current, getIntent().getStringExtra(EXTRA_CURRENT_NAME)));
        }
        if (links.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No saved links yet.\n\nAdd one with “Add link”"
                    + (canSaveCurrent ? ", or save the video that's playing." : "."));
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            empty.setPadding(dp(24), dp(16), dp(24), dp(8));
            b.setView(empty);
        } else {
            b.setView(content());
        }
        list = b.create();
        list.show();
    }

    /** A–Z bar, count, list. */
    private View content() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        // A–Z: only the letters that have links, so every choice shows something
        java.util.TreeSet<Character> present = new java.util.TreeSet<>();
        for (Link l : links) present.add(group(l.name));
        if (letter != null && !present.contains(letter)) letter = null;
        android.widget.HorizontalScrollView scroll = new android.widget.HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        letters = new LinearLayout(this);
        letters.setPadding(dp(16), dp(4), dp(16), dp(4));
        letters.addView(chip(null));
        for (Character c : present) if (c != '#') letters.addView(chip(c));
        if (present.contains('#')) letters.addView(chip('#'));
        scroll.addView(letters);
        box.addView(scroll);

        count = new TextView(this);
        count.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        count.setTextColor(0xFF9E9E9E);
        count.setPadding(dp(24), dp(2), dp(24), dp(6));
        box.addView(count);

        View line = new View(this);
        line.setBackgroundColor(0x33FFFFFF);
        box.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1) / 2 + 1)));

        android.widget.ListView lv = new android.widget.ListView(this);
        lv.setDivider(new android.graphics.drawable.ColorDrawable(0x1FFFFFFF));
        lv.setDividerHeight(Math.max(1, dp(1) / 2 + 1));
        adapter = new Adapter();
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((parent, view, pos, id) -> itemOptions(shown.get(pos)));
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int h = Math.min(links.size() * dp(62), (int) (screenH * 0.55f));
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(h, dp(62))));
        applyFilter();
        return box;
    }

    private TextView chip(final Character c) {
        TextView t = new TextView(this);
        t.setText(c == null ? "All" : String.valueOf(c));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(36));
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setFocusable(true);
        t.setClickable(true);
        t.setTag(c == null ? "all" : c);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), 0, dp(2), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> {
            letter = c;
            applyFilter();
        });
        t.setOnFocusChangeListener((v, f) -> styleChip((TextView) v));
        return t;
    }

    private void styleChip(TextView t) {
        Object tag = t.getTag();
        boolean selected = letter == null ? "all".equals(tag) : letter.equals(tag);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(16));
        bg.setColor(selected ? 0xFFE53935 : t.isFocused() ? 0x40FFFFFF : 0x00000000);
        if (!selected) bg.setStroke(Math.max(1, dp(1)), t.isFocused() ? 0xFFFFFFFF : 0x40FFFFFF);
        t.setBackground(bg);
        t.setTextColor(selected ? 0xFFFFFFFF : 0xFFE0E0E0);
        t.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
    }

    private void applyFilter() {
        shown.clear();
        for (Link l : links) if (letter == null || group(l.name) == letter) shown.add(l);
        if (letters != null) for (int i = 0; i < letters.getChildCount(); i++) styleChip((TextView) letters.getChildAt(i));
        if (count != null) {
            count.setText(letter == null ? links.size() + (links.size() == 1 ? " link" : " links") + " · A–Z"
                    : shown.size() + " of " + links.size() + " · starting with " + (letter == '#' ? "0–9 or a symbol" : letter));
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void refresh() {
        if (list != null) {
            list.setOnCancelListener(null);
            list.dismiss();
        }
        showList();
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            LinearLayout row;
            TextView name, url;
            if (v instanceof LinearLayout) {
                row = (LinearLayout) v;
                name = (TextView) row.getChildAt(0);
                url = (TextView) row.getChildAt(1);
            } else {
                row = new LinearLayout(SavedLinksActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(24), dp(10), dp(24), dp(10));
                row.setMinimumHeight(dp(60));
                row.setGravity(Gravity.CENTER_VERTICAL);
                name = new TextView(SavedLinksActivity.this);
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                name.setTextColor(0xFFFFFFFF);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.END);
                url = new TextView(SavedLinksActivity.this);
                url.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                url.setTextColor(0xFF9E9E9E);
                url.setSingleLine(true);
                url.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(name);
                row.addView(url);
            }
            Link l = shown.get(i);
            name.setText(l.name);
            url.setText(details(l));
            return row;
        }
    }

    /** "pixeldrain.eu.cc · 23 Oct 2026" */
    private String details(Link l) {
        String host = null;
        try { host = Uri.parse(l.url).getHost(); } catch (Throwable ignored) { }
        String date = l.added > 0 ? new java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date(l.added)) : null;
        return (host != null ? host : l.url) + (date != null ? " · " + date : "");
    }

    // ------------------------------------------------------------------ actions

    private void itemOptions(final Link l) {
        final String[] actions = {"Play", "Copy link", "Rename", "Share", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(l.name)
                .setItems(actions, (d, which) -> {
                    switch (which) {
                        case 0: play(l); break;
                        case 1: copy(l); refresh(); break;
                        case 2: rename(l); break;
                        case 3: share(l); break;
                        default: confirmDelete(l);
                    }
                })
                .setOnCancelListener(d -> refresh())
                .show();
    }

    private void play(Link l) {
        Intent i = new Intent(this, PasteUrlActivity.class);
        i.putExtra(PasteUrlActivity.EXTRA_URL, l.url);   // the usual link check, then play
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        close();
    }

    private void copy(Link l) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText(l.name, l.url));
            Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Couldn't copy the link", Toast.LENGTH_SHORT).show();
        }
    }

    private void share(Link l) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, l.name);
        send.putExtra(Intent.EXTRA_TEXT, l.name + "\n" + l.url);
        try {
            startActivity(Intent.createChooser(send, "Share link"));
        } catch (Exception e) {
            Toast.makeText(this, "No app to share with", Toast.LENGTH_SHORT).show();
        }
        refresh();
    }

    private void rename(final Link l) {
        final EditText input = field(l.name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(wrap(input))
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            String problem = nameProblem(name, l);
            if (problem != null) {
                input.setError(problem);
                return;
            }
            l.name = name;
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        input.requestFocus();
    }

    private void confirmDelete(final Link l) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this link?")
                .setMessage(l.name)
                .setPositiveButton("Delete", (d, w) -> {
                    links.remove(l);
                    save(this, links);
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                    refresh();
                })
                .setNegativeButton("Cancel", (d, w) -> refresh())
                .setOnCancelListener(d -> refresh())
                .show();
    }

    /** Add a link: name + link (the link is filled in from the clipboard when it holds one). */
    private void addDialog(String presetUrl, String presetName) {
        String url = presetUrl != null ? presetUrl : clipboardLink();
        final EditText urlField = field(url, "Link (http, https or rtsp)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        String name = presetName != null && !presetName.trim().isEmpty() ? presetName.trim()
                : url != null ? defaultName(url) : null;
        if (name != null) name = freeName(name);   // suggested names never clash
        final EditText nameField = field(name, "Name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(nameField);
        box.addView(urlField);

        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(presetUrl != null ? "Save this video" : "Add link")
                .setView(box)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", (x, w) -> refresh())
                .setOnCancelListener(x -> refresh())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String u = urlField.getText().toString().trim();
            if (!PasteUrlActivity.isValid(u)) {
                urlField.setError("That isn't a valid http, https or rtsp link");
                return;
            }
            Link sameLink = byUrl(u, null);
            if (sameLink != null) {
                urlField.setError("Already saved as “" + sameLink.name + "”");
                return;
            }
            String n = nameField.getText().toString().trim();
            if (n.isEmpty()) n = freeName(defaultName(u));
            String problem = nameProblem(n, null);
            if (problem != null) {
                nameField.setError(problem);
                return;
            }
            links.add(new Link(n, u, System.currentTimeMillis()));
            letter = null;   // show it
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            save(this, links);
            d.setOnCancelListener(null);
            d.dismiss();
            refresh();
        }));
        d.show();
        (url == null ? urlField : nameField).requestFocus();
    }

    private String clipboardLink() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null) return null;
            CharSequence t = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            String s = t == null ? null : t.toString().trim();
            return PasteUrlActivity.isValid(s) ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    private EditText field(String text, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(type);
        if (text != null) {
            e.setText(text);
            e.setSelection(text.length());
        }
        return e;
    }

    private View wrap(View v) {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private void close() {
        if (list != null) list.setOnCancelListener(null);
        finish();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
