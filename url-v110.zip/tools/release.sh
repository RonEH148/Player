#!/usr/bin/env bash
# Publishes this build for the in-app "Check for updates" button.
# Tag prefix "gamma-player-b" keeps it apart from other apps built in this repository,
# and it is never marked as the repository's "latest" release.
set -eu
TAG="gamma-player-b${GITHUB_RUN_NUMBER}"
VER=$(grep -o 'url-v[0-9]*' app/build.gradle | head -1 | sed 's/^url-//')
gh release create "$TAG" out/GammaPlayer-Tablet.apk out/GammaPlayer-TV.apk \
  --repo "$GITHUB_REPOSITORY" --target "$GITHUB_SHA" --latest=false \
  --title "Gamma Player $VER (build $GITHUB_RUN_NUMBER)" \
  --notes "Gamma Player $VER, build $GITHUB_RUN_NUMBER. Installed from the app: Settings > Check for updates."
# keep only the 3 newest Gamma Player releases
OLD=$(gh release list --repo "$GITHUB_REPOSITORY" --limit 200 --json tagName --jq '.[].tagName' \
      | grep '^gamma-player-b[0-9]*$' | sed 's/^gamma-player-b//' | sort -n | head -n -3 || true)
for n in $OLD; do
  gh release delete "gamma-player-b$n" --repo "$GITHUB_REPOSITORY" --cleanup-tag -y || true
done
# releases from before the rename (still named "Just Player URL"): no longer needed
for t in $(gh release list --repo "$GITHUB_REPOSITORY" --limit 200 --json tagName --jq '.[].tagName' | grep '^justplayer-url-b[0-9]*$' || true); do
  gh release delete "$t" --repo "$GITHUB_REPOSITORY" --cleanup-tag -y || true
done
