package com.brouken.player;

import android.net.Uri;
import android.util.Base64;

import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.extractor.ts.TsExtractor;

import java.util.HashMap;

/**
 * Network behaviour modelled on what mpv/VLC (FFmpeg networking) do by default:
 * follow every redirect including http<->https, long timeouts, keep retrying dropped
 * connections, a media-player User-Agent, and a large read-ahead buffer.
 */
public final class NetCompat {

    public static final String USER_AGENT = "VLC/3.0.21 LibVLC/3.0.21";
    static final int TIMEOUT_MS = 30_000;
    static final int MIN_RETRIES = 12;

    private NetCompat() {}

    /** Called from PlayerActivity.initializePlayer() right before ExoPlayer.Builder.build(). */
    public static void apply(ExoPlayer.Builder builder, PlayerActivity activity) {
        try {
            Uri uri = activity.mPrefs != null ? activity.mPrefs.mediaUri : null;
            Diag.onNewMedia(uri);
            Lifecycle.beginSession(activity);
            Ivtc.onPlayerBuild(activity);
            try {
                Decoder.apply(builder, activity);
            } catch (Throwable t) {
                Diag.log("Decoder setup failed: " + t);
            }
            if (!isHttp(uri)) {
                if (uri != null) {
                    // local files: the same memory budget as links (the default holds only a few MB of 4K)
                    builder.setLoadControl(new DefaultLoadControl.Builder()
                            .setBufferDurationsMs(20_000, 60_000, 1_500, 2_500)
                            .setTargetBufferBytes(Perf.sampleBufferBytes())
                            .setPrioritizeTimeOverSizeThresholds(false)
                            .build());
                }
                return;
            }

            HashMap<String, String> headers = new HashMap<>();
            String userInfo = uri.getUserInfo();
            if (userInfo != null && userInfo.contains(":")) {
                headers.put("Authorization", "Basic " + Base64.encodeToString(userInfo.getBytes(), Base64.NO_WRAP));
            }
            headers.putAll(StreamHeaders.forMedia(uri));   // from the browser (avoids 403 on protected streams)

            // mpv-style HTTP: all redirects, no compression, and servers that ignore Range are detected
            // instead of silently downloading the file from the start (see RangeSupport)
            MpvHttpDataSource.Factory http = new MpvHttpDataSource.Factory(USER_AGENT, headers, TIMEOUT_MS, Diag.TRANSFER_LISTENER);

            // Background read-ahead cache (like mpv's stream cache) so the connection runs at full speed.
            // HLS/DASH (.m3u8/.mpd) are many small segments that the player fetches itself: no read-ahead.
            boolean adaptive = StreamHeaders.isAdaptive(uri, activity.mPrefs != null ? activity.mPrefs.mediaType : null);
            androidx.media3.datasource.DataSource.Factory network = adaptive ? http : new ReadAheadDataSource.Factory(http);
            // "Use USB drive as buffer": the file is downloaded onto the drive and played from there
            Perf.driveMode = false;
            if (!adaptive && UsbBuffer.enabled(activity)) {
                String why = UsbBuffer.notUsedBecause(activity);
                Perf.driveMode = why == null;
                // The video is read from the drive in big pieces on a background thread (into memory),
                // so the player's many small reads never wait for the hard disk. Always set up while
                // the switch is on: a drive still waking up / mounting after the TV was switched on is
                // picked up when the video opens (no drive → plain streaming, as without it).
                network = new ReadAheadDataSource.Factory(new DriveDataSource.Factory(activity, uri, http, http));
                if (why != null) Diag.log("USB buffer: " + why + (why.startsWith("no USB") ? " yet – checking again when the video opens" : ""));
            }
            DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(activity, network);
            if (adaptive) Diag.log("Stream type: " + (uri.getPath() != null && uri.getPath().toLowerCase().endsWith(".mpd") ? "DASH" : "HLS"));

            DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                    .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS)
                    .setTsExtractorTimestampSearchBytes(1500 * TsExtractor.TS_PACKET_SIZE);
            if (RangeSupport.isLinear(uri)) {
                // like mpv on a server that can't seek: don't jump to the MKV index at the end, just play
                extractors.setMatroskaExtractorFlags(androidx.media3.extractor.mkv.MatroskaExtractor.FLAG_DISABLE_SEEK_FOR_CUES);
                Diag.log("Linear playback: index lookup off (server can't seek)");
            }

            boolean linear = RangeSupport.isLinear(uri);
            DefaultMediaSourceFactory sources = new DefaultMediaSourceFactory(dataSource,
                    LinearSeek.factory(extractors, linear,                 // linear: seeking inside the buffer
                            activity.mPrefs != null && activity.mPrefs.mapDV7ToHevc));   // DV7 → HDR10 base layer
            sources.setLoadErrorHandlingPolicy(new LoggingRetryPolicy(MIN_RETRIES));
            AssSubs.apply(sources);
            builder.setMediaSourceFactory(sources);

            // Bigger decoded-sample buffer for high-bitrate remuxes: up to 2 min / 128 MB in memory.
            builder.setLoadControl(new DefaultLoadControl.Builder()
                    .setBufferDurationsMs(60_000, 600_000, 2_000, 4_000)   // up to 10 min; memory is the limit
                    .setTargetBufferBytes(Perf.sampleBufferBytes())
                    .setPrioritizeTimeOverSizeThresholds(false)
                    // linear links: keep a few seconds behind the playhead so short jumps back work
                    .setBackBuffer(linear ? LinearSeek.backBufferMs() : 0, true)
                    .build());

            Diag.log("Net: redirects any, timeout " + (TIMEOUT_MS / 1000) + "s, retries " + MIN_RETRIES
                    + ", buffer 600s/" + Perf.sampleBufferBytes() / (1024 * 1024) + "MB + " + ReadAheadDataSource.capacity() / (1024 * 1024) + "MB read-ahead");
        } catch (Throwable t) {
            Diag.log("NetCompat failed: " + t);
        }
    }

    static boolean isHttp(Uri uri) {
        if (uri == null || uri.getScheme() == null) return false;
        String s = uri.getScheme().toLowerCase();
        return s.equals("http") || s.equals("https");
    }

    /** Default retry policy with more attempts, and every retry is shown in the overlay. */
    static final class LoggingRetryPolicy extends DefaultLoadErrorHandlingPolicy {
        LoggingRetryPolicy(int minRetries) {
            super(minRetries);
        }

        @Override
        public long getRetryDelayMsFor(LoadErrorHandlingPolicy.LoadErrorInfo info) {
            Throwable e = info.exception;
            if (RangeSupport.find(e) != null) {
                Diag.log("Server ignored a jump: " + e.getMessage());
                return androidx.media3.common.C.TIME_UNSET;   // handled by reopening in linear mode
            }
            // the website refused (403 forbidden, 401, 404 gone, 400 …): asking again gets the same
            // answer, so stop at once instead of a minute of retries. Busy / timeouts are retried.
            androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException http = null;
            for (Throwable t = e; t != null && http == null; t = t.getCause()) {
                if (t instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                    http = (androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) t;
                }
            }
            if (http != null && http.responseCode >= 400 && http.responseCode < 500
                    && http.responseCode != 408 && http.responseCode != 425 && http.responseCode != 429) {
                Diag.log("Refused by the website (HTTP " + http.responseCode + ") – not retried");
                return androidx.media3.common.C.TIME_UNSET;
            }
            long delay = super.getRetryDelayMsFor(info);
            Diag.log("Retry #" + info.errorCount + (delay == androidx.media3.common.C.TIME_UNSET ? " (giving up)" : " in " + delay + " ms")
                    + ": " + Diag.describe(e));
            return delay;
        }
    }
}
