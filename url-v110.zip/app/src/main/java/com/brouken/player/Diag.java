package com.brouken.player;

import android.app.Activity;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.ColorInfo;
import androidx.media3.common.Format;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.ExoPlayer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Live network/playback diagnostics shown as a small overlay on top of the player. */
public final class Diag {

    private static final int MAX_LOG = 12;
    private static final List<String> LOG = new ArrayList<>();
    private static final List<String> PROBE = new ArrayList<>();
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private static final AtomicLong bytes = new AtomicLong();
    private static volatile int opens;
    private static volatile int lastCode;
    private static volatile String lastHost = "";
    private static volatile String lastType = "";
    private static volatile long totalSize = -1;
    private static volatile boolean rangesOk;
    private static volatile String state = "idle";
    private static volatile Uri media;

    private static long lastTickBytes;
    private static long lastTickTime;
    private static double speedMbps;

    private static TextView view;
    private static Activity activity;
    private static boolean shown;   // overlay is off until you press ⓘ, and closes when you leave
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    private Diag() {}

    // ---------------------------------------------------------------- logging

    public static void log(String line) {
        synchronized (LOG) {
            LOG.add(TIME.format(new Date()) + " " + line);
            while (LOG.size() > MAX_LOG) LOG.remove(0);
        }
    }

    private static volatile String probedUrl;

    public static void setProbe(String url, List<String> lines) {
        probedUrl = url;
        synchronized (PROBE) {
            PROBE.clear();
            PROBE.addAll(lines);
        }
    }

    static String describe(Throwable t) {
        if (t == null) return "unknown";
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        for (Throwable c = t; c != null && depth < 4; c = c.getCause(), depth++) {
            if (depth > 0) sb.append(" <- ");
            sb.append(c.getClass().getSimpleName());
            if (c instanceof HttpDataSource.InvalidResponseCodeException) {
                sb.append(" HTTP ").append(((HttpDataSource.InvalidResponseCodeException) c).responseCode);
            }
            if (c.getMessage() != null) {
                String m = c.getMessage();
                sb.append(": ").append(m.length() > 90 ? m.substring(0, 90) + "…" : m);
            }
        }
        return sb.toString();
    }

    static void onNewMedia(Uri uri) {
        media = uri;
        videoDecoder = "";
        audioDecoder = "";
        TrackPrefs.reset();
        Decoder.onNewMedia();
        FormatBadge.newMedia();
        tracksLogged = false;
        lastFpsTime = 0;
        shownFps = 0;
        bytes.set(0);
        opens = 0;
        lastCode = 0;
        lastType = "";
        totalSize = -1;
        rangesOk = false;
        speedMbps = 0;
        lastTickBytes = 0;
        lastTickTime = SystemClock.elapsedRealtime();
        state = "preparing";
        synchronized (LOG) { LOG.clear(); }
        if (uri == null || probedUrl == null || !probedUrl.equals(uri.toString())) {
            synchronized (PROBE) { PROBE.clear(); }
        }
        if (uri != null && NetCompat.isHttp(uri)) {
            log("Open " + shorten(uri.toString()));
        }
    }

    // ---------------------------------------------------------------- network events

    public static final TransferListener TRANSFER_LISTENER = new TransferListener() {
        @Override
        public void onTransferInitializing(DataSource source, DataSpec dataSpec, boolean isNetwork) { }

        @Override
        public void onTransferStart(DataSource source, DataSpec dataSpec, boolean isNetwork) {
            if (!isNetwork) return;
            opens++;
            int code = 0;
            if (source instanceof HttpDataSource) {
                try { code = ((HttpDataSource) source).getResponseCode(); } catch (Throwable ignored) { }
            }
            lastCode = code;
            Uri finalUri = null;
            try { finalUri = source.getUri(); } catch (Throwable ignored) { }
            if (finalUri != null && finalUri.getHost() != null) lastHost = finalUri.getHost();
            try {
                Map<String, List<String>> headers = source.getResponseHeaders();
                String ct = header(headers, "Content-Type");
                if (ct != null) lastType = ct;
                String cr = header(headers, "Content-Range");
                if (cr != null && cr.contains("/")) {
                    try { totalSize = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim()); } catch (NumberFormatException ignored) { }
                    rangesOk = true;
                } else if (dataSpec.position == 0) {
                    String cl = header(headers, "Content-Length");
                    if (cl != null) try { totalSize = Long.parseLong(cl.trim()); } catch (NumberFormatException ignored) { }
                }
            } catch (Throwable ignored) { }
            if (opens <= 3 || code < 200 || code >= 300) {
                String redirected = (finalUri != null && media != null && finalUri.getHost() != null
                        && !finalUri.getHost().equals(media.getHost())) ? " via " + finalUri.getHost() : "";
                log("Conn #" + opens + ": HTTP " + code + " at " + mb(dataSpec.position) + redirected);
            }
        }

        @Override
        public void onBytesTransferred(DataSource source, DataSpec dataSpec, boolean isNetwork, int bytesTransferred) {
            if (isNetwork) bytes.addAndGet(bytesTransferred);
        }

        @Override
        public void onTransferEnd(DataSource source, DataSpec dataSpec, boolean isNetwork) { }
    };

    private static String header(Map<String, List<String>> headers, String name) {
        if (headers == null) return null;
        for (Map.Entry<String, List<String>> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name) && e.getValue() != null && !e.getValue().isEmpty()) {
                return e.getValue().get(0);
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- player events

    /** Called from PlayerActivity right after the player is created. */
    public static void onPlayerCreated() {
        ExoPlayer p = PlayerActivity.player;
        if (p != null) {
            p.addListener(PLAYER_LISTENER);
            p.addAnalyticsListener(ANALYTICS);
            TrackPrefs.applyParams(p);
            if (activity instanceof PlayerActivity) Decoder.onPlayerCreated((PlayerActivity) activity, p);
            if (activity instanceof PlayerActivity) {
                SubtitleFit.attach((PlayerActivity) activity);
                PlayerActivity pa = (PlayerActivity) activity;
            }
            if (isNetworkMedia()) {
                try { p.setWakeMode(C.WAKE_MODE_NETWORK); } catch (Throwable ignored) { }   // Wi-Fi high-perf lock while playing
            }
        }
    }

    private static volatile String videoDecoder = "";
    private static volatile String audioDecoder = "";

    static long currentSize() {
        return totalSize;
    }

    static String videoDecoderName() {
        String v = videoDecoder;
        int i = v.indexOf(" (");
        return i > 0 ? v.substring(0, i) : v;
    }

    static String decoderKind(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.contains("ffmpeg") || n.contains("dav1d") || n.contains("libgav1") || n.startsWith("lib")) return "SW app";
        if (n.startsWith("c2.android.") || n.startsWith("omx.google.") || n.contains(".sw.")) return "SW";
        return "HW";
    }

    private static final AnalyticsBase ANALYTICS = new AnalyticsBase() {
        @Override
        public void onVideoDecoderInitialized(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime t, String name, long a, long b) {
            videoDecoder = name + " (" + decoderKind(name) + ")";
            log("Video decoder: " + videoDecoder);
        }

        @Override
        public void onAudioDecoderInitialized(androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime t, String name, long a, long b) {
            audioDecoder = name;
        }
    };

    private static final ListenerBase PLAYER_LISTENER = new ListenerBase() {
        @Override
        public void onPlaybackStateChanged(int s) {
            switch (s) {
                case Player.STATE_BUFFERING: state = "buffering"; break;
                case Player.STATE_READY: state = "ready"; break;
                case Player.STATE_ENDED: state = "ended"; break;
                default: state = "idle";
            }
            if (isNetworkMedia()) log("State: " + state);
        }

        @Override
        public void onTracksChanged(androidx.media3.common.Tracks tracks) {
            logTracks(tracks);
            if (activity instanceof PlayerActivity) Decoder.onTracks(tracks, (PlayerActivity) activity);
            TrackPrefs.onTracks(tracks, activity);
        }

        @Override
        public void onVideoSizeChanged(androidx.media3.common.VideoSize size) {
            HANDLER.post(new Runnable() { @Override public void run() { SubtitleFit.update(); } });
            if (activity instanceof PlayerActivity) AspectModes.onVideoSize((PlayerActivity) activity);
        }

        @Override
        public void onRenderedFirstFrame() {
            Decoder.onRenderedFirstFrame(activity instanceof PlayerActivity ? (PlayerActivity) activity : null);
            FormatBadge.show(activity);
            if (activity instanceof PlayerActivity) ResumePoints.onFirstFrame((PlayerActivity) activity);
        }

        @Override
        public void onPositionDiscontinuity(Player.PositionInfo oldPos, Player.PositionInfo newPos, int reason) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK && isNetworkMedia()) {
                long s = newPos.positionMs / 1000;
                log(String.format(Locale.US, "Seek → %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60));
            }
        }

        @Override
        public void onIsPlayingChanged(boolean playing) {
            if (activity instanceof PlayerActivity) Decoder.onIsPlayingChanged(playing, (PlayerActivity) activity);
            if (!playing && activity != null) ResumePoints.save(activity);   // paused: remember where
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (activity instanceof PlayerActivity) Decoder.onError(error, (PlayerActivity) activity);
            state = "error";
            log("ERROR " + error.getErrorCodeName());
            log(describe(error.getCause() != null ? error.getCause() : error));
            shown = true;   // show what went wrong
        }
    };

    private static boolean tracksLogged;

    private static void logTracks(androidx.media3.common.Tracks tracks) {
        if (tracksLogged || tracks == null || tracks.isEmpty()) return;
        tracksLogged = true;
        // "Tracks: dolby-vision ac3 truehd · subtitles ×27" (same kinds counted, not repeated)
        java.util.LinkedHashMap<String, Integer> kinds = new java.util.LinkedHashMap<>();
        for (androidx.media3.common.Tracks.Group g : tracks.getGroups()) {
            for (int i = 0; i < g.length; i++) {
                Format f = g.getTrackFormat(i);
                String m = f.sampleMimeType == null ? "?" : f.sampleMimeType.substring(f.sampleMimeType.indexOf('/') + 1);
                if ("x-media3-cues".equals(m) || g.getType() == C.TRACK_TYPE_TEXT) m = "subtitles";
                if (!g.isTrackSupported(i)) m += " (✗)";
                Integer n = kinds.get(m);
                kinds.put(m, n == null ? 1 : n + 1);
            }
        }
        StringBuilder sb = new StringBuilder("Tracks:");
        for (Map.Entry<String, Integer> e : kinds.entrySet()) {
            sb.append(' ').append(e.getKey());
            if (e.getValue() > 1) sb.append(" ×").append(e.getValue());
            sb.append(',');
        }
        sb.setLength(sb.length() - 1);
        log(sb.toString());
    }

    // ---------------------------------------------------------------- overlay

    /** Called once from PlayerActivity.onCreate (via UrlButton.add). */
    public static void attach(Activity a) {
        try {
            activity = a;
            TextView tv = new TextView(a);
            tv.setTypeface(Typeface.DEFAULT);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            tv.setLineSpacing(0, 1.1f);
            tv.setTextColor(0xFFFFFFFF);
            tv.setBackgroundColor(0xB0000000);
            int pad = dp(a, 8);
            tv.setPadding(pad, pad / 2, pad, pad / 2);
            tv.setVisibility(View.GONE);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    shown = false;
                    v.setVisibility(View.GONE);
                }
            });
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
            lp.topMargin = dp(a, 56);
            lp.leftMargin = dp(a, 12);
            lp.rightMargin = dp(a, 12);
            a.addContentView(tv, lp);
            view = tv;
            HANDLER.removeCallbacks(TICK);
            HANDLER.post(TICK);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /** The overlay button (ⓘ, left of settings) toggles the overlay. */
    public static void toggle() {
        shown = !shown;
        // one refresh loop only: restart it (posting again added another loop every time ⓘ was pressed)
        HANDLER.removeCallbacks(TICK);
        HANDLER.post(TICK);
    }


    static boolean isShown() {
        return shown && view != null;
    }

    /** Player closed, Home, Recents, exit: the overlay is closed (press ⓘ to open it again). */
    public static void hide() {
        shown = false;
        if (view != null) view.setVisibility(View.GONE);
    }

    private static final Runnable TICK = new Runnable() {
        @Override
        public void run() {
            if (activity == null || activity.isDestroyed()) return;
            if (activity instanceof PlayerActivity) {
                try { Decoder.checkStall((PlayerActivity) activity); } catch (Throwable ignored) { }
            }
            try { ResumePoints.tick(activity); } catch (Throwable ignored) { }
            update();
            // once a second (the TV's CPU is weak; nothing here needs more)
            HANDLER.postDelayed(this, 1000);
        }
    };

    private static boolean isNetworkMedia() {
        try {
            if (activity instanceof PlayerActivity) {
                PlayerActivity pa = (PlayerActivity) activity;
                return pa.mPrefs != null && NetCompat.isHttp(pa.mPrefs.mediaUri);
            }
        } catch (Throwable ignored) { }
        return NetCompat.isHttp(media);
    }

    private static void update() {
        if (view == null) return;
        if (!shown) {
            view.setVisibility(View.GONE);
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long b = bytes.get();
        long dt = now - lastTickTime;
        if (dt >= 1000) {
            double inst = (b - lastTickBytes) * 8.0 / 1_000_000.0 / (dt / 1000.0);
            speedMbps = speedMbps == 0 ? inst : speedMbps * 0.6 + inst * 0.4;
            lastTickBytes = b;
            lastTickTime = now;
        }

        StringBuilder sb = new StringBuilder();
        synchronized (PROBE) {
            for (String p : PROBE) sb.append(p).append('\n');
        }

        if (!isNetworkMedia() && media != null) {
            // local file (USB drive …): how fast it's read
            long lb = ReadAheadDataSource.LOCAL_BYTES.get();
            long tnow = SystemClock.elapsedRealtime();
            if (tnow - lastLocalTime >= 1000) {
                if (lastLocalTime > 0) localMBps = (lb - lastLocalBytes) / 1048576.0 / ((tnow - lastLocalTime) / 1000.0);
                lastLocalBytes = lb;
                lastLocalTime = tnow;
            }
            sb.append(String.format(Locale.US, "Drive: reading %.1f MB/s · %s read", localMBps, mb(lb))).append('\n');
        } else {
        sb.append("Net: ");
        sb.append(lastCode == 0 ? "connecting…" : "HTTP " + lastCode);
        if (!lastHost.isEmpty()) sb.append(" · ").append(lastHost);
        sb.append('\n');
        sb.append("     ").append(opens).append(" conn · ").append(mb(b)).append(" recv · ")
                .append(String.format(Locale.US, "%.1f Mbit/s", speedMbps));
        if (totalSize > 0) sb.append(" · size ").append(mb(totalSize));
        sb.append(rangesOk ? " · seek ok" : "").append('\n');
        if (!lastType.isEmpty()) sb.append("     type ").append(lastType).append('\n');
        }

        ExoPlayer p = PlayerActivity.player;
        if (p != null) {
            Format v = null;
            try { v = p.getVideoFormat(); } catch (Throwable ignored) { }
            if (v != null) {
                sb.append("Video: ").append(v.codecs != null ? v.codecs : v.sampleMimeType)
                        .append(' ').append(v.width).append('x').append(v.height)
                        .append(' ').append(hdr(v.colorInfo));
                int br = v.peakBitrate > 0 ? v.peakBitrate : v.bitrate > 0 ? v.bitrate : v.averageBitrate;
                if (br > 0) {
                    sb.append(String.format(Locale.US, " · needs ~%.0f Mbit/s", br / 1_000_000.0));
                }
                sb.append('\n');
                // Frame rate of the file vs. frames actually shown, and the screen's refresh rate.
                sb.append("FPS: ").append(v.frameRate > 0 ? String.format(Locale.US, "%.3f", v.frameRate) : "?").append(" file");
                try {
                    androidx.media3.exoplayer.DecoderCounters dc = p.getVideoDecoderCounters();
                    if (dc != null) {
                        dc.ensureUpdated();
                        long nowF = SystemClock.elapsedRealtime();
                        if (nowF - lastFpsTime >= 1000) {
                            int rendered = dc.renderedOutputBufferCount;
                            if (lastFpsTime > 0 && rendered >= lastRendered) {
                                shownFps = (rendered - lastRendered) * 1000.0 / (nowF - lastFpsTime);
                            }
                            lastRendered = rendered;
                            lastFpsTime = nowF;
                        }
                        sb.append(String.format(Locale.US, " · %.1f shown · %d dropped", shownFps, dc.droppedBufferCount));
                    }
                } catch (Throwable ignored) { }
                sb.append('\n');
            }
            sb.append("Display: ").append(displayInfo()).append('\n');
            long buffered = 0;
            try { buffered = p.getTotalBufferedDuration(); } catch (Throwable ignored) { }
            if (!videoDecoder.isEmpty()) sb.append("Decoder: ").append(videoDecoder).append('\n');
            try {
                String u = PlayerActivity.player.getCurrentMediaItem() != null && PlayerActivity.player.getCurrentMediaItem().localConfiguration != null
                        ? PlayerActivity.player.getCurrentMediaItem().localConfiguration.uri.toString() : null;
                if (Decoder.lastSwitch != null && u != null && u.equals(Decoder.lastSwitchUri)) {
                    sb.append("     ").append(Decoder.lastSwitch).append('\n');   // stays visible, unlike the log
                }
            } catch (Throwable ignored) { }
            try {
                String usb = UsbBuffer.status(activity, p.getCurrentPosition(), p.getDuration());
                if (usb != null) sb.append("USB buffer: ").append(usb).append('\n');
            } catch (Throwable ignored) { }
            String dv78 = Dovi78.status();
            if (dv78 != null) sb.append(dv78).append('\n');
            String ivtc = Ivtc.status();
            if (ivtc != null) sb.append("IVTC: ").append(ivtc).append('\n');
            long pos = 0;
            try { pos = p.getCurrentPosition() / 1000; } catch (Throwable ignored) { }
            sb.append("Player: ").append(state)
                    .append(String.format(Locale.US, " · at %d:%02d:%02d", pos / 3600, (pos / 60) % 60, pos % 60))
                    .append(" · buffer ").append(buffered / 1000).append(" s");
            long ahead = ReadAheadDataSource.ahead();
            if (ahead > 0) {
                // what's downloaded but not yet unpacked, in time at this video's bitrate
                Format vf = null;
                try { vf = p.getVideoFormat(); } catch (Throwable ignored) { }
                long dur = p.getDuration();
                long secs = totalSize > 0 && dur > 0 ? ahead * (dur / 1000) / totalSize : -1;
                sb.append(" + ").append(mb(ahead)).append(UsbBuffer.current() != null ? " in memory from the drive" : " downloaded ahead");
                if (secs > 0) sb.append(" (~").append(secs).append(" s)");
                sb.append(" of ").append(ReadAheadDataSource.capacity() / (1024 * 1024)).append(" MB");
            }
            sb.append('\n');
        }

        synchronized (LOG) {
            for (String l : LOG) sb.append(l).append('\n');
        }
        sb.append("(tap to hide · ⓘ button to show)");
        if (activity != null) sb.append('\n').append(TvTune.report(activity));
        view.setText(aligned(sb.toString()));
        view.setVisibility(View.VISIBLE);
    }

    private static final java.util.regex.Pattern TIME_LINE = java.util.regex.Pattern.compile("^(\\d\\d:\\d\\d:\\d\\d) (.*)$");

    /**
     * Two columns: the label ("Net:", "Decoder:", the time of a log line) on the left, the text
     * in a column next to it. Continuation lines and wrapped lines line up with that column.
     */
    private static CharSequence aligned(String text) {
        String[] lines = text.split("\n", -1);
        String[][] rows = new String[lines.length][];
        float labelW = 0;
        android.text.TextPaint paint = view.getPaint();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i];
            String label, value;
            java.util.regex.Matcher m = TIME_LINE.matcher(l);
            int c = l.indexOf(": ");
            if (!l.isEmpty() && Character.isWhitespace(l.charAt(0))) {
                label = "";
                value = l.trim();
            } else if (m.matches()) {
                label = m.group(1);
                value = m.group(2);
            } else if (c > 0 && c <= 12 && l.substring(0, c).indexOf(' ') < 0) {
                label = l.substring(0, c + 1);
                value = l.substring(c + 2);
            } else {
                label = "";
                value = l;
            }
            rows[i] = new String[] {label, value};
            labelW = Math.max(labelW, paint.measureText(label));
        }
        int col = (int) Math.ceil(labelW) + dp(activity, 10);
        android.text.SpannableStringBuilder out = new android.text.SpannableStringBuilder();
        for (int i = 0; i < rows.length; i++) {
            int start = out.length();
            if (!rows[i][0].isEmpty()) {
                out.append(rows[i][0]);
                out.setSpan(new android.text.style.ForegroundColorSpan(0xFFB0B0B0), start, out.length(),
                        android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            out.append('\t').append(rows[i][1]);
            if (i < rows.length - 1) out.append('\n');
            int end = out.length();
            out.setSpan(new android.text.style.TabStopSpan.Standard(col), start, end, android.text.Spanned.SPAN_PARAGRAPH);
            out.setSpan(new android.text.style.LeadingMarginSpan.Standard(0, col), start, end, android.text.Spanned.SPAN_PARAGRAPH);
        }
        return out;
    }

    private static long lastLocalBytes, lastLocalTime;
    private static double localMBps;

    private static long lastFpsTime;
    private static int lastRendered;
    private static double shownFps;

    /** Current screen refresh rate (what frame-rate matching switched to) and the panel's maximum. */
    private static String displayInfo() {
        try {
            android.view.Display d = android.os.Build.VERSION.SDK_INT >= 30
                    ? activity.getDisplay()
                    : activity.getWindowManager().getDefaultDisplay();
            if (d == null) return "?";
            float now = d.getRefreshRate();
            float max = now;
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                for (android.view.Display.Mode m : d.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
            }
            return String.format(Locale.US, "%.0f Hz now (max %.0f Hz)", now, max);
        } catch (Throwable t) {
            return "?";
        }
    }

    private static String hdr(ColorInfo c) {
        if (c == null) return "SDR";
        switch (c.colorTransfer) {
            case C.COLOR_TRANSFER_ST2084: return "HDR10/PQ";
            case C.COLOR_TRANSFER_HLG: return "HLG";
            default: return "SDR";
        }
    }

    static String mb(long b) {
        if (b < 0) return "?";
        if (b >= 1_000_000_000L) return String.format(Locale.US, "%.2f GB", b / 1e9);
        return String.format(Locale.US, "%.1f MB", b / 1e6);
    }

    static String shorten(String s) {
        return s.length() > 70 ? s.substring(0, 67) + "…" : s;
    }

    private static int dp(Activity a, int dp) {
        return (int) (dp * a.getResources().getDisplayMetrics().density + 0.5f);
    }
}
