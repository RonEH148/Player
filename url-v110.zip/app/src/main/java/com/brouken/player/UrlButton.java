package com.brouken.player;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

/** The 🔗 button in the player's control bar. Called from PlayerActivity.onCreate. */
public final class UrlButton {

    private static final int STYLE_BUTTON_BOTTOM = R.style.ExoStyledControls_Button_Bottom;

    private UrlButton() {}

    /** HW+ / HW / SW toggle; reloads the video at the same position. */
    private static void addDecoderButton(final Activity activity, LinearLayout controls) {
        // Same style as the icon buttons, so it gets the same highlight when focused on a TV remote
        final android.widget.TextView t = new android.widget.TextView(activity, null, 0, STYLE_BUTTON_BOTTOM);
        t.setFocusable(true);
        t.setClickable(true);
        if (t.getBackground() == null) {
            android.util.TypedValue tv = new android.util.TypedValue();
            if (activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
                t.setBackgroundResource(tv.resourceId);
            }
        }
        t.setText(Decoder.name(Decoder.get(activity)));
        Decoder.button = t;
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setGravity(android.view.Gravity.CENTER);
        int pad = (int) (12 * activity.getResources().getDisplayMetrics().density);
        t.setPadding(pad, 0, pad, 0);
        t.setMinWidth((int) (48 * activity.getResources().getDisplayMetrics().density));
        t.setContentDescription("Decoder");
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mode = Decoder.cycle(activity);
                t.setText(Decoder.name(mode));
                android.widget.Toast.makeText(activity, "Decoder for this video: " + Decoder.name(mode), android.widget.Toast.LENGTH_SHORT).show();
                if (activity instanceof PlayerActivity) {
                    PlayerActivity pa = (PlayerActivity) activity;
                    if (PlayerActivity.player != null) {
                        pa.releasePlayer();
                        pa.initializePlayer();
                    }
                }
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!(activity instanceof PlayerActivity)) return true;
                PlayerActivity pa = (PlayerActivity) activity;
                Decoder.forget(pa);
                t.setText(Decoder.name(Decoder.get(activity)));
                android.widget.Toast.makeText(activity, "Decoder reset. Checking this video again.", android.widget.Toast.LENGTH_SHORT).show();
                if (PlayerActivity.player != null) {
                    pa.releasePlayer();
                    pa.initializePlayer();
                }
                return true;
            }
        });
        controls.addView(t, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
    }

    /** AUTO / IVTC / DEINT / OFF: telecine handling for this video, applied instantly. */
    private static void addIvtcButton(final Activity activity, LinearLayout controls) {
        final android.widget.TextView t = new android.widget.TextView(activity, null, 0, STYLE_BUTTON_BOTTOM);
        t.setFocusable(true);
        t.setClickable(true);
        if (t.getBackground() == null) {
            android.util.TypedValue tv = new android.util.TypedValue();
            if (activity.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
                t.setBackgroundResource(tv.resourceId);
            }
        }
        t.setText(Ivtc.label());
        Ivtc.button = t;
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setGravity(android.view.Gravity.CENTER);
        int pad = (int) (12 * activity.getResources().getDisplayMetrics().density);
        t.setPadding(pad, 0, pad, 0);
        t.setMinWidth((int) (48 * activity.getResources().getDisplayMetrics().density));
        t.setContentDescription("Telecine and deinterlacing");
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activity instanceof PlayerActivity) Ivtc.cycle((PlayerActivity) activity);
            }
        });
        controls.addView(t, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT));
    }

    /** Saved links: your named list of video links (play, copy, rename, share, delete). */
    private static void addSavedLinksButton(final Activity activity, LinearLayout controls) {
        ImageButton b = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
        b.setImageResource(R.drawable.ic_bookmarks_24dp);
        b.setContentDescription("Saved links");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity, SavedLinksActivity.class);
                if (activity instanceof PlayerActivity) {
                    PlayerActivity pa = (PlayerActivity) activity;
                    if (pa.mPrefs != null && pa.mPrefs.mediaUri != null) {
                        String u = pa.mPrefs.mediaUri.toString();
                        if (PasteUrlActivity.isValid(u)) {
                            i.putExtra(SavedLinksActivity.EXTRA_CURRENT, u);
                            if (pa.apiTitle != null) i.putExtra(SavedLinksActivity.EXTRA_CURRENT_NAME, pa.apiTitle);
                        }
                    }
                }
                activity.startActivity(i);
            }
        });
        controls.addView(b);
    }

    /** ⟳ Refresh: reopen the current video at the same position (frozen / not responding). */
    private static void addRefreshButton(final Activity activity, LinearLayout controls) {
        ImageButton b = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
        int icon = R.drawable.ic_refresh_24dp;
        if (icon != 0) b.setImageResource(icon);
        b.setContentDescription("Refresh");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (activity instanceof PlayerActivity && ((PlayerActivity) activity).mPrefs != null
                        && ((PlayerActivity) activity).mPrefs.mediaUri != null) {
                    android.widget.Toast.makeText(activity, "Refreshing…", android.widget.Toast.LENGTH_SHORT).show();
                    Lifecycle.refresh((PlayerActivity) activity);
                }
            }
        });
        controls.addView(b);
    }

    /** ⓘ: shows/hides the info overlay (network, decoder, telecine…). Placed left of the settings button. */
    public static void addOverlayButton(final Activity activity, LinearLayout controls) {
        try {
            ImageButton b = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
            b.setImageResource(R.drawable.ic_info_24dp);
            b.setContentDescription("Info overlay");
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Diag.toggle();
                }
            });
            controls.addView(b);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void add(final Activity activity, LinearLayout controls) {
        Perf.init(activity);
        try {
            ImageButton button = new ImageButton(activity, null, 0, STYLE_BUTTON_BOTTOM);
            int icon = R.drawable.ic_link_24dp;
            if (icon != 0) button.setImageResource(icon);
            button.setContentDescription("Open link");
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClassName(activity, "com.brouken.player.PasteUrlActivity");
                    intent.putExtra("dialog", true);
                    activity.startActivity(intent);
                }
            });
            controls.addView(button);
            addSavedLinksButton(activity, controls);
            addDecoderButton(activity, controls);
            addIvtcButton(activity, controls);
            addRefreshButton(activity, controls);
        } catch (Throwable t) {
            t.printStackTrace();
        }
        Diag.attach(activity);
        Updater.autoCheck(activity);
    }
}
