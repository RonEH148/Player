package com.brouken.player;

import android.view.View;
import android.view.ViewGroup;

import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.SubtitleView;

/**
 * The subtitle layer sits inside the video frame, so subtitles are placed and sized relative to
 * the picture exactly as authored. When the picture is bigger than the screen (Crop), the layer
 * is limited to the visible part so nothing ends up off screen.
 */
final class SubtitleFit {

    private SubtitleFit() {}

    private static PlayerActivity activity;
    private static SubtitleView view;

    private static final View.OnLayoutChangeListener LAYOUT = new View.OnLayoutChangeListener() {
        @Override
        public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
            if (l != ol || t != ot || r != or || b != ob) v.post(SubtitleFit::update);
        }
    };

    static void attach(PlayerActivity a) {
        try {
            if (a.playerView == null) return;
            SubtitleView sv = a.playerView.getSubtitleView();
            if (sv == null) return;
            if (sv == view && activity == a) { update(); return; }
            activity = a;
            view = sv;
            ((View) sv.getParent()).addOnLayoutChangeListener(LAYOUT);
            a.playerView.addOnLayoutChangeListener(LAYOUT);
            update();
        } catch (Throwable t) {
            Diag.log("Subtitles: " + t);
        }
    }

    /**
     * Plain text subtitles (SRT, WebVTT, MP4 text) have no picture position of their own. They get
     * the whole height of the screen, so on a letterboxed movie they sit in the black bar below the
     * picture – whether the bars are part of the video (most remuxes, 16:9 with bars) or added by
     * the player (most WEB-DLs, cropped to 2.39:1). Before, only the first kind ended up in the
     * bars. Picture subtitles (PGS, VobSub) and styled ones (ASS, TTML) stay on the picture, where
     * they were authored. When the controls are showing, subtitles move up above the time bar.
     */
    private static final float BOTTOM = 0.012f;   // like mpv's sub-margin-y 22 of 720

    private static ExoPlayer watched;
    private static final Player.Listener TRACKS = new ListenerBase() {
        @Override
        public void onTracksChanged(Tracks tracks) {
            SubtitleView sv = view;
            if (sv != null) sv.post(SubtitleFit::update);
        }
    };

    static void update() {
        SubtitleView sv = view;
        PlayerActivity a = activity;
        if (sv == null || a == null || a.playerView == null) return;
        try {
            ExoPlayer pl = PlayerActivity.player;
            if (pl != watched) {
                if (watched != null) watched.removeListener(TRACKS);
                watched = pl;
                if (pl != null) pl.addListener(TRACKS);
            }
            View frame = (View) sv.getParent();
            int[] f = new int[2];
            int[] p = new int[2];
            frame.getLocationInWindow(f);
            a.playerView.getLocationInWindow(p);
            int pTop = p[1], pBottom = p[1] + a.playerView.getHeight();
            int fTop = f[1], fBottom = f[1] + frame.getHeight();
            int left = Math.max(0, p[0] - f[0]);
            int right = Math.max(0, (f[0] + frame.getWidth()) - (p[0] + a.playerView.getWidth()));
            int top, bottom;
            boolean plain = plainText(pl);
            if (plain) {
                // the full height of the screen: negative margins reach into the player's black bars
                top = pTop - fTop;
                bottom = fBottom - pBottom;
            } else {
                top = Math.max(0, pTop - fTop);
                bottom = Math.max(0, fBottom - pBottom);
            }
            if (plain && (top < 0 || bottom < 0)) {
                if (frame instanceof ViewGroup) ((ViewGroup) frame).setClipChildren(false);
                a.playerView.setClipChildren(false);
            }
            ViewGroup.LayoutParams lp = sv.getLayoutParams();
            if (lp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
                if (m.leftMargin != left || m.topMargin != top || m.rightMargin != right || m.bottomMargin != bottom) {
                    m.setMargins(left, top, right, bottom);
                    sv.setLayoutParams(m);
                }
            }
            // above the time bar while the controls show (same height, so the text keeps its size)
            float pad = BOTTOM;
            int layerTop = fTop + top, layerBottom = fBottom - bottom, h = layerBottom - layerTop;
            View bar = a.findViewById(R.id.exo_progress);
            if (h > 0 && bar != null && a.playerView.isControllerFullyVisible() && bar.isShown()) {
                int[] b = new int[2];
                bar.getLocationInWindow(b);
                int limit = b[1] - Math.round(4 * a.getResources().getDisplayMetrics().density);
                if (limit < layerBottom) pad = Math.max(BOTTOM, (layerBottom - limit) / (float) h);
            }
            sv.setBottomPaddingFraction(Math.min(pad, 0.5f));
        } catch (Throwable ignored) { }
    }

    private static boolean plainText(Player pl) {
        if (pl == null) return false;
        try {
            for (Tracks.Group g : pl.getCurrentTracks().getGroups()) {
                if (g.getType() != C.TRACK_TYPE_TEXT || !g.isSelected()) continue;
                for (int i = 0; i < g.length; i++) {
                    if (!g.isTrackSelected(i)) continue;
                    Format fm = g.getTrackFormat(i);
                    String mime = fm.sampleMimeType;
                    if (MimeTypes.APPLICATION_MEDIA3_CUES.equals(mime) && fm.codecs != null) mime = fm.codecs;
                    return MimeTypes.APPLICATION_SUBRIP.equals(mime) || MimeTypes.TEXT_VTT.equals(mime)
                            || MimeTypes.APPLICATION_MP4VTT.equals(mime) || MimeTypes.APPLICATION_TX3G.equals(mime);
                }
            }
        } catch (Throwable ignored) { }
        return false;
    }
}
