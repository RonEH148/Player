package com.brouken.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Leaving the player stops all downloads. Coming back (from Settings, the file picker or the home
 * screen) simply continues the same video. Back → "Exit player?" → Exit clears everything about the
 * video, so the player opens empty next time.
 */
public final class Lifecycle {

    private Lifecycle() {}

    private static final String KEY_FRESH = "freshStartUrl";
    private static String sessionUri;

    /** Hooked in PlayerActivity.onStop(), after the player was released. */
    public static void onStop(PlayerActivity a) {
        ReadAheadDataSource.stopAll();
    }

    /** Replaces the initializePlayer() call in PlayerActivity.onStart(). */
    public static void onStart(final PlayerActivity a) {
        a.initializePlayer();
    }

    /** Back pressed while a video is open: ask, then clear everything. Returns true if handled. */
    public static boolean onBack(final PlayerActivity a) {
        if (a.mPrefs == null || a.mPrefs.mediaUri == null) return false;
        new AlertDialog.Builder(a)
                .setTitle("Exit player?")
                .setPositiveButton("Exit", (d, w) -> exit(a))
                .setNegativeButton("Cancel", null)
                .show();
        return true;
    }

    static void exit(PlayerActivity a) {
        ReadAheadDataSource.stopAll();
        try {
            if (PlayerActivity.player != null) a.releasePlayer();
        } catch (Throwable ignored) { }
        try {
            a.mPrefs.updatePosition(0L);
            a.mPrefs.mediaUri = null;
            a.mPrefs.mediaType = null;
            a.mPrefs.updateSubtitle(null);
            prefs(a).edit().remove("mediaUri").remove("mediaType").remove(KEY_FRESH).apply();
            a.apiTitle = null;
        } catch (Throwable ignored) { }
        Decoder.clearOverride(a);
        Decoder.systemBrightness(a);
        sessionUri = null;
        StreamHeaders.clear();
        Diag.log("Exit: cleared");
        a.finish();
    }

    /** A link pasted again starts from the beginning. */
    public static void markFreshStart(Context c, String url) {
        prefs(c).edit().putString(KEY_FRESH, url).apply();
    }

    /**
     * Refresh: drop every connection and the decoder, then reopen the video at the current
     * position. For a frozen video, and used automatically after a load failure.
     */
    public static void refresh(final PlayerActivity a) {
        try {
            if (PlayerActivity.player != null) a.releasePlayer();   // saves the current position
        } catch (Throwable ignored) { }
        ReadAheadDataSource.stopAll();
        Diag.log("Reopening at the same position");
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            if (!a.isFinishing() && !a.isDestroyed()) a.initializePlayer();
        }, 300);
    }

    /**
     * Called before every player start. A newly opened video starts at 0:00; reopening the same
     * video (decoder switch, refresh, coming back from Settings) keeps the position.
     */
    static void beginSession(PlayerActivity a) {
        try {
            if (a.mPrefs == null || a.mPrefs.mediaUri == null) return;
            String uri = a.mPrefs.mediaUri.toString();
            boolean fresh = uri.equals(prefs(a).getString(KEY_FRESH, null));
            if (fresh) prefs(a).edit().remove(KEY_FRESH).apply();
            if (fresh || !uri.equals(sessionUri)) {
                a.mPrefs.updatePosition(0L);
                sessionUri = uri;
                autoRetried = false;
            }
            else if (RangeSupport.isLinear(a.mPrefs.mediaUri) && a.mPrefs.getPosition() > 0) {
                // this server can't jump into the middle of the file; reopen from the start
                Diag.log("Server can't seek: reopening from the beginning");
                a.mPrefs.updatePosition(0L);
            }
        } catch (Throwable ignored) { }
    }

    private static boolean autoRetried;

    /**
     * Network load failed (Just Player would just stop and show ▶ that does nothing).
     * Server ignores Range → reopen in linear mode; any other first failure → reopen once.
     * Returns true if handled.
     */
    static boolean onSourceError(final PlayerActivity a, Throwable error) {
        try {
            if (a.mPrefs == null || !NetCompat.isHttp(a.mPrefs.mediaUri)) return false;
            RangeSupport.RangeIgnoredException ri = RangeSupport.find(error);
            if (ri != null && !ri.firstTime) {
                // linear server and the position is too far to read forward: start over
                android.widget.Toast.makeText(a, "This server can't jump there – playing from the start", android.widget.Toast.LENGTH_LONG).show();
                a.mPrefs.updatePosition(0L);
                refresh(a);
                return true;
            }
            if (ri != null || !autoRetried) {
                if (ri == null) autoRetried = true;
                Diag.log(ri != null ? "Server can't seek → reopening in linear mode" : "Load failed → reopening once");
                refresh(a);
                return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    /** Kept for PasteUrlActivity. */
    public static void clear(Context c) { }

    private static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }
}
