package com.phlox.tvwebbrowser.activity.main

import android.app.Activity
import android.app.Dialog
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R

/**
 * Lumen's ⋮ menu (look taken from Wisp's menu sheet, made for the remote): a card at the top
 * right with a row of navigation buttons, then the page's switches and the browser's places.
 * Built in code; every entry is focusable, OK runs it.
 */
object LumenMenu {

    class Button(val icon: Int, val label: String, val enabled: Boolean = true, val onClick: () -> Unit)

    /** [state]: shown on the right ("On", "3 blocked"); [active]: highlighted (a switch that is on). */
    class Item(val icon: Int, val label: String, val state: String? = null, val active: Boolean = false,
               val onClick: () -> Unit)

    private fun dp(a: Activity, v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, a.resources.displayMetrics).toInt()

    private fun focusBackground(a: Activity, radius: Float): StateListDrawable {
        fun shape(fill: Int, stroke: Int?) = GradientDrawable().apply {
            cornerRadius = radius
            setColor(fill)
            if (stroke != null) setStroke(dp(a, 2f), stroke)
        }
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_focused),
            shape(ContextCompat.getColor(a, R.color.wisp_accent_soft), ContextCompat.getColor(a, R.color.wisp_accent)))
        s.addState(intArrayOf(android.R.attr.state_pressed), shape(ContextCompat.getColor(a, R.color.wisp_accent_soft), null))
        s.addState(intArrayOf(), shape(0x00000000, null))
        return s
    }

    fun show(a: Activity, title: String?, top: List<Button>, groups: List<List<Item>>): Dialog {
        val text = ContextCompat.getColor(a, R.color.wisp_text)
        val secondary = ContextCompat.getColor(a, R.color.wisp_text_secondary)
        val icon = ContextCompat.getColor(a, R.color.wisp_icon)
        val accent = ContextCompat.getColor(a, R.color.wisp_accent)
        val divider = ContextCompat.getColor(a, R.color.wisp_divider)

        val dialog = Dialog(a)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val card = LinearLayout(a)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(a, 10f), dp(a, 10f), dp(a, 10f), dp(a, 10f))
        card.background = GradientDrawable().apply {
            cornerRadius = dp(a, 18f).toFloat()
            setColor(ContextCompat.getColor(a, R.color.wisp_sheet))
        }

        if (!title.isNullOrBlank()) {
            val t = TextView(a)
            t.text = title
            t.textSize = 13f
            t.setTextColor(secondary)
            t.setSingleLine()
            t.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            t.setPadding(dp(a, 10f), dp(a, 2f), dp(a, 10f), dp(a, 8f))
            card.addView(t)
        }

        var first: View? = null
        //navigation: one row of round buttons
        if (top.isNotEmpty()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (b in top) {
                val iv = ImageView(a)
                iv.setImageResource(b.icon)
                iv.setColorFilter(icon)
                iv.alpha = if (b.enabled) 1f else 0.35f
                iv.contentDescription = b.label
                iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
                iv.isFocusable = b.enabled
                iv.isClickable = b.enabled
                iv.background = focusBackground(a, dp(a, 24f).toFloat())
                iv.setPadding(dp(a, 12f), dp(a, 12f), dp(a, 12f), dp(a, 12f))
                iv.setOnClickListener {
                    dialog.dismiss()
                    b.onClick()
                }
                val lp = LinearLayout.LayoutParams(0, dp(a, 52f), 1f)
                row.addView(iv, lp)
                if (first == null && b.enabled) first = iv
            }
            card.addView(row)
        }

        fun addGroup(col: LinearLayout, group: List<Item>, divider0: Boolean) {
            if (divider0) {
                val line = View(a)
                line.setBackgroundColor(divider)
                val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 1f))
                llp.setMargins(dp(a, 6f), dp(a, 6f), dp(a, 6f), dp(a, 6f))
                col.addView(line, llp)
            }
            for (item in group) {
                val r = LinearLayout(a)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.isFocusable = true
                r.isClickable = true
                r.background = focusBackground(a, dp(a, 12f).toFloat())
                r.setPadding(dp(a, 12f), dp(a, 7f), dp(a, 12f), dp(a, 7f))
                val iv = ImageView(a)
                iv.setImageResource(item.icon)
                iv.setColorFilter(if (item.active) accent else icon)
                r.addView(iv, LinearLayout.LayoutParams(dp(a, 22f), dp(a, 22f)))
                val label = TextView(a)
                label.text = item.label
                label.maxLines = 1
                label.ellipsize = android.text.TextUtils.TruncateAt.END
                label.textSize = 16f
                label.setTextColor(text)
                if (item.active) label.setTypeface(label.typeface, Typeface.BOLD)
                label.setPadding(dp(a, 14f), 0, dp(a, 8f), 0)
                r.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                if (!item.state.isNullOrEmpty()) {
                    val s = TextView(a)
                    s.text = item.state
                    s.textSize = 13f
                    s.maxLines = 1
                    s.setTextColor(if (item.active) text else secondary)
                    r.addView(s)
                }
                r.setOnClickListener {
                    dialog.dismiss()
                    item.onClick()
                }
                col.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                if (first == null) first = r
            }
        }

        //a wide screen (TV, tablet) shows the page's entries next to the rest, so the whole menu
        //fits on the screen; narrow screens get one column that scrolls
        val metrics = a.resources.displayMetrics
        val nonEmpty = groups.filter { it.isNotEmpty() }
        val twoColumns = metrics.widthPixels / metrics.density >= 720f && nonEmpty.size >= 3
        if (twoColumns) {
            val cols = LinearLayout(a)
            cols.orientation = LinearLayout.HORIZONTAL
            val left = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            val right = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            addGroup(left, nonEmpty[0], true)
            nonEmpty.drop(1).forEach { addGroup(right, it, true) }
            cols.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val gap = View(a)
            cols.addView(gap, LinearLayout.LayoutParams(dp(a, 8f), 1))
            cols.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(cols)
        } else {
            nonEmpty.forEach { addGroup(card, it, true) }
        }

        //never taller than the screen below the bar (TVs are 540 dp tall): the rest scrolls
        val maxHeight = a.resources.displayMetrics.heightPixels - dp(a, 52f) - dp(a, 16f)
        val scroll = object : ScrollView(a) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxHeight, View.MeasureSpec.AT_MOST))
            }
        }
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(card)
        dialog.setContentView(scroll)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(0))
            w.setGravity(Gravity.TOP or Gravity.END)
            val lp = w.attributes
            lp.width = dp(a, if (twoColumns) 640f else 380f)
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.x = dp(a, 14f)
            lp.y = dp(a, 52f)
            lp.dimAmount = 0.35f
            w.attributes = lp
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        }
        dialog.show()
        first?.requestFocus()
        return dialog
    }
}
