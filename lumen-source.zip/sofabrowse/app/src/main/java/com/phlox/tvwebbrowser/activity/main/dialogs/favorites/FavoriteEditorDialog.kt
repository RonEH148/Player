package com.phlox.tvwebbrowser.activity.main.dialogs.favorites

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.model.FavoriteItem

/**
 * Add or edit a bookmark. Lumen: both fields are text fields from the start (no pencil buttons to
 * press first), the heading says what is being done, and an empty address is not saved.
 */
class FavoriteEditorDialog(context: Context, private val callback: Callback, private val item: FavoriteItem) : Dialog(context) {
    private val etTitle: EditText
    private val etUrl: EditText
    private val btnDone: Button
    private val btnCancel: Button

    interface Callback {
        fun onDone(item: FavoriteItem)
    }

    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(true)
        setContentView(R.layout.dialog_new_favorite_item)
        findViewById<TextView>(R.id.tvHeading).setText(
            if (item.id == 0L) R.string.new_bookmark else R.string.edit)
        etTitle = findViewById<View>(R.id.etTitle) as EditText
        etUrl = findViewById<View>(R.id.etUrl) as EditText
        btnDone = findViewById<View>(R.id.btnDone) as Button
        btnCancel = findViewById<View>(R.id.btnCancel) as Button

        btnDone.setOnClickListener {
            var urlStr = etUrl.text.toString().trim()
            if (urlStr.isEmpty() || urlStr == "https://" || urlStr == "http://") {
                etUrl.error = context.getString(R.string.url)
                etUrl.requestFocus()
                return@setOnClickListener
            }
            //add https:// if url not starts with any schema
            if (!urlStr.matches(Regex("^[A-Za-z]+://.*$"))) {
                urlStr = "https://$urlStr"
            }
            var title = etTitle.text.toString().trim()
            if (title.isEmpty()) {
                title = try { android.net.Uri.parse(urlStr).host?.removePrefix("www.") } catch (e: Exception) { null } ?: urlStr
            }
            this@FavoriteEditorDialog.item.title = title
            this@FavoriteEditorDialog.item.url = urlStr
            callback.onDone(this@FavoriteEditorDialog.item)
            dismiss()
        }
        btnCancel.setOnClickListener { dismiss() }

        etTitle.setText(item.title)
        etUrl.setText(item.url)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.let { w ->
            val dm = context.resources.displayMetrics
            w.setLayout(minOf((480 * dm.density).toInt(), dm.widthPixels), android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
            //the keyboard opens when the field is chosen (OK), not as soon as the dialog shows
            w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        }
        //the title field first, with the cursor at its end
        etTitle.requestFocus()
        etTitle.setSelection(etTitle.text.length)
    }
}
