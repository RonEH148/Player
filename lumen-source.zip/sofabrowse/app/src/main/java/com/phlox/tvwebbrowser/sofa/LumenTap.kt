package com.phlox.tvwebbrowser.sofa

import android.util.Log
import org.json.JSONObject
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * "Copy, don't download": the site's own player keeps downloading its video, and every piece it
 * hands to the browser (MediaSource appendBuffer, hooked in sofa_enhancements.js) is also passed
 * here over the LumenRelay channel. Lumen's player plays that copy from
 * http://127.0.0.1:<port>/tap/<epoch>/<track> (one endless fragmented MP4 per track), so the
 * picture comes from the player's decoding instead of the page's, and the server never sees a
 * second download.
 *
 * An "epoch" is one continuous run: start, and every seek (the page jumps, the copy restarts
 * from the pieces around the new position).
 */
object LumenTap {
    private const val TAG = "LumenTap"

    class TrackInfo(val sb: Int, val mime: String)

    private class Track(val sb: Int, val mime: String) {
        val splitter = LumenFmp4.Splitter()
        @Volatile var init: ByteArray? = null
        val ring = ArrayList<LumenFmp4.Fragment>()
        val out = LinkedBlockingQueue<ByteArray>()
        var lastStart = Double.NEGATIVE_INFINITY
        @Volatile var startedOutput = false
    }

    private class Epoch(val n: Int) {
        val tracks = ConcurrentHashMap<Int, Track>()
        val ready = CountDownLatch(1)
        @Volatile var startSec = Double.NaN
        @Volatile var started = false
        @Volatile var failed: String? = null
        /** Position asked for (seconds on the page's timeline), known once the page sent its pieces. */
        @Volatile var target = Double.NaN
        @Volatile var ringDoneAt = 0L
        /** Tracks the copy plays (those that had pieces when it started). */
        @Volatile var playing: List<Track> = emptyList()
    }

    private val END = ByteArray(0)
    private val counter = AtomicInteger(0)
    @Volatile private var epoch: Epoch? = null
    @Volatile private var origin: String? = null

    /** Lumen's player is showing a copy: MainActivity keeps the page running (not paused). */
    @Volatile var keepPageAlive = false

    /** The copy changed picture size/quality: the player should restart at its position. */
    @Volatile var onReinit: (() -> Unit)? = null

    /** The page's stream ended (endOfStream). */
    @Volatile var onEnded: (() -> Unit)? = null

    /** Starts a copy from the frame of [frameOrigin], at [atSec] (-1 = where the page is). Returns the epoch. */
    fun begin(frameOrigin: String, atSec: Double): Int {
        origin = frameOrigin
        keepPageAlive = true
        return newEpoch(atSec)
    }

    private fun newEpoch(atSec: Double): Int {
        val n = counter.incrementAndGet()
        epoch?.let { old -> old.tracks.values.forEach { it.out.offer(END) } }
        epoch = Epoch(n)
        post(JSONObject().put("op", "tapStart").put("epoch", n).put("t", atSec))
        LumenStreamProxy.note("COPY: start #$n at " + (if (atSec < 0) "the page's position" else "%.1f s".format(atSec)))
        return n
    }

    /** Seek: the page jumps to [sec] and a new copy starts there. Returns the new epoch. */
    fun seek(sec: Double): Int = newEpoch(sec.coerceAtLeast(0.0))

    fun setPlaying(playing: Boolean) = post(JSONObject().put("op", if (playing) "tapPlay" else "tapPause"))

    /** Lumen's player closed: the page goes to [sec] with its sound back, paused (or playing: [resume]). */
    fun stop(sec: Double, resume: Boolean = false) {
        post(JSONObject().put("op", "tapStop").put("t", sec).put("play", resume))
        epoch?.let { old -> old.tracks.values.forEach { it.out.offer(END) } }
        epoch = null
        keepPageAlive = false
        onReinit = null
        onEnded = null
    }

    private fun post(m: JSONObject) {
        val o = origin ?: return
        LumenPageFetch.post(o, m.toString())
    }

    /** Waits until epoch [n] can be played; returns its tracks, or null (see [failure]). */
    fun await(n: Int, timeoutMs: Long): List<TrackInfo>? {
        val e = epoch?.takeIf { it.n == n } ?: return null
        val until = System.currentTimeMillis() + timeoutMs
        while (!e.ready.await(250, TimeUnit.MILLISECONDS)) {
            if (System.currentTimeMillis() > until || epoch !== e) return null
            //after a jump the page may need a moment to fetch the new pieces; after 4 s start
            //with what there is
            if (e.ringDoneAt > 0 && System.currentTimeMillis() - e.ringDoneAt > 4000) tryStart(e, force = true)
        }
        if (e.failed != null) return null
        return e.playing.sortedBy { it.sb }.map { TrackInfo(it.sb, it.mime) }
    }

    fun failure(n: Int): String? = epoch?.takeIf { it.n == n }?.let { it.failed ?: if (!it.started) "the page sent nothing" else null }

    /** Where epoch [n] starts on the page's timeline (seconds): player position 0 = this. */
    fun startSec(n: Int): Double = epoch?.takeIf { it.n == n }?.startSec ?: Double.NaN

    // ---------------- from the page (LumenPageFetch) ----------------

    fun onMessage(m: JSONObject) {
        val e = epoch ?: return
        if (m.optInt("epoch", -1) != e.n && m.optString("op") != "tapEnd") return
        when (m.optString("op")) {
            "tapTrack" -> {
                val sb = m.optInt("sb")
                e.tracks[sb] = Track(sb, m.optString("type"))
            }
            "tapRingDone" -> {
                e.target = m.optDouble("t", 0.0)
                e.ringDoneAt = System.currentTimeMillis()
                tryStart(e, force = false)
            }
            "tapEnd" -> {
                LumenStreamProxy.note("COPY: the page's stream ended")
                e.tracks.values.forEach { it.out.offer(END) }
                onEnded?.invoke()
            }
            "tapError" -> {
                e.failed = m.optString("message", "failed")
                LumenStreamProxy.note("COPY: " + e.failed)
                e.ready.countDown()
            }
        }
    }

    fun onData(epochN: Int, sb: Int, bytes: ByteArray, off: Int) {
        val e = epoch ?: return
        if (e.n != epochN) return
        val t = e.tracks[sb] ?: return
        var check = false
        try {
            synchronized(t) {
                t.splitter.feed(bytes, off, bytes.size - off, { init ->
                    val old = t.init
                    if (old == null) {
                        t.init = init
                    } else if (!old.contentEquals(init)) {
                        //another quality / picture size: the player restarts on the new one
                        t.init = init
                        if (t.startedOutput) {
                            LumenStreamProxy.note("COPY: the page switched quality - restarting the copy")
                            onReinit?.invoke()
                        }
                    }
                }, { frag ->
                    if (!e.started) {
                        t.ring.add(frag)
                        if (t.ring.size > 400) t.ring.removeAt(0)
                        check = true
                    } else if (t.startedOutput) emit(e, t, frag)
                })
            }
        } catch (ex: Exception) {
            Log.w(TAG, "copy data: $ex")
        }
        if (check && e.ringDoneAt > 0) tryStart(e, force = false)
    }

    /**
     * Starts the copy once every track has the piece that contains the target position (what the
     * page already had, or what it fetched after the jump). [force]: start with what there is.
     */
    private fun tryStart(e: Epoch, force: Boolean) {
        synchronized(e) {
            if (e.started || e.failed != null || e.target.isNaN()) return
            val t = e.target
            val tracks = e.tracks.values.filter { it.init != null }
            if (tracks.isEmpty()) {
                if (force) {
                    e.failed = "no MP4 video from the page"
                    e.ready.countDown()
                }
                return
            }
            val sortedByTrack = HashMap<Int, List<LumenFmp4.Fragment>>()
            val startIdx = HashMap<Int, Int>()
            for (tr in tracks) synchronized(tr) {
                val sorted = tr.ring.filter { !it.startSec.isNaN() }.sortedBy { it.startSec }
                sortedByTrack[tr.sb] = sorted
                //the piece that contains t: it starts at or before t, and the next one after t (or,
                //for the newest piece, t is within a usual piece length of its start)
                val gaps = sorted.zipWithNext { a, b -> b.startSec - a.startSec }.filter { it > 0.2 }.sorted()
                val usual = if (gaps.isEmpty()) 6.0 else gaps[gaps.size / 2]
                var i = sorted.indexOfLast { it.startSec <= t + 0.05 }
                if (i >= 0) {
                    val next = sorted.getOrNull(i + 1)
                    val contains = if (next != null) next.startSec > t else t - sorted[i].startSec < usual * 1.5
                    if (!contains) i = -1
                }
                if (i < 0 && force) i = sorted.indexOfFirst { it.startSec > t - usual * 1.5 }
                startIdx[tr.sb] = i
            }
            if (!force && tracks.any { (startIdx[it.sb] ?: -1) < 0 }) return
            val use = tracks.filter { (startIdx[it.sb] ?: -1) >= 0 }
            if (use.isEmpty()) {
                e.failed = "the page sent no video at this position"
                e.ready.countDown()
                return
            }
            var s = Double.NaN
            for (tr in use) {
                val first = sortedByTrack[tr.sb]!![startIdx[tr.sb]!!].startSec
                if (s.isNaN() || first < s) s = first
            }
            e.startSec = s
            for (tr in use) synchronized(tr) {
                tr.out.offer(tr.init!!)
                tr.startedOutput = true
                val sorted = sortedByTrack[tr.sb]!!
                for (f in sorted.subList(startIdx[tr.sb]!!, sorted.size)) emit(e, tr, f)
                tr.ring.clear()
            }
            e.playing = use
            e.started = true
            LumenStreamProxy.note("COPY #${e.n}: ${use.size} track(s) " + use.joinToString { it.mime.substringBefore(';') } +
                    ", from %.1f s (asked %.1f s)".format(s, t))
            e.ready.countDown()
        }
    }

    private fun emit(e: Epoch, t: Track, frag: LumenFmp4.Fragment) {
        if (frag.startSec.isNaN() || frag.startSec <= t.lastStart + 1e-6) return
        t.lastStart = frag.startSec
        t.out.offer(LumenFmp4.shifted(frag.bytes, e.startSec, t.splitter.timescales))
    }

    // ---------------- to Lumen's player (LumenStreamProxy) ----------------

    /** Serves /tap/<epoch>/<sb>: the track's init segment, then fragments as they come. */
    fun serve(out: OutputStream, epochN: Int, sb: Int) {
        val e = epoch
        val t = e?.takeIf { it.n == epochN }?.tracks?.get(sb)
        if (t == null) {
            val body = "Gone".toByteArray()
            out.write("HTTP/1.1 410 Gone\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
            out.write(body)
            out.flush()
            return
        }
        val type = if (t.mime.startsWith("audio", true)) "audio/mp4" else "video/mp4"
        out.write("HTTP/1.1 200 OK\r\nContent-Type: $type\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n".toByteArray())
        out.flush()
        while (true) {
            val chunk = t.out.poll(120, TimeUnit.SECONDS) ?: break
            if (chunk === END) break
            out.write(chunk)
            out.flush()
            LumenStreamProxy.markActivity()
        }
    }
}
