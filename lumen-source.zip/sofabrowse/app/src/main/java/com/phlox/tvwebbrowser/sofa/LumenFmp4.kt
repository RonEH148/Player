package com.phlox.tvwebbrowser.sofa

/**
 * Just enough fragmented-MP4 (the format web players hand to the browser) for [LumenTap]:
 * splits a byte stream into the init segment (ftyp + moov) and fragments (moof + mdat), reads
 * each track's timescale and each fragment's start time (tfdt), and shifts fragment times so a
 * copy starts near zero. No Android dependencies (tested on the desktop).
 */
object LumenFmp4 {

    class Fragment(val bytes: ByteArray, val startSec: Double)

    /** Top-level boxes of a stream that arrives in arbitrary pieces. */
    class Splitter {
        private var buf = ByteArray(0)
        private var len = 0
        private var ftyp: ByteArray? = null
        private var moof: ByteArray? = null
        /** Track id -> timescale, from the latest init segment. */
        var timescales: Map<Int, Long> = emptyMap()
            private set

        /** Feeds bytes; [onInit] gets a complete init segment, [onFragment] each moof+mdat. */
        fun feed(data: ByteArray, off: Int, n: Int, onInit: (ByteArray) -> Unit, onFragment: (Fragment) -> Unit) {
            ensure(len + n)
            System.arraycopy(data, off, buf, len, n)
            len += n
            var pos = 0
            while (len - pos >= 8) {
                var size = u32(buf, pos)
                val type = type(buf, pos + 4)
                var header = 8
                if (size == 1L) {
                    if (len - pos < 16) break
                    size = u64(buf, pos + 8)
                    header = 16
                } else if (size == 0L) {
                    break //"to the end of the file": never the case for MSE segments; wait for more
                }
                if (size < header || size > Int.MAX_VALUE) {
                    //not a box stream any more: drop what we have
                    pos = len
                    break
                }
                if (len - pos < size) break
                val box = buf.copyOfRange(pos, pos + size.toInt())
                pos += size.toInt()
                when (type) {
                    "ftyp" -> ftyp = box
                    "moov" -> {
                        timescales = readTimescales(box)
                        val init = (ftyp ?: ByteArray(0)) + box
                        ftyp = null
                        moof = null
                        onInit(init)
                    }
                    "moof" -> moof = box
                    "mdat" -> {
                        val m = moof
                        if (m != null) {
                            moof = null
                            onFragment(Fragment(m + box, startSeconds(m, timescales)))
                        }
                    }
                    else -> {} //styp, sidx, prft, emsg, free: not needed by the player
                }
            }
            if (pos > 0) {
                System.arraycopy(buf, pos, buf, 0, len - pos)
                len -= pos
            }
        }

        private fun ensure(cap: Int) {
            if (buf.size >= cap) return
            buf = buf.copyOf(maxOf(cap, buf.size * 2, 64 * 1024))
        }
    }

    // ---------------- box helpers ----------------
    fun u32(b: ByteArray, p: Int): Long =
        ((b[p].toLong() and 0xFF) shl 24) or ((b[p + 1].toLong() and 0xFF) shl 16) or
                ((b[p + 2].toLong() and 0xFF) shl 8) or (b[p + 3].toLong() and 0xFF)

    fun u64(b: ByteArray, p: Int): Long = (u32(b, p) shl 32) or u32(b, p + 4)

    private fun put32(b: ByteArray, p: Int, v: Long) {
        b[p] = (v ushr 24).toByte(); b[p + 1] = (v ushr 16).toByte(); b[p + 2] = (v ushr 8).toByte(); b[p + 3] = v.toByte()
    }

    private fun put64(b: ByteArray, p: Int, v: Long) {
        put32(b, p, v ushr 32)
        put32(b, p + 4, v and 0xFFFFFFFFL)
    }

    fun type(b: ByteArray, p: Int): String =
        String(charArrayOf(b[p].toInt().toChar(), b[p + 1].toInt().toChar(), b[p + 2].toInt().toChar(), b[p + 3].toInt().toChar()))

    /** Calls [fn](type, start, end, headerSize) for each child box in [from, to). */
    private inline fun children(b: ByteArray, from: Int, to: Int, fn: (String, Int, Int, Int) -> Unit) {
        var p = from
        while (p + 8 <= to) {
            var size = u32(b, p)
            var header = 8
            if (size == 1L) {
                if (p + 16 > to) return
                size = u64(b, p + 8)
                header = 16
            } else if (size == 0L) {
                size = (to - p).toLong()
            }
            if (size < header || p + size > to) return
            fn(type(b, p + 4), p, (p + size).toInt(), header)
            p += size.toInt()
        }
    }

    /** track_ID -> timescale from a moov box. */
    fun readTimescales(moov: ByteArray): Map<Int, Long> {
        val out = HashMap<Int, Long>()
        children(moov, 8, moov.size) { t, s, e, h ->
            if (t != "trak") return@children
            var id = -1
            var scale = -1L
            children(moov, s + h, e) { t2, s2, e2, h2 ->
                if (t2 == "tkhd") {
                    val v = moov[s2 + h2].toInt() and 0xFF
                    id = u32(moov, s2 + h2 + 4 + (if (v == 1) 16 else 8)).toInt()
                } else if (t2 == "mdia") {
                    children(moov, s2 + h2, e2) { t3, s3, _, h3 ->
                        if (t3 == "mdhd") {
                            val v = moov[s3 + h3].toInt() and 0xFF
                            scale = u32(moov, s3 + h3 + 4 + (if (v == 1) 16 else 8))
                        }
                    }
                }
            }
            if (id >= 0 && scale > 0) out[id] = scale
        }
        return out
    }

    /** Earliest tfdt of a moof (seconds), using the tracks' timescales; NaN if there is none. */
    fun startSeconds(moof: ByteArray, timescales: Map<Int, Long>): Double {
        var best = Double.NaN
        forEachTfdt(moof, timescales) { _, value, scale ->
            val sec = value.toDouble() / scale
            if (best.isNaN() || sec < best) best = sec
        }
        return best
    }

    /** Calls [fn](offsetOfTfdtFullBox, baseMediaDecodeTime, timescale) for each traf. */
    private inline fun forEachTfdt(moof: ByteArray, timescales: Map<Int, Long>, fn: (Int, Long, Long) -> Unit) {
        children(moof, 8, moof.size) { t, s, e, h ->
            if (t != "traf") return@children
            var trackId = -1
            var tfdtAt = -1
            children(moof, s + h, e) { t2, s2, _, h2 ->
                if (t2 == "tfhd") trackId = u32(moof, s2 + h2 + 4).toInt()
                else if (t2 == "tfdt") tfdtAt = s2 + h2
            }
            if (tfdtAt >= 0) {
                val v = moof[tfdtAt].toInt() and 0xFF
                val value = if (v == 1) u64(moof, tfdtAt + 4) else u32(moof, tfdtAt + 4)
                val scale = timescales[trackId] ?: timescales.values.firstOrNull() ?: 90000L
                fn(tfdtAt, value, scale)
            }
        }
    }

    /** A copy of the fragment with every track's time moved [shiftSec] earlier (never below 0). */
    fun shifted(fragment: ByteArray, shiftSec: Double, timescales: Map<Int, Long>): ByteArray {
        val out = fragment.copyOf()
        //the moof is the first box of a fragment
        val moofSize = u32(out, 0).toInt().coerceAtMost(out.size)
        val moof = out.copyOfRange(0, moofSize)
        forEachTfdt(moof, timescales) { at, value, scale ->
            val delta = Math.round(shiftSec * scale)
            val nv = (value - delta).coerceAtLeast(0L)
            val v = out[at].toInt() and 0xFF
            if (v == 1) put64(out, at + 4, nv) else put32(out, at + 4, nv and 0xFFFFFFFFL)
        }
        return out
    }
}
