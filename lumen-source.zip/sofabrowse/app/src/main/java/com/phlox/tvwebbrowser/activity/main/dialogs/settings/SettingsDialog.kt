package com.phlox.tvwebbrowser.activity.main.dialogs.settings

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.activity.main.SettingsModel

/**
 * Lumen settings: categories on the left (move with Up/Down, the page shows at once), the
 * category's settings on the right (Right to go in, Left/Back to come out). Look taken from Wisp.
 */
class SettingsDialog(context: Context, val model: SettingsModel) :
    Dialog(context, R.style.SettingsDialog),
    DialogInterface.OnDismissListener, VersionSettingsView.Callback {

    private class Category(val icon: Int, val title: Int)

    private val categories = listOf(
        Category(R.drawable.ic_wisp_tune, R.string.lumen_set_general),
        Category(R.drawable.ic_wisp_block, R.string.lumen_set_adblock),
        Category(R.drawable.ic_wisp_play, R.string.lumen_set_video),
        Category(R.drawable.ic_wisp_more, R.string.lumen_set_remote),
        Category(R.drawable.ic_wisp_globe, R.string.lumen_set_content),
        Category(R.drawable.ic_wisp_key, R.string.lumen_set_privacy),
        Category(R.drawable.ic_wisp_download, R.string.lumen_set_downloads),
        Category(R.drawable.ic_wisp_vpn, R.string.lumen_set_vpn),
        Category(R.drawable.ic_wisp_shield, R.string.lumen_set_advanced),
        Category(R.drawable.ic_wisp_info, R.string.lumen_set_about)
    )

    private var mainView: MainSettingsView? = null
    private var versionView: VersionSettingsView? = null
    private val content = FrameLayout(context)
    private val rows = ArrayList<View>()
    private var current = -1

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, context.resources.displayMetrics).toInt()
    private fun color(id: Int) = ContextCompat.getColor(context, id)

    init {
        setTitle(R.string.settings)
        val root = LinearLayout(context)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(color(R.color.wisp_bg))

        //left: the categories
        val left = LinearLayout(context)
        left.orientation = LinearLayout.VERTICAL
        left.setPadding(dp(12f), dp(16f), dp(12f), dp(16f))
        val heading = TextView(context)
        heading.setText(R.string.settings)
        heading.textSize = 24f
        heading.setTypeface(heading.typeface, Typeface.BOLD)
        heading.setTextColor(color(R.color.wisp_text))
        heading.setPadding(dp(12f), 0, 0, dp(14f))
        left.addView(heading)
        categories.forEachIndexed { i, c -> left.addView(categoryRow(i, c)) }
        val leftScroll = ScrollView(context)
        leftScroll.isVerticalScrollBarEnabled = false
        leftScroll.setBackgroundColor(color(R.color.wisp_bar))
        leftScroll.addView(left)
        root.addView(leftScroll, LinearLayout.LayoutParams(dp(270f), ViewGroup.LayoutParams.MATCH_PARENT))

        //right: the settings of the chosen category
        content.setPadding(dp(8f), dp(8f), dp(8f), 0)
        root.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        setContentView(root)
        setOnDismissListener(this)
        select(0)
        rows.firstOrNull()?.requestFocus()
    }

    private fun categoryRow(index: Int, c: Category): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.isFocusable = true
        row.isClickable = true
        row.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        row.background = rowBackground()
        val icon = ImageView(context)
        icon.setImageResource(c.icon)
        icon.setColorFilter(color(R.color.wisp_icon))
        row.addView(icon, LinearLayout.LayoutParams(dp(24f), dp(24f)))
        val label = TextView(context)
        label.setText(c.title)
        label.textSize = 17f
        label.setTextColor(color(R.color.wisp_text))
        label.setPadding(dp(14f), 0, 0, 0)
        row.addView(label)
        row.setOnFocusChangeListener { _, has -> if (has) select(index) }
        row.setOnClickListener {
            select(index)
            //into the settings of the category
            content.post { content.getChildAt(0)?.let { it.requestFocus(View.FOCUS_RIGHT) } }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(4f)
        row.layoutParams = lp
        rows.add(row)
        return row
    }

    /** Selected category: soft fill; focused (remote): outlined too. */
    private fun rowBackground(): StateListDrawable {
        val r = dp(12f).toFloat()
        fun shape(fill: Int, stroke: Int?) = GradientDrawable().apply {
            cornerRadius = r
            setColor(fill)
            if (stroke != null) setStroke(dp(2f), stroke)
        }
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_focused), shape(color(R.color.wisp_accent_soft), color(R.color.wisp_accent)))
        s.addState(intArrayOf(android.R.attr.state_selected), shape(color(R.color.wisp_accent_soft), null))
        s.addState(intArrayOf(), shape(0x00000000, null))
        return s
    }

    private fun select(index: Int) {
        if (index == current) return
        current = index
        rows.forEachIndexed { i, v -> v.isSelected = i == index }
        val view: View = if (index == categories.size - 1) {
            versionView ?: VersionSettingsView(context).also {
                it.callback = this
                versionView = it
            }
        } else {
            val m = mainView ?: MainSettingsView(context).also { mainView = it }
            m.showGroup(index)
            m
        }
        if (content.getChildAt(0) !== view) {
            content.removeAllViews()
            content.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun inContent(v: View?): Boolean {
        var p: android.view.ViewParent? = v?.parent
        while (p != null) {
            if (p === content) return true
            p = p.parent
        }
        return false
    }

    /**
     * Left from the settings returns to the chosen category (not to whichever is nearest), and
     * Back inside the settings returns to the categories first; Back there closes.
     */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val f = currentFocus
        if (inContent(f) && current in rows.indices) {
            if (event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT && event.action == android.view.KeyEvent.ACTION_DOWN &&
                f !is android.widget.EditText && f !is android.widget.AbsSeekBar) {
                val next = f!!.focusSearch(View.FOCUS_LEFT)
                if (next == null || !inContent(next)) {
                    rows[current].requestFocus()
                    return true
                }
            }
            if (event.keyCode == android.view.KeyEvent.KEYCODE_BACK) {
                if (event.action == android.view.KeyEvent.ACTION_UP) rows[current].requestFocus()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT)
    }

    override fun onDismiss(dialog: DialogInterface?) {
        mainView?.save()
    }

    override fun onNeedToCloseSettings() {
        dismiss()
    }
}
