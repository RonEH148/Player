package com.phlox.tvwebbrowser.activity.main.dialogs.settings

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.phlox.tvwebbrowser.R
import com.phlox.tvwebbrowser.activity.main.SettingsModel

/**
 * Lumen settings: categories on the left (move with Up/Down, the page shows at once), the
 * category's settings on the right (Right to go in, Left/Back to come out). Look taken from Wisp.
 */
class SettingsDialog(context: Context, val model: SettingsModel) :
    Dialog(context, R.style.SettingsDialog),
    DialogInterface.OnDismissListener, VersionSettingsView.Callback {

    private class Category(val icon: Int, val title: Int)

    private val categories = listOf(
        Category(R.drawable.ic_wisp_tune, R.string.lumen_set_general),
        Category(R.drawable.ic_wisp_block, R.string.lumen_set_adblock),
        Category(R.drawable.ic_wisp_play, R.string.lumen_set_video),
        Category(R.drawable.gamepad_circle_up_24px, R.string.lumen_set_remote),
        Category(R.drawable.ic_wisp_globe, R.string.lumen_set_content),
        Category(R.drawable.ic_wisp_key, R.string.lumen_set_privacy),
        Category(R.drawable.ic_wisp_download, R.string.lumen_set_downloads),
        Category(R.drawable.ic_wisp_vpn, R.string.lumen_set_vpn),
        Category(R.drawable.ic_wisp_shield, R.string.lumen_set_advanced),
        Category(R.drawable.ic_wisp_info, R.string.lumen_set_about)
    )

    private var mainView: MainSettingsView? = null
    private var versionView: VersionSettingsView? = null
    private val content = FrameLayout(context)
    private val rows = ArrayList<View>()
    private var current = -1

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, context.resources.displayMetrics).toInt()
    private fun color(id: Int) = ContextCompat.getColor(context, id)

    init {
        setTitle(R.string.settings)
        val root = LinearLayout(context)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(color(R.color.wisp_bg))

        //left: the categories
        val left = LinearLayout(context)
        left.orientation = LinearLayout.VERTICAL
        left.setPadding(dp(12f), dp(16f), dp(12f), dp(16f))
        val heading = TextView(context)
        heading.setText(R.string.settings)
        heading.textSize = 24f
        heading.setTypeface(heading.typeface, Typeface.BOLD)
        heading.setTextColor(color(R.color.wisp_text))
        heading.setPadding(dp(12f), 0, 0, dp(14f))
        left.addView(heading)
        categories.forEachIndexed { i, c -> left.addView(categoryRow(i, c)) }
        val leftScroll = ScrollView(context)
        leftScroll.isVerticalScrollBarEnabled = false
        leftScroll.setBackgroundColor(color(R.color.wisp_bar))
        leftScroll.addView(left)
        root.addView(leftScroll, LinearLayout.LayoutParams(dp(270f), ViewGroup.LayoutParams.MATCH_PARENT))

        //right: the settings of the chosen category
        content.setPadding(dp(8f), dp(8f), dp(8f), 0)
        root.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        setContentView(root)
        setOnDismissListener(this)
        select(0)
        setOnShowListener { rows.getOrNull(current)?.requestFocus() }
    }

    /**
     * Makes every control obvious for the remote (look from Wisp): a row with a switch becomes one
     * target (OK flips the switch, the whole row lights up), buttons become pills, and spinners,
     * text fields and sliders get an outline while focused.
     */
    private fun polish(v: View) {
        if (v is ViewGroup) {
            val kids = (0 until v.childCount).map { v.getChildAt(it) }
            val sw = kids.firstOrNull { it is android.widget.CompoundButton }
            val otherFocusables = kids.count { it !== sw && hasFocusable(it) }
            if (v is LinearLayout && sw is android.widget.CompoundButton && otherFocusables == 0 && v.visibility != View.GONE) {
                v.isFocusable = true
                v.isClickable = true
                v.background = ContextCompat.getDrawable(context, R.drawable.lumen_row_bg)
                v.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
                outdent(v)
                sw.isFocusable = false
                sw.isClickable = false
                if (!v.hasOnClickListeners()) v.setOnClickListener { if (sw.isEnabled) sw.toggle() }
                return
            }
            kids.forEach { polish(it) }
            return
        }
        when (v) {
            is android.widget.CompoundButton -> {}
            is android.widget.Button -> {
                v.isAllCaps = false
                v.setTextColor(color(R.color.wisp_text))
                v.stateListAnimator = null
                if (v.layoutParams?.width == ViewGroup.LayoutParams.MATCH_PARENT) {
                    //a full-width button opens more settings: shown as a row with an arrow, its text
                    //lined up with the other rows
                    v.background = ContextCompat.getDrawable(context, R.drawable.lumen_row_bg)
                    v.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                    v.textSize = 16f
                    v.minHeight = dp(48f)
                    v.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
                    ContextCompat.getDrawable(context, R.drawable.ic_wisp_forward)?.mutate()?.let { d ->
                        d.setTint(color(R.color.wisp_text_secondary))
                        d.setBounds(0, 0, dp(18f), dp(18f))
                        v.setCompoundDrawablesRelative(null, null, d, null)
                    }
                    outdent(v)
                } else {
                    v.background = ContextCompat.getDrawable(context, R.drawable.lumen_button_bg)
                }
            }
            is android.widget.EditText -> {
                //text fields look like the address field: a pill, outlined while the remote is on it
                v.background = ContextCompat.getDrawable(context, R.drawable.lumen_url_pill_selector)
                v.setPadding(dp(16f), dp(10f), dp(16f), dp(10f))
                v.textSize = 16f
                (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.topMargin = maxOf(it.topMargin, dp(6f)); it.bottomMargin = maxOf(it.bottomMargin, dp(6f)) }
            }
            is android.widget.ImageButton -> {
                v.background = ContextCompat.getDrawable(context, R.drawable.lumen_icon_button_bg)
                v.setColorFilter(color(R.color.wisp_icon))
                v.scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            is android.widget.Spinner, is android.widget.SeekBar -> {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    v.foreground = ContextCompat.getDrawable(context, R.drawable.lumen_focus_outline)
                }
            }
        }
    }

    /** Rows reach 12 dp into the page's margin, so their text lines up with titles and notes. */
    private fun outdent(v: View) {
        (v.layoutParams as? ViewGroup.MarginLayoutParams)?.let {
            it.marginStart = -dp(12f)
            it.marginEnd = -dp(12f)
            v.layoutParams = it
        }
    }

    private fun hasFocusable(v: View): Boolean {
        if (v.isFocusable && v.visibility == View.VISIBLE) return true
        if (v is ViewGroup) for (i in 0 until v.childCount) if (hasFocusable(v.getChildAt(i))) return true
        return false
    }

    private fun categoryRow(index: Int, c: Category): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.isFocusable = true
        row.isClickable = true
        row.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        row.background = rowBackground()
        val icon = ImageView(context)
        icon.setImageResource(c.icon)
        icon.setColorFilter(color(R.color.wisp_icon))
        row.addView(icon, LinearLayout.LayoutParams(dp(24f), dp(24f)))
        val label = TextView(context)
        label.setText(c.title)
        label.textSize = 17f
        label.setTextColor(color(R.color.wisp_text))
        label.setPadding(dp(14f), 0, 0, 0)
        row.addView(label)
        row.setOnFocusChangeListener { _, has -> if (has) select(index) }
        row.setOnClickListener {
            select(index)
            //into the settings of the category, from the top
            content.post {
                (content.getChildAt(0) as? ScrollView)?.let { it.scrollTo(0, 0); it.requestFocus(View.FOCUS_DOWN) }
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(4f)
        row.layoutParams = lp
        rows.add(row)
        return row
    }

    /** Selected category: soft fill; focused (remote): outlined too. */
    private fun rowBackground(): StateListDrawable {
        val r = dp(12f).toFloat()
        fun shape(fill: Int, stroke: Int?) = GradientDrawable().apply {
            cornerRadius = r
            setColor(fill)
            if (stroke != null) setStroke(dp(2f), stroke)
        }
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_focused), shape(color(R.color.wisp_accent_soft), color(R.color.wisp_accent)))
        s.addState(intArrayOf(android.R.attr.state_selected), shape(color(R.color.wisp_accent_soft), null))
        s.addState(intArrayOf(), shape(0x00000000, null))
        return s
    }

    private fun select(index: Int) {
        if (index == current) return
        current = index
        rows.forEachIndexed { i, v -> v.isSelected = i == index }
        val view: View = if (index == categories.size - 1) {
            versionView ?: VersionSettingsView(context).also {
                it.callback = this
                versionView = it
                polish(it)
            }
        } else {
            val m = mainView ?: MainSettingsView(context).also { mainView = it; polish(it) }
            m.showGroup(index)
            m
        }
        if (content.getChildAt(0) !== view) {
            content.removeAllViews()
            content.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun inContent(v: View?): Boolean {
        var p: android.view.ViewParent? = v?.parent
        while (p != null) {
            if (p === content) return true
            p = p.parent
        }
        return false
    }

    /**
     * Keys for the remote:
     * - categories: Up/Down stay in the list, Right/OK go into the category's settings (top first);
     * - settings: Up/Down never jump into the category list (the page scrolls instead), Left at the
     *   left edge and Back return to the chosen category; Back there closes.
     */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        val f = currentFocus
        val down = event.action == android.view.KeyEvent.ACTION_DOWN
        val code = event.keyCode
        val page = content.getChildAt(0) as? ScrollView
        if (f != null && rows.contains(f)) {
            val i = rows.indexOf(f)
            if (down && code == android.view.KeyEvent.KEYCODE_DPAD_DOWN && i == rows.size - 1) return true
            if (down && code == android.view.KeyEvent.KEYCODE_DPAD_UP && i == 0) return true
            if (down && code == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) {
                page?.let { it.scrollTo(0, 0); it.requestFocus(View.FOCUS_DOWN) }
                return true
            }
        }
        if (inContent(f) && current in rows.indices) {
            if (down && (code == android.view.KeyEvent.KEYCODE_DPAD_DOWN || code == android.view.KeyEvent.KEYCODE_DPAD_UP)) {
                val dir = if (code == android.view.KeyEvent.KEYCODE_DPAD_DOWN) View.FOCUS_DOWN else View.FOCUS_UP
                val next = f!!.focusSearch(dir)
                if (next == null || !inContent(next)) {
                    //nothing more in that direction on this page: scroll (shows the texts in between)
                    page?.arrowScroll(dir)
                    return true
                }
            }
            if (down && code == android.view.KeyEvent.KEYCODE_DPAD_LEFT &&
                f !is android.widget.EditText && f !is android.widget.AbsSeekBar) {
                val next = f!!.focusSearch(View.FOCUS_LEFT)
                if (next == null || !inContent(next)) {
                    rows[current].requestFocus()
                    return true
                }
            }
            if (code == android.view.KeyEvent.KEYCODE_BACK) {
                if (event.action == android.view.KeyEvent.ACTION_UP) rows[current].requestFocus()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT)
    }

    override fun onDismiss(dialog: DialogInterface?) {
        mainView?.save()
    }

    override fun onNeedToCloseSettings() {
        dismiss()
    }
}
