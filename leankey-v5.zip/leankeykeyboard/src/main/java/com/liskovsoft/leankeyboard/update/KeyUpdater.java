package com.liskovsoft.leankeyboard.update;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.util.Base64;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * LeanKey Plus: updates itself from the GitHub Releases of your repository (the same one Lumen
 * updates from). The build workflow publishes "LeanKeyboard-Plus-&lt;versionCode&gt;.apk".
 * A private repository needs a read-only access token; it can be taken over from Lumen.
 */
public final class KeyUpdater {
    public static final int REQUEST_LUMEN_SOURCE = 4711;
    private static final String DEFAULT_REPO = "RonEH148/Player";
    private static final String PREFS = "leankey_plus_update";
    private static final String KEY_REPO = "repo";
    private static final String KEY_TOKEN = "token";
    private static final String LUMEN_ACTION = "com.sofabrowse.tv.action.SHARE_UPDATE_SOURCE";
    private static final String KEYSTORE_ALIAS = "leankey_plus_update_token";
    private static final Pattern ASSET = Pattern.compile("leankeyboard-plus-(\\d+)\\.apk", Pattern.CASE_INSENSITIVE);

    private static final Handler sMain = new Handler(Looper.getMainLooper());

    private KeyUpdater() {}

    static final class Release {
        String title;
        String notes;
        int versionCode;
        String assetName;
        String apiUrl;
        String downloadUrl;
        long size;
    }

    // ---------------------------------------------------------------- settings

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String repo(Context c) {
        String r = prefs(c).getString(KEY_REPO, "");
        return r == null || r.trim().isEmpty() ? DEFAULT_REPO : r.trim();
    }

    private static String token(Context c) {
        String enc = prefs(c).getString(KEY_TOKEN, "");
        if (enc == null || enc.isEmpty()) return null;
        String t = decrypt(enc);
        return t == null || t.trim().isEmpty() ? null : t.trim();
    }

    private static void save(Context c, String repo, String token) {
        SharedPreferences.Editor e = prefs(c).edit();
        if (repo != null) e.putString(KEY_REPO, repo.trim());
        if (token != null) e.putString(KEY_TOKEN, token.trim().isEmpty() ? "" : encrypt(token.trim()));
        e.apply();
    }

    // ---------------------------------------------------------------- token encryption (Android keystore)

    @SuppressLint("NewApi")
    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEYSTORE_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(KEYSTORE_ALIAS, null)).getSecretKey();
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(KEYSTORE_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return g.generateKey();
    }

    private static String encrypt(String plain) {
        if (Build.VERSION.SDK_INT < 23) return "p:" + plain; // very old Android: no keystore AES
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = cipher.getIV();
            byte[] data = cipher.doFinal(plain.getBytes("UTF-8"));
            return "k:" + Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(data, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private static String decrypt(String enc) {
        try {
            if (enc.startsWith("p:")) return enc.substring(2);
            if (!enc.startsWith("k:") || Build.VERSION.SDK_INT < 23) return null;
            String[] parts = enc.substring(2).split(":");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------------------------------------------------------- checking

    private static int installedVersion(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private static HttpURLConnection open(String url, String token, boolean binary) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", "LeanKeyboard-Plus");
        c.setRequestProperty("Accept", binary ? "application/octet-stream" : "application/vnd.github+json");
        if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
        return c;
    }

    private static String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            sb.append(new String(buf, 0, n, "UTF-8"));
            if (sb.length() > 4_000_000) break;
        }
        in.close();
        return sb.toString();
    }

    /** Newest LeanKeyboard Plus release. Network: call off the main thread. */
    static Release fetchLatest(Context ctx) throws Exception {
        String repo = repo(ctx);
        String token = token(ctx);
        HttpURLConnection c = open("https://api.github.com/repos/" + repo + "/releases?per_page=40", token, false);
        try {
            int code = c.getResponseCode();
            if (code == 401 || code == 403) throw new Exception("GitHub refused the access token for " + repo + ". Check \"Update source\".");
            if (code == 404) throw new Exception(token != null ? "No releases found in " + repo + " (or the token can't read it)."
                    : repo + " wasn't found. A private repository needs an access token: \"Update source\" → \"Take over from Lumen\".");
            if (code != 200) throw new Exception("GitHub answered " + code);
            JSONArray releases = new JSONArray(readAll(c.getInputStream()));
            Release best = null;
            for (int r = 0; r < releases.length(); r++) {
                JSONObject rel = releases.getJSONObject(r);
                if (rel.optBoolean("draft")) continue;
                JSONArray assets = rel.optJSONArray("assets");
                if (assets == null) continue;
                for (int i = 0; i < assets.length(); i++) {
                    JSONObject a = assets.getJSONObject(i);
                    Matcher m = ASSET.matcher(a.optString("name"));
                    if (!m.matches()) continue;
                    int vc = Integer.parseInt(m.group(1));
                    if (best != null && best.versionCode >= vc) continue;
                    best = new Release();
                    best.versionCode = vc;
                    best.title = rel.optString("name", rel.optString("tag_name"));
                    best.notes = rel.optString("body", "");
                    best.assetName = a.optString("name");
                    best.apiUrl = a.optString("url");
                    best.downloadUrl = a.optString("browser_download_url");
                    best.size = a.optLong("size");
                }
            }
            if (best == null) throw new Exception("No LeanKeyboard Plus build found in " + repo
                    + ". Build it once with the updated build-leankey.yml (it publishes a release).");
            return best;
        } finally {
            c.disconnect();
        }
    }

    // ---------------------------------------------------------------- UI

    @SuppressWarnings("deprecation")
    private static AlertDialog.Builder dialog(Activity a) {
        return new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
    }

    private static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_LONG).show();
    }

    /** Settings → "Check for updates". */
    public static void check(final Activity a) {
        toast(a, "Checking for LeanKeyboard Plus updates…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                Release r = null;
                String error = null;
                try {
                    r = fetchLatest(a);
                } catch (Exception e) {
                    error = e.getMessage() != null ? e.getMessage() : e.toString();
                }
                final Release release = r;
                final String err = error;
                sMain.post(new Runnable() {
                    @Override
                    public void run() {
                        if (a.isFinishing()) return;
                        if (err != null) {
                            dialog(a).setTitle("Update check failed").setMessage(err).setPositiveButton(android.R.string.ok, null).show();
                            return;
                        }
                        int have = installedVersion(a);
                        if (release.versionCode <= have) {
                            toast(a, "LeanKeyboard Plus is up to date (build " + have + ")");
                            return;
                        }
                        String size = release.size > 0 ? String.format(Locale.US, " · %.1f MB", release.size / 1048576.0) : "";
                        String notes = release.notes == null ? "" : release.notes;
                        if (notes.length() > 600) notes = notes.substring(0, 600);
                        dialog(a).setTitle("LeanKeyboard Plus update available")
                                .setMessage("New version: build " + release.versionCode + " (you have " + have + ")" + size + "\n\n" + notes)
                                .setPositiveButton("Install", (d, w) -> download(a, release))
                                .setNegativeButton("Later", null)
                                .show();
                    }
                });
            }
        }).start();
    }

    /** Settings → "Update source": repository, access token, or take both over from Lumen. */
    public static void editSource(final Activity a) {
        float dp = a.getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding((int) (20 * dp), (int) (8 * dp), (int) (20 * dp), 0);
        final EditText repo = new EditText(a);
        repo.setSingleLine();
        repo.setHint("owner/repository");
        repo.setText(repo(a));
        final EditText token = new EditText(a);
        token.setSingleLine();
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setHint(token(a) != null ? "Access token: saved (leave empty to keep)" : "Access token (private repository)");
        box.addView(repo);
        box.addView(token);
        dialog(a).setTitle("Update source")
                .setMessage("GitHub repository with the LeanKeyboard Plus builds. The quickest way: take the settings over from Lumen.")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String t = token.getText().toString();
                    save(a, repo.getText().toString(), t.trim().isEmpty() ? null : t);
                    toast(a, "Saved");
                })
                .setNeutralButton("Take over from Lumen", (d, w) -> askLumen(a))
                .setNegativeButton("Remove token", (d, w) -> {
                    save(a, null, "");
                    toast(a, "Access token removed");
                })
                .show();
    }

    private static void askLumen(Activity a) {
        Intent i = new Intent(LUMEN_ACTION);
        try {
            a.startActivityForResult(i, REQUEST_LUMEN_SOURCE);
        } catch (ActivityNotFoundException e) {
            toast(a, "Lumen (build 95 or newer) isn't installed");
        }
    }

    /** From the settings activity's onActivityResult. */
    public static boolean onActivityResult(Activity a, int requestCode, int resultCode, Intent data) {
        if (requestCode != REQUEST_LUMEN_SOURCE) return false;
        if (resultCode != Activity.RESULT_OK || data == null) {
            toast(a, "Lumen didn't share its update source");
            return true;
        }
        String repo = data.getStringExtra("repo");
        String token = data.getStringExtra("token");
        save(a, repo, token == null ? "" : token);
        toast(a, "Update source taken over from Lumen: " + repo(a));
        return true;
    }

    // ---------------------------------------------------------------- download + install

    @SuppressWarnings("deprecation")
    private static void download(final Activity a, final Release r) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            dialog(a).setTitle("Allow LeanKeyboard Plus to install updates")
                    .setMessage("Android needs your permission once: switch on \"Allow from this source\", then come back and choose Install again.")
                    .setPositiveButton(android.R.string.ok, (d, w) -> {
                        try {
                            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
                        } catch (Exception e) {
                            toast(a, e.toString());
                        }
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .show();
            return;
        }
        final ProgressDialog progress = new ProgressDialog(a);
        progress.setMessage("Downloading " + r.assetName + "…");
        progress.setProgressStyle(r.size > 0 ? ProgressDialog.STYLE_HORIZONTAL : ProgressDialog.STYLE_SPINNER);
        progress.setMax(100);
        final boolean[] cancelled = {false};
        progress.setOnCancelListener(d -> cancelled[0] = true);
        progress.show();
        File dir = a.getExternalCacheDir() != null ? a.getExternalCacheDir() : a.getCacheDir();
        final File file = new File(dir, "leankey-update.apk");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String error = null;
                try {
                    file.delete();
                    downloadTo(a, r, file, progress, cancelled);
                } catch (Exception e) {
                    error = e.getMessage() != null ? e.getMessage() : e.toString();
                }
                final String err = error;
                sMain.post(new Runnable() {
                    @Override
                    public void run() {
                        try { progress.dismiss(); } catch (Exception ignored) { }
                        if (cancelled[0]) { file.delete(); return; }
                        if (err != null) {
                            dialog(a).setTitle("Update download failed").setMessage(err).setPositiveButton(android.R.string.ok, null).show();
                            return;
                        }
                        install(a, file);
                    }
                });
            }
        }).start();
    }

    /** GitHub sends files through a redirect to its storage, which must not get the token. */
    @SuppressWarnings("deprecation")
    private static void downloadTo(Context ctx, Release r, File file, final ProgressDialog progress, boolean[] cancelled) throws Exception {
        String tok = token(ctx);
        String url = tok != null ? r.apiUrl : r.downloadUrl;
        String auth = tok;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = open(url, auth, true);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                url = c.getHeaderField("Location");
                if (url == null) throw new Exception("Bad redirect");
                auth = null;
                c.disconnect();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new Exception("Download failed (HTTP " + code + ")");
            }
            InputStream in = c.getInputStream();
            OutputStream out = new FileOutputStream(file);
            try {
                byte[] buf = new byte[65536];
                long total = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (cancelled[0]) return;
                    if (r.size > 0) {
                        final int pct = (int) (total * 100 / r.size);
                        sMain.post(() -> progress.setProgress(pct));
                    }
                }
            } finally {
                out.close();
                in.close();
                c.disconnect();
            }
            return;
        }
        throw new Exception("Too many redirects");
    }

    private static void install(Activity a, File file) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            Uri uri;
            if (Build.VERSION.SDK_INT >= 24) {
                uri = FileProvider.getUriForFile(a, a.getPackageName() + ".lkupdate", file);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                uri = Uri.fromFile(file);
            }
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
        } catch (Exception e) {
            toast(a, "Can't start the installer: " + e);
        }
    }
}
