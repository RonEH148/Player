package com.liskovsoft.leankeyboard.ime;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipboardManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * LeanKey Plus "copy & paste in all apps" (accessibility service, turned on in the TV's
 * accessibility settings). Holding OK on the remote:
 *  - on a text field: pastes what was copied last;
 *  - anywhere else: shows the selected item's text, to copy all of it or one line.
 * Copies go into the keyboard's clipboard history.
 *
 * It stays out of the way when:
 *  - the keyboard is on screen (the keyboard's own Copy/Cut/Paste chips are used then);
 *  - the app reacted to the long press itself (e.g. opened its own menu);
 *  - the app is the Lumen browser, which has its own select-and-copy for web pages.
 */
public class CopyPasteService extends AccessibilityService {
    private static final long HOLD_MS = 900;
    private static final int MAX_TEXT = 4000;

    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private long mDownAt;
    private long mLastWindowChange;
    private View mPanel;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event != null && event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            mLastWindowChange = SystemClock.uptimeMillis();
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        int code = event.getKeyCode();
        boolean ok = code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (!ok || mPanel != null) return false;
        // keys are only watched, never taken away from the app
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            mDownAt = SystemClock.uptimeMillis();
            mHandler.removeCallbacks(mLongPress);
            mHandler.postDelayed(mLongPress, HOLD_MS);
        } else if (event.getAction() == KeyEvent.ACTION_UP) {
            mHandler.removeCallbacks(mLongPress);
        }
        return false;
    }

    private final Runnable mLongPress = new Runnable() {
        @Override
        public void run() {
            if (LeanbackImeService.sInputViewShown || keyboardWindowShown()) return;
            // the app opened something of its own for the long press (a menu, a dialog)
            if (mLastWindowChange > mDownAt) return;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) return;
            CharSequence pkg = root.getPackageName();
            if (pkg != null) {
                String p = pkg.toString();
                if (p.equals(getPackageName()) || p.startsWith("com.sofabrowse.tv")) return;
            }
            AccessibilityNodeInfo node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (node == null) node = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY);
            if (node == null) return;
            if (node.isEditable()) paste(node); else showText(node);
        }
    };

    private boolean keyboardWindowShown() {
        if (Build.VERSION.SDK_INT < 21) return false;
        try {
            for (AccessibilityWindowInfo w : getWindows()) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void paste(AccessibilityNodeInfo node) {
        String clip = ClipHistory.primaryClip(this);
        if (clip == null) {
            List<String> history = ClipHistory.clips(this);
            if (!history.isEmpty()) {
                clip = history.get(0);
                ClipHistory.copy(this, clip); // back onto the clipboard so the app can paste it
            }
        }
        if (clip == null) {
            toast("Nothing copied yet");
            return;
        }
        // the app pastes from the clipboard itself
        if (node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) {
            toast("Pasted");
            return;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            CharSequence current = node.getText();
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    (current == null ? "" : current.toString()) + clip);
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                toast("Pasted");
                return;
            }
        }
        toast("This field doesn't accept pasting");
    }

    private void collect(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 8) return;
        int total = 0;
        for (String s : out) total += s.length();
        if (total > MAX_TEXT) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.toString().trim().length() > 0) out.add(t.toString().trim());
        else if (d != null && d.toString().trim().length() > 0) out.add(d.toString().trim());
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out, depth + 1);
    }

    private void showText(AccessibilityNodeInfo node) {
        List<String> raw = new ArrayList<>();
        collect(node, raw, 0);
        if (raw.isEmpty()) collect(node.getParent(), raw, 0);
        Set<String> parts = new LinkedHashSet<>();
        for (String s : raw) {
            String c = s.replaceAll("\\s+", " ").trim();
            if (!c.isEmpty()) parts.add(c);
        }
        if (parts.isEmpty()) return; // nothing to copy: stay quiet
        String all = TextUtils.join("\n", parts);
        Set<String> pieces = new LinkedHashSet<>();
        for (String p : parts) {
            if (p.length() <= 120) pieces.add(p);
            else for (String s : p.split("(?<=[.!?])\\s+")) if (!s.trim().isEmpty()) pieces.add(s.trim());
        }
        showPanel(all, new ArrayList<>(pieces));
    }

    private void showPanel(String all, List<String> pieces) {
        closePanel();
        float dp = getResources().getDisplayMetrics().density;
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding((int) (20 * dp), (int) (16 * dp), (int) (20 * dp), (int) (16 * dp));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(18 * dp);
        bg.setColor(0xF2202124);
        list.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Copy text  ·  Back closes");
        title.setTextColor(0xFF8AB4F8);
        title.setTextSize(18);
        title.setPadding(0, 0, 0, (int) (8 * dp));
        list.addView(title);

        addItem(list, "Copy all", all, true, dp);
        if (pieces.size() > 1) {
            int n = 0;
            for (String p : pieces) {
                if (n++ >= 40) break;
                addItem(list, p, p, false, dp);
            }
        }

        ScrollView scroll = new ScrollView(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent event) {
                if (event.getKeyCode() == KeyEvent.KEYCODE_BACK || event.getKeyCode() == KeyEvent.KEYCODE_ESCAPE) {
                    if (event.getAction() == KeyEvent.ACTION_UP) closePanel();
                    return true;
                }
                return super.dispatchKeyEvent(event);
            }
        };
        scroll.addView(list);

        int width = Math.max((int) (360 * dp), (int) (getResources().getDisplayMetrics().widthPixels * 0.5f));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 22 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                        : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR,
                WindowManager.LayoutParams.FLAG_DIM_BEHIND, PixelFormat.TRANSLUCENT);
        lp.dimAmount = 0.4f;
        lp.gravity = Gravity.CENTER;
        try {
            ((WindowManager) getSystemService(WINDOW_SERVICE)).addView(scroll, lp);
            mPanel = scroll;
            scroll.post(new Runnable() {
                @Override
                public void run() {
                    View first = list.getChildAt(1);
                    if (first != null) first.requestFocus();
                }
            });
        } catch (Throwable e) {
            toast("Couldn't show the copy panel");
        }
    }

    private void addItem(LinearLayout list, String label, final String copy, boolean strong, float dp) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(strong ? 17 : 15);
        b.setMaxLines(3);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setTextColor(0xFFE8EAED);
        StateListDrawable states = new StateListDrawable();
        GradientDrawable focused = new GradientDrawable();
        focused.setCornerRadius(12 * dp);
        focused.setColor(0xFF1A73E8);
        GradientDrawable normal = new GradientDrawable();
        normal.setCornerRadius(12 * dp);
        normal.setColor(0x22FFFFFF);
        states.addState(new int[]{android.R.attr.state_focused}, focused);
        states.addState(new int[]{}, normal);
        b.setBackground(states);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (6 * dp);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipHistory.copy(CopyPasteService.this, copy);
                toast("Copied: " + (copy.length() > 50 ? copy.substring(0, 47) + "…" : copy));
                closePanel();
            }
        });
        list.addView(b);
    }

    private void closePanel() {
        View v = mPanel;
        mPanel = null;
        if (v == null) return;
        try {
            ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(v);
        } catch (Throwable ignored) { }
    }

    private void toast(String s) {
        try { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }

    @Override
    public void onDestroy() {
        closePanel();
        super.onDestroy();
    }
}
