package com.liskovsoft.leankeyboard.ime;

import android.content.Context;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * LeanKey Plus: the extra chips in the suggestion bar above the keys.
 *
 *   [◀ Select] [Select ▶] [Select all] [Copy] [Cut] [Clear]   editing (when the field has text)
 *   🕘 …                                                       things you typed before that match
 *   📋 …                                                       clipboard history (newest first)
 *   [Forget history]
 *
 * Choosing a 📋 or 🕘 chip inserts it at the cursor (replacing selected text) without submitting,
 * so a link can still be edited before pressing Go.
 */
public final class StripExtras {
    static final String SEL_LEFT = "[◀ Select]";
    static final String SEL_RIGHT = "[Select ▶]";
    static final String SEL_ALL = "[Select all]";
    static final String COPY = "[Copy]";
    static final String CUT = "[Cut]";
    static final String CLEAR = "[Clear]";
    static final String FORGET = "[Forget history]";
    static final String CLOSE = "[✕ Close clipboard]";

    /** Clipboard key was pressed: the bar shows the whole clipboard history only. */
    static boolean clipMode;
    private static final String CLIP = "📋 ";
    private static final String TYPED = "🕘 ";
    private static final int SHOW_CLIPS = 15;
    private static final int SHOW_TYPED = 8;
    private static final int LABEL_MAX = 48;

    /** Chip label → full text it inserts. */
    private static final Map<String, String> INSERTS = new HashMap<>();

    private StripExtras() {}

    /** Chips to append after the editor text chip. */
    static List<String> build(Context c, InputConnection ic, EditorInfo info) {
        INSERTS.clear();
        List<String> out = new ArrayList<>();
        if (clipMode) {
            String primary = ClipHistory.primaryClip(c);
            if (primary != null) ClipHistory.addClip(c, primary);
            for (String clip : ClipHistory.clips(c)) addInsert(out, CLIP, clip);
            out.add(CLOSE);
            if (!ClipHistory.clips(c).isEmpty()) out.add(FORGET);
            return out;
        }
        String text = ic != null ? fullText(ic) : "";
        boolean password = isPassword(info);

        if (!text.isEmpty()) {
            out.add(SEL_LEFT);
            out.add(SEL_RIGHT);
            out.add(SEL_ALL);
            if (!password) {
                out.add(COPY);
                out.add(CUT);
            }
            out.add(CLEAR);
        }

        if (!password) {
            String q = text.trim().toLowerCase(Locale.ROOT);
            int n = 0;
            for (String t : ClipHistory.typed(c)) {
                if (n >= SHOW_TYPED) break;
                if (t.equals(text)) continue;
                if (q.isEmpty() || t.toLowerCase(Locale.ROOT).contains(q)) {
                    addInsert(out, TYPED, t);
                    n++;
                }
            }
        }

        // the current clipboard may have been set while the keyboard was closed
        String primary = ClipHistory.primaryClip(c);
        if (primary != null) ClipHistory.addClip(c, primary);
        int n = 0;
        for (String clip : ClipHistory.clips(c)) {
            if (n++ >= SHOW_CLIPS) break;
            addInsert(out, CLIP, clip);
        }

        if (!ClipHistory.clips(c).isEmpty() || !ClipHistory.typed(c).isEmpty()) out.add(FORGET);
        return out;
    }

    /** @return true if the chip was one of ours and has been handled. */
    static boolean handle(Context c, InputConnection ic, CharSequence chip) {
        if (chip == null || ic == null) return false;
        String label = chip.toString();
        String insert = INSERTS.get(label);
        if (insert != null || label.equals(CLOSE)) clipMode = false;
        if (label.equals(CLOSE)) return true;
        if (insert != null) {
            ic.commitText(insert, 1);                 // replaces the selection, if any
            return true;
        }
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        String text = et != null && et.text != null ? et.text.toString() : fullText(ic);
        int start = et != null ? Math.min(et.selectionStart, et.selectionEnd) : text.length();
        int end = et != null ? Math.max(et.selectionStart, et.selectionEnd) : text.length();
        if (start < 0) start = 0;
        if (end < 0 || end > text.length()) end = text.length();
        if (start > end) start = end;

        switch (label) {
            case SEL_LEFT:
                ic.setSelection(wordStartBefore(text, start), end);
                return true;
            case SEL_RIGHT:
                ic.setSelection(start, wordEndAfter(text, end));
                return true;
            case SEL_ALL:
                ic.setSelection(0, text.length());
                return true;
            case COPY:
            case CUT: {
                String part = start < end ? text.substring(start, end) : text;
                ClipHistory.copy(c, part);
                toast(c, (label.equals(CUT) ? "Cut: " : "Copied: ") + shorten(part));
                if (label.equals(CUT)) {
                    if (start == end) ic.setSelection(0, text.length());
                    ic.commitText("", 1);
                }
                return true;
            }
            case CLEAR:
                ic.setSelection(0, text.length());
                ic.commitText("", 1);
                return true;
            case FORGET:
                clipMode = false;
                ClipHistory.clearAll(c);
                toast(c, "Clipboard and typing history cleared");
                return true;
            default:
                return false;
        }
    }

    // ---------------------------------------------------------------------------------------------

    private static void addInsert(List<String> out, String prefix, String full) {
        String label = prefix + shorten(full.replace('\n', ' '));
        if (INSERTS.containsKey(label)) return;
        INSERTS.put(label, full);
        out.add(label);
    }

    private static String shorten(String s) {
        return s.length() <= LABEL_MAX ? s : s.substring(0, LABEL_MAX - 1) + "…";
    }

    /** Separators for word-wise selection; includes URL punctuation so "/abc123" selects the last part of a link. */
    private static boolean isSep(char ch) {
        return Character.isWhitespace(ch) || "/.:?&=#-_,;".indexOf(ch) >= 0;
    }

    static int wordStartBefore(String t, int pos) {
        int i = pos;
        while (i > 0 && isSep(t.charAt(i - 1))) i--;      // skip separators right before
        while (i > 0 && !isSep(t.charAt(i - 1))) i--;     // then the word
        return i;
    }

    static int wordEndAfter(String t, int pos) {
        int i = pos;
        while (i < t.length() && isSep(t.charAt(i))) i++;
        while (i < t.length() && !isSep(t.charAt(i))) i++;
        return i;
    }

    static String fullText(InputConnection ic) {
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        if (et != null && et.text != null) return et.text.toString();
        return LeanbackUtils.getEditorText(ic);
    }

    static boolean isPassword(EditorInfo info) {
        if (info == null) return false;
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        if (cls == InputType.TYPE_CLASS_TEXT) {
            return var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD;
        }
        return cls == InputType.TYPE_CLASS_NUMBER && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
    }

    private static void toast(Context c, String s) {
        try { Toast.makeText(c, s, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
    }
}
