package com.liskovsoft.leankeyboard.ime;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/**
 * LeanKey Plus: remembers the last texts that were copied (clipboard history) and the texts you
 * entered and confirmed with Go/Enter (typed history). Stored only on this device.
 */
public final class ClipHistory {
    private static final String PREFS = "leankey_plus_history";
    private static final String KEY_CLIPS = "clips";
    private static final String KEY_TYPED = "typed";
    static final int MAX_CLIPS = 25;
    static final int MAX_TYPED = 50;
    private static final int MAX_LEN = 8000;

    private ClipHistory() {}

    public static List<String> clips(Context c) { return load(c, KEY_CLIPS); }

    public static List<String> typed(Context c) { return load(c, KEY_TYPED); }

    public static void addClip(Context c, CharSequence text) { add(c, KEY_CLIPS, text, MAX_CLIPS); }

    public static void addTyped(Context c, CharSequence text) {
        if (text == null || text.toString().trim().length() < 3) return;
        add(c, KEY_TYPED, text.toString().trim(), MAX_TYPED);
    }

    public static void removeClip(Context c, String text) {
        List<String> list = clips(c);
        if (list.remove(text)) save(c, KEY_CLIPS, list);
    }

    public static void clearAll(Context c) {
        prefs(c).edit().remove(KEY_CLIPS).remove(KEY_TYPED).apply();
    }

    /** Current system clipboard text, or null. */
    public static String primaryClip(Context c) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData data = cm.getPrimaryClip();
            if (data == null || data.getItemCount() == 0) return null;
            CharSequence t = data.getItemAt(0).coerceToText(c);
            return t == null || t.length() == 0 ? null : t.toString();
        } catch (Throwable e) {
            return null;
        }
    }

    /** Puts text on the system clipboard (and so into the history). */
    public static void copy(Context c, CharSequence text) {
        if (text == null || text.length() == 0) return;
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("LeanKey", text));
        } catch (Throwable ignored) { }
        addClip(c, text);
    }

    // ---------------------------------------------------------------------------------------------

    private static void add(Context c, String key, CharSequence text, int max) {
        if (text == null) return;
        String s = text.toString();
        if (s.trim().isEmpty() || s.length() > MAX_LEN) return;
        List<String> list = load(c, key);
        list.remove(s);
        list.add(0, s);
        while (list.size() > max) list.remove(list.size() - 1);
        save(c, key, list);
    }

    private static List<String> load(Context c, String key) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (Throwable ignored) { }
        return out;
    }

    private static void save(Context c, String key, List<String> list) {
        JSONArray a = new JSONArray();
        for (String s : list) a.put(s);
        prefs(c).edit().putString(key, a.toString()).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
