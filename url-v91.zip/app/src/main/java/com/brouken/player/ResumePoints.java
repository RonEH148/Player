package com.brouken.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

import java.util.Locale;

/**
 * "Continue watching": the last position of every video (by link), saved while playing and when
 * it's closed. Opening it again asks Resume / Start from the beginning, when resuming really
 * works there (links that can seek, files, and links that can't seek when the USB drive holds
 * the video up to that point).
 */
final class ResumePoints {

    private ResumePoints() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("resume_points", Context.MODE_PRIVATE);
    }

    /** Saved position (ms), or 0. */
    static long get(Context c, Uri uri) {
        if (uri == null) return 0;
        String v = prefs(c).getString(uri.toString(), null);
        if (v == null) return 0;
        try { return Long.parseLong(v.split("\\|")[0]); } catch (Exception e) { return 0; }
    }

    static void put(Context c, Uri uri, long pos, long dur) {
        if (uri == null) return;
        SharedPreferences p = prefs(c);
        boolean finished = dur > 0 && dur != C.TIME_UNSET && pos > dur - 120_000;   // last 2 minutes: watched
        if (pos < 30_000 || finished) {
            if (p.contains(uri.toString())) p.edit().remove(uri.toString()).apply();
        } else {
            if (p.getAll().size() > 500) p.edit().clear().apply();
            p.edit().putString(uri.toString(), pos + "|" + dur + "|" + System.currentTimeMillis()).apply();
        }
        UsbBuffer.notePosition(uri, pos, dur);
    }

    /** Saves the player's position now (pause, close). */
    static void save(Context c) {
        try {
            ExoPlayer p = PlayerActivity.player;
            if (p == null || p.getCurrentMediaItem() == null || p.getCurrentMediaItem().localConfiguration == null) return;
            if (p.getPlaybackState() == Player.STATE_IDLE) return;
            Uri u = p.getCurrentMediaItem().localConfiguration.uri;
            if (p.getPlaybackState() == Player.STATE_ENDED) { put(c, u, Long.MAX_VALUE / 4, p.getDuration()); return; }
            put(c, u, p.getCurrentPosition(), p.getDuration());
        } catch (Throwable ignored) { }
    }

    private static long lastTick;

    /** Twice a second from the overlay timer: saved every 10 s while playing. */
    static void tick(Context c) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastTick < 10_000) return;
        ExoPlayer p = PlayerActivity.player;
        if (p == null || !p.isPlaying()) return;
        lastTick = now;
        save(c);
    }

    // ------------------------------------------------------------------ opening a video

    private static long pending;
    private static String pendingUri;

    /** A new video is opened: start where it was left, if that works here. Returns the position or 0. */
    static long startAt(PlayerActivity a, Uri uri) {
        pending = 0;
        pendingUri = null;
        long pos = get(a, uri);
        if (pos <= 0) return 0;
        boolean ok = !NetCompat.isHttp(uri) || !RangeSupport.isLinear(uri)
                || UsbBuffer.storedUntilMs(a, uri) >= pos + 5_000;
        if (!ok) {
            Diag.log("Continue watching: not possible here (server can't seek, not on the USB drive) – from the start");
            return 0;
        }
        pending = pos;
        pendingUri = uri.toString();
        return pos;
    }

    /** First picture of the video: ask once. */
    static void onFirstFrame(final PlayerActivity a) {
        if (a == null || pending <= 0 || PlayerActivity.player == null) return;
        final ExoPlayer p = PlayerActivity.player;
        try {
            if (p.getCurrentMediaItem() == null || !p.getCurrentMediaItem().localConfiguration.uri.toString().equals(pendingUri)) return;
        } catch (Throwable t) { return; }
        final long pos = pending;
        pending = 0;
        p.pause();
        AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("Continue watching?")
                .setMessage("You stopped at " + time(pos) + ".")
                .setPositiveButton("Resume", (x, w) -> p.play())
                .setNegativeButton("Start from the beginning", (x, w) -> {
                    p.seekTo(0);   // straight to the player: a jump back to 0:00 is always allowed
                    p.play();
                })
                .setOnCancelListener(x -> p.play())
                .create();
        d.show();
    }

    static String time(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                : String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }
}
