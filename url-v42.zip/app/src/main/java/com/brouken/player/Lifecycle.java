package com.brouken.player;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Leaving the player stops all downloads. Coming back (from Settings, the file picker or the home
 * screen) simply continues the same video. Back → "Exit player?" → Exit clears everything about the
 * video, so the player opens empty next time.
 */
public final class Lifecycle {

    private Lifecycle() {}

    private static final String KEY_FRESH = "freshStartUrl";
    private static String sessionUri;

    /** Hooked in PlayerActivity.onStop(), after the player was released. */
    public static void onStop(PlayerActivity a) {
        ReadAheadDataSource.stopAll();
    }

    /** Replaces the initializePlayer() call in PlayerActivity.onStart(). */
    public static void onStart(final PlayerActivity a) {
        a.initializePlayer();
    }

    /**
     * Back pressed.
     *  - A video is open: it pauses and asks "Resume" (continue from the same spot, after enough
     *    buffer) or "Main screen" (close the video, back to the empty player).
     *  - Main screen (no video): "Exit player?"
     * Returns true if handled.
     */
    public static boolean onBack(final PlayerActivity a) {
        if (a.mPrefs == null || a.mPrefs.mediaUri == null) {
            new AlertDialog.Builder(a)
                    .setTitle("Exit player?")
                    .setPositiveButton("Exit", (d, w) -> exit(a))
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        }
        final androidx.media3.exoplayer.ExoPlayer p = PlayerActivity.player;
        if (p != null) p.pause();
        dismissBackDialog();
        backDialog = new AlertDialog.Builder(a)
                .setTitle("Video paused")
                .setPositiveButton("Resume", (d, w) -> resume(a))
                .setNegativeButton("Main screen", (d, w) -> mainScreen(a))
                .setOnCancelListener(d -> resume(a))
                .create();
        backDialog.setOnDismissListener(d -> backDialog = null);
        backDialog.show();
        return true;
    }

    private static AlertDialog backDialog;

    /** PiP, Home, or the video started playing again: the Resume / Main screen question is moot. */
    static void dismissBackDialog() {
        AlertDialog d = backDialog;
        backDialog = null;
        if (d != null) {
            try {
                d.setOnCancelListener(null);
                d.dismiss();
            } catch (Throwable ignored) { }
        }
    }

    private static final android.os.Handler HANDLER = new android.os.Handler(android.os.Looper.getMainLooper());
    private static Runnable waiting;

    /** Continue from where it was paused; if the buffer ran dry, wait until there is enough first. */
    static void resume(final PlayerActivity a) {
        if (waiting != null) HANDLER.removeCallbacks(waiting);
        final androidx.media3.exoplayer.ExoPlayer p = PlayerActivity.player;
        if (p == null) {
            if (!a.isFinishing()) a.initializePlayer();   // was released: reopens at the saved position
            return;
        }
        final long need = NetCompat.isHttp(a.mPrefs.mediaUri) ? 5_000 : 1_000;
        waiting = new Runnable() {
            int shown = -1;
            @Override
            public void run() {
                if (PlayerActivity.player != p || a.isFinishing()) return;
                if (p.getPlayWhenReady()) return;              // you pressed play yourself
                long buffered = p.getTotalBufferedDuration();
                long duration = p.getDuration();
                boolean toEnd = duration != androidx.media3.common.C.TIME_UNSET
                        && p.getBufferedPosition() >= duration - 500;
                if (buffered >= need || toEnd || p.getPlaybackState() == androidx.media3.common.Player.STATE_ENDED) {
                    p.play();
                    return;
                }
                int sec = (int) (buffered / 1000);
                if (sec != shown) {
                    shown = sec;
                    CenterText.show(a, "Buffering… " + sec + " / " + need / 1000 + " s", 1500);
                }
                HANDLER.postDelayed(this, 300);
            }
        };
        waiting.run();
    }

    /** Close the video and show the empty player (open file / URL). */
    static void mainScreen(PlayerActivity a) {
        if (waiting != null) HANDLER.removeCallbacks(waiting);
        clearMedia(a);
        Diag.log("Main screen");
        try {
            a.initializePlayer();
            if (android.os.Build.VERSION.SDK_INT >= 26 && Utils.isPiPSupported(a)) {
                a.updatePictureInPictureActions(R.drawable.ic_play_arrow_24dp, R.string.exo_controls_play_description, 1, 1);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    /** Player left with Home/Recents/closed PiP: video closed, player gone (next start = main screen). */
    static void leave(PlayerActivity a) {
        clearMedia(a);
        Diag.log("Left the player: video closed");
        if (android.os.Build.VERSION.SDK_INT >= 21) a.finishAndRemoveTask();
        else a.finish();
    }

    static void exit(PlayerActivity a) {
        clearMedia(a);
        Diag.log("Exit: cleared");
        // Remove the task too: reopening from Recents would otherwise replay the link that
        // originally opened the player (e.g. from the browser), which may have expired.
        if (android.os.Build.VERSION.SDK_INT >= 21) a.finishAndRemoveTask();
        else a.finish();
    }

    private static void clearMedia(PlayerActivity a) {
        dismissBackDialog();
        Diag.hide();
        ReadAheadDataSource.stopAll();
        try {
            a.setIntent(new android.content.Intent(a, PlayerActivity.class));   // the opening link is used up
        } catch (Throwable ignored) { }
        try {
            if (PlayerActivity.player != null) a.releasePlayer();
        } catch (Throwable ignored) { }
        try {
            a.mPrefs.updatePosition(0L);
            a.mPrefs.mediaUri = null;
            a.mPrefs.mediaType = null;
            a.mPrefs.updateSubtitle(null);
            prefs(a).edit().remove("mediaUri").remove("mediaType").remove(KEY_FRESH).apply();
            a.apiTitle = null;
        } catch (Throwable ignored) { }
        Decoder.clearOverride(a);
        Decoder.systemBrightness(a);
        sessionUri = null;
        Ivtc.newSession();
        StreamHeaders.clear();
    }

    /** A link pasted again starts from the beginning. */
    public static void markFreshStart(Context c, String url) {
        prefs(c).edit().putString(KEY_FRESH, url).apply();
    }

    /**
     * Refresh: drop every connection and the decoder, then reopen the video at the current
     * position. For a frozen video, and used automatically after a load failure.
     */
    public static void refresh(final PlayerActivity a) {
        try {
            if (PlayerActivity.player != null) a.releasePlayer();   // saves the current position
        } catch (Throwable ignored) { }
        ReadAheadDataSource.stopAll();
        Diag.log("Reopening at the same position");
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            if (!a.isFinishing() && !a.isDestroyed()) a.initializePlayer();
        }, 300);
    }

    /**
     * Called before every player start. A newly opened video starts at 0:00; reopening the same
     * video (decoder switch, refresh, coming back from Settings) keeps the position.
     */
    static void beginSession(PlayerActivity a) {
        try {
            if (a.mPrefs == null || a.mPrefs.mediaUri == null) return;
            String uri = a.mPrefs.mediaUri.toString();
            boolean fresh = uri.equals(prefs(a).getString(KEY_FRESH, null));
            if (fresh) prefs(a).edit().remove(KEY_FRESH).apply();
            if (fresh || !uri.equals(sessionUri)) {
                a.mPrefs.updatePosition(0L);
                sessionUri = uri;
                Ivtc.newSession();
                if (!uri.equals(prefs(a).getString("decoderUserUri", null))) Decoder.clearOverride(a);   // new video: HW+ again
                autoRetried = false;
            }
            else if (RangeSupport.isLinear(a.mPrefs.mediaUri) && a.mPrefs.getPosition() > 0) {
                // this server can't jump into the middle of the file; reopen from the start
                Diag.log("Server can't seek: reopening from the beginning");
                a.mPrefs.updatePosition(0L);
            }
        } catch (Throwable ignored) { }
    }

    private static boolean autoRetried;

    /**
     * Network load failed (Just Player would just stop and show ▶ that does nothing).
     * Server ignores Range → reopen in linear mode; any other first failure → reopen once.
     * Returns true if handled.
     */
    static boolean onSourceError(final PlayerActivity a, Throwable error) {
        try {
            if (a.mPrefs == null || !NetCompat.isHttp(a.mPrefs.mediaUri)) return false;
            RangeSupport.RangeIgnoredException ri = RangeSupport.find(error);
            if (ri != null && !ri.firstTime) {
                // linear server and the position is too far to read forward: start over
                android.widget.Toast.makeText(a, "This server can't jump there – playing from the start", android.widget.Toast.LENGTH_LONG).show();
                a.mPrefs.updatePosition(0L);
                refresh(a);
                return true;
            }
            if (ri != null || !autoRetried) {
                if (ri == null) autoRetried = true;
                Diag.log(ri != null ? "Server can't seek → reopening in linear mode" : "Load failed → reopening once");
                refresh(a);
                return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    /** Kept for PasteUrlActivity. */
    public static void clear(Context c) { }

    private static SharedPreferences prefs(Context c) {
        return PreferenceManager.getDefaultSharedPreferences(c);
    }
}
