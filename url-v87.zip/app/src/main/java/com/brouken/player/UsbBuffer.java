package com.brouken.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.TypedValue;
import android.widget.TextView;

import androidx.media3.datasource.DataSource;
import androidx.media3.extractor.SeekMap;

import java.io.File;
import java.util.Locale;
import java.util.Random;

/**
 * Settings → "Use USB drive as buffer" and "Test USB drive". Finds the USB drive, measures how
 * fast the TV can write to it, and keeps the one {@link DriveBuffer} of the video that's open.
 */
final class UsbBuffer {

    private UsbBuffer() {}

    static final String KEY = "usbBuffer";
    static final String KEY_TEST = "usbBufferTest";
    private static final String KEY_SPEED = "usbTestSpeed";
    private static final String KEY_DRIVE = "usbTestDrive";

    /** Write speed (MB/s, while reading back) needed: 4K remuxes are 8–11 MB/s. */
    static final float GOOD = 15f, ENOUGH = 10f;
    private static final long MIN_FREE = 6L << 30;

    // ------------------------------------------------------------------ the drive

    static final String KEY_TREE = "usbTree";
    static final int REQUEST_PICK = 4711;

    /**
     * The folder on the USB drive used for the buffer, or null:
     *  1. Just Player's own folder on a drive Android lists for apps (TVs),
     *  2. the same on a drive it mounts but doesn't list (writable directly),
     *  3. the folder you picked on the drive in Android's folder picker (Samsung tablets).
     */
    static DriveDir drive(Context c) {
        if (appContext == null && c != null) appContext = c.getApplicationContext();
        File d = listedDrive(c);
        if (d == null) d = otherDrive(c);
        if (d != null) return new DriveDir.FileDir(d);
        return pickedDrive(c);
    }

    private static DriveDir pickedDrive(Context c) {
        try {
            String t = PreferenceManager.getDefaultSharedPreferences(c).getString(KEY_TREE, null);
            if (t == null || android.os.Build.VERSION.SDK_INT < 21) return null;
            Uri tree = Uri.parse(t);
            boolean granted = false;
            for (android.content.UriPermission up : c.getContentResolver().getPersistedUriPermissions()) {
                if (up.getUri().equals(tree) && up.isWritePermission()) granted = true;
            }
            if (!granted) return null;
            DriveDir.SafDir root = new DriveDir.SafDir(c, tree, android.provider.DocumentsContract.getTreeDocumentId(tree));
            if (root.usableSpace() <= 0) return null;   // drive not connected right now
            return root.sub("Just Player buffer");
        } catch (Throwable t) {
            return null;
        }
    }

    /** Opens Android's folder picker (from Settings) when no drive can be used directly. */
    static void pick(androidx.fragment.app.Fragment f) {
        try {
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            f.startActivityForResult(i, REQUEST_PICK);
        } catch (Throwable t) {
            if (f.getActivity() != null) message(f.getActivity(), "No folder picker", "This device has no folder picker for storage.");
        }
    }

    /** Folder chosen in the picker: keep the permission, then test the drive. */
    static void onPicked(Activity a, Uri tree, Done after) {
        if (tree == null) return;
        String docId = android.provider.DocumentsContract.getTreeDocumentId(tree);
        if (docId != null && docId.startsWith("primary")) {
            message(a, "That's the internal storage", "Pick the USB drive (or a folder on it), so the buffer never wears out the internal storage.");
            return;
        }
        try {
            a.getContentResolver().takePersistableUriPermission(tree,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION | android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Throwable t) {
            message(a, "No permission", "Android didn't give write access to that folder.");
            return;
        }
        PreferenceManager.getDefaultSharedPreferences(a).edit().putString(KEY_TREE, tree.toString()).apply();
        test(a, after);
    }

    /** Settings sets this: what to do when no drive is found (open the folder picker). */
    static Runnable pickHook;
    /** What to do after the test that follows picking the folder (turn the switch on). */
    static Done afterPick;

    /** Removable storage Android lists for apps (TVs, microSD cards). */
    private static File listedDrive(Context c) {
        try {
            File[] dirs = c.getExternalFilesDirs(null);
            for (int i = 1; i < dirs.length; i++) {
                File d = dirs[i];
                if (d == null) continue;
                try {
                    if (Environment.isExternalStorageRemovable(d)
                            && Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState(d))) return d;
                } catch (IllegalArgumentException ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /**
     * USB drives that Android mounts but doesn't list for apps (Samsung tablets with a USB-C
     * drive): Just Player's own folder on it is created and checked for writing.
     */
    private static File otherDrive(Context c) {
        try {
            android.os.storage.StorageManager sm = (android.os.storage.StorageManager) c.getSystemService(Context.STORAGE_SERVICE);
            if (sm == null || android.os.Build.VERSION.SDK_INT < 24) return null;
            for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                if (v.isPrimary() || !v.isRemovable() || !Environment.MEDIA_MOUNTED.equals(v.getState())) continue;
                File root = null;
                if (android.os.Build.VERSION.SDK_INT >= 30) root = v.getDirectory();
                if (root == null) {
                    try { root = new File((String) v.getClass().getMethod("getPath").invoke(v)); } catch (Throwable ignored) { }
                }
                if (root == null) continue;
                File mine = new File(root, "Android/data/" + c.getPackageName() + "/files");
                mine.mkdirs();
                File probe = new File(mine, ".write-test");
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(probe)) {
                    o.write(1);
                    probe.delete();
                    return mine;
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
        return null;
    }

    /** The drive itself, to know whether the test was done on this one. */
    static String driveId(DriveDir d) {
        return d.driveId();
    }

    static volatile Context appContext;

    static boolean enabled(Context c) {
        if (appContext == null && c != null) appContext = c.getApplicationContext();
        return PreferenceManager.getDefaultSharedPreferences(c).getBoolean(KEY, false);
    }

    /** Tested speed of this drive, or -1. */
    static float testedSpeed(Context c, DriveDir d) {
        if (d == null) return -1f;
        android.content.SharedPreferences p = PreferenceManager.getDefaultSharedPreferences(c);
        String saved = p.getString(KEY_DRIVE, null);
        String id = driveId(d);
        if (id.equals(saved)) return p.getFloat(KEY_SPEED, -1f);
        // tested with v84 or older (by its path): still the same drive → keep the result
        if (saved != null && saved.startsWith("/") && d instanceof DriveDir.FileDir
                && ((DriveDir.FileDir) d).f.getAbsolutePath().startsWith(saved)) {
            p.edit().putString(KEY_DRIVE, id).apply();
            return p.getFloat(KEY_SPEED, -1f);
        }
        return -1f;
    }

    /** Why the buffer isn't used for the next video, or null when it is. */
    static String notUsedBecause(Context c) {
        if (!enabled(c)) return "off";
        DriveDir d = drive(c);
        if (d == null) return "no USB drive connected";
        float s = testedSpeed(c, d);
        if (s < 0) return "this drive hasn't been tested (Settings → Test USB drive)";
        if (s < ENOUGH) return String.format(Locale.US, "this drive is too slow (%.1f MB/s)", s);
        if (d.usableSpace() < MIN_FREE) return "less than 6 GB free on the drive";
        return null;
    }

    // ------------------------------------------------------------------ the video's buffer

    private static DriveBuffer current;
    private static boolean waited;

    private static DriveDir root(DriveDir drive) throws java.io.IOException { return drive.sub("buffer"); }

    /** The folder for this link: the same link, or the same file (exact size) under another link; null = none yet. */
    private static DriveDir findFolder(Context c, DriveDir drive, Uri uri) throws java.io.IOException {
        String key = uri.toString();
        DriveDir r = root(drive);
        DriveDir byKey = r.find(id(key));
        if (byKey != null) return byKey;
        long size = Decoder.knownSize(c, key);
        if (size > 0) {
            for (DriveDir f : r.dirs()) {
                org.json.JSONObject m = meta(f);
                if (m != null && m.optLong("size", -1) == size) return f;
            }
        }
        return null;
    }

    private static DriveDir folderFor(Context c, DriveDir drive, Uri uri) throws java.io.IOException {
        DriveDir f = findFolder(c, drive, uri);
        return f != null ? f : root(drive).sub(id(uri.toString()));
    }

    static String id(String key) {
        try {
            byte[] h = java.security.MessageDigest.getInstance("SHA-1").digest(key.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format(Locale.US, "%02x", h[i]));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(key.hashCode());
        }
    }

    static org.json.JSONObject meta(DriveDir folder) {
        try {
            byte[] b = folder.read("meta.json");
            return b == null ? null : new org.json.JSONObject(new String(b, "UTF-8"));
        } catch (Throwable t) {
            return null;
        }
    }

    /** The buffer for this link (created on first use); null = read from the network as usual. */
    static synchronized DriveBuffer session(Context c, Uri uri, DataSource.Factory upstream) {
        if (uri == null) return null;
        if (current != null && current.key.equals(uri.toString())) return current;
        String why = notUsedBecause(c);
        if (why != null && why.startsWith("no USB") && enabled(c) && !waited) {
            // first video after the TV was switched on: the drive may still be spinning up /
            // being mounted. Waited for once (up to 10 s); later videos without a drive start at once.
            waited = true;
            for (int i = 0; i < 20 && why != null && why.startsWith("no USB"); i++) {
                try { Thread.sleep(500); } catch (InterruptedException e) { return null; }
                why = notUsedBecause(c);
            }
            if (why == null) {
                Perf.driveMode = true;
                Diag.log("USB buffer: the drive is ready now");
            }
        }
        if (why != null) return null;
        closeAll(false);
        DriveDir d = drive(c);
        if (d == null) return null;
        DriveDir dir;
        try {
            dir = folderFor(c, d, uri);
        } catch (java.io.IOException e) {
            Diag.log("USB buffer: can't use the drive (" + e.getMessage() + ")");
            return null;
        }
        makeRoom(d, dir);
        long mine = dir.bytes();
        long cap = d.usableSpace() + mine - DriveBuffer.MARGIN;
        if (cap < (2L << 30)) return null;
        current = new DriveBuffer(dir, uri, RangeSupport.isLinear(uri), upstream, cap);
        Diag.log(String.format(Locale.US, "USB buffer: on (%.0f GB usable on the drive)", cap / 1e9));
        return current;
    }

    /**
     * Space on the drive is getting low: the downloads not watched for the longest time are
     * deleted (never the one being opened), until there's room for a 4K remux again.
     */
    private static void makeRoom(DriveDir drive, DriveDir keep) {
        final long want = 100L << 30;
        if (drive.usableSpace() >= want) return;
        java.util.List<DriveDir> old = new java.util.ArrayList<>();
        try {
            for (DriveDir f : root(drive).dirs()) if (!f.equals(keep)) old.add(f);
        } catch (java.io.IOException e) {
            return;
        }
        java.util.Collections.sort(old, (a, b) -> Long.compare(lastUsed(a), lastUsed(b)));
        for (DriveDir f : old) {
            if (drive.usableSpace() >= want) break;
            org.json.JSONObject m = meta(f);
            Diag.log("USB buffer: deleting an old download to make room" + (m != null ? " (" + m.optString("title", "") + ")" : ""));
            f.deleteTree();
        }
    }

    private static long lastUsed(DriveDir f) {
        org.json.JSONObject m = meta(f);
        return m != null ? m.optLong("last", 0) : 0;
    }

    static long treeBytes(File f) {
        long n = 0;
        File[] k = f.listFiles();
        if (k != null) for (File x : k) n += x.isDirectory() ? treeBytes(x) : x.length();
        return n;
    }

    /** The video was closed: stop its download; keep it on the drive (or delete it). */
    static synchronized void closeAll(boolean delete) {
        if (current != null) {
            current.close(delete);
            if (delete) Diag.log("USB buffer: download deleted");
            current = null;
        }
    }

    /** Back → "Delete & close": is there a download of this video to delete? */
    static synchronized boolean hasDownload() {
        return current != null && current.usedBytes() > 0;
    }

    /** Remember where the player is (for "continue watching" and the saved-downloads list). */
    static synchronized void notePosition(Uri uri, long posMs, long durMs) {
        if (current != null && uri != null && current.key.equals(uri.toString())) current.setPosition(posMs, durMs);
    }

    /**
     * How far (ms) this video is on the drive from the start, for deciding whether "continue
     * watching" works on a link that can't seek; -1 if nothing is stored.
     */
    static long storedUntilMs(Context c, Uri uri) {
        try {
            DriveDir d = drive(c);
            if (d == null || uri == null || !enabled(c)) return -1;
            DriveDir f = findFolder(c, d, uri);
            org.json.JSONObject m = f == null ? null : meta(f);
            if (m == null) return -1;
            if (m.optBoolean("complete")) return Long.MAX_VALUE;
            org.json.JSONArray ix = m.optJSONArray("index");
            org.json.JSONArray r = m.optJSONArray("ranges");
            if (ix == null || r == null || ix.length() == 0) return -1;
            long best = -1;
            for (int i = 0; i < ix.length(); i++) {
                org.json.JSONArray e = ix.getJSONArray(i);
                long pos = e.getLong(1);
                for (int j = 0; j < r.length(); j++) {
                    org.json.JSONArray x = r.getJSONArray(j);
                    if (pos >= x.getLong(0) && pos < x.getLong(1)) { best = Math.max(best, e.getLong(0) / 1000); break; }
                }
            }
            return best;
        } catch (Throwable t) {
            return -1;
        }
    }

    // ------------------------------------------------------------------ saved downloads (settings)

    static String savedSummary(Context c) {
        DriveDir d = drive(c);
        if (d == null) return "No USB drive connected";
        int n = 0;
        long bytes = 0;
        try {
            for (DriveDir f : root(d).dirs()) if (meta(f) != null) { n++; bytes += f.bytes(); }
        } catch (java.io.IOException ignored) { }
        if (n == 0) return "None";
        return String.format(Locale.US, "%d video%s · %.1f GB on the drive", n, n == 1 ? "" : "s", bytes / 1e9);
    }

    static void manageSaved(final Activity a, final Runnable changed) {
        final DriveDir d = drive(a);
        if (d == null) { message(a, "No USB drive", "Connect the USB drive first. If it is connected, this device doesn't let apps write to it."); return; }
        final java.util.List<DriveDir> items = new java.util.ArrayList<>();
        try {
            for (DriveDir f : root(d).dirs()) if (meta(f) != null) items.add(f);
        } catch (java.io.IOException ignored) { }
        java.util.Collections.sort(items, (x, y) -> Long.compare(lastUsed(y), lastUsed(x)));
        if (items.isEmpty()) { message(a, "Saved downloads", "Nothing is saved on the drive."); return; }
        String[] labels = new String[items.size()];
        for (int i = 0; i < items.size(); i++) {
            org.json.JSONObject m = meta(items.get(i));
            String t = m.optString("title", "");
            if (t.isEmpty()) t = Titles.fromUrl(Uri.parse(m.optString("url", "")));
            long size = m.optLong("size", -1);
            long have = items.get(i).bytes();
            String part = m.optBoolean("complete") ? "complete" : size > 0 ? String.format(Locale.US, "%.0f%%", have * 100.0 / size) : Diag.mb(have);
            long pos = m.optLong("pos", 0);
            labels[i] = t + "\n" + String.format(Locale.US, "%.1f GB · %s", have / 1e9, part)
                    + (pos > 0 ? " · stopped at " + time(pos) : "");
        }
        new AlertDialog.Builder(a)
                .setTitle("Saved downloads")
                .setItems(labels, (dlg, which) -> {
                    final DriveDir f = items.get(which);
                    new AlertDialog.Builder(a)
                            .setTitle("Delete this download?")
                            .setMessage(labels[which])
                            .setPositiveButton("Delete", (x, y) -> { deleteSaved(f); changed.run(); manageSaved(a, changed); })
                            .setNegativeButton("Cancel", (x, y) -> manageSaved(a, changed))
                            .show();
                })
                .setNeutralButton("Delete all", (dlg, w) -> new AlertDialog.Builder(a)
                        .setTitle("Delete all saved downloads?")
                        .setPositiveButton("Delete all", (x, y) -> { for (DriveDir f : items) deleteSaved(f); changed.run(); })
                        .setNegativeButton("Cancel", null)
                        .show())
                .setNegativeButton("Close", null)
                .show();
    }

    private static synchronized void deleteSaved(DriveDir f) {
        if (current != null && current.dir.equals(f)) { current.close(true); current = null; return; }
        f.deleteTree();
    }

    static void deleteTree(File f) {
        if (f == null) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    /** Refresh button: restart the download (links that can seek). */
    static void kick() {
        DriveBuffer b = current();
        if (b != null) b.kick();
    }

    static synchronized DriveBuffer current() {
        return current;
    }

    /** Seek points inside what's on the drive (links that can't seek), or null. */
    static SeekMap.SeekPoints seekPoints(long timeUs) {
        DriveBuffer b = current();
        return b != null && b.linear ? b.seekPoints(timeUs) : null;
    }

    /** {from, to} ms the player can jump to on the drive (links that can't seek), or null. */
    static long[] seekableMs(Uri uri) {
        DriveBuffer b = current();
        if (b == null || !b.linear || uri == null || !b.key.equals(uri.toString())) return null;
        return b.seekableMs();
    }

    /** How far the video is ready on the drive (ms), for the gray part of the time bar; -1 = unknown. */
    static long readyUntilMs(Uri uri, long durationMs) {
        DriveBuffer b = current();
        if (b == null || uri == null || !b.key.equals(uri.toString()) || b.bypass) return -1;
        long best = -1;
        long total = Diag.currentSize();
        if (total > 0 && durationMs > 0) best = (long) (b.readyEnd() * (double) durationMs / total);
        long[] idx = b.linear ? b.seekableMs() : null;
        if (idx != null) best = Math.max(best, idx[1]);
        return best;
    }

    /** Overlay line, or null. */
    static String status(Context c, long positionMs, long durationMs) {
        DriveBuffer b = current();
        if (b == null) {
            if (!enabled(c)) return null;
            String why = notUsedBecause(c);
            return why == null ? null : "not used – " + why;
        }
        if (b.bypass) return "stopped – the drive couldn't keep up, normal buffer";
        long[] s = b.stats();
        StringBuilder sb = new StringBuilder();
        sb.append(Diag.mb(s[0])).append(" ready ahead");
        long[] seek = b.linear ? b.seekableMs() : null;
        if (seek != null && seek[1] > positionMs) {
            sb.append(" (").append(time(seek[1] - positionMs)).append(")");
        } else {
            long total = Diag.currentSize();
            if (total > 0 && durationMs > 0) sb.append(" (~").append(time(s[0] * durationMs / total)).append(")");
        }
        if (b.isComplete()) sb.append(" · whole file downloaded");
        sb.append(" · ").append(Diag.mb(s[1])).append(" on the drive");
        if (b.downloadMbps > 0 && !b.isComplete()) sb.append(String.format(Locale.US, " · arriving at %.0f Mbit/s", b.downloadMbps));
        // the drive's own speed only matters when it holds the download back
        if (b.driveBusy > 0.5) sb.append(String.format(Locale.US, " · the drive is the limit (%.0f MB/s)", b.writeMBps));
        return sb.toString();
    }

    private static String time(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                : String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    // ------------------------------------------------------------------ settings

    static String testSummary(Context c) {
        DriveDir d = drive(c);
        if (d == null) return "No USB drive connected";
        float s = testedSpeed(c, d);
        String free = String.format(Locale.US, "%.0f GB free", d.usableSpace() / 1e9);
        if (s < 0) return "Not tested yet · " + free;
        return String.format(Locale.US, "%.1f MB/s · %s · %s", s, verdict(s), free);
    }

    private static String verdict(float s) {
        return s >= GOOD ? "fast enough for 4K remuxes" : s >= ENOUGH ? "enough for most 4K, tight for the biggest remuxes"
                : "too slow for 4K remuxes";
    }

    /** Switch turned on: test the drive first if needed. Returns false to keep it off. */
    static boolean onSwitch(final Activity a, boolean on, final Runnable turnedOn, final Runnable refresh) {
        if (!on) {
            closeAll(false);
            return true;
        }
        DriveDir d = drive(a);
        if (d == null) {
            // offers the folder picker (tablets); after choosing, the test runs and turns it on
            afterPick = ok -> { if (ok) turnedOn.run(); refresh.run(); };
            test(a, null);
            return false;
        }
        float s = testedSpeed(a, d);
        if (s >= ENOUGH) return true;
        if (s >= 0) {
            message(a, "This drive is too slow", String.format(Locale.US,
                    "This device writes to it at %.1f MB/s; 4K remuxes need at least %.0f MB/s.", s, ENOUGH));
            return false;
        }
        test(a, ok -> {
            if (ok) turnedOn.run();
            refresh.run();
        });
        return false;   // turned on by the test when it passes
    }

    interface Done { void done(boolean ok); }

    /**
     * Writes 256 MB into the same folder, the same way the buffer does, while reading back what
     * was written a moment earlier (as during playback); the time includes flushing to the drive.
     */
    static void test(final Activity a, final Done done) {
        final DriveDir d = drive(a);
        if (d == null) {
            if (pickHook != null) {
                // Samsung tablets: apps may only write to a USB drive through a folder you pick once
                new AlertDialog.Builder(a)
                        .setTitle("Choose the USB drive")
                        .setMessage("This device lets apps use a USB drive only through a folder you choose. In the next screen, open the USB drive and tap “Use this folder”, then “Allow”.")
                        .setPositiveButton("Choose", (x, y) -> pickHook.run())
                        .setNegativeButton("Cancel", null)
                        .show();
            } else {
                message(a, "No USB drive", "Connect the USB drive first.");
            }
            if (done != null) done.done(false);
            return;
        }
        final TextView text = new TextView(a);
        int pad = (int) (24 * a.getResources().getDisplayMetrics().density);
        text.setPadding(pad, pad / 2, pad, 0);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        text.setText("Writing to the drive…");
        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Testing the USB drive")
                .setView(text)
                .setCancelable(false)
                .setPositiveButton("OK", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            final int MB = 1 << 20, total = 256;
            DriveDir dir = null;
            float speed = -1f;
            String error = null;
            try {
                if (d.usableSpace() < (total + 64L) * MB) throw new java.io.IOException("not enough free space");
                dir = d.sub("speedtest");
                byte[] buf = new byte[MB], back = new byte[MB];
                new Random().nextBytes(buf);
                DriveDir.Chan w = dir.open("test.bin", true);
                DriveDir.Chan r = dir.open("test.bin", false);
                try {
                    long t0 = System.nanoTime();
                    for (int i = 0; i < total; i++) {
                        buf[i % MB] ^= 1;
                        w.write((long) i * MB, buf, 0, MB);
                        if (i >= 32) {
                            long rp = (long) (i - 32) * MB;
                            int got = 0;
                            while (got < MB) {
                                int n = r.read(rp + got, back, got, MB - got);
                                if (n <= 0) break;
                                got += n;
                            }
                        }
                        if (i % 32 == 31) {
                            w.sync();
                            final int done1 = i + 1;
                            final double sofar = done1 / ((System.nanoTime() - t0) / 1e9);
                            ui.post(() -> text.setText(String.format(Locale.US, "Writing to the drive… %d of %d MB (%.1f MB/s)",
                                    done1, total, sofar)));
                        }
                    }
                    w.sync();
                    speed = (float) (total / ((System.nanoTime() - t0) / 1e9));
                } finally {
                    w.close();
                    r.close();
                }
            } catch (Throwable t) {
                error = t.getMessage() != null ? t.getMessage() : t.toString();
            } finally {
                if (dir != null) dir.deleteTree();
            }
            final float result = speed;
            final String err = error;
            ui.post(() -> {
                boolean ok = result >= ENOUGH;
                if (result > 0) {
                    PreferenceManager.getDefaultSharedPreferences(a).edit()
                            .putFloat(KEY_SPEED, result).putString(KEY_DRIVE, driveId(d)).apply();
                    text.setText(String.format(Locale.US, "%.1f MB/s – %s.%s", result, verdict(result),
                            ok ? "\n\nThe drive can be used as the buffer." : "\n\nThe buffer stays off for this drive."
                                    + " If it's formatted as NTFS, exFAT is usually much faster on Android TVs."));
                } else {
                    text.setText("The test couldn't write to the drive: " + err);
                }
                dialog.setCancelable(true);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                if (done != null) done.done(ok);
            });
        }, "usb-speed-test").start();
    }

    private static void message(Activity a, String title, String msg) {
        new AlertDialog.Builder(a).setTitle(title).setMessage(msg).setPositiveButton(android.R.string.ok, null).show();
    }
}
