package com.brouken.player;

import android.app.ActivityManager;
import android.content.Context;

/**
 * Memory budget for streaming buffers, sized to the whole device, not just the app's heap.
 *
 *   2 GB TVs (Philips 43PQT8100, MediaTek MT96xx class): 32 MB read-ahead + 96 MB samples
 *   3–6 GB devices:                                      48 MB + 128 MB
 *   Tab S9 (8–12 GB):                                    64 MB + 200 MB
 *
 * Both are also capped to half the app's heap, so playback never pushes the app (or the TV's
 * launcher and system services) into low-memory kills.
 */
public final class Perf {
    private Perf() {}

    private static volatile long totalRam;
    private static volatile long availRam;
    /** The video plays from the USB drive buffer. */
    static volatile boolean driveMode;
    private static volatile boolean lowRam;

    /** Called when the player opens (UrlButton.add). */
    public static void init(Context c) {
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            totalRam = mi.totalMem;
            availRam = mi.availMem;
            lowRam = am.isLowRamDevice();
        } catch (Throwable ignored) { }
    }

    private static long heap() {
        return Runtime.getRuntime().maxMemory();
    }

    private static final long GB = 1024L * 1024 * 1024;
    private static final int MB = 1024 * 1024;

    /** 2–3 GB devices, i.e. most Android TVs: lighter buffers, normal thread priority. */
    public static boolean lowEnd() {
        if (lowRam) return true;
        if (totalRam > 0) return totalRam < 3 * GB + GB / 2;
        return heap() < 300L * MB;
    }

    private static int cap(int want) {
        long half = heap() / 2;
        return (int) Math.max(16L * MB, Math.min(want, half / 2));
    }

    /** Background download cache. */
    /**
     * Read-ahead kept in native shared memory (outside the app's 512 MB heap limit), sized to the
     * device's RAM and to what's free right now: Tab S9 (12 GB) 1 GB, TV (2 GB) 192 MB.
     */
    public static int nativeReadAheadBytes() {
        long want;
        if (totalRam >= 10 * GB) want = 1024L * MB;
        else if (totalRam >= 7 * GB) want = 768L * MB;
        else if (totalRam >= 5 * GB) want = 384L * MB;
        else if (totalRam >= 3 * GB + GB / 2) want = 256L * MB;
        else want = 192L * MB;
        // USB drive buffer on a TV: the head start is on the drive; memory only smooths the reads
        if (driveMode && lowEnd()) want = Math.min(want, 96L * MB);
        if (availRam > 0) want = Math.min(want, availRam / 3);   // never more than a third of the free RAM
        return (int) Math.max(32L * MB, want);
    }

    public static int readAheadBytes() {
        int want;
        if (lowEnd()) want = 32 * MB;
        else if (totalRam > 0 && totalRam < 7 * GB) want = 48 * MB;
        else want = 64 * MB;
        return cap(want);
    }

    /** Demuxed video/audio waiting to be decoded (the "buffer" in the overlay). */
    public static int sampleBufferBytes() {
        int want;
        if (lowEnd()) want = 96 * MB;          // ~9 s of an 80 Mbit/s 4K remux
        else if (totalRam > 0 && totalRam < 7 * GB) want = 128 * MB;
        else want = 200 * MB;                  // ~20 s
        if (ReadAheadDataSource.nativeRing()) {
            // the read-ahead lives outside the heap now: the samples can use more of it
            if (lowEnd()) want = driveMode ? 96 * MB : 128 * MB;   // from the drive, refills are instant
            else if (totalRam > 0 && totalRam < 7 * GB) want = 200 * MB;
            else want = 300 * MB;
            return (int) Math.max(32L * MB, Math.min(want, (long) (heap() * 0.55)));
        }
        long half = heap() / 2;
        return (int) Math.max(32L * MB, Math.min(want, half - readAheadBytes()));
    }

    static String describe() {
        return String.format(java.util.Locale.US, "RAM %.1f GB%s · heap %d MB · buffers %d+%d MB",
                totalRam / (double) GB, lowRam ? " (low-RAM device)" : "", heap() / MB,
                readAheadBytes() / MB, sampleBufferBytes() / MB);
    }
}
