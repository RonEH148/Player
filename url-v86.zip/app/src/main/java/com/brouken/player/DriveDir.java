package com.brouken.player;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A folder on the USB drive, for the drive buffer. Two kinds:
 *  - a normal folder (TVs, where Android lets the app write to its own folder on the drive),
 *  - a folder you picked in Android's folder picker (Samsung tablets and phones, where apps may
 *    only write to a USB drive through that permission).
 * Both give positional reads and writes on plain files, so the buffer works the same way.
 */
abstract class DriveDir {

    /** An open file: read and write at any position. */
    interface Chan {
        int read(long pos, byte[] b, int off, int len) throws IOException;
        void write(long pos, byte[] b, int off, int len) throws IOException;
        void sync() throws IOException;
        void close();
    }

    abstract String id();
    /** The drive itself, to know whether the speed test was done on this one. */
    abstract String driveId();
    /** Subfolder, created if missing. */
    abstract DriveDir sub(String name) throws IOException;
    /** Subfolder, or null if it doesn't exist. */
    abstract DriveDir find(String name);
    abstract List<DriveDir> dirs();
    /** Length of a file in this folder, or -1. */
    abstract long length(String name);
    abstract void delete(String name);
    abstract void deleteTree();
    abstract Chan open(String name, boolean write) throws IOException;
    abstract long usableSpace();
    /** Bytes of all files in here (and below). */
    abstract long bytes();
    abstract void writeAtomic(String name, byte[] data) throws IOException;

    byte[] read(String name) {
        if (length(name) < 0) return null;
        Chan c = null;
        try {
            c = open(name, false);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[64 * 1024];
            long p = 0;
            int n;
            while ((n = c.read(p, b, 0, b.length)) > 0) { o.write(b, 0, n); p += n; }
            return o.toByteArray();
        } catch (IOException e) {
            return null;
        } finally {
            if (c != null) c.close();
        }
    }

    @Override public boolean equals(Object o) { return o instanceof DriveDir && ((DriveDir) o).id().equals(id()); }
    @Override public int hashCode() { return id().hashCode(); }

    // ------------------------------------------------------------------ plain folder

    static final class FileDir extends DriveDir {
        final File f;

        FileDir(File f) { this.f = f; }

        @Override String id() { return f.getAbsolutePath(); }

        @Override String driveId() {
            String p = f.getAbsolutePath();
            int i = p.indexOf("/Android/");
            return i > 0 ? p.substring(0, i) : p;
        }

        @Override DriveDir sub(String name) throws IOException {
            File d = new File(f, name);
            if (!d.isDirectory() && !d.mkdirs()) throw new IOException("can't create " + d);
            return new FileDir(d);
        }

        @Override DriveDir find(String name) {
            File d = new File(f, name);
            return d.isDirectory() ? new FileDir(d) : null;
        }

        @Override List<DriveDir> dirs() {
            List<DriveDir> out = new ArrayList<>();
            File[] k = f.listFiles();
            if (k != null) for (File x : k) if (x.isDirectory()) out.add(new FileDir(x));
            return out;
        }

        @Override long length(String name) {
            File x = new File(f, name);
            return x.isFile() ? x.length() : -1;
        }

        @Override void delete(String name) { new File(f, name).delete(); }

        @Override void deleteTree() { UsbBuffer.deleteTree(f); }

        @Override Chan open(String name, boolean write) throws IOException {
            if (write) f.mkdirs();
            final RandomAccessFile r = new RandomAccessFile(new File(f, name), write ? "rw" : "r");
            return new Chan() {
                public int read(long pos, byte[] b, int off, int len) throws IOException { r.seek(pos); return r.read(b, off, len); }
                public void write(long pos, byte[] b, int off, int len) throws IOException { r.seek(pos); r.write(b, off, len); }
                public void sync() throws IOException { r.getFD().sync(); }
                public void close() { try { r.close(); } catch (IOException ignored) { } }
            };
        }

        @Override long usableSpace() { return f.getUsableSpace(); }

        @Override long bytes() { return UsbBuffer.treeBytes(f); }

        @Override void writeAtomic(String name, byte[] data) throws IOException {
            f.mkdirs();
            File tmp = new File(f, name + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) {
                o.write(data);
                o.getFD().sync();
            }
            if (!tmp.renameTo(new File(f, name))) throw new IOException("rename failed");
        }
    }

    // ------------------------------------------------------------------ picked folder (Storage Access Framework)

    static final class SafDir extends DriveDir {
        private final ContentResolver cr;
        private final Uri tree;
        private final String doc;
        /** name → {document id, mime, size}; refreshed when something isn't found. */
        private final Map<String, String[]> kids = new HashMap<>();
        private boolean listed;
        private long spaceAt;
        private long space;

        SafDir(Context c, Uri tree, String doc) {
            this.cr = c.getApplicationContext().getContentResolver();
            this.tree = tree;
            this.doc = doc;
        }

        @Override String id() { return tree + "|" + doc; }
        @Override String driveId() { return tree.toString(); }

        private Uri uri(String docId) { return DocumentsContract.buildDocumentUriUsingTree(tree, docId); }

        private synchronized void list() {
            kids.clear();
            Uri u = DocumentsContract.buildChildDocumentsUriUsingTree(tree, doc);
            try (Cursor c = cr.query(u, new String[] {Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
                    Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE}, null, null, null)) {
                if (c != null) while (c.moveToNext()) {
                    kids.put(c.getString(1), new String[] {c.getString(0), c.getString(2), String.valueOf(c.isNull(3) ? 0 : c.getLong(3))});
                }
            } catch (Throwable ignored) { }
            listed = true;
        }

        private synchronized String[] kid(String name) {
            if (!listed) list();
            String[] k = kids.get(name);
            if (k == null) { list(); k = kids.get(name); }
            return k;
        }

        @Override synchronized DriveDir sub(String name) throws IOException {
            String[] k = kid(name);
            if (k != null && Document.MIME_TYPE_DIR.equals(k[1])) return new SafDir(cr, tree, k[0]);
            try {
                Uri made = DocumentsContract.createDocument(cr, uri(doc), Document.MIME_TYPE_DIR, name);
                if (made == null) throw new IOException("can't create folder " + name);
                list();
                return new SafDir(cr, tree, DocumentsContract.getDocumentId(made));
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException("can't create folder " + name + ": " + e.getMessage());
            }
        }

        @Override DriveDir find(String name) {
            String[] k = kid(name);
            return k != null && Document.MIME_TYPE_DIR.equals(k[1]) ? new SafDir(cr, tree, k[0]) : null;
        }

        @Override synchronized List<DriveDir> dirs() {
            list();
            List<DriveDir> out = new ArrayList<>();
            for (String[] k : kids.values()) if (Document.MIME_TYPE_DIR.equals(k[1])) out.add(new SafDir(cr, tree, k[0]));
            return out;
        }

        @Override synchronized long length(String name) {
            list();   // sizes change while downloading
            String[] k = kids.get(name);
            return k == null || Document.MIME_TYPE_DIR.equals(k[1]) ? -1 : Long.parseLong(k[2]);
        }

        @Override synchronized void delete(String name) {
            String[] k = kid(name);
            if (k == null) return;
            try { DocumentsContract.deleteDocument(cr, uri(k[0])); } catch (Throwable ignored) { }
            kids.remove(name);
        }

        @Override void deleteTree() {
            try { DocumentsContract.deleteDocument(cr, uri(doc)); } catch (Throwable ignored) { }
        }

        private synchronized Uri fileUri(String name, boolean create) throws IOException {
            String[] k = kid(name);
            if (k != null) return uri(k[0]);
            if (!create) throw new IOException(name + " not found");
            try {
                Uri made = DocumentsContract.createDocument(cr, uri(doc), "application/octet-stream", name);
                if (made == null) throw new IOException("can't create " + name);
                kids.put(name, new String[] {DocumentsContract.getDocumentId(made), "application/octet-stream", "0"});
                return made;
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException("can't create " + name + ": " + e.getMessage());
            }
        }

        @Override Chan open(String name, boolean write) throws IOException {
            return chan(fileUri(name, write), write ? "rw" : "r");
        }

        private Chan chan(Uri u, String mode) throws IOException {
            final ParcelFileDescriptor pfd = cr.openFileDescriptor(u, mode);
            if (pfd == null) throw new IOException("can't open " + u);
            final FileChannel in = new FileInputStream(pfd.getFileDescriptor()).getChannel();
            final FileChannel out = mode.startsWith("rw") ? new FileOutputStream(pfd.getFileDescriptor()).getChannel() : null;
            return new Chan() {
                public int read(long pos, byte[] b, int off, int len) throws IOException {
                    int n = in.read(ByteBuffer.wrap(b, off, len), pos);
                    return n < 0 ? -1 : n;
                }
                public void write(long pos, byte[] b, int off, int len) throws IOException {
                    ByteBuffer bb = ByteBuffer.wrap(b, off, len);
                    long p = pos;
                    while (bb.hasRemaining()) p += out.write(bb, p);
                }
                public void sync() throws IOException { pfd.getFileDescriptor().sync(); }
                public void close() { try { pfd.close(); } catch (IOException ignored) { } }
            };
        }

        @Override long usableSpace() {
            long now = System.currentTimeMillis();
            if (now - spaceAt < 5000) return space;
            ParcelFileDescriptor pfd = null;
            try {
                Uri u = fileUri(".space", true);
                pfd = cr.openFileDescriptor(u, "r");
                android.system.StructStatVfs st = android.system.Os.fstatvfs(pfd.getFileDescriptor());
                space = st.f_bavail * st.f_frsize;
                spaceAt = now;
            } catch (Throwable t) {
                space = 0;
            } finally {
                if (pfd != null) try { pfd.close(); } catch (IOException ignored) { }
            }
            return space;
        }

        @Override synchronized long bytes() {
            list();
            long n = 0;
            for (String[] k : kids.values()) {
                if (Document.MIME_TYPE_DIR.equals(k[1])) n += new SafDir(cr, tree, k[0]).bytes();
                else n += Long.parseLong(k[2]);
            }
            return n;
        }

        @Override synchronized void writeAtomic(String name, byte[] data) throws IOException {
            String tmpName = name + ".tmp";
            delete(tmpName);
            Uri tmp = fileUri(tmpName, true);
            Chan c = chan(tmp, "rwt");
            try {
                c.write(0, data, 0, data.length);
                c.sync();
            } finally {
                c.close();
            }
            delete(name);
            try {
                Uri renamed = DocumentsContract.renameDocument(cr, tmp, name);
                list();
                if (renamed == null) throw new IOException("rename failed");
            } catch (IOException e) {
                throw e;
            } catch (Exception e) {
                throw new IOException("rename failed: " + e.getMessage());
            }
        }

        private SafDir(ContentResolver cr, Uri tree, String doc) {
            this.cr = cr;
            this.tree = tree;
            this.doc = doc;
        }
    }
}
